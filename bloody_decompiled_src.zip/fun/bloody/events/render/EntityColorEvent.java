/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 */
package fun.bloody.events.render;

import fun.bloody.utils.client.managers.event.events.callables.EventCancellable;
import net.minecraft.class_1297;

public class EntityColorEvent
extends EventCancellable {
    private class_1297 entity;
    private int color;

    public class_1297 getEntity() {
        return this.entity;
    }

    public int getColor() {
        return this.color;
    }

    public void setEntity(class_1297 entity) {
        this.entity = entity;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public EntityColorEvent(class_1297 entity, int color) {
        this.entity = entity;
        this.color = color;
    }
}

