/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.events.render;

import fun.bloody.utils.client.managers.event.events.Event;

public class WorldLoadEvent
implements Event {
}

