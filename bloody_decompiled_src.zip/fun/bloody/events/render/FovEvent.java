/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.events.render;

import fun.bloody.utils.client.managers.event.events.callables.EventCancellable;

public class FovEvent
extends EventCancellable {
    private int fov;

    public int getFov() {
        return this.fov;
    }

    public void setFov(int fov) {
        this.fov = fov;
    }
}

