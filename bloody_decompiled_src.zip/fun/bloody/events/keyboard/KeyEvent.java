/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3675$class_307
 *  net.minecraft.class_437
 */
package fun.bloody.events.keyboard;

import fun.bloody.utils.client.managers.event.events.Event;
import fun.bloody.utils.display.interfaces.QuickImports;
import net.minecraft.class_3675;
import net.minecraft.class_437;

public record KeyEvent(class_437 screen, class_3675.class_307 type, int key, int action) implements Event,
QuickImports
{
    public boolean isKeyDown(int key) {
        return this.isKeyDown(key, KeyEvent.mc.field_1755 == null);
    }

    public boolean isKeyDown(int key, boolean screen) {
        return this.key == key && this.action == 1 && screen;
    }

    public boolean isKeyReleased(int key) {
        return this.isKeyReleased(key, KeyEvent.mc.field_1755 == null);
    }

    public boolean isKeyReleased(int key, boolean screen) {
        return this.key == key && this.action == 0 && screen;
    }
}

