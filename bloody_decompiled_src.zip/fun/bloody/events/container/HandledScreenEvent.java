/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1735
 *  net.minecraft.class_332
 */
package fun.bloody.events.container;

import fun.bloody.utils.client.managers.event.events.Event;
import net.minecraft.class_1735;
import net.minecraft.class_332;

public class HandledScreenEvent
implements Event {
    private class_332 drawContext;
    private class_1735 slotHover;
    private int backgroundWidth;
    private int backgroundHeight;

    public class_332 getDrawContext() {
        return this.drawContext;
    }

    public class_1735 getSlotHover() {
        return this.slotHover;
    }

    public int getBackgroundWidth() {
        return this.backgroundWidth;
    }

    public int getBackgroundHeight() {
        return this.backgroundHeight;
    }

    public HandledScreenEvent(class_332 drawContext, class_1735 slotHover, int backgroundWidth, int backgroundHeight) {
        this.drawContext = drawContext;
        this.slotHover = slotHover;
        this.backgroundWidth = backgroundWidth;
        this.backgroundHeight = backgroundHeight;
    }
}

