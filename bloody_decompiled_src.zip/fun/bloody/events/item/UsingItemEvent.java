/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.events.item;

import fun.bloody.utils.client.managers.event.events.callables.EventCancellable;

public class UsingItemEvent
extends EventCancellable {
    byte type;

    public byte getType() {
        return this.type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public UsingItemEvent(byte type) {
        this.type = type;
    }
}

