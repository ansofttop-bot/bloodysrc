/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.events.chat;

import fun.bloody.utils.client.managers.event.events.callables.EventCancellable;

public class TabCompleteEvent
extends EventCancellable {
    public final String prefix;
    public String[] completions;

    public TabCompleteEvent(String prefix) {
        this.prefix = prefix;
        this.completions = null;
    }
}

