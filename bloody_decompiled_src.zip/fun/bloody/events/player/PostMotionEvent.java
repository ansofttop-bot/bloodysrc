/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.events.player;

import fun.bloody.utils.client.managers.event.events.callables.EventCancellable;

public class PostMotionEvent
extends EventCancellable {
}

