/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 */
package fun.bloody.events.block;

import fun.bloody.utils.client.managers.event.events.Event;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public record BlockBreakingEvent(class_2338 blockPos, class_2350 direction) implements Event
{
}

