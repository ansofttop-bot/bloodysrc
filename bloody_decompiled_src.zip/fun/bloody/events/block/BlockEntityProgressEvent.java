/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2586
 */
package fun.bloody.events.block;

import fun.bloody.utils.client.managers.event.events.Event;
import net.minecraft.class_2586;

public record BlockEntityProgressEvent(class_2586 blockEntity, Type type) implements Event
{

    public static enum Type {
        ADD,
        REMOVE;

    }
}

