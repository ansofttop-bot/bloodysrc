/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 */
package fun.bloody.events.block;

import fun.bloody.utils.client.managers.event.events.Event;
import net.minecraft.class_2338;

public record BreakBlockEvent(class_2338 blockPos) implements Event
{
}

