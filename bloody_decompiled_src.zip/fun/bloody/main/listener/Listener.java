/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.main.listener;

import fun.bloody.utils.display.interfaces.QuickLogger;

public interface Listener
extends QuickLogger {
}

