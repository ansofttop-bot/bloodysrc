/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.main.listener;

import fun.bloody.Bloody;
import fun.bloody.main.listener.Listener;
import fun.bloody.main.listener.impl.EventListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListenerRepository {
    private final List<Listener> listeners = new ArrayList<Listener>();

    public void setup() {
        this.registerListeners(new EventListener());
    }

    public void registerListeners(Listener ... listeners) {
        this.listeners.addAll(List.of(listeners));
        Arrays.stream(listeners).forEach(listener -> Bloody.getInstance().getEventManager().register(listener));
    }

    public List<Listener> getListeners() {
        return this.listeners;
    }
}

