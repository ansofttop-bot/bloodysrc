/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.main;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class FontGenerator {
    public static final String CHARSET = "\"\\\" \u00a1\u2030\u00b7\u20b4\u2260\u00bf\u00d7\u00d8\u00f8\u0410\u0411\u0412\u0413\u0414\u0415\u0401\u0416\u0417\u0418\u0419\u041a\u041b\u041c\u041d\u041e\u041f\u0420\u0421\u0422\u0423\u0424\u0425\u0426\u0427\u0428\u0429\u042a\u042b\u042c\u042d\u042e\u042f\u0430\u0431\u0432\u0433\u0434\u0435\u0451\u0436\u0437\u0438\u0439\u043a\u043b\u043c\u043d\u043e\u043f\u0440\u0441\u0442\u0443\u0444\u0445\u0446\u0447\u0448\u0449\u044a\u044b\u044c\u044d\u044e\u044f\u0454\u2013\u2014\u2018\u2019\u201c\u201d\u201e\u2026\u2190\u2191\u2192\u2193\u02bb\u02cc\u037e\u2070\u00b9\u00b3\u2074\u2075\u2076\u2077\u2078\u2079\u207a\u207b\u207c\u207d\u207e\u2071\u2122\u0294\u0295\u00a4\u00a5\u00a9\u00ae\u00b5\u00b6\u00bc\u00bd\u00be\u0387\u2010\u201a\u2020\u2021\u2022\u2032\u2033\u2034\u2039\u203a\u203d\u2042\u2117\u2212\u221e\u0404\u2660\u2663\u2665\u2666\u266d\u266e\u266f\u2680\u2681\u2682\u2683\u2684\u2685\u02ac\u2744\u23cf\u23fb\u23fc\u23fd\u2b58\u25b2\u25b6\u25bc\u25c0\u25cf\u25e6\ufffd\u00a6\u1d00\u0299\u1d04\u1d05\u1d07\ua730\u0262\u029c\u1d0a\u1d0b\u029f\u1d0d\u0274\u1d0f\u1d18\ua7af\u0280\ua731\u1d1b\u1d1c\u1d20\u1d21\u028f\u1d22\u00a7\u02a1\u02a2\u0298\u01c0\u01c3\u01c2\u01c1\u2602\u2664\u2667\u2661\u2662\u2194\u2211\u25a1\u25b3\u25b7\u25bd\u25c1\u25cb\u2606\u2605\u2080\u2081\u2082\u2083\u2084\u2085\u2086\u2087\u2088\u2089\u208a\u208b\u208c\u208d\u208e\u222b\u2300\u2318\u26a0\u24ea\u2460\u2461\u2462\u2463\u2464\u2465\u2466\u2467\u2468\u2469\u246a\u246b\u246c\u246d\u246e\u246f\u2470\u2471\u2472\u2473\u24b6\u24b7\u24b8\u24b9\u24ba\u24bb\u24bc\u24bd\u24be\u24bf\u24c0\u24c1\u24c2\u24c3\u24c4\u24c5\u24c6\u24c7\u24c8\u24c9\u24ca\u24cb\u24cc\u24cd\u24ce\u24cf\u24d0\u24d1\u24d2\u24d3\u24d4\u24d5\u24d6\u24d7\u24d8\u24d9\u24da\u24db\u24dc\u24dd\u24de\u24df\u24e0\u24e1\u24e2\u24e3\u24e4\u24e5\u24e6\u24e7\u24e8\u24e9\u2611\u2612!#$%&'()*+,-./0123456789:;<=>[\\\\]^_`?@ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz{|}~\u00a3\u0192\u00aa\u00ba\u00ac\u00ab\u00bb\u2261\u00b1\u2265\u2264\u2320\u2321\u00f7\u2248\u00b0\u2219\u221a\u207f\u00b2\u25a0\"";

    public static void main(String[] args2) {
        String fontFolderPath = "mtsdf-font/";
        Path outputPath = FontGenerator.initFile(fontFolderPath);
        if (outputPath == null) {
            // empty if block
        }
        FontGenerator.generate(fontFolderPath, outputPath, "iconmain");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void generate(String fontFolderPath, Path outputPath, String fontPath) {
        File fontFolder = new File(fontFolderPath + fontPath);
        File[] fontFiles = fontFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(".ttf"));
        if (fontFiles != null && fontFiles.length > 0) {
            ExecutorService executor = Executors.newFixedThreadPool(fontFiles.length);
            ArrayList processes = new ArrayList();
            for (File fontFile : fontFiles) {
                executor.execute(() -> {
                    try {
                        String fontFileName = fontFile.getName().replaceFirst("[.][^.]+$", "");
                        String command = String.format("%s/atlas-gen.exe -font %s -charset %s/charset.txt -type mtsdf -format png -imageout %s.png -json %s.json -size 64 -square4 -pxrange 12", fontFolderPath, fontFile.getAbsolutePath(), fontFolderPath, outputPath.resolve(fontFileName.toLowerCase().replaceAll("-", "_")), outputPath.resolve(fontFileName.toLowerCase().replaceAll("-", "_")));
                        Process process = Runtime.getRuntime().exec(command);
                        processes.add(process);
                        int exitCode = process.waitFor();
                        if (exitCode != 0) return;
                    }
                    catch (IOException | InterruptedException exception) {
                        // empty catch block
                    }
                });
            }
            executor.shutdown();
            try {
                if (!executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS)) {
                    // empty if block
                }
            }
            catch (InterruptedException interruptedException) {
                // empty catch block
            }
            for (Process process : processes) {
                process.destroy();
            }
        }
    }

    private static Path initFile(String fontFolderPath) {
        Path charsetPath;
        Path outputPath = Path.of(fontFolderPath + "out", new String[0]);
        if (Files.notExists(outputPath, new LinkOption[0])) {
            try {
                Files.createDirectories(outputPath, new FileAttribute[0]);
            }
            catch (IOException e) {
                return null;
            }
        }
        if (Files.notExists(charsetPath = Path.of(fontFolderPath + "charset.txt", new String[0]), new LinkOption[0])) {
            try {
                Files.createFile(charsetPath, new FileAttribute[0]);
                Files.write(charsetPath, CHARSET.getBytes(), new OpenOption[0]);
            }
            catch (IOException e) {
                return null;
            }
        }
        return outputPath;
    }
}

