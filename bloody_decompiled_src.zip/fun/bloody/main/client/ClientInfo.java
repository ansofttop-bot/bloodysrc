/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.main.client;

import fun.bloody.main.client.ClientInfoProvider;
import fun.bloody.utils.client.chat.StringHelper;
import java.io.File;

public record ClientInfo(String clientName, String userName, String role, File clientDir, File filesDir) implements ClientInfoProvider
{
    @Override
    public String getFullInfo() {
        return String.format("Welcome! Client: %s Version: %s Branch: %s", this.clientName, "Baflllik && HZeed", StringHelper.getUserRole());
    }

    @Override
    public File configsDir() {
        return this.clientDir;
    }
}

