/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2761
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.connection.tps;

import fun.bloody.Bloody;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.utils.client.managers.event.EventHandler;
import net.minecraft.class_2761;
import net.minecraft.class_3532;

public class TPSCalculate {
    private float TPS = 20.0f;
    private float adjustTicks = 0.0f;
    private long timestamp;

    public TPSCalculate() {
        Bloody.getInstance().getEventManager().register(this);
    }

    @EventHandler
    private void onPacket(PacketEvent e) {
        if (e.getPacket() instanceof class_2761) {
            this.updateTPS();
        }
    }

    private void updateTPS() {
        long delay = System.nanoTime() - this.timestamp;
        float maxTPS = 20.0f;
        float rawTPS = maxTPS * (1.0E9f / (float)delay);
        float boundedTPS = class_3532.method_15363((float)rawTPS, (float)0.0f, (float)maxTPS);
        this.TPS = (float)this.round(boundedTPS);
        this.adjustTicks = boundedTPS - maxTPS;
        this.timestamp = System.nanoTime();
    }

    public double round(double input) {
        return (double)Math.round(input * 100.0) / 100.0;
    }

    public float getTPS() {
        return this.TPS;
    }

    public float getAdjustTicks() {
        return this.adjustTicks;
    }

    public long getTimestamp() {
        return this.timestamp;
    }
}

