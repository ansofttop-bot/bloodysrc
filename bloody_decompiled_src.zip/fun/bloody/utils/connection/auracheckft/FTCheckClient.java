/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  net.minecraft.class_2561
 *  net.minecraft.class_310
 *  net.minecraft.class_5250
 */
package fun.bloody.utils.connection.auracheckft;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fun.bloody.utils.client.chat.ChatMessage;
import java.net.URI;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

public class FTCheckClient
extends WebSocketClient {
    private JsonObject config = new JsonObject();
    private long lastWarningTime = 0L;
    private static final long WARNING_INTERVAL = 5000L;
    private boolean connected = false;

    public FTCheckClient(URI serverUri) {
        super(serverUri);
        this.setConnectionLostTimeout(10);
    }

    @Override
    public void onOpen(ServerHandshake handshake) {
        this.connected = true;
        try {
            this.send("{\"type\":\"getConfig\"}");
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Override
    public void onMessage(String message) {
        try {
            JsonObject data = JsonParser.parseString((String)message).getAsJsonObject();
            if (data.has("type") && data.get("type").getAsString().equals("config")) {
                this.config = data.getAsJsonObject("data");
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        this.connected = false;
    }

    @Override
    public void onError(Exception ex) {
        this.connected = false;
    }

    public boolean isConnected() {
        return this.connected && this.isOpen();
    }

    public boolean isFtFixed() {
        if (!this.isConnected()) {
            return false;
        }
        try {
            return this.config.has("ftfixed") && this.config.get("ftfixed").getAsBoolean();
        }
        catch (Exception e) {
            return false;
        }
    }

    public void checkAndWarnFunTime() {
        if (!this.isConnected()) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return;
        }
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastWarningTime < 5000L) {
            return;
        }
        try {
            if (this.isFtFixed()) {
                class_5250 prefix = ChatMessage.brandmessage();
                class_5250 message = class_2561.method_43470((String)" \u00bb Funtime \u0438\u0441\u043f\u0440\u0430\u0432\u0438\u043b \u041a\u0438\u043b\u043b\u0430\u0443\u0440\u0443. \u041d\u0435 \u0438\u0433\u0440\u0430\u0439\u0442\u0435 \u0441 \u043d\u0435\u0439, \u0438\u043d\u0430\u0447\u0435 \u0432\u0430\u0441 \u0437\u0430\u0431\u0430\u043d\u044f\u0442! \u041c\u044b \u0443\u0436\u0435 \u0443\u0441\u0435\u0440\u0434\u043d\u043e \u0434\u0435\u043b\u0430\u0435\u043c \u043d\u043e\u0432\u0443\u044e \u2014 \u043e\u0436\u0438\u0434\u0430\u0439\u0442\u0435.");
                mc.field_1724.method_7353((class_2561)prefix.method_27661().method_10852((class_2561)message), false);
                this.lastWarningTime = currentTime;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}

