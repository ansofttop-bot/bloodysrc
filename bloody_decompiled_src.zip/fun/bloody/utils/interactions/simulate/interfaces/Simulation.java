/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 */
package fun.bloody.utils.interactions.simulate.interfaces;

import net.minecraft.class_243;

public interface Simulation {
    public class_243 pos();

    public void tick();
}

