/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_304
 *  net.minecraft.class_3675
 *  net.minecraft.class_463
 *  net.minecraft.class_471
 *  net.minecraft.class_497
 *  net.minecraft.class_498
 */
package fun.bloody.utils.interactions.inv;

import fun.bloody.display.screens.clickgui.MenuScreen;
import fun.bloody.events.player.InputEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.packet.network.Network;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.TurnsConfig;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.interactions.inv.InventoryTask;
import fun.bloody.utils.interactions.simulate.Simulations;
import fun.bloody.utils.math.script.Script;
import fun.bloody.utils.math.task.TaskPriority;
import java.util.List;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_463;
import net.minecraft.class_471;
import net.minecraft.class_497;
import net.minecraft.class_498;

public final class InventoryFlowManager
implements QuickImports {
    public static final List<class_304> moveKeys = List.of(InventoryFlowManager.mc.field_1690.field_1894, InventoryFlowManager.mc.field_1690.field_1881, InventoryFlowManager.mc.field_1690.field_1913, InventoryFlowManager.mc.field_1690.field_1849, InventoryFlowManager.mc.field_1690.field_1903);
    public static final Script script = new Script();
    public static final Script postScript = new Script();
    public static boolean canMove = true;

    public static void tick() {
        script.update();
    }

    public static void postMotion() {
        postScript.update();
    }

    public static void input(InputEvent e) {
        if (!canMove) {
            e.inputNone();
        }
    }

    public static void addTask(Runnable task) {
        if (script.isFinished() && Simulations.hasPlayerMovement()) {
            switch (Network.server) {
                case "FunTime": {
                    script.cleanup().addTickStep(0, () -> {
                        InventoryFlowManager.disableMoveKeys();
                        InventoryFlowManager.rotateToCamera();
                    }).addTickStep(1, () -> {
                        task.run();
                        InventoryFlowManager.enableMoveKeys();
                    });
                    return;
                }
                case "ReallyWorld": {
                    if (!InventoryFlowManager.mc.field_1724.method_24828()) break;
                    script.cleanup().addTickStep(0, InventoryFlowManager::disableMoveKeys).addTickStep(2, InventoryFlowManager::rotateToCamera).addTickStep(3, task::run).addTickStep(4, InventoryFlowManager::enableMoveKeys);
                    return;
                }
                case "SpookyTime": 
                case "CopyTime": {
                    script.cleanup().addTickStep(0, () -> {
                        InventoryFlowManager.disableMoveKeys();
                        InventoryFlowManager.rotateToCamera();
                    }).addTickStep(1, task::run).addTickStep(2, InventoryFlowManager::enableMoveKeys);
                    return;
                }
            }
        }
        script.addTickStep(0, InventoryFlowManager::rotateToCamera);
        postScript.cleanup().addTickStep(0, () -> {
            task.run();
            InventoryTask.closeScreen(true);
        });
    }

    private static void rotateToCamera() {
        Module module = new Module("InventoryComponent", "Inventory Component", ModuleCategory.PLAYER);
        module.state = true;
        TurnsConnection.INSTANCE.rotateTo(MathAngle.cameraAngle(), TurnsConfig.DEFAULT, TaskPriority.HIGH_IMPORTANCE_3, module);
    }

    public static void disableMoveKeys() {
        canMove = false;
        InventoryFlowManager.unPressMoveKeys();
    }

    public static void enableMoveKeys() {
        InventoryTask.closeScreen(true);
        canMove = true;
        InventoryFlowManager.updateMoveKeys();
    }

    public static void unPressMoveKeys() {
        moveKeys.forEach(keyBinding -> keyBinding.method_23481(false));
    }

    public static void updateMoveKeys() {
        moveKeys.forEach(keyBinding -> keyBinding.method_23481(class_3675.method_15987((long)mc.method_22683().method_4490(), (int)keyBinding.method_1429().method_1444())));
    }

    public static boolean shouldSkipExecution() {
        return InventoryFlowManager.mc.field_1755 != null && !PlayerInteractionHelper.isChat(InventoryFlowManager.mc.field_1755) && !(InventoryFlowManager.mc.field_1755 instanceof class_498) && !(InventoryFlowManager.mc.field_1755 instanceof class_471) && !(InventoryFlowManager.mc.field_1755 instanceof class_463) && !(InventoryFlowManager.mc.field_1755 instanceof class_497) && !(InventoryFlowManager.mc.field_1755 instanceof MenuScreen);
    }

    private InventoryFlowManager() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

