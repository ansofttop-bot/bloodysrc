/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_2338
 *  net.minecraft.class_2374
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 *  net.minecraft.class_4184
 *  net.minecraft.class_4604
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Vector3f
 *  org.joml.Vector4d
 *  org.joml.Vector4f
 *  org.lwjgl.opengl.GL11
 */
package fun.bloody.utils.math.projection;

import fun.bloody.utils.display.geometry.Render3D;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.math.calc.Calculate;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4d;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

public final class Projection
implements QuickImports {
    @NotNull
    public static class_243 worldSpaceToScreenSpace(class_243 pos) {
        Vector3f delta = pos.method_46409();
        int[] viewport = new int[4];
        GL11.glGetIntegerv((int)2978, (int[])viewport);
        Vector3f target = new Vector3f();
        Vector4f transformedCoordinates = new Vector4f(delta.x, delta.y, delta.z, 1.0f).mul((Matrix4fc)Render3D.lastWorldSpaceMatrix.method_23761());
        Matrix4f matrixProj = new Matrix4f((Matrix4fc)Render3D.lastProjMat);
        matrixProj.project(transformedCoordinates.x(), transformedCoordinates.y(), transformedCoordinates.z(), viewport, target);
        return new class_243((double)target.x / mc.method_22683().method_4495(), (double)((float)mc.method_22683().method_4507() - target.y) / mc.method_22683().method_4495(), (double)target.z);
    }

    public static double getDistanceToGround() {
        for (double y = Projection.mc.field_1724.method_23318(); y > 0.0; y -= 0.1) {
            if (Projection.mc.field_1687.method_8320(Projection.mc.field_1724.method_24515().method_10087((int)(Projection.mc.field_1724.method_23318() - y + 1.0))).method_26215()) continue;
            return Projection.mc.field_1724.method_23318() - y;
        }
        return 256.0;
    }

    public static Vector4d getVector4D(class_1297 ent) {
        Vector4d position = null;
        if (ent != null) {
            for (class_243 vector : Projection.getVec3ds(ent, Calculate.interpolate(ent))) {
                vector = Projection.worldSpaceToScreenSpace(new class_243(vector.field_1352, vector.field_1351, vector.field_1350));
                if (!(vector.field_1350 > 0.0) || !(vector.field_1350 < 1.0)) continue;
                if (position == null) {
                    position = new Vector4d(vector.field_1352, vector.field_1351, vector.field_1350, 0.0);
                }
                position.x = Math.min(vector.field_1352, position.x);
                position.y = Math.min(vector.field_1351, position.y);
                position.z = Math.max(vector.field_1352, position.z);
                position.w = Math.max(vector.field_1351, position.w);
            }
        }
        return position;
    }

    @NotNull
    public static class_243[] getVec3ds(class_1297 ent, class_243 pos) {
        class_238 axisAlignedBB2 = ent.method_5829();
        class_238 axisAlignedBB = new class_238(axisAlignedBB2.field_1323 - ent.method_23317() + pos.field_1352 - (double)0.1f, axisAlignedBB2.field_1322 - ent.method_23318() + pos.field_1351 - (double)0.1f, axisAlignedBB2.field_1321 - ent.method_23321() + pos.field_1350 - (double)0.1f, axisAlignedBB2.field_1320 - ent.method_23317() + pos.field_1352 + (double)0.1f, axisAlignedBB2.field_1325 - ent.method_23318() + pos.field_1351 + (double)0.1f, axisAlignedBB2.field_1324 - ent.method_23321() + pos.field_1350 + (double)0.1f);
        return new class_243[]{new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1322, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1325, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1322, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1325, axisAlignedBB.field_1321), new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1322, axisAlignedBB.field_1324), new class_243(axisAlignedBB.field_1323, axisAlignedBB.field_1325, axisAlignedBB.field_1324), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1322, axisAlignedBB.field_1324), new class_243(axisAlignedBB.field_1320, axisAlignedBB.field_1325, axisAlignedBB.field_1324)};
    }

    public static boolean canSee(class_243 vec3d) {
        class_4184 camera = Projection.mc.method_1561().field_4686;
        Turns angle = MathAngle.fromVec3d(vec3d.method_1020(camera.method_19326()));
        return Math.abs(class_3532.method_15393((float)(angle.getYaw() - camera.method_19330()))) < 90.0f && Math.abs(class_3532.method_15393((float)(angle.getPitch() - camera.method_19329()))) < 60.0f || Projection.canSee(new class_238(class_2338.method_49638((class_2374)vec3d)));
    }

    public static boolean canSee(class_238 box) {
        class_4604 frustum = Projection.mc.field_1769.field_27740;
        return box != null && frustum != null && frustum.method_23093(box);
    }

    public static boolean cantSee(Vector4d vec) {
        return vec == null || vec.x < 0.0 && vec.z < 1.0 || vec.y < 0.0 && vec.w < 1.0;
    }

    public static double centerX(Vector4d vec) {
        return vec.x + (vec.z - vec.x) / 2.0;
    }

    private Projection() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

