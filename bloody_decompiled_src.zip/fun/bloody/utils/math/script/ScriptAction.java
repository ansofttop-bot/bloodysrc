/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.math.script;

@FunctionalInterface
public interface ScriptAction {
    public void perform();
}

