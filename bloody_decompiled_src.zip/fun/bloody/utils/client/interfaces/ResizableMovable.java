/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.client.interfaces;

public interface ResizableMovable {
    public ResizableMovable position(float var1, float var2);

    public ResizableMovable size(float var1, float var2);
}

