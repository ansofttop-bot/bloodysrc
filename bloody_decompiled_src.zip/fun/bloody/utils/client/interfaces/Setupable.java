/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.client.interfaces;

import fun.bloody.features.module.setting.Setting;

public interface Setupable {
    public void setup(Setting ... var1);
}

