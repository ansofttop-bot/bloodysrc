/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1657
 *  net.minecraft.class_2378
 *  net.minecraft.class_2960
 *  net.minecraft.class_3414
 *  net.minecraft.class_3419
 *  net.minecraft.class_7923
 */
package fun.bloody.utils.client.sound;

import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import net.minecraft.class_1657;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7923;

public final class SoundManager
implements QuickImports {
    public static class_3414 OPEN_GUI = class_3414.method_47908((class_2960)class_2960.method_60654((String)"minecraft:gui_open"));
    public static class_3414 CLOSE_GUI = class_3414.method_47908((class_2960)class_2960.method_60654((String)"minecraft:gui_close"));
    public static class_3414 ENABLE_MODULE = class_3414.method_47908((class_2960)class_2960.method_60654((String)"minecraft:module_enable"));
    public static class_3414 DISABLE_MODULE = class_3414.method_47908((class_2960)class_2960.method_60654((String)"minecraft:module_disable"));
    public static class_3414 CATEGORY_CLICK = class_3414.method_47908((class_2960)class_2960.method_60654((String)"minecraft:guicategory_select"));
    public static class_3414 ORTHODOX = class_3414.method_47908((class_2960)class_2960.method_60654((String)"minecraft:kolokolnia_kill"));

    public static void init() {
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)OPEN_GUI.comp_3319(), (Object)OPEN_GUI);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)CLOSE_GUI.comp_3319(), (Object)CLOSE_GUI);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)ENABLE_MODULE.comp_3319(), (Object)ENABLE_MODULE);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)DISABLE_MODULE.comp_3319(), (Object)DISABLE_MODULE);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)CATEGORY_CLICK.comp_3319(), (Object)CATEGORY_CLICK);
        class_2378.method_10230((class_2378)class_7923.field_41172, (class_2960)ORTHODOX.comp_3319(), (Object)ORTHODOX);
    }

    public static void playSound(class_3414 sound) {
        SoundManager.playSound(sound, 1.0f, 1.0f);
    }

    public static void playSound(class_3414 sound, float volume, float pitch) {
        if (!PlayerInteractionHelper.nullCheck()) {
            SoundManager.mc.field_1687.method_8396((class_1657)SoundManager.mc.field_1724, SoundManager.mc.field_1724.method_24515(), sound, class_3419.field_15245, volume, pitch);
        }
    }

    private SoundManager() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

