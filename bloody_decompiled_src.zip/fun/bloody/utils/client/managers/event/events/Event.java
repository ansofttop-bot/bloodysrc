/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.client.managers.event.events;

public interface Event {
}

