/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.client.managers.event.events;

import fun.bloody.utils.client.managers.event.events.Event;

public abstract class EventStoppable
implements Event {
    private boolean stopped;

    protected EventStoppable() {
    }

    public void stop() {
        this.stopped = true;
    }

    public boolean isStopped() {
        return this.stopped;
    }
}

