/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.client.managers.file.impl;

import fun.bloody.common.proxy.Config;
import fun.bloody.utils.client.managers.file.ClientFile;
import fun.bloody.utils.client.managers.file.exception.FileLoadException;
import fun.bloody.utils.client.managers.file.exception.FileSaveException;
import java.io.File;

public class ProxyFile
extends ClientFile {
    public ProxyFile() {
        super("Proxy/Proxyconfig");
    }

    @Override
    public void saveToFile(File path) throws FileSaveException {
        Config.saveConfig();
    }

    @Override
    public void loadFromFile(File path) throws FileLoadException {
        Config.loadConfig();
    }
}

