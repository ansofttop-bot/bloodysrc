/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonIOException
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  com.google.gson.JsonSyntaxException
 */
package fun.bloody.utils.client.managers.file.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleRepository;
import fun.bloody.features.module.setting.Setting;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.GroupSetting;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.features.module.setting.implement.TextSetting;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.client.managers.api.draggable.DraggableRepository;
import fun.bloody.utils.client.managers.file.ClientFile;
import fun.bloody.utils.client.managers.file.exception.FileLoadException;
import fun.bloody.utils.client.managers.file.exception.FileSaveException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ModuleFile
extends ClientFile {
    private final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final ModuleRepository moduleRepository;
    private final DraggableRepository draggableRepository;

    public ModuleFile(ModuleRepository moduleRepository, DraggableRepository draggableRepository) {
        super("AutoCfg");
        this.moduleRepository = moduleRepository;
        this.draggableRepository = draggableRepository;
    }

    @Override
    public void saveToFile(File path) throws FileSaveException {
        this.saveToFile(path, this.getName() + ".json");
    }

    @Override
    public void loadFromFile(File path) throws FileLoadException {
        this.loadFromFile(path, this.getName() + ".json");
    }

    @Override
    public void saveToFile(File path, String fileName) throws FileSaveException {
        JsonObject functionObject = this.createJsonObjectFromModules();
        File file = new File(path, fileName);
        this.writeJsonToFile(functionObject, file);
        super.saveToFile(path, fileName);
    }

    @Override
    public void loadFromFile(File path, String fileName) throws FileLoadException {
        File file = new File(path, fileName);
        JsonObject functionObject = this.readJsonFromFile(file);
        if (functionObject != null) {
            this.updateModulesFromJsonObject(functionObject);
        }
        super.loadFromFile(path, fileName);
    }

    private JsonObject createJsonObjectFromModules() {
        JsonObject functionObject = new JsonObject();
        for (Module module : this.moduleRepository.modules()) {
            JsonObject moduleObject = new JsonObject();
            moduleObject.addProperty("bind", (Number)module.getKey());
            if (module instanceof ClickGui) {
                moduleObject.addProperty("bindRemoved", Boolean.valueOf(module.getKey() == -1));
            }
            moduleObject.addProperty("state", Boolean.valueOf(module.isState()));
            module.settings().forEach(setting -> this.addSettingToJsonObject(moduleObject, (Setting)setting));
            functionObject.add(module.getName().toLowerCase(), (JsonElement)moduleObject);
        }
        for (AbstractDraggable draggable : this.draggableRepository.draggable()) {
            JsonObject draggableObject = new JsonObject();
            draggableObject.addProperty("posX", (Number)draggable.getX());
            draggableObject.addProperty("posY", (Number)draggable.getY());
            functionObject.add(draggable.getName().toLowerCase(), (JsonElement)draggableObject);
        }
        return functionObject;
    }

    private void addSettingToJsonObject(JsonObject moduleObject, Setting setting) {
        if (setting instanceof BooleanSetting) {
            BooleanSetting booleanSetting = (BooleanSetting)setting;
            moduleObject.addProperty(setting.getName(), Boolean.valueOf(booleanSetting.isValue()));
        }
        if (setting instanceof SliderSettings) {
            SliderSettings valueSetting = (SliderSettings)setting;
            moduleObject.addProperty(setting.getName(), (Number)Float.valueOf(valueSetting.getValue()));
        }
        if (setting instanceof ColorSetting) {
            ColorSetting colorSetting = (ColorSetting)setting;
            moduleObject.addProperty(setting.getName(), (Number)colorSetting.getColor());
        }
        if (setting instanceof BindSetting) {
            BindSetting bindSetting = (BindSetting)setting;
            moduleObject.addProperty(setting.getName(), (Number)bindSetting.getKey());
        }
        if (setting instanceof TextSetting) {
            TextSetting textSetting = (TextSetting)setting;
            moduleObject.addProperty(setting.getName(), textSetting.getText());
        }
        if (setting instanceof SelectSetting) {
            SelectSetting selectSetting = (SelectSetting)setting;
            moduleObject.addProperty(setting.getName(), selectSetting.getSelected());
        }
        if (setting instanceof MultiSelectSetting) {
            MultiSelectSetting multiSelectSetting = (MultiSelectSetting)setting;
            List<String> selected = multiSelectSetting.getSelected();
            String selectedAsString = String.join((CharSequence)",", selected);
            moduleObject.addProperty(setting.getName(), selectedAsString);
        }
        if (setting instanceof GroupSetting) {
            GroupSetting groupSetting = (GroupSetting)setting;
            JsonObject groupObject = new JsonObject();
            groupObject.addProperty("state", Boolean.valueOf(groupSetting.isValue()));
            for (Setting subSetting : groupSetting.getSubSettings()) {
                this.addSettingToJsonObject(groupObject, subSetting);
            }
            moduleObject.add(setting.getName(), (JsonElement)groupObject);
        }
    }

    private void writeJsonToFile(JsonObject functionObject, File file) throws FileSaveException {
        try (FileWriter writer = new FileWriter(file);){
            this.GSON.toJson((JsonElement)functionObject, (Appendable)writer);
        }
        catch (IOException e) {
            throw new FileSaveException("Failed to save module to file", e);
        }
    }

    private JsonObject readJsonFromFile(File file) throws FileLoadException {
        JsonObject jsonObject;
        FileReader reader = new FileReader(file);
        try {
            jsonObject = JsonParser.parseReader((Reader)reader).getAsJsonObject();
        }
        catch (Throwable throwable) {
            try {
                try {
                    reader.close();
                }
                catch (Throwable throwable2) {
                    throwable.addSuppressed(throwable2);
                }
                throw throwable;
            }
            catch (IOException e) {
                throw new FileLoadException("Failed to load module from file", e);
            }
            catch (JsonIOException | JsonSyntaxException e) {
                throw new FileLoadException("Failed to parse JSON from file", e);
            }
        }
        reader.close();
        return jsonObject;
    }

    private void updateModulesFromJsonObject(JsonObject functionObject) {
        for (Module module : this.moduleRepository.modules()) {
            JsonObject moduleObject = functionObject.getAsJsonObject(module.getName().toLowerCase());
            if (moduleObject == null) continue;
            if (moduleObject.has("bind") && moduleObject.has("state")) {
                int bind = this.normalizeBindKey(moduleObject.get("bind").getAsInt());
                if (module instanceof ClickGui && bind == -1 && !moduleObject.has("bindRemoved")) {
                    bind = 260;
                }
                module.setKey(bind);
                module.setState(moduleObject.get("state").getAsBoolean());
            }
            module.settings().forEach(setting -> this.updateSettingFromJsonObject(moduleObject, (Setting)setting));
        }
        for (AbstractDraggable draggable : this.draggableRepository.draggable()) {
            JsonObject draggableObject = functionObject.getAsJsonObject(draggable.getName().toLowerCase());
            if (draggableObject == null || !draggableObject.has("posX") || !draggableObject.has("posY")) continue;
            draggable.setX(draggableObject.get("posX").getAsInt());
            draggable.setY(draggableObject.get("posY").getAsInt());
        }
    }

    private void updateSettingFromJsonObject(JsonObject moduleObject, Setting setting) {
        JsonElement settingElement = moduleObject.get(setting.getName());
        if (settingElement == null || settingElement.isJsonNull()) {
            return;
        }
        if (setting instanceof BooleanSetting) {
            BooleanSetting booleanSetting = (BooleanSetting)setting;
            booleanSetting.setValue(settingElement.getAsBoolean());
        }
        if (setting instanceof SliderSettings) {
            SliderSettings valueSetting = (SliderSettings)setting;
            valueSetting.setValue(settingElement.getAsFloat());
        }
        if (setting instanceof ColorSetting) {
            ColorSetting colorSetting = (ColorSetting)setting;
            colorSetting.setColor(settingElement.getAsInt());
        }
        if (setting instanceof BindSetting) {
            BindSetting bindSetting = (BindSetting)setting;
            bindSetting.setKey(this.normalizeBindKey(settingElement.getAsInt()));
        }
        if (setting instanceof TextSetting) {
            TextSetting textSetting = (TextSetting)setting;
            textSetting.setText(settingElement.getAsString());
        }
        if (setting instanceof SelectSetting) {
            SelectSetting selectSetting = (SelectSetting)setting;
            selectSetting.setSelected(this.normalizeSelectValue(selectSetting, settingElement.getAsString()));
        }
        if (setting instanceof MultiSelectSetting) {
            MultiSelectSetting multiSelectSetting = (MultiSelectSetting)setting;
            String asString2 = settingElement.getAsString();
            ArrayList<String> selectedList = new ArrayList<String>(Arrays.asList(asString2.split(",")));
            selectedList.removeIf(s -> !multiSelectSetting.getList().contains(s));
            multiSelectSetting.setSelected(selectedList);
        }
        if (setting instanceof GroupSetting) {
            GroupSetting groupSetting = (GroupSetting)setting;
            JsonObject groupObject = settingElement.getAsJsonObject();
            if (groupObject.has("state")) {
                groupSetting.setValue(groupObject.get("state").getAsBoolean());
            }
            for (Setting subSetting : groupSetting.getSubSettings()) {
                this.updateSettingFromJsonObject(groupObject, subSetting);
            }
        }
    }

    private int normalizeBindKey(int key) {
        return key == 0 ? -1 : key;
    }

    private String normalizeSelectValue(SelectSetting setting, String value) {
        if ("Blur".equals(value) && setting.getList().contains("\u0411\u043b\u044e\u0440")) {
            return "\u0411\u043b\u044e\u0440";
        }
        return value;
    }
}

