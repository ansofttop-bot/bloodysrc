/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.client.managers.file;

import fun.bloody.Bloody;
import fun.bloody.utils.client.managers.file.ClientFile;
import fun.bloody.utils.client.managers.file.impl.BlockESPFile;
import fun.bloody.utils.client.managers.file.impl.EntityESPFile;
import fun.bloody.utils.client.managers.file.impl.FriendFile;
import fun.bloody.utils.client.managers.file.impl.MacroFile;
import fun.bloody.utils.client.managers.file.impl.ModuleFile;
import fun.bloody.utils.client.managers.file.impl.PrefixFile;
import fun.bloody.utils.client.managers.file.impl.ProxyFile;
import fun.bloody.utils.client.managers.file.impl.StaffFile;
import fun.bloody.utils.client.managers.file.impl.WayFile;
import java.util.ArrayList;
import java.util.List;

public class FileRepository {
    private final List<ClientFile> clientFiles = new ArrayList<ClientFile>();

    public void setup(Bloody main) {
        this.register(new ModuleFile(main.getModuleRepository(), main.getDraggableRepository()), new EntityESPFile(main.getBoxESPRepository()), new BlockESPFile(main.getBoxESPRepository()), new MacroFile(main.getMacroRepository()), new WayFile(main.getWayRepository()), new PrefixFile(), new FriendFile(), new StaffFile(), new ProxyFile());
    }

    public void register(ClientFile ... clientFIle) {
        this.clientFiles.addAll(List.of(clientFIle));
    }

    public List<ClientFile> getClientFiles() {
        return this.clientFiles;
    }
}

