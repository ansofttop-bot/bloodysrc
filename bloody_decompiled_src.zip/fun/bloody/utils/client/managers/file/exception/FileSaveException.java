/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.client.managers.file.exception;

import fun.bloody.utils.client.managers.file.exception.FileProcessingException;

public class FileSaveException
extends FileProcessingException {
    public FileSaveException(String message) {
        super(message);
    }

    public FileSaveException(String message, Throwable cause) {
        super(message, cause);
    }
}

