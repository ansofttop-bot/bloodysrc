/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_2561
 *  net.minecraft.class_2583
 *  net.minecraft.class_310
 *  net.minecraft.class_5250
 */
package fun.bloody.utils.client.chat;

import fun.bloody.features.impl.misc.Unhook;
import fun.bloody.utils.client.text.TextHelper;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public class ChatMessage {
    public static class_5250 brandmessage() {
        return (class_5250)TextHelper.applyPredefinedGradient("Bloody", "black_light_purple", true);
    }

    public static class_5250 blockesp() {
        return (class_5250)TextHelper.applyPredefinedGradient("Block Esp", "black_light_purple", true);
    }

    public static void brandmessage(String message) {
        if (Unhook.unhooked) {
            return;
        }
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("Bloody -> ", "black_light_purple", true);
            class_5250 formattedMessage = prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
            class_310.method_1551().field_1724.method_7353((class_2561)formattedMessage, false);
        }
    }

    public static void ancientmessage(String message) {
        if (Unhook.unhooked) {
            return;
        }
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("Ancient Xray -> ", "black_light_purple", true);
            class_5250 formattedMessage = prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
            class_310.method_1551().field_1724.method_7353((class_2561)formattedMessage, false);
        }
    }

    public static void helpmessage(String message) {
        if (Unhook.unhooked) {
            return;
        }
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("Help -> ", "black_light_purple", true);
            class_5250 formattedMessage = prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
            class_310.method_1551().field_1724.method_7353((class_2561)formattedMessage, false);
        }
    }

    public static void swapmessage(String message) {
        if (Unhook.unhooked) {
            return;
        }
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("AutoSwap -> ", "black_light_purple", true);
            class_5250 formattedMessage = prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
            class_310.method_1551().field_1724.method_7353((class_2561)formattedMessage, false);
        }
    }

    public static void ircmessage(String message) {
        if (Unhook.unhooked) {
            return;
        }
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("[IRC] ", "black_light_purple", true);
            class_5250 formattedMessage = prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
            class_310.method_1551().field_1724.method_7353((class_2561)formattedMessage, false);
        }
    }

    public static void ircmessageWithGreen(String message) {
        if (Unhook.unhooked) {
            return;
        }
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("[IRC] ", "black_light_purple", true);
            class_5250 formattedMessage = prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message).method_10862(class_2583.field_24360.method_10977(class_124.field_1060)));
            class_310.method_1551().field_1724.method_7353((class_2561)formattedMessage, false);
        }
    }

    public static void ircmessageWithRed(String message) {
        if (Unhook.unhooked) {
            return;
        }
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("[IRC] ", "black_light_purple", true);
            class_5250 formattedMessage = prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message).method_10862(class_2583.field_24360.method_10977(class_124.field_1061)));
            class_310.method_1551().field_1724.method_7353((class_2561)formattedMessage, false);
        }
    }

    public static class_2561 ircprefixDeveloper(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Developer ", "dark_red_bright_red", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixCurator(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("\u041a\u0443\u0440\u0430\u0442\u043e\u0440 ", "dark_red", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixYouTube(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("YouTube ", "red_white", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixPikmi(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("\u041f\u0438\u043a\u043c\u0438 ", "purple_bright_pink", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixLabuba(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("\u041b\u0430\u0431\u0443\u0431\u0430 ", "pink_dark_pink", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixZapen(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("\u0417\u0430\u043f\u0435\u043d ", "bright_red", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixBoost(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("\u0411\u0443\u0441\u0442 ", "dark_green_bright_green", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixRich(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("\u0420\u0438\u0447 ", "red_orange", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixPanda(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("\u041f\u0430\u043d\u0434\u0430 ", "white_black", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixSmiley(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("(\u25cf'\u25e1'\u25cf) ", "turquoise_blue", true);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixBibi(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("\u0411\u0438\u0431\u0438...! ", "cyan_orange_fade", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixBenena(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("\u0411\u044d\u043d\u0435\u043d\u0430 ", "yellow_cyan", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }

    public static class_2561 ircprefixBlyabuba(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("\u0411\u043b\u044f\u0431\u0443\u0431\u0430 ", "purple_red_fade", false);
        return prefix.method_27661().method_10852((class_2561)class_2561.method_43470((String)message));
    }
}

