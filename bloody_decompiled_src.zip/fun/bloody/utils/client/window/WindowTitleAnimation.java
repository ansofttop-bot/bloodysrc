/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.client.window;

import antidaunleak.api.UserProfile;

public class WindowTitleAnimation {
    private static final WindowTitleAnimation INSTANCE = new WindowTitleAnimation();
    private String currentTitle = "<User: " + UserProfile.getInstance().profile("username") + ">";
    private int animationTick = 0;
    private boolean isRemoving = true;
    private boolean isUserPhase = true;
    private int pauseTicks = 0;
    private final int delayTicks = 1;
    private final int pauseDuration = 100;
    private String overrideTitle = null;

    private WindowTitleAnimation() {
    }

    public static WindowTitleAnimation getInstance() {
        return INSTANCE;
    }

    public void updateTitle() {
        if (this.pauseTicks > 0) {
            --this.pauseTicks;
            return;
        }
        if (this.animationTick >= 1) {
            Object newTitle;
            String fullText;
            String string = fullText = this.isUserPhase ? "<User: " + UserProfile.getInstance().profile("username") + ">" : "<Uid: " + UserProfile.getInstance().profile("uid") + ">";
            if (this.isRemoving) {
                if (this.currentTitle.length() > 1) {
                    newTitle = this.currentTitle.substring(0, this.currentTitle.length() - 1);
                } else {
                    newTitle = "<";
                    this.isRemoving = false;
                }
            } else if (this.currentTitle.length() < fullText.length()) {
                newTitle = fullText.substring(0, this.currentTitle.length() + 1);
            } else {
                newTitle = fullText;
                this.isRemoving = true;
                this.isUserPhase = !this.isUserPhase;
                this.pauseTicks = 100;
            }
            this.currentTitle = newTitle;
            this.animationTick = 0;
        }
        ++this.animationTick;
    }

    public void setOverrideTitle(String title) {
        this.overrideTitle = title;
    }

    public String getCurrentTitle() {
        if (this.overrideTitle != null) {
            return this.overrideTitle;
        }
        return "Minecraft 1.21.4";
    }
}

