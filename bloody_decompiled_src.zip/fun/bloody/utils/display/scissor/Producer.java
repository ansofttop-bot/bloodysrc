/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.display.scissor;

public interface Producer<T> {
    public T create();
}

