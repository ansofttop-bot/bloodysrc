/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.display.color;

import fun.bloody.features.impl.render.CustomHUD;
import fun.bloody.features.impl.render.Hud;
import java.awt.Color;

public class HudColorHelper {
    public static Color getTargetHudBackground() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getTargetHudBackground();
        }
        return Hud.getInstance().getBackgroundColor();
    }

    public static Color getWatermarkBackground() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getWatermarkBackground();
        }
        return Hud.getInstance().getBackgroundColor();
    }

    public static Color getKeyBindsBackground() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getKeyBindsBackground();
        }
        return Hud.getInstance().getBackgroundColor();
    }

    public static Color getStaffBackground() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getStaffBackground();
        }
        return Hud.getInstance().getBackgroundColor();
    }

    public static Color getPotionsBackground() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getPotionsBackground();
        }
        return Hud.getInstance().getBackgroundColor();
    }

    public static Color getArrayListBackground() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getArrayListBackground();
        }
        return Hud.getInstance().getBackgroundColor();
    }

    public static int getTargetHudTextColor() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getTargetHudTextColor();
        }
        return Hud.getInstance().getTextColor();
    }

    public static int getWatermarkTextColor() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getWatermarkTextColor();
        }
        return Hud.getInstance().getTextColor();
    }

    public static int getKeyBindsTextColor() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getKeyBindsTextColor();
        }
        return Hud.getInstance().getTextColor();
    }

    public static int getStaffTextColor() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getStaffTextColor();
        }
        return Hud.getInstance().getTextColor();
    }

    public static int getPotionsTextColor() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getPotionsTextColor();
        }
        return Hud.getInstance().getTextColor();
    }

    public static int getArrayListTextColor() {
        CustomHUD customHUD = CustomHUD.getInstance();
        if (customHUD != null && customHUD.isState()) {
            return customHUD.getArrayListTextColor();
        }
        return Hud.getInstance().getTextColor();
    }
}

