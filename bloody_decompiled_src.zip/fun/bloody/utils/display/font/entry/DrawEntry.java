/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.display.font.entry;

import fun.bloody.utils.display.font.glyph.Glyph;

public record DrawEntry(float atX, float atY, int color, Glyph toDraw) {
}

