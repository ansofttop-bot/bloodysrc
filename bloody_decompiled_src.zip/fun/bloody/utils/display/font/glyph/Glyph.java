/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.display.font.glyph;

import fun.bloody.utils.display.font.glyph.GlyphMap;

public record Glyph(int u, int v, int width, int height, char value, GlyphMap owner) {
}

