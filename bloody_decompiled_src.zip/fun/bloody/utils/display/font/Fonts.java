/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.display.font;

import fun.bloody.Bloody;
import fun.bloody.utils.display.font.FontRenderer;
import java.awt.Font;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class Fonts {
    private static final Map<FontKey, FontRenderer> fontCache = new HashMap<FontKey, FontRenderer>();

    public static FontRenderer create(float size, String name) {
        FontRenderer fontRenderer;
        block9: {
            String path = "assets/minecraft/fonts/" + name + ".ttf";
            InputStream inputStream = Bloody.class.getClassLoader().getResourceAsStream(path);
            if (inputStream == null) {
                System.err.println("Warning: Font file not found: " + path + " - using default font");
                Font font = new Font("SansSerif", 0, (int)(size / 2.0f));
                return new FontRenderer(font, size / 2.0f);
            }
            InputStream stream = inputStream;
            try {
                Font font = Font.createFont(0, stream).deriveFont(size / 2.0f);
                fontRenderer = new FontRenderer(font, size / 2.0f);
                if (stream == null) break block9;
            }
            catch (Throwable throwable) {
                if (stream != null) {
                    try {
                        stream.close();
                    }
                    catch (Throwable throwable2) {
                        throwable.addSuppressed(throwable2);
                    }
                }
                throw throwable;
            }
            stream.close();
        }
        return fontRenderer;
    }

    public static void init() {
        for (Type type : Type.values()) {
            for (int size = 4; size <= 32; ++size) {
                fontCache.put(new FontKey(size, type), Fonts.create(size, type.getType()));
            }
        }
    }

    public static FontRenderer getSize(int size) {
        return Fonts.getSize(size, Type.INST);
    }

    public static FontRenderer getSize(int size, Type type) {
        return fontCache.computeIfAbsent(new FontKey(size, type), k -> Fonts.create(size, type.getType()));
    }

    public static enum Type {
        DEFAULT("sf_medium"),
        REGULAR("sf_regular"),
        SEMI("sf_semibold"),
        BOLD("sf_bold"),
        BOLDED("bold"),
        MANROPEEXTRABOLD("manropeextrabold"),
        MANROPEBOLD("manropebold"),
        RICHREGULAR("rich_regular"),
        ICONRICHREG("iconrichreg"),
        ICONRICHREGREG("iconrichreg"),
        ICONbloodyREG("iconrichreg"),
        INST("suisseintl"),
        ICONS("icons"),
        ICONSTYPENEW("icon2"),
        GUIICONS("guiicons"),
        DIVINE("divine"),
        DIVINE_ICONS("divine_icons"),
        ICONSCATEGORY("categoryicons");

        private final String type;

        public String getType() {
            return this.type;
        }

        private Type(String type) {
            this.type = type;
        }
    }

    private record FontKey(int size, Type type) {
    }
}

