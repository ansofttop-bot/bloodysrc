/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  it.unimi.dsi.fastutil.objects.Object2ObjectMap
 *  it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap
 *  it.unimi.dsi.fastutil.objects.ObjectArrayList
 *  it.unimi.dsi.fastutil.objects.ObjectList
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_124
 *  net.minecraft.class_2561
 *  net.minecraft.class_2583
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 *  org.apache.commons.lang3.mutable.MutableFloat
 *  org.apache.commons.lang3.mutable.MutableInt
 *  org.joml.Matrix4f
 */
package fun.bloody.utils.display.font;

import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.events.render.TextFactoryEvent;
import fun.bloody.utils.client.chat.StringHelper;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.entry.DrawEntry;
import fun.bloody.utils.display.font.glyph.Glyph;
import fun.bloody.utils.display.font.glyph.GlyphMap;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.math.calc.Calculate;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import java.awt.Color;
import java.awt.Font;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import org.apache.commons.lang3.mutable.MutableFloat;
import org.apache.commons.lang3.mutable.MutableInt;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;

public class FontRenderer
implements QuickImports {
    private final Object2ObjectMap<class_2960, ObjectList<DrawEntry>> GLYPH_PAGE_CACHE = new Object2ObjectOpenHashMap();
    private final ObjectList<GlyphMap> maps = new ObjectArrayList();
    private Font font;

    public FontRenderer(Font font, float sizePx) {
        this.init(font, sizePx);
    }

    private void init(Font font, float sizePx) {
        this.font = font.deriveFont(sizePx * 2.0f);
    }

    private GlyphMap generateMap(char from, char to) {
        GlyphMap glyphMap = new GlyphMap(from, to, this.font, FontRenderer.randomIdentifier(), 5);
        this.maps.add((Object)glyphMap);
        return glyphMap;
    }

    private Glyph locateGlyph(char glyph) {
        for (GlyphMap map : this.maps) {
            if (!map.contains(glyph)) continue;
            return map.getGlyph(glyph);
        }
        char base = (char)Calculate.floorNearestMulN(glyph, 128);
        return this.generateMap(base, (char)(base + 128)).getGlyph(glyph);
    }

    public void drawText(class_4587 matrix, class_2561 text, double x, double y) {
        StringBuilder sb = new StringBuilder();
        this.findStyle(sb, text);
        this.drawString(matrix, sb.toString(), x, y, ColorAssist.getText());
    }

    public void findStyle(StringBuilder sb, class_2561 component) {
        class_2583 style = component.method_10866();
        if (component.method_10855().isEmpty()) {
            if (style.method_10973() != null) {
                sb.append(ColorAssist.formatting(style.method_10973().method_27716()));
            }
            sb.append(component.getString()).append(class_124.field_1070);
        } else {
            component.method_36136(style).forEach(text -> this.findStyle(sb, (class_2561)text));
        }
    }

    public void drawStringWithScroll(class_4587 matrix, String text, double x, double y, float width, int color) {
        String separation = "  |  ";
        float textWidth = this.getStringWidth(text + separation);
        if (textWidth - width < 10.0f) {
            this.drawString(matrix, text, x, y, color);
            return;
        }
        this.drawString(matrix, text + separation + text, x - (double)Calculate.textScrolling(textWidth), y, color);
    }

    public void drawString(class_4587 matrix, String text, double x, double y, int color) {
        TextFactoryEvent event = new TextFactoryEvent(text);
        EventManager.callEvent(event);
        text = event.getText();
        char[] chars = text.toCharArray();
        float xOffset = 0.0f;
        float yOffset = 0.0f;
        int lineStart = 0;
        StringBuilder stringColor = new StringBuilder();
        boolean colorFormat = false;
        boolean textColor = false;
        int clr = color;
        for (int i = 0; i < chars.length; ++i) {
            char c = chars[i];
            if (c == '\u00a7') {
                colorFormat = true;
                continue;
            }
            if (colorFormat) {
                colorFormat = false;
                char c1 = Character.toUpperCase(c);
                if (ColorAssist.colorCodes.containsKey(c1)) {
                    clr = new Color(ColorAssist.colorCodes.get(c1)).getRGB();
                    continue;
                }
                if (c1 != 'R') continue;
                clr = color;
                continue;
            }
            if (c == '\u23cf') {
                if (textColor) {
                    clr = new Color(Integer.parseInt(stringColor.toString())).getRGB();
                    stringColor.setLength(0);
                }
                textColor = !textColor;
                continue;
            }
            if (textColor) {
                stringColor.append(c);
                continue;
            }
            if (c == '\n') {
                yOffset += this.getStringHeight(text.substring(lineStart, i)) - 2.0f;
                xOffset = 0.0f;
                lineStart = i + 1;
                continue;
            }
            Glyph glyph = this.locateGlyph(c);
            if (glyph == null) continue;
            if (glyph.value() != ' ') {
                class_2960 i1 = glyph.owner().bindToTexture;
                DrawEntry entry = new DrawEntry(xOffset, yOffset, clr, glyph);
                ((ObjectList)this.GLYPH_PAGE_CACHE.computeIfAbsent((Object)i1, integer -> new ObjectArrayList())).add((Object)entry);
            }
            xOffset += (float)glyph.width();
        }
        if (!this.GLYPH_PAGE_CACHE.isEmpty()) {
            this.drawGlyphs(matrix, x, y);
        }
        this.GLYPH_PAGE_CACHE.clear();
    }

    public void drawGradientString(class_4587 matrix, String text, double x, double y, int colorStart, int colorEnd) {
        TextFactoryEvent event = new TextFactoryEvent(text);
        EventManager.callEvent(event);
        text = event.getText();
        char[] chars = text.toCharArray();
        float xOffset = 0.0f;
        float yOffset = 0.0f;
        int lineStart = 0;
        int textLength = text.length();
        for (int i = 0; i < chars.length; ++i) {
            char c = chars[i];
            if (c == '\n') {
                yOffset += this.getStringHeight(text.substring(lineStart, i)) - 2.0f;
                xOffset = 0.0f;
                lineStart = i + 1;
                continue;
            }
            Glyph glyph = this.locateGlyph(c);
            if (glyph == null) continue;
            if (glyph.value() != ' ') {
                float t = (float)i / (float)(textLength - 1);
                int color = this.interpolateColor(colorStart, colorEnd, t);
                class_2960 i1 = glyph.owner().bindToTexture;
                DrawEntry entry = new DrawEntry(xOffset, yOffset, color, glyph);
                ((ObjectList)this.GLYPH_PAGE_CACHE.computeIfAbsent((Object)i1, integer -> new ObjectArrayList())).add((Object)entry);
            }
            xOffset += (float)glyph.width();
        }
        if (!this.GLYPH_PAGE_CACHE.isEmpty()) {
            this.drawGlyphs(matrix, x, y);
        }
        this.GLYPH_PAGE_CACHE.clear();
    }

    private void drawGlyphs(class_4587 matrix, double x, double y) {
        matrix.method_22903();
        matrix.method_22904(x, y - 3.0, 0.0);
        matrix.method_22905(0.5f, 0.5f, 1.0f);
        Matrix4f matrix4f = matrix.method_23760().method_23761();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        for (class_2960 identifier : this.GLYPH_PAGE_CACHE.keySet()) {
            RenderSystem.setShaderTexture((int)0, (class_2960)identifier);
            class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1575);
            for (DrawEntry drawEntry : (ObjectList)this.GLYPH_PAGE_CACHE.get((Object)identifier)) {
                float x1 = drawEntry.atX();
                float y1 = drawEntry.atY();
                Glyph glyph = drawEntry.toDraw();
                GlyphMap glyphMap = glyph.owner();
                float width = glyph.width();
                float height = glyph.height();
                float u1 = (float)glyph.u() / (float)glyphMap.width;
                float v1 = (float)glyph.v() / (float)glyphMap.height;
                float u2 = (float)(glyph.u() + glyph.width()) / (float)glyphMap.width;
                float v2 = (float)(glyph.v() + glyph.height()) / (float)glyphMap.height;
                int color = drawEntry.color();
                buffer.method_22918(matrix4f, x1 + 0.0f, y1 + height, 0.0f).method_22913(u1, v2).method_39415(color);
                buffer.method_22918(matrix4f, x1 + width, y1 + height, 0.0f).method_22913(u2, v2).method_39415(color);
                buffer.method_22918(matrix4f, x1 + width, y1 + 0.0f, 0.0f).method_22913(u2, v1).method_39415(color);
                buffer.method_22918(matrix4f, x1 + 0.0f, y1 + 0.0f, 0.0f).method_22913(u1, v1).method_39415(color);
            }
            class_286.method_43433((class_9801)buffer.method_60800());
        }
        RenderSystem.disableBlend();
        matrix.method_22909();
    }

    public void drawCenteredString(class_4587 stack, String s, double x, double y, int color) {
        this.drawString(stack, s, (int)(x - (double)(this.getStringWidth(s) / 2.0f)), (float)y, color);
    }

    public float getStringWidth(class_2561 text) {
        return text != null ? this.getStringWidth(text.getString()) : 0.0f;
    }

    public float getStringWidth(String text) {
        TextFactoryEvent event = new TextFactoryEvent(text);
        EventManager.callEvent(event);
        text = event.getText();
        float currentLine = 0.0f;
        float maxPreviousLines = 0.0f;
        boolean ignore = false;
        for (char c : text.toCharArray()) {
            if (ignore) {
                ignore = false;
                continue;
            }
            if (c == '\u00a7') {
                ignore = true;
                continue;
            }
            if (c == '\n') {
                maxPreviousLines = Math.max(currentLine, maxPreviousLines);
                currentLine = 0.0f;
                continue;
            }
            Glyph glyph = this.locateGlyph(c);
            currentLine += glyph == null ? 0.0f : (float)glyph.width();
        }
        return Math.max(currentLine, maxPreviousLines) / 2.0f;
    }

    public float getStringHeight(class_2561 text) {
        return this.getStringHeight(text.getString());
    }

    public float getStringHeight(String text) {
        float currentLine = 0.0f;
        float previous = 0.0f;
        for (char c : (text.isEmpty() ? " " : text).toCharArray()) {
            if (c == '\n') {
                currentLine = currentLine == 0.0f ? (float)this.locateGlyph(' ').height() : currentLine;
                previous += currentLine;
                currentLine = 0.0f;
                continue;
            }
            Glyph glyph = this.locateGlyph(c);
            currentLine = Math.max(glyph == null ? 0.0f : (float)glyph.height(), currentLine);
        }
        return currentLine + previous;
    }

    public String trimToWidth(String text, int maxWidth, boolean backwards) {
        return backwards ? this.trimToWidthBackwards(text, maxWidth) : this.trimToWidth(text, maxWidth);
    }

    public String trimToWidth(String text, int maxWidth) {
        return text.substring(0, this.getTrimmedLength(text, maxWidth));
    }

    private int getTrimmedLength(String text, int maxWidth) {
        WidthLimitingVisitor visitor = new WidthLimitingVisitor(maxWidth);
        this.visitForwards(text, visitor);
        return visitor.getLength();
    }

    public String trimToWidthBackwards(String text, int maxWidth) {
        MutableFloat widthLeft = new MutableFloat((float)maxWidth);
        MutableInt trimmedLength = new MutableInt(text.length());
        for (int i = text.length() - 1; i >= 0; --i) {
            char c = text.charAt(i);
            Glyph glyph = this.locateGlyph(c);
            if (glyph == null) continue;
            widthLeft.subtract((float)glyph.width());
            if (!(widthLeft.floatValue() < 0.0f)) continue;
            trimmedLength.setValue(i + 1);
            break;
        }
        return text.substring(trimmedLength.intValue());
    }

    private boolean visitForwards(String text, CharacterVisitor visitor) {
        int length = text.length();
        for (int i = 0; i < length; ++i) {
            char c = text.charAt(i);
            if (visitor.accept(i, c)) continue;
            return false;
        }
        return true;
    }

    private int interpolateColor(int colorStart, int colorEnd, float t) {
        float startAlpha = (float)(colorStart >> 24 & 0xFF) / 255.0f;
        float startRed = (float)(colorStart >> 16 & 0xFF) / 255.0f;
        float startGreen = (float)(colorStart >> 8 & 0xFF) / 255.0f;
        float startBlue = (float)(colorStart & 0xFF) / 255.0f;
        float endAlpha = (float)(colorEnd >> 24 & 0xFF) / 255.0f;
        float endRed = (float)(colorEnd >> 16 & 0xFF) / 255.0f;
        float endGreen = (float)(colorEnd >> 8 & 0xFF) / 255.0f;
        float endBlue = (float)(colorEnd & 0xFF) / 255.0f;
        float alpha = startAlpha + t * (endAlpha - startAlpha);
        float red = startRed + t * (endRed - startRed);
        float green = startGreen + t * (endGreen - startGreen);
        float blue = startBlue + t * (endBlue - startBlue);
        return (int)(alpha * 255.0f) << 24 | (int)(red * 255.0f) << 16 | (int)(green * 255.0f) << 8 | (int)(blue * 255.0f);
    }

    @Contract(value="-> new", pure=true)
    @NotNull
    public static class_2960 randomIdentifier() {
        return class_2960.method_60655((String)"rich", (String)("temp/" + StringHelper.randomString(32)));
    }

    @Contract(value="_ -> new", pure=true)
    public static int @NotNull [] RGBIntToRGB(int in) {
        int red = in >> 16 & 0xFF;
        int green = in >> 8 & 0xFF;
        int blue = in & 0xFF;
        return new int[]{red, green, blue};
    }

    public FontRenderer setFont(Font font) {
        this.font = font;
        return this;
    }

    public Font getFont() {
        return this.font;
    }

    private class WidthLimitingVisitor
    implements CharacterVisitor {
        private float widthLeft;
        private int length;

        public WidthLimitingVisitor(float maxWidth) {
            this.widthLeft = maxWidth;
        }

        @Override
        public boolean accept(int index, char c) {
            Glyph glyph = FontRenderer.this.locateGlyph(c);
            if (glyph != null) {
                this.widthLeft -= (float)glyph.width();
                if (this.widthLeft >= 0.0f) {
                    this.length = index + 1;
                    return true;
                }
            }
            return false;
        }

        public int getLength() {
            return this.length;
        }
    }

    @FunctionalInterface
    public static interface CharacterVisitor {
        public boolean accept(int var1, char var2);
    }
}

