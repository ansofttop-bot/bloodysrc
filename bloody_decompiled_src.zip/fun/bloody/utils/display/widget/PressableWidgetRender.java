/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 */
package fun.bloody.utils.display.widget;

import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.display.shape.ShapeProperties;
import java.awt.Color;
import net.minecraft.class_332;

public class PressableWidgetRender
implements QuickImports {
    private final Animation animation = new Decelerate().setMs(200).setValue(8.0);

    public static void render(class_332 context, int x, int y, int width, int height, boolean active, String text) {
        ShapeProperties animRect = ShapeProperties.create(context.method_51448(), (float)x + (float)(width - width) / 2.0f, (float)y + (float)(height - height) / 2.0f, width, height).round(4.0f).thickness(3.0f).outlineColor(new Color(150, 150, 150, 150).getRGB()).color(new Color(18, 19, 20, 125).getRGB(), new Color(0, 2, 5, 125).getRGB(), new Color(0, 2, 5, 125).getRGB(), new Color(18, 19, 20, 125).getRGB()).build();
        rectangle.render(animRect);
        if (text != null && !text.isEmpty() && Fonts.getSize(18, Fonts.Type.DEFAULT).getStringWidth(text) <= (float)width) {
            Fonts.getSize(18, Fonts.Type.DEFAULT).drawString(context.method_51448(), text, (float)x - Fonts.getSize(18, Fonts.Type.DEFAULT).getStringWidth(text) / 2.0f + (float)width / 2.0f, (float)y + 7.0f, new Color(255, 255, 255, 255).getRGB());
        }
    }
}

