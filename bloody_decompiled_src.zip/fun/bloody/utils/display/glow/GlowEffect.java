/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_4587
 */
package fun.bloody.utils.display.glow;

import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import java.awt.Color;
import net.minecraft.class_4587;

public class GlowEffect {
    public static void applyGlow(class_4587 matrix, float x, float y, float width, float height, Object blur) {
        GlowEffect.applyGlow(matrix, x, y, width, height, blur, 4.0f);
    }

    public static void applyGlow(class_4587 matrix, float x, float y, float width, float height, Object blur, float rounding) {
        if (!GlowEffect.isGlowEnabled()) {
            return;
        }
        long time = System.currentTimeMillis();
        float pulse = (float)Math.sin((double)time * 0.002) * 0.5f + 0.5f;
        int clientColor = ColorAssist.getClientColor();
        int whiteColor = Color.WHITE.getRGB();
        int blendColor1 = ColorAssist.interpolateColor(whiteColor, clientColor, 0.3f + pulse * 0.2f);
        int blendColor2 = ColorAssist.interpolateColor(clientColor, whiteColor, 0.4f + pulse * 0.3f);
        try {
            blur.getClass().getMethod("render", ShapeProperties.class).invoke(blur, ShapeProperties.create(matrix, x - 2.0f, y - 2.0f, width + 4.0f, height + 4.0f).round(rounding).softness(2.0f).thickness(3.0f).outlineColor(ColorAssist.multAlpha(blendColor1, 0.4f)).color(ColorAssist.multAlpha(blendColor1, 0.4f)).build());
            blur.getClass().getMethod("render", ShapeProperties.class).invoke(blur, ShapeProperties.create(matrix, x - 1.0f, y - 1.0f, width + 2.0f, height + 2.0f).round(rounding - 0.5f).softness(1.5f).thickness(2.0f).outlineColor(ColorAssist.multAlpha(blendColor2, 0.6f)).color(ColorAssist.multAlpha(blendColor2, 0.6f)).build());
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static boolean isGlowEnabled() {
        return false;
    }
}

