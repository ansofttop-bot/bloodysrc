/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.display.shape;

import fun.bloody.utils.display.shape.ShapeProperties;

public interface Shape {
    public void render(ShapeProperties var1);
}

