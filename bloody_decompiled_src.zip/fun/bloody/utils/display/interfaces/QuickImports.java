/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  net.minecraft.class_1041
 *  net.minecraft.class_289
 *  net.minecraft.class_310
 *  net.minecraft.class_9779
 */
package fun.bloody.utils.display.interfaces;

import com.google.gson.Gson;
import fun.bloody.display.screens.clickgui.components.implement.window.WindowManager;
import fun.bloody.utils.display.draw.DrawEngine;
import fun.bloody.utils.display.draw.DrawEngineImpl;
import fun.bloody.utils.display.interfaces.QuickLogger;
import fun.bloody.utils.display.shape.implement.Arc;
import fun.bloody.utils.display.shape.implement.Blur;
import fun.bloody.utils.display.shape.implement.Image;
import fun.bloody.utils.display.shape.implement.Rectangle;
import net.minecraft.class_1041;
import net.minecraft.class_289;
import net.minecraft.class_310;
import net.minecraft.class_9779;

public interface QuickImports
extends QuickLogger {
    public static final class_310 mc = class_310.method_1551();
    public static final class_9779 tickCounter = mc.method_61966();
    public static final class_1041 window = mc.method_22683();
    public static final class_289 tessellator = class_289.method_1348();
    public static final DrawEngine drawEngine = new DrawEngineImpl();
    public static final Rectangle rectangle = new Rectangle();
    public static final Blur blur = new Blur();
    public static final Arc arc = new Arc();
    public static final Image image = new Image();
    public static final Gson gson = new Gson();
    public static final WindowManager windowManager = new WindowManager();
}

