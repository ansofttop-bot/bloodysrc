/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_2561
 *  net.minecraft.class_5250
 */
package fun.bloody.utils.display.interfaces;

import fun.bloody.utils.client.chat.ChatMessage;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public interface QuickLogger {
    public static class_2561 getPrefix() {
        class_5250 text = ChatMessage.brandmessage();
        text.method_10862(text.method_10866().method_10977(class_124.field_1080));
        text.method_27693(" -> ");
        return text;
    }

    default public void logDirect(class_2561 ... components) {
    }

    default public void logDirect(String message, class_124 color) {
    }

    default public void logDirect(String message) {
    }
}

