/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1741
 *  net.minecraft.class_8051
 */
package fun.bloody.utils.display.interfaces;

import net.minecraft.class_1741;
import net.minecraft.class_8051;

public interface IArmorItem {
    public class_1741 zov_pidarok$getMaterial();

    public class_8051 zov_pidarok$getType();
}

