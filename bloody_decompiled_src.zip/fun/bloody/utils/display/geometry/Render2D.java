/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1058
 *  net.minecraft.class_1799
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 */
package fun.bloody.utils.display.geometry;

import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.display.item.ItemRender;
import fun.bloody.utils.display.shape.ShapeProperties;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1058;
import net.minecraft.class_1799;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

public final class Render2D
implements QuickImports {
    private static final List<Quad> QUAD = new ArrayList<Quad>();

    public static void onRender(class_332 context) {
        class_4587 matrix = context.method_51448();
        Matrix4f matrix4f = matrix.method_23760().method_23761();
        if (!QUAD.isEmpty()) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader((class_10156)class_10142.field_53876);
            class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);
            QUAD.forEach(quad -> drawEngine.quad(matrix4f, buffer, quad.x, quad.y, quad.width, quad.height, quad.color));
            class_286.method_43433((class_9801)buffer.method_60800());
            RenderSystem.disableBlend();
            QUAD.clear();
        }
    }

    public static void defaultDrawStack(class_332 context, class_1799 stack, float x, float y, boolean rect, boolean drawItemInSlot, float scale) {
        class_4587 matrix = context.method_51448();
        if (rect) {
            blur.render(ShapeProperties.create(matrix, x, y, 16.0f * scale + 2.0f, 16.0f * scale + 2.0f).round(2.0f).color(ColorAssist.HALF_BLACK).build());
        }
        matrix.method_22903();
        matrix.method_46416(x + 1.0f, y + 1.0f, 0.0f);
        matrix.method_22905(scale, scale, 1.0f);
        context.method_51427(stack, 0, 0);
        if (drawItemInSlot) {
            context.method_51431(Render2D.mc.field_1772, stack, 0, 0);
        }
        matrix.method_22909();
    }

    public static void drawStack(class_4587 matrix, class_1799 stack, float x, float y, boolean rect, float scale) {
        float posX = x + 1.0f;
        float posY = y + 1.0f;
        float padding = 1.0f;
        matrix.method_22903();
        matrix.method_46416(posX, posY, 0.0f);
        if (rect) {
            blur.render(ShapeProperties.create(matrix, -padding, -padding, 16.0f * scale + padding * 2.0f, 16.0f * scale + padding * 2.0f).round(1.5f).color(ColorAssist.HALF_BLACK).build());
        }
        matrix.method_22905(scale, scale, 1.0f);
        ItemRender.drawItem(matrix, stack, 0.0f, 0.0f, true, true);
        matrix.method_22909();
    }

    public static void drawTexture(class_332 context, class_2960 id, float x, float y, int size) {
        class_4587 matrix = context.method_51448();
        if (id != null) {
            matrix.method_22903();
            matrix.method_46416(x, y, 0.0f);
            matrix.method_22905((float)size, (float)size, 1.0f);
            RenderSystem.enableBlend();
            Render2D.drawTexture(matrix, id, 0, 0, 1.0f, 1.0f, size, size, size, size, size, size, -1);
            RenderSystem.disableBlend();
            matrix.method_46416(-x, -y, 0.0f);
            matrix.method_22909();
        }
    }

    public static Color applyOpacity(Color color, float opacity) {
        opacity = Math.min(1.0f, Math.max(0.0f, opacity));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * opacity));
    }

    public static int applyOpacity(int color_int, float opacity) {
        opacity = Math.min(1.0f, Math.max(0.0f, opacity));
        Color color = new Color(color_int);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * opacity)).getRGB();
    }

    public static void drawTexture(class_332 context, class_2960 id, float x, float y, float size, float round, int uvSize, int regionSize, int textureSize, int backgroundColor) {
        Render2D.drawTexture(context, id, x, y, size, round, uvSize, regionSize, textureSize, backgroundColor, -1);
    }

    public static void drawTexture(class_332 context, class_2960 id, float x, float y, float size, float round, int uvSize, int regionSize, int textureSize, int backgroundColor, int color) {
        class_4587 matrix = context.method_51448();
        rectangle.render(ShapeProperties.create(matrix, x, y, size, size).round(round).color(backgroundColor).build());
        if (id != null) {
            matrix.method_22903();
            matrix.method_46416(x, y, 0.0f);
            matrix.method_22905(size, size, 1.0f);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc((int)772, (int)773);
            Render2D.drawTexture(matrix, id, 0, 0, 1.0f, 1.0f, uvSize, uvSize, regionSize, regionSize, textureSize, textureSize, color);
            RenderSystem.disableBlend();
            matrix.method_46416(-x, -y, 0.0f);
            matrix.method_22909();
        }
    }

    public static void drawSprite(class_4587 matrix, class_1058 sprite, float x, float y, float width, int height) {
        if (width != 0.0f && height != 0) {
            Render2D.drawTexturedQuad(matrix, sprite.method_45852(), x, x + width, y, y + (float)height, sprite.method_4594(), sprite.method_4577(), sprite.method_4593(), sprite.method_4575(), -1);
        }
    }

    public static void drawSprite(class_4587 matrix, class_1058 sprite, float x, float y, float width, int height, int color) {
        if (width != 0.0f && height != 0) {
            Render2D.drawTexturedQuad(matrix, sprite.method_45852(), x, x + width, y, y + (float)height, sprite.method_4594(), sprite.method_4577(), sprite.method_4593(), sprite.method_4575(), color);
        }
    }

    public static void drawTexture(class_4587 matrix, class_2960 texture, int x, int y, float width, float height, float u, float v, int regionWidth, int regionHeight, int textureWidth, int textureHeight, int color) {
        Render2D.drawTexture(matrix, texture, x, (float)x + width, y, (float)y + height, 0.0f, regionWidth, regionHeight, u, v, textureWidth, textureHeight, color);
    }

    public static void drawTexture(class_4587 matrix, class_2960 texture, float x1, float x2, float y1, float y2, float z, int regionWidth, int regionHeight, float u, float v, int textureWidth, int textureHeight, int color) {
        Render2D.drawTexturedQuad(matrix, texture, x1, x2, y1, y2, (u + 0.0f) / (float)textureWidth, (u + (float)regionWidth) / (float)textureWidth, (v + 0.0f) / (float)textureHeight, (v + (float)regionHeight) / (float)textureHeight, color);
    }

    public static void drawTexturedQuad(class_4587 matrix, class_2960 texture, float x1, float x2, float y1, float y2, float u1, float u2, float v1, float v2, int color) {
        RenderSystem.setShaderTexture((int)0, (class_2960)texture);
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        Matrix4f matrix4f = matrix.method_23760().method_23761();
        buffer.method_22918(matrix4f, x1, y1, 0.0f).method_22913(u1, v1).method_39415(color);
        buffer.method_22918(matrix4f, x1, y2, 0.0f).method_22913(u1, v2).method_39415(color);
        buffer.method_22918(matrix4f, x2, y2, 0.0f).method_22913(u2, v2).method_39415(color);
        buffer.method_22918(matrix4f, x2, y1, 0.0f).method_22913(u2, v1).method_39415(color);
        class_286.method_43433((class_9801)buffer.method_60800());
    }

    public static void drawCircle(class_4587 matrix, float x, float y, float radius, int color) {
        int segments = 16;
        float angleStep = (float)(Math.PI * 2 / (double)segments);
        Matrix4f matrix4f = matrix.method_23760().method_23761();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        for (int i = 0; i < segments; ++i) {
            float angle1 = (float)i * angleStep;
            float angle2 = (float)(i + 1) * angleStep;
            float x1 = x + radius * (float)Math.cos(angle1);
            float y1 = y + radius * (float)Math.sin(angle1);
            float x2 = x + radius * (float)Math.cos(angle2);
            float y2 = y + radius * (float)Math.sin(angle2);
            buffer.method_22918(matrix4f, x, y, 0.0f).method_39415(color);
            buffer.method_22918(matrix4f, x1, y1, 0.0f).method_39415(color);
            buffer.method_22918(matrix4f, x2, y2, 0.0f).method_39415(color);
            buffer.method_22918(matrix4f, x, y, 0.0f).method_39415(color);
        }
        class_286.method_43433((class_9801)buffer.method_60800());
        RenderSystem.disableBlend();
    }

    public static void endBuilding(class_287 bb) {
        class_9801 builtBuffer = bb.method_60794();
        if (builtBuffer != null) {
            class_286.method_43433((class_9801)builtBuffer);
        }
    }

    public static void drawQuad(float x, float y, float width, float height, int color) {
        QUAD.add(new Quad(x, y, width, height, ColorAssist.multAlpha(color, RenderSystem.getShaderColor()[3])));
    }

    private Render2D() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public record Quad(float x, float y, float width, float height, int color) {
    }
}

