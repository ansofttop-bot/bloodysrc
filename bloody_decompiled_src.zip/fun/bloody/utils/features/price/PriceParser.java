/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_9323
 *  org.apache.commons.lang3.StringUtils
 */
package fun.bloody.utils.features.price;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1799;
import net.minecraft.class_9323;
import org.apache.commons.lang3.StringUtils;

public class PriceParser {
    private final Pattern funTimePricePattern = Pattern.compile("\\$(\\d+(?:\\s\\d{3})*(?:\\.\\d{2})?)");

    public int getPrice(class_1799 stack) {
        Matcher matcher;
        String customName;
        class_9323 tag = stack.method_57353();
        if (tag == null) {
            return -1;
        }
        String componentString = tag.toString();
        String price = StringUtils.substringBetween((String)componentString, (String)"literal{ $", (String)"}[style={color=green}]");
        if ((price == null || price.isEmpty()) && (customName = stack.method_7964().getString()) != null && (matcher = this.funTimePricePattern.matcher(customName)).find()) {
            price = matcher.group(1);
        }
        if (price == null || price.isEmpty()) {
            return -1;
        }
        try {
            price = price.replaceAll("[\\s,]", "");
            return Integer.parseInt(price);
        }
        catch (NumberFormatException e) {
            return -1;
        }
    }
}

