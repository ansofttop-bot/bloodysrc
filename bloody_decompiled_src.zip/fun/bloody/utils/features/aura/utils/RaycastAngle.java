/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1675
 *  net.minecraft.class_238
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 *  net.minecraft.class_3966
 *  net.minecraft.class_638
 *  net.minecraft.class_746
 */
package fun.bloody.utils.features.aura.utils;

import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.features.aura.striking.StrikerConstructor;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import java.util.Objects;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class RaycastAngle
implements QuickImports {
    public static class_3965 raycast(double range, Turns angle, boolean includeFluids) {
        return RaycastAngle.raycast(Objects.requireNonNull(RaycastAngle.mc.field_1724).method_5836(1.0f), range, angle, includeFluids);
    }

    public static class_3965 raycast(class_243 vec, double range, Turns angle, boolean includeFluids) {
        class_1297 entity = RaycastAngle.mc.field_1719;
        if (entity == null) {
            return null;
        }
        class_243 rotationVec = angle.toVector();
        class_243 end = vec.method_1031(rotationVec.field_1352 * range, rotationVec.field_1351 * range, rotationVec.field_1350 * range);
        class_638 world = RaycastAngle.mc.field_1687;
        if (world == null) {
            return null;
        }
        class_3959.class_242 fluidHandling = includeFluids ? class_3959.class_242.field_1347 : class_3959.class_242.field_1348;
        class_3959 context = new class_3959(vec, end, class_3959.class_3960.field_17559, fluidHandling, entity);
        return world.method_17742(context);
    }

    public static class_3965 raycast(class_243 start, class_243 end, class_3959.class_3960 shapeType) {
        return RaycastAngle.raycast(start, end, shapeType, (class_1297)RaycastAngle.mc.field_1724);
    }

    public static class_3965 raycast(class_243 start, class_243 end, class_3959.class_3960 shapeType, class_1297 entity) {
        return RaycastAngle.raycast(start, end, shapeType, class_3959.class_242.field_1348, entity);
    }

    public static class_3965 raycast(class_243 start, class_243 end, class_3959.class_3960 shapeType, class_3959.class_242 fluidHandling, class_1297 entity) {
        return RaycastAngle.mc.field_1687.method_17742(new class_3959(start, end, shapeType, fluidHandling, entity));
    }

    public static class_3966 raytraceEntity(double range, Turns angle, Predicate<class_1297> filter) {
        class_746 entity = RaycastAngle.mc.field_1724;
        if (entity == null) {
            return null;
        }
        class_243 cameraVec = entity.method_5836(1.0f);
        class_243 rotationVec = angle.toVector();
        class_243 vec3d3 = cameraVec.method_1031(rotationVec.field_1352 * range, rotationVec.field_1351 * range, rotationVec.field_1350 * range);
        class_238 box = entity.method_5829().method_18804(rotationVec.method_1021(range)).method_1009(1.0, 1.0, 1.0);
        return class_1675.method_18075((class_1297)entity, (class_243)cameraVec, (class_243)vec3d3, (class_238)box, e -> !e.method_7325() && filter.test((class_1297)e), (double)(range * range));
    }

    public static boolean rayTrace(StrikerConstructor.AttackPerpetratorConfigurable config) {
        boolean elytraMode;
        boolean bl = elytraMode = RaycastAngle.mc.field_1724.method_6128() && config.getTarget().method_6128();
        if (elytraMode) {
            return true;
        }
        return RaycastAngle.rayTrace(TurnsConnection.INSTANCE.getRotation().toVector(), config.getMaximumRange() - 0.25f, config.getBox());
    }

    public static boolean rayTrace(double range, class_238 box) {
        return RaycastAngle.rayTrace(TurnsConnection.INSTANCE.getRotation().toVector(), range - 0.25, box);
    }

    public static boolean rayTrace(class_243 clientVec, double range, class_238 box) {
        double distanceToTarget;
        double distanceToBlock;
        class_243 cameraVec = Objects.requireNonNull(RaycastAngle.mc.field_1724).method_33571();
        if (box.method_1006(cameraVec)) {
            return true;
        }
        class_243 targetCenter = box.method_1005();
        class_243 directionToTarget = targetCenter.method_1020(cameraVec).method_1029();
        class_243 rayEnd = cameraVec.method_1019(directionToTarget.method_1021(range));
        class_3965 blockHit = RaycastAngle.raycast(cameraVec, rayEnd, class_3959.class_3960.field_17558);
        if (blockHit != null && blockHit.method_17783() != class_239.class_240.field_1333 && (distanceToBlock = cameraVec.method_1022(blockHit.method_17784())) < (distanceToTarget = cameraVec.method_1022(targetCenter)) - 0.3) {
            class_243[] testPoints = new class_243[]{targetCenter, new class_243(box.field_1323, box.field_1322, box.field_1321), new class_243(box.field_1320, box.field_1322, box.field_1321), new class_243(box.field_1323, box.field_1325, box.field_1321), new class_243(box.field_1320, box.field_1325, box.field_1321), new class_243(box.field_1323, box.field_1322, box.field_1324), new class_243(box.field_1320, box.field_1322, box.field_1324), new class_243(box.field_1323, box.field_1325, box.field_1324), new class_243(box.field_1320, box.field_1325, box.field_1324)};
            int visiblePoints = 0;
            for (class_243 point : testPoints) {
                double distToPoint;
                class_3965 pointHit = RaycastAngle.raycast(cameraVec, point, class_3959.class_3960.field_17558);
                if (pointHit == null || pointHit.method_17783() == class_239.class_240.field_1333) {
                    ++visiblePoints;
                    continue;
                }
                double distToPointBlock = cameraVec.method_1022(pointHit.method_17784());
                if (!(distToPointBlock >= (distToPoint = cameraVec.method_1022(point)) - 0.1)) continue;
                ++visiblePoints;
            }
            if (visiblePoints < 3) {
                return false;
            }
        }
        return box.method_992(cameraVec, cameraVec.method_1019(clientVec.method_1021(range))).isPresent();
    }

    private RaycastAngle() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

