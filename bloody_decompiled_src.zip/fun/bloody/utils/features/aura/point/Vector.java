/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.features.aura.point;

import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.math.time.StopWatch;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class Vector {
    private static final Random random = new Random();
    private static final StopWatch pointTimer = new StopWatch();
    private static final StopWatch updateTimer = new StopWatch();
    private static List<class_243> cachedPoints = new ArrayList<class_243>();
    private static int currentPointIndex = 0;

    public static class_243 hitbox(class_1297 entity, float X, float Y, float Z, float WIDTH) {
        double wHalf = entity.method_17681() / WIDTH;
        double yExpand = class_3532.method_15350((double)(entity.method_23320() - entity.method_23318()), (double)0.0, (double)entity.method_17682());
        double xExpand = class_3532.method_15350((double)(QuickImports.mc.field_1724.method_23317() - entity.method_23317()), (double)(-wHalf), (double)wHalf);
        double zExpand = class_3532.method_15350((double)(QuickImports.mc.field_1724.method_23321() - entity.method_23321()), (double)(-wHalf), (double)wHalf);
        return new class_243(entity.method_23317() + xExpand / (double)X, entity.method_23318() + yExpand / (double)Y, entity.method_23321() + zExpand / (double)Z);
    }

    public static class_243 brain(class_1297 entity, float min, float max) {
        double normalizedDistance;
        double distance = QuickImports.mc.field_1724.method_19538().method_1022(entity.method_19538());
        double heightFactor = normalizedDistance = class_3532.method_15350((double)((distance - (double)min) / (double)(max - min)), (double)0.0, (double)1.0);
        double minHeight = 0.2;
        double maxHeight = 0.8;
        double targetHeight = minHeight + (maxHeight - minHeight) * heightFactor;
        double targetY = entity.method_23318() + (double)entity.method_17682() * targetHeight;
        return new class_243(entity.method_23317(), targetY, entity.method_23321());
    }

    public static class_243 custom(class_1297 entity, int pointCount, float switchDelay) {
        if (updateTimer.every(1000.0) || cachedPoints.isEmpty()) {
            Vector.generateRandomPoints(entity, pointCount);
            currentPointIndex = 0;
            pointTimer.reset();
        }
        if (pointTimer.finished(switchDelay)) {
            currentPointIndex = (currentPointIndex + 1) % cachedPoints.size();
            pointTimer.reset();
        }
        if (cachedPoints.isEmpty()) {
            return entity.method_19538();
        }
        return cachedPoints.get(currentPointIndex);
    }

    private static void generateRandomPoints(class_1297 entity, int pointCount) {
        cachedPoints.clear();
        double width = entity.method_17681();
        double height = entity.method_17682();
        class_243 entityPos = entity.method_19538();
        for (int i = 0; i < pointCount; ++i) {
            double x = entityPos.field_1352 + (random.nextDouble() - 0.5) * width;
            double y = entityPos.field_1351 + random.nextDouble() * height;
            double z = entityPos.field_1350 + (random.nextDouble() - 0.5) * width;
            cachedPoints.add(new class_243(x, y, z));
        }
    }

    public static List<class_243> getAllCachedPoints() {
        return new ArrayList<class_243>(cachedPoints);
    }

    public static int getCurrentPointIndex() {
        return currentPointIndex;
    }

    public static long getTimeSinceLastSwitch() {
        return pointTimer.elapsedTime();
    }

    public static void clearCache() {
        cachedPoints.clear();
        currentPointIndex = 0;
        pointTimer.reset();
        updateTimer.reset();
    }

    public static void forceUpdate(class_1297 entity, int pointCount) {
        Vector.generateRandomPoints(entity, pointCount);
        currentPointIndex = 0;
        pointTimer.reset();
        updateTimer.reset();
    }
}

