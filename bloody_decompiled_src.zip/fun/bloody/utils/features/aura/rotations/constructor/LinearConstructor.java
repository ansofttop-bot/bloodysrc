/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 */
package fun.bloody.utils.features.aura.rotations.constructor;

import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import net.minecraft.class_1297;
import net.minecraft.class_243;

public class LinearConstructor
extends RotateConstructor {
    public LinearConstructor() {
        super("Linear");
    }

    @Override
    public Turns limitAngleChange(Turns currentAngle, Turns targetAngle, class_243 vec3d, class_1297 entity) {
        Turns angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = angleDelta.getYaw();
        float pitchDelta = angleDelta.getPitch();
        float rotationDifference = (float)Math.hypot(yawDelta, pitchDelta);
        float straightLineYaw = Math.abs(yawDelta / rotationDifference) * 360.0f;
        float straightLinePitch = Math.abs(pitchDelta / rotationDifference) * 360.0f;
        float newYaw = currentAngle.getYaw() + Math.min(Math.max(yawDelta, -straightLineYaw), straightLineYaw);
        float newPitch = currentAngle.getPitch() + Math.min(Math.max(pitchDelta, -straightLinePitch), straightLinePitch);
        return new Turns(newYaw, newPitch);
    }

    @Override
    public class_243 randomValue() {
        return new class_243(0.0, 0.0, 0.0);
    }
}

