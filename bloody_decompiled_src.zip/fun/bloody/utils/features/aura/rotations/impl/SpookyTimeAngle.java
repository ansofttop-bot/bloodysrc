/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.features.aura.rotations.impl;

import fun.bloody.Bloody;
import fun.bloody.features.impl.combat.Aura;
import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.striking.StrikeManager;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.math.calc.Calculate;
import java.security.SecureRandom;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class SpookyTimeAngle
extends RotateConstructor {
    private final SecureRandom secureRandom = new SecureRandom();
    private final Random random = new Random();
    private float lastYaw = 0.0f;
    private float lastPitch = 0.0f;
    private float targetYaw = 0.0f;
    private float targetPitch = 0.0f;
    private long lastRandomizationTime = 0L;
    private float currentRandomOffsetYaw = 0.0f;
    private float currentRandomOffsetPitch = 0.0f;
    private static final long RANDOMIZATION_INTERVAL = 150L;
    private boolean wasInAir = false;
    private float jumpCompensation = 0.0f;
    private float jumpCompensationDecay = 0.85f;
    private float smoothFactor = 0.15f;
    private float maxSpeedMultiplier = 0.75f;

    public SpookyTimeAngle() {
        super("SpookyTime");
    }

    @Override
    public Turns limitAngleChange(Turns currentTurns, Turns targetTurns, class_243 vec3d, class_1297 entity) {
        float rotationDifference;
        StrikeManager attackHandler = Bloody.getInstance().getAttackPerpetrator().getAttackHandler();
        boolean canAttack = entity != null && attackHandler.canAttack(Aura.getInstance().getConfig(), 0);
        this.updateRandomization();
        this.updateJumpCompensation();
        Turns angleDelta = MathAngle.calculateDelta(currentTurns, targetTurns);
        float yawDelta = angleDelta.getYaw();
        float pitchDelta = angleDelta.getPitch();
        float distanceToTarget = rotationDifference = Math.max((float)Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta)), 0.001f);
        float adaptiveSpeed = this.calculateAdaptiveSpeed(distanceToTarget, canAttack);
        this.targetYaw = targetTurns.getYaw();
        this.targetPitch = targetTurns.getPitch();
        float yawDiff = class_3532.method_15393((float)(this.targetYaw - this.lastYaw));
        float pitchDiff = this.targetPitch - this.lastPitch;
        float smoothYaw = yawDiff * this.smoothFactor * adaptiveSpeed;
        float smoothPitch = pitchDiff * this.smoothFactor * adaptiveSpeed;
        float randomizedYaw = smoothYaw + this.currentRandomOffsetYaw;
        float randomizedPitch = smoothPitch + this.currentRandomOffsetPitch;
        randomizedPitch -= this.jumpCompensation;
        if (this.random.nextFloat() < 0.03f) {
            randomizedYaw += (this.random.nextFloat() - 0.5f) * 0.8f;
            randomizedPitch += (this.random.nextFloat() - 0.5f) * 0.4f;
        }
        float newYaw = this.lastYaw + randomizedYaw;
        float newPitch = class_3532.method_15363((float)(this.lastPitch + randomizedPitch), (float)-90.0f, (float)90.0f);
        float gcd = (float)Calculate.computeGcd();
        newYaw -= (newYaw - this.lastYaw) % gcd;
        newPitch -= (newPitch - this.lastPitch) % gcd;
        this.lastYaw = newYaw;
        this.lastPitch = newPitch;
        return new Turns(newYaw, newPitch);
    }

    private float calculateAdaptiveSpeed(float distance, boolean canAttack) {
        float baseSpeed = canAttack ? this.randomLerp(0.7f, 0.9f) : this.randomLerp(0.3f, 0.5f);
        float distanceFactor = class_3532.method_15363((float)(distance / 45.0f), (float)0.5f, (float)this.maxSpeedMultiplier);
        return baseSpeed * distanceFactor;
    }

    private void updateRandomization() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastRandomizationTime > 150L) {
            this.lastRandomizationTime = currentTime;
            this.currentRandomOffsetYaw = (this.random.nextFloat() - 0.5f) * 1.2f;
            this.currentRandomOffsetPitch = (this.random.nextFloat() - 0.5f) * 0.6f;
        }
    }

    private void updateJumpCompensation() {
        boolean isInAir;
        boolean bl = isInAir = !SpookyTimeAngle.mc.field_1724.method_24828();
        this.jumpCompensation = isInAir && !this.wasInAir ? this.randomLerp(2.5f, 4.0f) : (isInAir ? (this.jumpCompensation *= this.jumpCompensationDecay) : 0.0f);
        this.wasInAir = isInAir;
    }

    private float randomLerp(float min, float max) {
        return class_3532.method_16439((float)this.secureRandom.nextFloat(), (float)min, (float)max);
    }

    @Override
    public class_243 randomValue() {
        return new class_243((double)this.randomLerp(0.03f, 0.08f), (double)this.randomLerp(0.05f, 0.12f), (double)this.randomLerp(0.03f, 0.08f));
    }
}

