/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.features.aura.rotations.impl;

import fun.bloody.Bloody;
import fun.bloody.features.impl.combat.Aura;
import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.striking.StrikeManager;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.math.calc.Calculate;
import java.security.SecureRandom;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class HWAngle
extends RotateConstructor {
    private static long tickCounter = 0L;
    private float resetProgress = 0.0f;
    private final SecureRandom secureRandom = new SecureRandom();
    private boolean jitterApplied = false;

    public HWAngle() {
        super("snap");
    }

    @Override
    public Turns limitAngleChange(Turns currentAngle, Turns targetAngle, class_243 vec3d, class_1297 entity) {
        Aura aura = Aura.getInstance();
        StrikeManager attackHandler = Bloody.getInstance().getAttackPerpetrator().getAttackHandler();
        boolean canAttack = entity != null && attackHandler.canAttack(aura.getConfig(), 0);
        Turns angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = angleDelta.getYaw();
        float pitchDelta = angleDelta.getPitch();
        float rotationDifference = (float)Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta));
        float speed = canAttack ? this.randomLerp(0.86f, 0.96f) : this.randomLerp(0.1f, 0.4f);
        float maxRotation = 180.0f;
        float lineYaw = Math.abs(yawDelta / rotationDifference) * maxRotation;
        float linePitch = Math.abs(pitchDelta / rotationDifference) * maxRotation;
        float moveYaw = class_3532.method_15363((float)yawDelta, (float)(-lineYaw), (float)lineYaw);
        float movePitch = class_3532.method_15363((float)pitchDelta, (float)(-linePitch), (float)linePitch);
        Turns moveAngle = new Turns(currentAngle.getYaw(), currentAngle.getPitch());
        moveAngle.setYaw(class_3532.method_16439((float)Calculate.getRandom(speed, speed + 0.2f), (float)currentAngle.getYaw(), (float)(currentAngle.getYaw() + moveYaw)));
        moveAngle.setPitch(class_3532.method_16439((float)Calculate.getRandom(speed, speed + 0.2f), (float)currentAngle.getPitch(), (float)(currentAngle.getPitch() + movePitch)));
        return new Turns(moveAngle.getYaw(), moveAngle.getPitch());
    }

    private float applyGaussianJitter(float rotation, float strength) {
        return rotation + (float)(this.secureRandom.nextGaussian() * (double)strength);
    }

    private float randomLerp(float min, float max) {
        return class_3532.method_16439((float)new SecureRandom().nextFloat(), (float)min, (float)max);
    }

    @Override
    public class_243 randomValue() {
        return new class_243(0.1, 0.1, 0.1);
    }
}

