/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.features.aura.rotations.impl;

import fun.bloody.utils.features.aura.point.Vector;
import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.math.time.TimerUtil;
import java.security.SecureRandom;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class FakeAngle
extends RotateConstructor {
    private int swingCount = 0;
    private boolean hasSwungTwice = false;
    private boolean hasSwung = false;
    private boolean disableRotation = false;
    TimerUtil timer = new TimerUtil();

    public FakeAngle() {
        super("FakeAngle to LonyGrief");
    }

    @Override
    public Turns limitAngleChange(Turns currentAngle, Turns targetAngle, class_243 vec3d, class_1297 entity) {
        if (entity != null) {
            class_243 aimPoint = Vector.brain(entity, 0.0f, 5.0f);
            targetAngle = MathAngle.calculateAngle(aimPoint);
        }
        Turns angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = angleDelta.getYaw();
        float pitchDelta = angleDelta.getPitch();
        float rotationDifference = (float)Math.hypot(yawDelta, pitchDelta);
        float straightLineYaw = Math.abs(yawDelta / rotationDifference) * 360.0f;
        float straightLinePitch = Math.abs(pitchDelta / rotationDifference) * 360.0f;
        float jitterYaw = (float)(8.0 * Math.sin((double)System.currentTimeMillis() / 85.0));
        float jitterPitch = (float)(8.0 * Math.sin((double)System.currentTimeMillis() / 95.0));
        float newYaw = currentAngle.getYaw() + Math.min(Math.max(yawDelta, -straightLineYaw), straightLineYaw);
        float newPitch = currentAngle.getPitch() + Math.min(Math.max(pitchDelta, -straightLinePitch), straightLinePitch);
        return new Turns(newYaw, newPitch);
    }

    @Override
    public class_243 randomValue() {
        return new class_243(0.05, 0.1, 0.02);
    }

    private float randomLerp(float min, float max) {
        return class_3532.method_16439((float)new SecureRandom().nextFloat(), (float)min, (float)max);
    }
}

