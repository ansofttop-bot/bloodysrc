/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.features.aura.rotations.impl;

import fun.bloody.Bloody;
import fun.bloody.features.impl.combat.Aura;
import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.striking.StrikeManager;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.math.time.StopWatch;
import java.security.SecureRandom;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class TestAngle
extends RotateConstructor {
    private final SecureRandom random = new SecureRandom();
    private int hitCounter = 0;
    private float baseSpeed = 0.4f;
    private float timeFactor = 0.0f;
    private float timeFactorFast = 0.0f;

    public TestAngle() {
        super("Test");
    }

    @Override
    public Turns limitAngleChange(Turns currentAngle, Turns targetAngle, class_243 vec3d, class_1297 entity) {
        if (entity == null) {
            return currentAngle;
        }
        Aura aura = Aura.getInstance();
        StrikeManager attackHandler = Bloody.getInstance().getAttackPerpetrator().getAttackHandler();
        StopWatch attackTimer = attackHandler.getAttackTimer();
        boolean canAttack = attackHandler.canAttack(aura.getConfig(), 0);
        int count = attackHandler.getCount();
        if (count > this.hitCounter) {
            this.hitCounter = count;
            this.baseSpeed = this.random.nextBoolean() ? 0.4f : 0.2f;
        }
        Turns angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = angleDelta.getYaw();
        float pitchDelta = angleDelta.getPitch();
        float rotationDifference = Math.max((float)Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta)), 0.001f);
        float lineYaw = Math.abs(yawDelta / rotationDifference) * 180.0f;
        float linePitch = Math.abs(pitchDelta / rotationDifference) * 180.0f;
        float moveYaw = class_3532.method_15363((float)yawDelta, (float)(-lineYaw), (float)lineYaw);
        float movePitch = class_3532.method_15363((float)pitchDelta, (float)(-linePitch), (float)linePitch);
        Turns moveTurns = new Turns(currentAngle.getYaw(), currentAngle.getPitch());
        if (canAttack) {
            float snapSpeed = 0.85f;
            float snapYaw = class_3532.method_16439((float)snapSpeed, (float)currentAngle.getYaw(), (float)(currentAngle.getYaw() + moveYaw));
            float snapPitch = class_3532.method_16439((float)snapSpeed, (float)currentAngle.getPitch(), (float)(currentAngle.getPitch() + movePitch));
            moveTurns.setYaw(snapYaw);
            moveTurns.setPitch(snapPitch);
            return moveTurns;
        }
        float speed = this.baseSpeed;
        if (!attackTimer.finished(500.0)) {
            speed = -0.2f;
        }
        this.timeFactor = (float)(System.currentTimeMillis() % 2000L) / 75.0f;
        this.timeFactorFast = (float)(System.currentTimeMillis() % 1000L) / 75.0f;
        Turns jitterPattern = switch (this.hitCounter % 4) {
            case 0 -> new Turns((float)Math.cos(this.timeFactor), (float)Math.sin(this.timeFactorFast));
            case 1 -> new Turns((float)Math.sin(this.timeFactor), (float)Math.cos(this.timeFactorFast));
            case 2 -> new Turns((float)Math.sin(this.timeFactor), (float)(-Math.cos(this.timeFactorFast)));
            default -> new Turns((float)(-Math.cos(this.timeFactor)), (float)Math.sin(this.timeFactorFast));
        };
        float yawJitter = 0.0f;
        float pitchJitter = 0.0f;
        if (!attackTimer.finished(1000.0)) {
            yawJitter = this.randomLerp(6.0f, 12.0f) * jitterPattern.getYaw();
            pitchJitter = this.randomLerp(2.0f, 4.0f) * jitterPattern.getPitch();
        }
        float yawLerpFactor = class_3532.method_15363((float)this.randomLerp(speed, speed + 0.2f), (float)0.0f, (float)1.0f);
        float pitchLerpFactor = class_3532.method_15363((float)this.randomLerp(speed, speed + 0.2f), (float)0.0f, (float)1.0f);
        float finalYaw = class_3532.method_16439((float)yawLerpFactor, (float)currentAngle.getYaw(), (float)(currentAngle.getYaw() + moveYaw)) + yawJitter;
        float finalPitch = class_3532.method_16439((float)pitchLerpFactor, (float)currentAngle.getPitch(), (float)(currentAngle.getPitch() + movePitch)) + pitchJitter;
        moveTurns.setYaw(finalYaw);
        moveTurns.setPitch(finalPitch);
        return moveTurns;
    }

    @Override
    public class_243 randomValue() {
        return new class_243(0.0, 0.0, 0.0);
    }

    private float randomLerp(float min, float max) {
        return class_3532.method_16439((float)this.random.nextFloat(), (float)min, (float)max);
    }
}

