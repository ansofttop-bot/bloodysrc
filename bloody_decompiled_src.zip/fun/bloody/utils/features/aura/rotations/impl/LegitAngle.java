/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.features.aura.rotations.impl;

import fun.bloody.Bloody;
import fun.bloody.features.impl.combat.Aura;
import fun.bloody.utils.features.aura.point.Vector;
import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.striking.StrikeManager;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.math.time.StopWatch;
import java.security.SecureRandom;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class LegitAngle
extends RotateConstructor {
    private boolean isPullingBack = false;
    private long pullBackStartTime = 0L;
    private final SecureRandom random = new SecureRandom();

    public LegitAngle() {
        super("Matrix");
    }

    @Override
    public Turns limitAngleChange(Turns currentAngle, Turns targetAngle, class_243 vec3d, class_1297 entity) {
        float jitterPitch;
        float speed;
        StrikeManager attackHandler = Bloody.getInstance().getAttackPerpetrator().getAttackHandler();
        Aura aura = Aura.getInstance();
        StopWatch attackTimer = attackHandler.getAttackTimer();
        if (entity != null) {
            class_243 aimPoint = Vector.hitbox(entity, 1.0f, 1.2f, 1.0f, 4.0f);
            targetAngle = MathAngle.calculateAngle(aimPoint);
        }
        Turns angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = angleDelta.getYaw();
        float pitchDelta = angleDelta.getPitch();
        float rotationDifference = (float)Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta));
        boolean canAttack = entity != null && attackHandler.canAttack(aura.getConfig(), 0);
        float preAttackSpeed = 0.75f;
        float f = speed = !attackTimer.finished(250.0) ? 0.1f : 0.7f;
        if (!attackTimer.finished(350.0)) {
            speed = 0.15f;
        }
        if (!attackTimer.finished(500.0)) {
            speed = 0.25f;
        }
        float lineYaw = Math.abs(yawDelta / rotationDifference) * (float)(canAttack ? 360 : 100);
        float linePitch = Math.abs(pitchDelta / rotationDifference) * 180.0f;
        float jitterYaw = canAttack ? 0.0f : (float)(3.0 * Math.sin((double)System.currentTimeMillis() / 85.0));
        float f2 = jitterPitch = canAttack ? 0.0f : (float)(2.0 * Math.cos((double)System.currentTimeMillis() / 85.0));
        if (!aura.isState() || entity == null) {
            jitterYaw = 0.0f;
            jitterPitch = 0.0f;
        }
        float moveYaw = class_3532.method_15363((float)yawDelta, (float)(-lineYaw), (float)lineYaw);
        float movePitch = class_3532.method_15363((float)pitchDelta, (float)(-linePitch), (float)linePitch);
        Turns moveAngle = new Turns(currentAngle.getYaw(), currentAngle.getPitch());
        moveAngle.setYaw(class_3532.method_16439((float)this.randomLerp(speed, speed), (float)currentAngle.getYaw(), (float)(currentAngle.getYaw() + moveYaw)) + jitterYaw);
        moveAngle.setPitch(class_3532.method_16439((float)this.randomLerp(speed, speed), (float)currentAngle.getPitch(), (float)(currentAngle.getPitch() + movePitch)) + jitterPitch);
        return moveAngle;
    }

    private float randomLerp(float min, float max) {
        return class_3532.method_16439((float)this.random.nextFloat(), (float)min, (float)max);
    }

    @Override
    public class_243 randomValue() {
        return new class_243(0.0, 0.0, 0.0);
    }
}

