/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.features.aura.rotations.impl;

import fun.bloody.Bloody;
import fun.bloody.features.impl.combat.Aura;
import fun.bloody.utils.client.packet.network.Network;
import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.striking.StrikeManager;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.math.calc.Calculate;
import fun.bloody.utils.math.time.StopWatch;
import fun.bloody.utils.math.time.TimerUtil;
import java.security.SecureRandom;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class FTAngle
extends RotateConstructor {
    private int swingCount = 0;
    private boolean hasSwungTwice = false;
    private boolean hasSwung = false;
    private boolean disableRotation = false;
    TimerUtil timer = new TimerUtil();
    private final SecureRandom secureRandom = new SecureRandom();
    private final Random random = new Random();
    private int hitCounter = 0;
    private boolean isRotatingUpward = false;
    private long upwardRotationStartTime = 0L;
    private static final int HITS_BEFORE_ROTATION = 7;
    private static final float ROTATION_SPEED_MS = 300.0f;
    private float funTimeShakeAngle = 0.0f;
    private float funTimeShakeSpeed = 0.06f;
    private float funTimeTargetSpeed = 0.06f;
    private float funTimeRandomOffset = 0.0f;
    private float funTimeShakeAmplitude = 8.0f;
    private float funTimePitchAmplitude = 3.0f;
    private long funTimeNextLookUpTime = 0L;
    private boolean funTimeIsLookingUp = false;
    private long funTimeLookUpStartTime = 0L;
    private int hitCounterFor10 = 0;
    private boolean isRotatingSpecial = false;
    private long specialRotationStartTime = 0L;
    private int specialRotationDirection = 0;
    private static final int HITS_BEFORE_SPECIAL = 10;
    private static final float SPECIAL_ROTATION_SPEED_MS = 200.0f;
    private boolean wasInAir = false;
    private long lastRandomizationTime = 0L;
    private float currentRandomOffsetYaw = 0.0f;
    private float currentRandomOffsetPitch = 0.0f;
    private float lastYaw = 0.0f;
    private float lastPitch = 0.0f;

    public FTAngle() {
        super("FunTime");
    }

    @Override
    public Turns limitAngleChange(Turns currentTurns, Turns targetTurns, class_243 vec3d, class_1297 entity) {
        if (entity == null) {
            this.isRotatingUpward = false;
            this.hitCounter = 0;
            this.lastYaw = FTAngle.mc.field_1724.method_36454();
            this.lastPitch = FTAngle.mc.field_1724.method_36455();
            return new Turns(FTAngle.mc.field_1724.method_36454(), FTAngle.mc.field_1724.method_36455());
        }
        StrikeManager attackHandler = Bloody.getInstance().getAttackPerpetrator().getAttackHandler();
        StopWatch attackTimer = attackHandler.getAttackTimer();
        int count = attackHandler.getCount();
        if (count > this.hitCounter) {
            this.hitCounter = count;
            if (this.hitCounter % 7 == 0) {
                this.isRotatingUpward = true;
                this.upwardRotationStartTime = System.currentTimeMillis();
            }
        }
        if (this.isRotatingUpward && attackHandler.canAttack(Aura.getInstance().getConfig(), 0)) {
            this.isRotatingUpward = false;
        }
        Turns TurnsDelta = MathAngle.calculateDelta(currentTurns, targetTurns);
        float yawDelta = TurnsDelta.getYaw();
        float pitchDelta = TurnsDelta.getPitch();
        float rotationDifference = Math.max((float)Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta)), 0.001f);
        boolean canAttack = attackHandler.canAttack(Aura.getInstance().getConfig(), 0);
        double time = (double)System.currentTimeMillis() / 1000.0;
        float sineWaveYaw = (float)(Math.sin(time * 10.0) * 32.0);
        float microJitterYaw = (this.random.nextFloat() - 0.5f) * 1.15f;
        float microJitterPitch = (this.random.nextFloat() - 0.5f) * 0.35f;
        float lineYaw = Math.abs(yawDelta / rotationDifference) * 180.0f;
        float linePitch = Math.abs(pitchDelta / rotationDifference) * 180.0f;
        float moveYaw = class_3532.method_15363((float)yawDelta, (float)(-lineYaw), (float)lineYaw);
        float movePitch = class_3532.method_15363((float)pitchDelta, (float)(-linePitch), (float)linePitch);
        Turns moveTurns = new Turns(currentTurns.getYaw(), currentTurns.getPitch());
        if (this.isRotatingUpward) {
            float targetPitch;
            long elapsed = System.currentTimeMillis() - this.upwardRotationStartTime;
            float progress = Math.min(1.0f, (float)elapsed / 300.0f);
            if (progress < 0.5f) {
                float upProgress = progress * 2.0f;
                targetPitch = class_3532.method_16439((float)upProgress, (float)targetTurns.getPitch(), (float)-90.0f);
            } else {
                float downProgress = (progress - 0.5f) * 2.0f;
                targetPitch = class_3532.method_16439((float)downProgress, (float)-90.0f, (float)targetTurns.getPitch());
            }
            moveTurns.setPitch(targetPitch);
            moveTurns.setYaw(class_3532.method_16439((float)this.randomLerp(canAttack ? 0.92f : 0.4f, canAttack ? 1.0f : 0.6f), (float)currentTurns.getYaw(), (float)(currentTurns.getYaw() + moveYaw)) + microJitterYaw);
        } else {
            float resultPitch;
            float resultYaw;
            if (canAttack) {
                float lerpFactor = this.randomLerp(0.92f, 1.0f);
                resultYaw = class_3532.method_16439((float)lerpFactor, (float)currentTurns.getYaw(), (float)(currentTurns.getYaw() + moveYaw)) + microJitterYaw;
                resultPitch = class_3532.method_16439((float)lerpFactor, (float)currentTurns.getPitch(), (float)(currentTurns.getPitch() + movePitch)) + microJitterPitch;
            } else {
                float playerYaw = FTAngle.mc.field_1724.method_36454();
                float playerPitch = FTAngle.mc.field_1724.method_36455();
                resultYaw = class_3532.method_16439((float)0.26f, (float)currentTurns.getYaw(), (float)playerYaw) + sineWaveYaw * 0.16f + microJitterYaw;
                resultPitch = class_3532.method_16439((float)0.24f, (float)currentTurns.getPitch(), (float)playerPitch) + microJitterPitch;
            }
            moveTurns.setYaw(resultYaw);
            moveTurns.setPitch(resultPitch);
        }
        return moveTurns;
    }

    @Override
    public class_243 randomValue() {
        return new class_243(0.05, 0.1, 0.02);
    }

    private float randomLerp(float min, float max) {
        return class_3532.method_16439((float)new SecureRandom().nextFloat(), (float)min, (float)max);
    }

    private float getTpsFactor() {
        return Network.TPS / 20.0f;
    }

    private Turns calculateFTRotation(class_243 point) {
        class_243 eyes = FTAngle.mc.field_1724.method_33571();
        float neuroRand1 = this.random.nextFloat();
        float distToTarget = (float)eyes.method_1022(point);
        float baseSpeed = class_3532.method_15363((float)(distToTarget * 0.3f), (float)1.2f, (float)3.5f) * this.getTpsFactor();
        Turns angle = MathAngle.fromVec3d(point.method_1020(eyes));
        float targetYaw = angle.getYaw();
        float targetPitch = class_3532.method_15363((float)angle.getPitch(), (float)-90.0f, (float)90.0f);
        float yawDiff = class_3532.method_15393((float)(targetYaw - this.lastYaw));
        float pitchDiff = targetPitch - this.lastPitch;
        float smoothFactor = 0.12f + neuroRand1 * 0.1f;
        float smoothYaw = yawDiff * smoothFactor * baseSpeed;
        float smoothPitch = pitchDiff * smoothFactor * baseSpeed * 0.85f;
        if (this.random.nextFloat() < 0.02f) {
            smoothYaw += (this.random.nextFloat() - 0.5f) * 1.5f;
            smoothPitch += (this.random.nextFloat() - 0.5f) * 1.0f;
        }
        float newYaw = this.lastYaw + smoothYaw;
        float newPitch = this.lastPitch + smoothPitch;
        newPitch = class_3532.method_15363((float)newPitch, (float)-90.0f, (float)90.0f);
        float gcd = (float)Calculate.computeGcd();
        newYaw -= (newYaw - this.lastYaw) % gcd;
        newPitch -= (newPitch - this.lastPitch) % gcd;
        this.lastYaw = newYaw;
        this.lastPitch = newPitch;
        return new Turns(newYaw, newPitch);
    }
}

