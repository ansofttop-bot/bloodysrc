/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.features.aura.rotations.impl;

import fun.bloody.Bloody;
import fun.bloody.features.impl.combat.Aura;
import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.striking.StrikeManager;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.math.time.StopWatch;
import java.security.SecureRandom;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class OtherAngle
extends RotateConstructor {
    private final SecureRandom random = new SecureRandom();
    private int hitCount = 0;
    private int currentPoint = 0;
    private float wavePhase = 0.0f;
    private float waveSpeed = 0.06f;
    private float shakeYaw = 0.0f;
    private float shakePitch = 0.0f;
    private float randomYaw = 0.0f;
    private float randomPitch = 0.0f;
    private long lastRandomUpdate = 0L;
    private float jumpPitchOffset = 0.0f;

    public OtherAngle() {
        super("Other");
    }

    @Override
    public Turns limitAngleChange(Turns currentAngle, Turns targetAngle, class_243 vec3d, class_1297 entity) {
        boolean isOnGround;
        if (entity == null) {
            float playerYaw = OtherAngle.mc.field_1724.method_36454();
            float playerPitch = OtherAngle.mc.field_1724.method_36455();
            float yawDiff = class_3532.method_15393((float)(playerYaw - currentAngle.getYaw()));
            float pitchDiff = playerPitch - currentAngle.getPitch();
            float returnSpeed = 0.3f;
            float newYaw = currentAngle.getYaw() + yawDiff * returnSpeed;
            float newPitch = currentAngle.getPitch() + pitchDiff * returnSpeed;
            return new Turns(newYaw, class_3532.method_15363((float)newPitch, (float)-90.0f, (float)90.0f));
        }
        StrikeManager attackHandler = Bloody.getInstance().getAttackPerpetrator().getAttackHandler();
        StopWatch attackTimer = attackHandler.getAttackTimer();
        boolean canAttack = attackHandler.canAttack(Aura.getInstance().getConfig(), 0);
        int count = attackHandler.getCount();
        long currentTime = System.currentTimeMillis();
        if (count > this.hitCount) {
            this.hitCount = count;
            this.currentPoint = this.random.nextInt(4);
        }
        this.wavePhase += this.waveSpeed;
        float waveYaw = (float)(Math.sin(this.wavePhase) * 1.25);
        float wavePitch = (float)(Math.cos((double)this.wavePhase * 0.8) * 0.75);
        if (!attackTimer.finished(250.0)) {
            float intensity = 1.0f - (float)attackTimer.elapsedTime() / 250.0f;
            this.shakeYaw = this.randomLerp(-1.75f, 1.75f) * intensity;
            this.shakePitch = this.randomLerp(-0.9f, 0.9f) * intensity;
        } else {
            this.shakeYaw = 0.0f;
            this.shakePitch = 0.0f;
        }
        if (currentTime - this.lastRandomUpdate >= 100L) {
            this.randomYaw = this.randomLerp(-0.75f, 0.75f);
            this.randomPitch = this.randomLerp(-0.4f, 0.4f);
            this.lastRandomUpdate = currentTime;
        }
        this.jumpPitchOffset = !(isOnGround = OtherAngle.mc.field_1724.method_24828()) ? this.randomLerp(-0.4f, 0.4f) : (this.jumpPitchOffset *= 0.7f);
        Turns angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = angleDelta.getYaw();
        float pitchDelta = angleDelta.getPitch();
        float rotationDifference = Math.max((float)Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta)), 0.001f);
        float lineYaw = Math.abs(yawDelta / rotationDifference) * 180.0f;
        float linePitch = Math.abs(pitchDelta / rotationDifference) * 180.0f;
        float moveYaw = class_3532.method_15363((float)yawDelta, (float)(-lineYaw), (float)lineYaw);
        float movePitch = class_3532.method_15363((float)pitchDelta, (float)(-linePitch), (float)linePitch);
        float speed = canAttack ? this.randomLerp(0.7f, 0.85f) : this.randomLerp(0.4f, 0.6f);
        float finalYaw = class_3532.method_16439((float)speed, (float)currentAngle.getYaw(), (float)(currentAngle.getYaw() + moveYaw));
        float finalPitch = class_3532.method_16439((float)speed, (float)currentAngle.getPitch(), (float)(currentAngle.getPitch() + movePitch));
        finalPitch += wavePitch + this.shakePitch + this.randomPitch + this.jumpPitchOffset;
        finalPitch = class_3532.method_15363((float)finalPitch, (float)-90.0f, (float)90.0f);
        return new Turns(finalYaw += waveYaw + this.shakeYaw + this.randomYaw, finalPitch);
    }

    @Override
    public class_243 randomValue() {
        return switch (this.currentPoint) {
            case 0 -> new class_243((double)this.randomLerp(-0.15f, 0.15f), (double)this.randomLerp(0.2f, 0.45f), (double)this.randomLerp(-0.15f, 0.15f));
            case 1 -> new class_243((double)this.randomLerp(-0.2f, 0.2f), (double)this.randomLerp(-0.1f, 0.15f), (double)this.randomLerp(-0.2f, 0.2f));
            case 2 -> new class_243((double)this.randomLerp(-0.25f, 0.25f), (double)this.randomLerp(-0.4f, -0.15f), (double)this.randomLerp(-0.25f, 0.25f));
            case 3 -> new class_243((double)this.randomLerp(-0.35f, 0.35f), (double)this.randomLerp(-0.15f, 0.2f), (double)this.randomLerp(-0.35f, 0.35f));
            default -> new class_243(0.0, 0.0, 0.0);
        };
    }

    private float randomLerp(float min, float max) {
        return class_3532.method_16439((float)this.random.nextFloat(), (float)min, (float)max);
    }
}

