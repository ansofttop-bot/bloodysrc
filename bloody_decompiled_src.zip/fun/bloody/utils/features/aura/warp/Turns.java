/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.features.aura.warp;

import fun.bloody.utils.features.aura.warp.TurnsConnection;
import fun.bloody.utils.math.calc.Calculate;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class Turns {
    public static Turns DEFAULT = new Turns(0.0f, 0.0f);
    private float yaw;
    private float pitch;

    public static Turns fromTargetHead(class_243 playerPos, class_243 targetPos, double targetHeight) {
        double headY = targetPos.field_1351 + targetHeight * 0.9;
        double deltaX = targetPos.field_1352 - playerPos.field_1352;
        double deltaY = headY - (playerPos.field_1351 + 1.5);
        double deltaZ = targetPos.field_1350 - playerPos.field_1350;
        float yaw = (float)Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0f;
        yaw = class_3532.method_15393((float)yaw);
        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        float pitch = (float)Math.toDegrees(-Math.atan2(deltaY, horizontalDistance));
        pitch = class_3532.method_15363((float)pitch, (float)-90.0f, (float)90.0f);
        return new Turns(yaw, pitch);
    }

    public Turns adjustSensitivity() {
        double gcd = Calculate.computeGcd();
        Turns previousAngle = TurnsConnection.INSTANCE.getServerAngle();
        float adjustedYaw = this.adjustAxis(this.yaw, previousAngle.yaw, gcd);
        float adjustedPitch = this.adjustAxis(this.pitch, previousAngle.pitch, gcd);
        return new Turns(adjustedYaw, class_3532.method_15363((float)adjustedPitch, (float)-90.0f, (float)90.0f));
    }

    public Turns random(float f) {
        return new Turns(this.yaw + Calculate.getRandom(-f, f), this.pitch + Calculate.getRandom(-f, f));
    }

    private float adjustAxis(float axisValue, float previousValue, double gcd) {
        float delta = axisValue - previousValue;
        return previousValue + (float)Math.round((double)delta / gcd) * (float)gcd;
    }

    public final class_243 toVector() {
        float f = this.pitch * ((float)Math.PI / 180);
        float g = -this.yaw * ((float)Math.PI / 180);
        float h = class_3532.method_15362((float)g);
        float i = class_3532.method_15374((float)g);
        float j = class_3532.method_15362((float)f);
        float k = class_3532.method_15374((float)f);
        return new class_243((double)(i * j), (double)(-k), (double)(h * j));
    }

    public Turns addYaw(float yaw) {
        return new Turns(this.yaw + yaw, this.pitch);
    }

    public Turns addPitch(float pitch) {
        this.pitch = class_3532.method_15363((float)(this.pitch + pitch), (float)-90.0f, (float)90.0f);
        return this;
    }

    public Turns of(Turns angle) {
        return new Turns(angle.getYaw(), angle.getPitch());
    }

    public float getYaw() {
        return this.yaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public String toString() {
        return "Turns(yaw=" + this.getYaw() + ", pitch=" + this.getPitch() + ")";
    }

    public Turns(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public static class VecRotation {
        private final Turns angle;
        private final class_243 vec;

        public String toString() {
            return "Turns.VecRotation(angle=" + String.valueOf(this.getAngle()) + ", vec=" + String.valueOf(this.getVec()) + ")";
        }

        public Turns getAngle() {
            return this.angle;
        }

        public class_243 getVec() {
            return this.vec;
        }

        public VecRotation(Turns angle, class_243 vec) {
            this.angle = angle;
            this.vec = vec;
        }
    }
}

