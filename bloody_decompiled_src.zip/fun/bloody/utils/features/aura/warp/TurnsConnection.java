/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2708
 *  net.minecraft.class_2828
 *  net.minecraft.class_3532
 */
package fun.bloody.utils.features.aura.warp;

import fun.bloody.Bloody;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.events.player.PlayerVelocityStrafeEvent;
import fun.bloody.events.player.RotationUpdateEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.features.aura.warp.TurnsConfig;
import fun.bloody.utils.features.aura.warp.TurnsConstructor;
import fun.bloody.utils.math.task.TaskPriority;
import fun.bloody.utils.math.task.TaskProcessor;
import java.lang.runtime.SwitchBootstraps;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2828;
import net.minecraft.class_3532;

public class TurnsConnection
implements QuickImports {
    public static TurnsConnection INSTANCE = new TurnsConnection();
    private TurnsConstructor lastRotationPlan;
    private final TaskProcessor<TurnsConstructor> rotationPlanTaskProcessor = new TaskProcessor();
    public Turns currentAngle;
    private Turns previousAngle;
    private Turns serverAngle = Turns.DEFAULT;
    private Turns fakeAngle;

    public TurnsConnection() {
        Bloody.getInstance().getEventManager().register(this);
    }

    public void setRotation(Turns value) {
        this.previousAngle = value == null ? (this.currentAngle != null ? this.currentAngle : MathAngle.cameraAngle()) : this.currentAngle;
        this.currentAngle = value;
    }

    public Turns getRotation() {
        return this.currentAngle != null ? this.currentAngle : MathAngle.cameraAngle();
    }

    public Turns getFakeRotation() {
        if (this.fakeAngle != null) {
            return this.fakeAngle;
        }
        return this.currentAngle != null ? this.currentAngle : (this.previousAngle != null ? this.previousAngle : MathAngle.cameraAngle());
    }

    public void setFakeRotation(Turns angle) {
        this.fakeAngle = angle;
    }

    public Turns getPreviousRotation() {
        return this.currentAngle != null && this.previousAngle != null ? this.previousAngle : new Turns(TurnsConnection.mc.field_1724.field_5982, TurnsConnection.mc.field_1724.field_6004);
    }

    public Turns getMoveRotation() {
        TurnsConstructor rotationPlan = this.getCurrentRotationPlan();
        return this.currentAngle != null && rotationPlan != null && rotationPlan.isMoveCorrection() ? this.currentAngle : MathAngle.cameraAngle();
    }

    public TurnsConstructor getCurrentRotationPlan() {
        return this.rotationPlanTaskProcessor.fetchActiveTaskValue() != null ? this.rotationPlanTaskProcessor.fetchActiveTaskValue() : this.lastRotationPlan;
    }

    public void rotateTo(Turns.VecRotation vecRotation, class_1309 entity, int reset, TurnsConfig configurable, TaskPriority taskPriority, Module provider) {
        this.rotateTo(configurable.createRotationPlan(vecRotation.getAngle(), vecRotation.getVec(), (class_1297)entity, reset), taskPriority, provider);
    }

    public void rotateTo(Turns angle, int reset, TurnsConfig configurable, TaskPriority taskPriority, Module provider) {
        this.rotateTo(configurable.createRotationPlan(angle, angle.toVector(), null, reset), taskPriority, provider);
    }

    public void rotateTo(Turns angle, TurnsConfig configurable, TaskPriority taskPriority, Module provider) {
        this.rotateTo(configurable.createRotationPlan(angle, angle.toVector(), null, 1), taskPriority, provider);
    }

    public void rotateTo(TurnsConstructor plan, TaskPriority taskPriority, Module provider) {
        this.rotationPlanTaskProcessor.addTask(new TaskProcessor.Task<TurnsConstructor>(1, taskPriority.getPriority(), provider, plan));
    }

    public void update() {
        TurnsConstructor activePlan = this.getCurrentRotationPlan();
        if (activePlan == null) {
            return;
        }
        Turns clientAngle = MathAngle.cameraAngle();
        if (this.lastRotationPlan != null) {
            double differenceFromCurrentToPlayer = TurnsConnection.computeRotationDifference(this.serverAngle, clientAngle);
            if (activePlan.getTicksUntilReset() <= this.rotationPlanTaskProcessor.tickCounter && differenceFromCurrentToPlayer < (double)activePlan.getResetThreshold()) {
                this.setRotation(null);
                this.lastRotationPlan = null;
                this.rotationPlanTaskProcessor.tickCounter = 0;
                return;
            }
        }
        Turns newAngle = activePlan.nextRotation(this.currentAngle != null ? this.currentAngle : clientAngle, this.rotationPlanTaskProcessor.fetchActiveTaskValue() == null).adjustSensitivity();
        this.setRotation(newAngle);
        this.lastRotationPlan = activePlan;
        this.rotationPlanTaskProcessor.tick(1);
    }

    public static double computeRotationDifference(Turns a, Turns b) {
        return Math.hypot(Math.abs(TurnsConnection.computeAngleDifference(a.getYaw(), b.getYaw())), Math.abs(a.getPitch() - b.getPitch()));
    }

    public static float computeAngleDifference(float a, float b) {
        return class_3532.method_15393((float)(a - b));
    }

    private class_243 fixVelocity(class_243 currVelocity, class_243 movementInput, float speed) {
        if (this.currentAngle != null) {
            float yaw = this.currentAngle.getYaw();
            double d = movementInput.method_1027();
            if (d < 1.0E-7) {
                return class_243.field_1353;
            }
            class_243 vec3d = (d > 1.0 ? movementInput.method_1029() : movementInput).method_1021((double)speed);
            float f = class_3532.method_15374((float)(yaw * ((float)Math.PI / 180)));
            float g = class_3532.method_15362((float)(yaw * ((float)Math.PI / 180)));
            return new class_243(vec3d.method_10216() * (double)g - vec3d.method_10215() * (double)f, vec3d.method_10214(), vec3d.method_10215() * (double)g + vec3d.method_10216() * (double)f);
        }
        return currVelocity;
    }

    public void clear() {
        this.rotationPlanTaskProcessor.activeTasks.clear();
    }

    public void resetRotationPlan() {
        this.lastRotationPlan = null;
    }

    @EventHandler
    public void onPlayerVelocityStrafe(PlayerVelocityStrafeEvent e) {
        TurnsConstructor currentRotationPlan = this.getCurrentRotationPlan();
        if (currentRotationPlan != null && currentRotationPlan.isMoveCorrection()) {
            e.setVelocity(this.fixVelocity(e.getVelocity(), e.getMovementInput(), e.getSpeed()));
        }
    }

    @EventHandler
    public void onTick(TickEvent e) {
        EventManager.callEvent(new RotationUpdateEvent(0));
        this.update();
        EventManager.callEvent(new RotationUpdateEvent(2));
    }

    @EventHandler
    public void onPacket(PacketEvent event) {
        if (!event.isCancelled()) {
            class_2596<?> class_25962 = event.getPacket();
            Objects.requireNonNull(class_25962);
            class_2596<?> class_25963 = class_25962;
            int n = 0;
            block4: while (true) {
                switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{class_2828.class, class_2708.class}, class_25963, n)) {
                    case 0: {
                        class_2828 player = (class_2828)class_25963;
                        if (!player.method_36172()) {
                            n = 1;
                            continue block4;
                        }
                        this.serverAngle = new Turns(player.method_12271(1.0f), player.method_12270(1.0f));
                        break block4;
                    }
                    case 1: {
                        class_2708 player = (class_2708)class_25963;
                        this.serverAngle = new Turns(player.comp_3228().comp_3150(), player.comp_3228().comp_3151());
                        break block4;
                    }
                }
                break;
            }
        }
    }

    public TurnsConstructor getLastRotationPlan() {
        return this.lastRotationPlan;
    }

    public TaskProcessor<TurnsConstructor> getRotationPlanTaskProcessor() {
        return this.rotationPlanTaskProcessor;
    }

    public Turns getCurrentAngle() {
        return this.currentAngle;
    }

    public Turns getPreviousAngle() {
        return this.previousAngle;
    }

    public Turns getServerAngle() {
        return this.serverAngle;
    }

    public Turns getFakeAngle() {
        return this.fakeAngle;
    }
}

