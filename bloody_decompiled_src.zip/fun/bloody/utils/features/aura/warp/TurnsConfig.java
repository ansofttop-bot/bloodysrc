/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_243
 */
package fun.bloody.utils.features.aura.warp;

import fun.bloody.utils.features.aura.rotations.constructor.LinearConstructor;
import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.features.aura.warp.TurnsConstructor;
import net.minecraft.class_1297;
import net.minecraft.class_243;

public class TurnsConfig {
    public static TurnsConfig DEFAULT = new TurnsConfig(new LinearConstructor(), true, true);
    public static boolean moveCorrection;
    public static boolean freeCorrection;
    private final RotateConstructor angleSmooth;
    private final int resetThreshold = 1;

    public TurnsConfig(boolean moveCorrection, boolean freeCorrection) {
        this(new LinearConstructor(), moveCorrection, freeCorrection);
    }

    public TurnsConfig(boolean moveCorrection) {
        this(new LinearConstructor(), moveCorrection, true);
    }

    public TurnsConfig(RotateConstructor angleSmooth, boolean moveCorrection, boolean freeCorrection) {
        this.angleSmooth = angleSmooth;
        TurnsConfig.moveCorrection = moveCorrection;
        TurnsConfig.freeCorrection = freeCorrection;
    }

    public TurnsConstructor createRotationPlan(Turns angle, class_243 vec, class_1297 entity, int reset) {
        return new TurnsConstructor(angle, vec, entity, this.angleSmooth, reset, 1.0f, moveCorrection, freeCorrection);
    }

    public TurnsConstructor createRotationPlan(Turns angle, class_243 vec, class_1297 entity, boolean moveCorrection, boolean freeCorrection) {
        return new TurnsConstructor(angle, vec, entity, this.angleSmooth, 1, 1.0f, moveCorrection, freeCorrection);
    }
}

