/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1291
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1735
 *  net.minecraft.class_1743
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2848$class_2849
 *  net.minecraft.class_2868
 *  net.minecraft.class_2879
 *  net.minecraft.class_4050
 *  net.minecraft.class_6880
 */
package fun.bloody.utils.features.aura.striking;

import fun.bloody.events.item.UsingItemEvent;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.features.impl.combat.Aura;
import fun.bloody.features.impl.combat.TriggerBot;
import fun.bloody.features.impl.misc.MaceHelper;
import fun.bloody.features.impl.movement.AutoSprint;
import fun.bloody.main.listener.impl.EventListener;
import fun.bloody.utils.client.packet.network.Network;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.features.aura.striking.StrikerConstructor;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.utils.Pressing;
import fun.bloody.utils.features.aura.utils.RaycastAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.interactions.inv.InventoryFlowManager;
import fun.bloody.utils.interactions.inv.InventoryTask;
import fun.bloody.utils.interactions.simulate.PlayerSimulation;
import fun.bloody.utils.math.calc.Calculate;
import fun.bloody.utils.math.time.StopWatch;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1743;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_4050;
import net.minecraft.class_6880;

public class StrikeManager
implements QuickImports {
    private final StopWatch attackTimer = new StopWatch();
    private final StopWatch shieldWatch = new StopWatch();
    private final StopWatch sprintCooldown = new StopWatch();
    private final Pressing clickScheduler = new Pressing();
    private int count = 0;
    private boolean prevSprinting;
    private class_2848.class_2849 lastSprintCommand = null;
    private boolean pendingStartSprint = false;
    private boolean pendingStopSprint = false;
    private boolean didStopSprint = false;
    private static final long SPRINT_COOLDOWN_MS = 200L;

    void tick() {
        StrikerConstructor.AttackPerpetratorConfigurable config;
        String sprintMode = this.getSprintMode();
        if (sprintMode.equals("Funtime") && Aura.getInstance().isState() && Aura.getInstance().getTarget() != null && this.canAttack(config = Aura.getInstance().getConfig(), 1) && !this.canAttack(config, 0) && StrikeManager.mc.field_1724.method_5624() && this.getTargetDistance() <= (double)this.getAttackRange()) {
            AutoSprint.tickStop = 2;
            StrikeManager.mc.field_1690.field_1867.method_23481(false);
            StrikeManager.mc.field_1690.field_1894.method_23481(false);
            StrikeManager.mc.field_1724.method_5728(false);
        }
    }

    void onPacket(PacketEvent e) {
        class_2596<?> packet = e.getPacket();
        if (packet instanceof class_2879 || packet instanceof class_2868) {
            this.clickScheduler.recalculate();
        }
    }

    void onUsingItem(UsingItemEvent e) {
        if (e.getType() == -1 && !this.shieldWatch.finished(50.0)) {
            e.cancel();
        }
    }

    void handleAttack(StrikerConstructor.AttackPerpetratorConfigurable config) {
        boolean elytraMode;
        if (this.canAttack(config, 0)) {
            this.preAttackEntity(config);
        }
        boolean bl = elytraMode = Aura.getInstance().getTarget() != null && Aura.getInstance().getTarget().method_6128() && StrikeManager.mc.field_1724.method_6128();
        if (elytraMode) {
            class_243 lookVec;
            class_243 eyePos;
            class_243 targetVelocity = config.getTarget().method_18798();
            double targetSpeed = targetVelocity.method_37267();
            float leadTicks = 0.0f;
            class_243 predictedPos = config.getTarget().method_19538().method_1019(targetVelocity.method_1021((double)leadTicks));
            class_238 predictedBox = new class_238(predictedPos.field_1352 - (double)(config.getTarget().method_17681() / 2.0f), predictedPos.field_1351, predictedPos.field_1350 - (double)(config.getTarget().method_17681() / 2.0f), predictedPos.field_1352 + (double)(config.getTarget().method_17681() / 2.0f), predictedPos.field_1351 + (double)config.getTarget().method_17682(), predictedPos.field_1350 + (double)(config.getTarget().method_17681() / 2.0f));
            if (!predictedBox.method_992(eyePos = StrikeManager.mc.field_1724.method_33571(), eyePos.method_1019((lookVec = TurnsConnection.INSTANCE.getRotation().toVector()).method_1021((double)config.getMaximumRange()))).isPresent()) {
                return;
            }
            if (!RaycastAngle.rayTrace(config) || !this.canAttack(config, 0)) {
                return;
            }
        } else if (!RaycastAngle.rayTrace(config) || !this.canAttack(config, 0)) {
            return;
        }
        String sprintMode = this.getSprintMode();
        String aimMode = this.getAimMode();
        if (aimMode.equals("FunTime") && !this.isLookingAtTarget(config)) {
            return;
        }
        if (sprintMode.equals("\u041d\u0435\u0442")) {
            this.attackEntity(config);
            return;
        }
        if (sprintMode.equals("Legit") && !this.isSprinting()) {
            this.attackEntity(config);
        }
        if (sprintMode.equals("Packet")) {
            StrikeManager.mc.field_1724.method_5728(false);
            StrikeManager.mc.field_1724.method_46742();
            this.attackEntity(config);
        }
        if (sprintMode.equals("Funtime")) {
            StrikeManager.mc.field_1724.method_5728(false);
            this.attackEntity(config);
        }
    }

    private boolean isLookingAtTarget(StrikerConstructor.AttackPerpetratorConfigurable config) {
        if (config.getTarget() == null) {
            return false;
        }
        class_243 eyePos = StrikeManager.mc.field_1724.method_33571();
        class_243 lookVec = TurnsConnection.INSTANCE.getRotation().toVector();
        class_243 targetPos = config.getTarget().method_5829().method_1005();
        class_238 targetBox = config.getTarget().method_5829();
        return targetBox.method_992(eyePos, eyePos.method_1019(lookVec.method_1021((double)config.getMaximumRange()))).isPresent();
    }

    private String getAimMode() {
        if (Aura.getInstance().isState()) {
            return Aura.getInstance().getAimMode().getSelected();
        }
        return "Other";
    }

    private String getSprintMode() {
        if (Aura.getInstance().isState()) {
            return Aura.getInstance().getSprintReset().getSelected();
        }
        if (TriggerBot.getInstance().isState()) {
            return TriggerBot.getInstance().sprintReset.getSelected();
        }
        return "Legit";
    }

    void preAttackEntity(StrikerConstructor.AttackPerpetratorConfigurable config) {
        String sprintMode;
        if (config.isShouldUnPressShield() && StrikeManager.mc.field_1724.method_6115() && StrikeManager.mc.field_1724.method_6030().method_7909().equals(class_1802.field_8255)) {
            StrikeManager.mc.field_1761.method_2897((class_1657)StrikeManager.mc.field_1724);
            this.shieldWatch.reset();
        }
        if ((sprintMode = this.getSprintMode()).equals("\u041d\u0435\u0442")) {
            return;
        }
        if (sprintMode.equals("Legit")) {
            if (StrikeManager.mc.field_1724.method_5624() && this.getTargetDistance() <= (double)this.getAttackRange()) {
                AutoSprint.tickStop = 2;
                StrikeManager.mc.field_1690.field_1867.method_23481(false);
                StrikeManager.mc.field_1724.method_5728(false);
                return;
            }
            return;
        }
        if (sprintMode.equals("Funtime")) {
            return;
        }
    }

    void postAttackEntity(StrikerConstructor.AttackPerpetratorConfigurable config) {
        String sprintMode = this.getSprintMode();
        if (sprintMode.equals("Funtime")) {
            StrikeManager.mc.field_1690.field_1894.method_23481(false);
        }
    }

    void attackEntity(StrikerConstructor.AttackPerpetratorConfigurable config) {
        if (Aura.getInstance().isState() && Aura.getInstance().getAttackSetting().isSelected("Fake Lag")) {
            Aura.getInstance();
            Aura.tickStop = 1;
        }
        this.attack(config);
        this.breakShield(config);
        this.attackTimer.reset();
        ++this.count;
    }

    private void breakShield(StrikerConstructor.AttackPerpetratorConfigurable config) {
        class_1309 target = config.getTarget();
        Turns angleToPlayer = MathAngle.fromVec3d(StrikeManager.mc.field_1724.method_5829().method_1005().method_1020(target.method_33571()));
        boolean targetOnShield = target.method_6115() && target.method_6030().method_7909().equals(class_1802.field_8255);
        boolean angle = Math.abs(TurnsConnection.computeAngleDifference(target.method_36454(), angleToPlayer.getYaw())) < 90.0f;
        class_1735 axe = InventoryTask.getSlot(s -> s.method_7677().method_7909() instanceof class_1743);
        if (config.isShouldBreakShield() && targetOnShield && axe != null && angle && InventoryFlowManager.script.isFinished()) {
            InventoryTask.swapHand(axe, class_1268.field_5808, false);
            InventoryTask.closeScreen(true);
            this.attack(config);
            InventoryTask.swapHand(axe, class_1268.field_5808, false, true);
            InventoryTask.closeScreen(true);
        }
    }

    private void attack(StrikerConstructor.AttackPerpetratorConfigurable config) {
        float chance = Calculate.getRandom(0, 100);
        if (Aura.getInstance().isState() && Aura.getInstance().getAttackSetting().isSelected("Hit Chance")) {
            if (chance < Aura.getInstance().getHitChance().getValue()) {
                StrikeManager.mc.field_1761.method_2918((class_1657)StrikeManager.mc.field_1724, (class_1297)config.getTarget());
            }
        } else if (TriggerBot.getInstance().isState() && TriggerBot.getInstance().attackSetting.isSelected("Hit Chance")) {
            if (chance < TriggerBot.getInstance().hitChance.getValue()) {
                StrikeManager.mc.field_1761.method_2918((class_1657)StrikeManager.mc.field_1724, (class_1297)config.getTarget());
            }
        } else {
            StrikeManager.mc.field_1761.method_2918((class_1657)StrikeManager.mc.field_1724, (class_1297)config.getTarget());
        }
        StrikeManager.mc.field_1724.method_6104(class_1268.field_5808);
    }

    private boolean isSprinting() {
        return EventListener.serverSprint && !StrikeManager.mc.field_1724.method_6128() && !StrikeManager.mc.field_1724.method_5799();
    }

    private float getAttackRange() {
        if (Aura.getInstance().isState()) {
            return Aura.getInstance().getAttackRange().getValue();
        }
        if (TriggerBot.getInstance().isState()) {
            return TriggerBot.getInstance().attackRange.getValue();
        }
        return 3.0f;
    }

    private double getTargetDistance() {
        if (Aura.getInstance().isState() && Aura.getInstance().getTarget() != null) {
            return StrikeManager.mc.field_1724.method_5739((class_1297)Aura.getInstance().getTarget());
        }
        if (TriggerBot.getInstance().isState() && TriggerBot.getInstance().target != null) {
            return StrikeManager.mc.field_1724.method_5739((class_1297)TriggerBot.getInstance().target);
        }
        return 0.0;
    }

    public boolean canAttack(StrikerConstructor.AttackPerpetratorConfigurable config, int ticks) {
        String aimMode = this.getAimMode();
        if (aimMode.equals("FunTime")) {
            float tpsFactor = Network.TPS / 20.0f;
            ticks = Math.round((float)ticks * tpsFactor);
        }
        for (int i = 0; i <= ticks; ++i) {
            if (!this.canCrit(config, i)) continue;
            return true;
        }
        return false;
    }

    public boolean canCrit(StrikerConstructor.AttackPerpetratorConfigurable config, int ticks) {
        boolean isMaceInHand;
        if (StrikeManager.mc.field_1724.method_6115() && !StrikeManager.mc.field_1724.method_6030().method_7909().equals(class_1802.field_8255) && config.isEatAndAttack()) {
            return false;
        }
        if (!this.clickScheduler.isCooldownComplete(false, 1)) {
            return false;
        }
        PlayerSimulation simulated = PlayerSimulation.simulateLocalPlayer(ticks);
        boolean noRestrict = !this.hasMovementRestrictions(simulated);
        boolean critState = this.isPlayerInCriticalState(simulated, ticks);
        boolean bl = isMaceInHand = StrikeManager.mc.field_1724.method_6047().method_7909() == class_1802.field_49814;
        if (isMaceInHand && !StrikeManager.mc.field_1724.method_24828()) {
            boolean isFalling;
            boolean bl2 = isFalling = StrikeManager.mc.field_1724.method_18798().field_1351 < 0.0;
            if (MaceHelper.isUsingWindCharge()) {
                float cooldownProgress = StrikeManager.mc.field_1724.method_7261(0.5f);
                if (isFalling && StrikeManager.mc.field_1724.field_6017 >= 1.2f && cooldownProgress >= 0.85f) {
                    return true;
                }
            } else {
                float cooldownProgress = StrikeManager.mc.field_1724.method_7261(0.5f);
                if (isFalling && StrikeManager.mc.field_1724.field_6017 >= 0.8f && cooldownProgress >= 0.8f) {
                    return true;
                }
            }
            if (config.isOnlyCritical() && !noRestrict) {
                return false;
            }
        }
        if (Aura.getInstance().getSmartCrits().isValue() && Aura.getInstance().isState()) {
            if (noRestrict) {
                return critState || simulated.onGround;
            }
            return true;
        }
        if (TriggerBot.getInstance().smartCrits.isValue() && TriggerBot.getInstance().isState()) {
            if (noRestrict) {
                return critState || simulated.onGround;
            }
            return true;
        }
        if (config.isOnlyCritical() && !this.hasMovementRestrictions(simulated)) {
            return this.isPlayerInCriticalState(simulated, ticks);
        }
        return true;
    }

    private boolean hasMovementRestrictions(PlayerSimulation simulated) {
        return simulated.hasStatusEffect((class_6880<class_1291>)class_1294.field_5919) || simulated.hasStatusEffect((class_6880<class_1291>)class_1294.field_5902) || PlayerInteractionHelper.isBoxInBlock(simulated.boundingBox.method_1014(-0.001), class_2246.field_10343) || simulated.isSubmergedInWater() || simulated.isInLava() || simulated.isClimbing() || !PlayerInteractionHelper.canChangeIntoPose(class_4050.field_18076, simulated.pos) || simulated.player.method_31549().field_7479;
    }

    private boolean isPlayerInCriticalState(PlayerSimulation simulated, int ticks) {
        boolean fall = simulated.fallDistance > 0.0f;
        return !simulated.onGround && fall;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setPrevSprinting(boolean prevSprinting) {
        this.prevSprinting = prevSprinting;
    }

    public void setLastSprintCommand(class_2848.class_2849 lastSprintCommand) {
        this.lastSprintCommand = lastSprintCommand;
    }

    public void setPendingStartSprint(boolean pendingStartSprint) {
        this.pendingStartSprint = pendingStartSprint;
    }

    public void setPendingStopSprint(boolean pendingStopSprint) {
        this.pendingStopSprint = pendingStopSprint;
    }

    public void setDidStopSprint(boolean didStopSprint) {
        this.didStopSprint = didStopSprint;
    }

    public StopWatch getAttackTimer() {
        return this.attackTimer;
    }

    public StopWatch getShieldWatch() {
        return this.shieldWatch;
    }

    public StopWatch getSprintCooldown() {
        return this.sprintCooldown;
    }

    public Pressing getClickScheduler() {
        return this.clickScheduler;
    }

    public int getCount() {
        return this.count;
    }

    public boolean isPrevSprinting() {
        return this.prevSprinting;
    }

    public class_2848.class_2849 getLastSprintCommand() {
        return this.lastSprintCommand;
    }

    public boolean isPendingStartSprint() {
        return this.pendingStartSprint;
    }

    public boolean isPendingStopSprint() {
        return this.pendingStopSprint;
    }

    public boolean isDidStopSprint() {
        return this.didStopSprint;
    }
}

