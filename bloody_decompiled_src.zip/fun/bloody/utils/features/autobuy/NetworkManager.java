/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.features.autobuy;

import fun.bloody.utils.client.chat.ChatMessage;
import fun.bloody.utils.features.autobuy.BuyRequest;
import fun.bloody.utils.features.autobuy.ClientUpdateHandler;
import fun.bloody.utils.features.autobuy.CommandSender;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class NetworkManager {
    private static final int PORT = 20001;
    private static final int RECONNECT_DELAY = 2000;
    private ServerSocket serverSocket = null;
    private Socket clientSocket = null;
    private PrintWriter clientOut = null;
    private BufferedReader clientIn = null;
    private List<Socket> connections = new ArrayList<Socket>();
    private Map<Socket, PrintWriter> outs = new ConcurrentHashMap<Socket, PrintWriter>();
    private Map<Socket, BufferedReader> ins = new ConcurrentHashMap<Socket, BufferedReader>();
    private Map<Socket, Boolean> clientInAuction = new ConcurrentHashMap<Socket, Boolean>();
    private ExecutorService executorService = Executors.newFixedThreadPool(10, r -> {
        Thread t = new Thread(r);
        t.setDaemon(false);
        return t;
    });
    private volatile boolean running = false;
    private volatile boolean isClientMode = false;
    private long lastReconnectAttempt = 0L;
    private static boolean shutdownHookRegistered = false;
    private ConcurrentLinkedQueue<BuyRequest> queue = new ConcurrentLinkedQueue();
    private ConcurrentLinkedQueue<BuyRequest> priorityQueue = new ConcurrentLinkedQueue();

    public void start(String mode) {
        this.running = true;
        this.isClientMode = mode.equals("\u041f\u0440\u043e\u0432\u0435\u0440\u044f\u044e\u0449\u0438\u0439");
        if (!shutdownHookRegistered) {
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                if (this.running) {
                    // empty if block
                }
            }));
            shutdownHookRegistered = true;
        }
        this.executorService.execute(() -> this.connectionLoop(mode));
    }

    public void stop() {
        this.running = false;
        this.executorService.shutdownNow();
        this.executorService = Executors.newFixedThreadPool(10, r -> {
            Thread t = new Thread(r);
            t.setDaemon(false);
            return t;
        });
        this.stopAll();
    }

    private void connectionLoop(String mode) {
        while (this.running) {
            if (mode.equals("\u041f\u043e\u043a\u0443\u043f\u0430\u044e\u0449\u0438\u0439")) {
                this.startServer();
            } else if (mode.equals("\u041f\u0440\u043e\u0432\u0435\u0440\u044f\u044e\u0449\u0438\u0439")) {
                long currentTime = System.currentTimeMillis();
                if ((this.clientSocket == null || this.clientSocket.isClosed()) && currentTime - this.lastReconnectAttempt >= 2000L) {
                    this.startClient();
                    this.lastReconnectAttempt = currentTime;
                }
            }
            try {
                Thread.sleep(500L);
            }
            catch (InterruptedException interruptedException) {}
        }
    }

    private void startServer() {
        if (this.serverSocket == null || this.serverSocket.isClosed()) {
            try {
                this.serverSocket = new ServerSocket(20001);
                ChatMessage.brandmessage("\u0421\u0435\u0440\u0432\u0435\u0440 \u0437\u0430\u043f\u0443\u0449\u0435\u043d \u043d\u0430 \u043f\u043e\u0440\u0442\u0443 20001");
                this.executorService.execute(this::listenerThread);
            }
            catch (IOException e) {
                ChatMessage.brandmessage("\u041e\u0448\u0438\u0431\u043a\u0430 \u0437\u0430\u043f\u0443\u0441\u043a\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0430");
            }
        }
    }

    private void startClient() {
        try {
            this.clientSocket = new Socket("localhost", 20001);
            this.clientSocket.setTcpNoDelay(true);
            this.clientSocket.setSoTimeout(0);
            this.clientSocket.setKeepAlive(true);
            this.clientOut = new PrintWriter(this.clientSocket.getOutputStream(), true);
            this.clientIn = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));
            this.clientOut.println("connect");
            this.executorService.execute(this::clientReaderThread);
            ChatMessage.brandmessage("\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e \u043a \u043f\u043e\u043a\u0443\u043f\u0430\u044e\u0449\u0435\u043c\u0443 \u0430\u043a\u043a\u0430\u0443\u043d\u0442\u0443");
        }
        catch (IOException e) {
            this.clientSocket = null;
            this.clientOut = null;
            this.clientIn = null;
        }
    }

    private void listenerThread() {
        try {
            while (this.running && this.serverSocket != null && !this.serverSocket.isClosed()) {
                Socket conn = this.serverSocket.accept();
                conn.setTcpNoDelay(true);
                conn.setKeepAlive(true);
                conn.setSoTimeout(0);
                this.connections.add(conn);
                PrintWriter out = new PrintWriter(conn.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                this.outs.put(conn, out);
                this.ins.put(conn, in);
                this.clientInAuction.put(conn, false);
                ChatMessage.brandmessage("\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d \u0430\u043a\u043a\u0430\u0443\u043d\u0442 \u0441 \u043f\u0440\u043e\u0432\u0435\u0440\u044f\u044e\u0449\u0438\u043c");
                this.executorService.execute(() -> this.readerThread(conn));
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void readerThread(Socket conn) {
        try {
            String line;
            BufferedReader in = this.ins.get(conn);
            while ((line = in.readLine()) != null) {
                PrintWriter out;
                if (line.startsWith("buy:")) {
                    this.handleBuyMessage(line);
                    continue;
                }
                if (line.equals("enter_auction")) {
                    this.clientInAuction.put(conn, true);
                    continue;
                }
                if (line.equals("leave_auction")) {
                    this.clientInAuction.put(conn, false);
                    continue;
                }
                if (!line.equals("ping") || (out = this.outs.get(conn)) == null) continue;
                out.println("pong");
            }
        }
        catch (IOException iOException) {
        }
        finally {
            this.removeConnection(conn);
        }
    }

    private void handleBuyMessage(String line) {
        try {
            String[] parts = line.substring(4).split("\\|");
            if (parts.length == 2) {
                String itemName = parts[0];
                int price = Integer.parseInt(parts[1]);
                BuyRequest request = new BuyRequest(itemName, price);
                this.priorityQueue.add(request);
            }
        }
        catch (NumberFormatException numberFormatException) {
            // empty catch block
        }
    }

    private void clientReaderThread() {
        try {
            String line;
            while ((line = this.clientIn.readLine()) != null) {
                if (line.equals("update_now")) {
                    ClientUpdateHandler.handleUpdate();
                    continue;
                }
                if (line.startsWith("switch_server:")) {
                    String cmd = line.substring(14);
                    CommandSender.handleServerSwitch(cmd);
                    continue;
                }
                if (line.equals("open_auction")) {
                    CommandSender.openAuction();
                    continue;
                }
                if (!line.equals("pong")) continue;
            }
        }
        catch (IOException iOException) {
        }
        finally {
            this.stopClient();
            if (this.running && this.isClientMode) {
                try {
                    Thread.sleep(2000L);
                }
                catch (InterruptedException interruptedException) {}
            }
        }
    }

    private void removeConnection(Socket conn) {
        this.connections.remove(conn);
        this.outs.remove(conn);
        this.ins.remove(conn);
        this.clientInAuction.remove(conn);
        try {
            conn.close();
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    private void stopAll() {
        this.queue.clear();
        this.priorityQueue.clear();
        if (this.serverSocket != null) {
            try {
                this.serverSocket.close();
            }
            catch (IOException iOException) {
                // empty catch block
            }
            this.serverSocket = null;
        }
        for (Socket conn : new ArrayList<Socket>(this.connections)) {
            this.removeConnection(conn);
        }
        this.stopClient();
    }

    private void stopClient() {
        if (this.clientSocket != null) {
            try {
                this.clientSocket.close();
            }
            catch (IOException iOException) {
                // empty catch block
            }
            this.clientSocket = null;
        }
        this.clientOut = null;
        this.clientIn = null;
    }

    public void sendToAllClients(String message) {
        ArrayList<Socket> deadConnections = new ArrayList<Socket>();
        for (Socket conn : new ArrayList<Socket>(this.connections)) {
            PrintWriter out = this.outs.get(conn);
            if (out == null) continue;
            try {
                out.println(message);
                if (!out.checkError()) continue;
                deadConnections.add(conn);
            }
            catch (Exception e) {
                deadConnections.add(conn);
            }
        }
        for (Socket conn : deadConnections) {
            this.removeConnection(conn);
        }
    }

    public void sendBuy(String itemName, int price) {
        if (this.clientOut != null) {
            try {
                this.clientOut.println("buy:" + itemName + "|" + price);
                if (this.clientOut.checkError()) {
                    this.stopClient();
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    public void notifyAuctionEnter() {
        if (this.clientOut != null) {
            try {
                this.clientOut.println("enter_auction");
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    public void notifyAuctionLeave() {
        if (this.clientOut != null) {
            try {
                this.clientOut.println("leave_auction");
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    public void sendUpdateToClients() {
        this.sendToAllClients("update_now");
    }

    public void requestAuctionOpen() {
        this.sendToAllClients("open_auction");
    }

    public long getClientInAuctionCount() {
        return this.clientInAuction.values().stream().filter(Boolean::booleanValue).count();
    }

    public boolean hasConnectedClients() {
        return !this.connections.isEmpty();
    }

    public boolean isConnectedToServer() {
        return this.clientSocket != null && !this.clientSocket.isClosed() && this.clientOut != null;
    }

    public BuyRequest pollRequest() {
        BuyRequest request = this.priorityQueue.poll();
        if (request == null) {
            request = this.queue.poll();
        }
        return request;
    }

    public int getQueueSize() {
        return this.priorityQueue.size() + this.queue.size();
    }

    public boolean isQueuesEmpty() {
        return this.priorityQueue.isEmpty() && this.queue.isEmpty();
    }

    public void clearQueues() {
        this.queue.clear();
        this.priorityQueue.clear();
    }
}

