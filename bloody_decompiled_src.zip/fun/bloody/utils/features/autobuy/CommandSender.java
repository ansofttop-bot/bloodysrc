/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 *  net.minecraft.class_2797
 *  net.minecraft.class_310
 *  net.minecraft.class_746
 *  net.minecraft.class_7635$class_7636
 */
package fun.bloody.utils.features.autobuy;

import fun.bloody.utils.features.autobuy.ServerSwitchHandler;
import java.time.Instant;
import java.util.BitSet;
import net.minecraft.class_2596;
import net.minecraft.class_2797;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_7635;

public class CommandSender {
    private static class_310 mc = class_310.method_1551();

    public static void sendCommand(class_746 player, String command) {
        if (player != null && player.field_3944 != null) {
            player.field_3944.method_52787((class_2596)new class_2797(command, Instant.now(), 0L, null, new class_7635.class_7636(0, new BitSet())));
        }
    }

    public static void handleServerSwitch(String cmd) {
        if (CommandSender.mc.field_1724 != null && CommandSender.mc.field_1724.field_3944 != null) {
            CommandSender.mc.field_1724.field_3944.method_52787((class_2596)new class_2797(cmd, Instant.now(), 0L, null, new class_7635.class_7636(0, new BitSet())));
            ServerSwitchHandler.setWaitingForServerLoad(true);
            ServerSwitchHandler.setServerSwitchTime(System.currentTimeMillis());
        }
    }

    public static void openAuction() {
        if (CommandSender.mc.field_1724 != null && CommandSender.mc.field_1724.field_3944 != null) {
            CommandSender.mc.field_1724.field_3944.method_52787((class_2596)new class_2797("/ah", Instant.now(), 0L, null, new class_7635.class_7636(0, new BitSet())));
        }
    }
}

