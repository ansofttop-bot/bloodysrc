/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.utils.features.autobuy;

public class BuyRequest {
    public String itemName;
    public int price;

    public BuyRequest(String itemName, int price) {
        this.itemName = itemName;
        this.price = price;
    }
}

