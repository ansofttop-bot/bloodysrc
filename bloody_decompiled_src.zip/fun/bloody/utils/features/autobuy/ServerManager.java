/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_266
 *  net.minecraft.class_269
 *  net.minecraft.class_638
 *  net.minecraft.class_746
 *  net.minecraft.class_8646
 */
package fun.bloody.utils.features.autobuy;

import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.utils.features.autobuy.CommandSender;
import fun.bloody.utils.features.autobuy.NetworkManager;
import fun.bloody.utils.math.time.TimerUtil;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_8646;

public class ServerManager {
    private List<String> anarchyServers165 = new ArrayList<String>();
    private List<String> anarchyServers214 = new ArrayList<String>();
    private int currentServerIndex = 0;
    private String currentServer = "";
    private boolean inHub = false;
    private boolean waitingForServerLoad = false;
    private TimerUtil hubCheckTimer = TimerUtil.create();
    private TimerUtil serverSwitchCooldown = TimerUtil.create();
    private BooleanSetting bypassDelay;
    private BooleanSetting bypassDelay1214;

    public ServerManager(BooleanSetting bypassDelay, BooleanSetting bypassDelay1214) {
        this.bypassDelay = bypassDelay;
        this.bypassDelay1214 = bypassDelay1214;
        this.initializeServers();
    }

    private void initializeServers() {
        int i;
        this.anarchyServers165.addAll(List.of("/an102", "/an103", "/an104", "/an105", "/an106", "/an107"));
        for (i = 203; i <= 221; ++i) {
            this.anarchyServers165.add("/an" + i);
        }
        for (i = 302; i <= 313; ++i) {
            this.anarchyServers165.add("/an" + i);
        }
        this.anarchyServers165.addAll(List.of("/an502", "/an503", "/an504", "/an505", "/an506", "/an507", "/an602"));
        for (i = 11; i <= 14; ++i) {
            this.anarchyServers214.add("/an" + i);
        }
        for (i = 21; i <= 27; ++i) {
            this.anarchyServers214.add("/an" + i);
        }
        for (i = 31; i <= 34; ++i) {
            this.anarchyServers214.add("/an" + i);
        }
        for (i = 51; i <= 53; ++i) {
            this.anarchyServers214.add("/an" + i);
        }
        this.anarchyServers214.add("/an91");
    }

    public void resetTimers() {
        this.hubCheckTimer.resetCounter();
        this.serverSwitchCooldown.resetCounter();
    }

    public void reset() {
        this.currentServerIndex = 0;
        this.currentServer = "";
        this.inHub = false;
        this.waitingForServerLoad = false;
    }

    public void updateHubStatus(class_638 world) {
        this.inHub = this.isInHubInternal(world);
    }

    private boolean isInHubInternal(class_638 world) {
        if (world == null) {
            return true;
        }
        class_269 scoreboard = world.method_8428();
        class_266 objective = scoreboard.method_1189(class_8646.field_45157);
        if (objective == null) {
            return true;
        }
        String displayName = objective.method_1114().getString();
        return !displayName.contains("\u0410\u043d\u0430\u0440\u0445\u0438\u044f-");
    }

    private int getCurrentAnarchyNumber(class_638 world) {
        String[] parts;
        String displayName;
        if (world == null) {
            return -1;
        }
        class_269 scoreboard = world.method_8428();
        class_266 objective = scoreboard.method_1189(class_8646.field_45157);
        if (objective != null && (displayName = objective.method_1114().getString()).contains("\u0410\u043d\u0430\u0440\u0445\u0438\u044f-") && (parts = displayName.split("-")).length > 1) {
            try {
                return Integer.parseInt(parts[1].trim());
            }
            catch (NumberFormatException e) {
                return -1;
            }
        }
        return -1;
    }

    private String getNextServer(List<String> servers, class_638 world) {
        String currentServerCmd;
        int currentIdx;
        if (servers.isEmpty()) {
            return null;
        }
        int currentAnarchy = this.getCurrentAnarchyNumber(world);
        if (currentAnarchy != -1 && (currentIdx = servers.indexOf(currentServerCmd = "/an" + currentAnarchy)) != -1) {
            this.currentServerIndex = currentIdx;
        }
        this.currentServerIndex = (this.currentServerIndex + 1) % servers.size();
        return servers.get(this.currentServerIndex);
    }

    public void switchToNextServer(class_746 player, NetworkManager networkManager, boolean isBuyer) {
        if (!this.serverSwitchCooldown.hasTimeElapsed(3000L)) {
            return;
        }
        if (!isBuyer) {
            return;
        }
        List<String> availableServers = this.getAvailableServers();
        if (availableServers == null) {
            return;
        }
        class_638 world = (class_638)player.method_37908();
        String newServer = this.getNextServer(availableServers, world);
        if (newServer != null) {
            this.currentServer = newServer;
            CommandSender.sendCommand(player, newServer);
            networkManager.sendToAllClients("switch_server:" + newServer);
            this.waitingForServerLoad = true;
            this.serverSwitchCooldown.resetCounter();
        }
    }

    public void joinAnarchyFromHub(class_746 player) {
        List<String> availableServers = this.getAvailableServers();
        if (availableServers == null || availableServers.isEmpty()) {
            return;
        }
        String server = availableServers.get(0);
        CommandSender.sendCommand(player, server);
        this.waitingForServerLoad = true;
        this.hubCheckTimer.resetCounter();
    }

    private List<String> getAvailableServers() {
        if (this.bypassDelay1214.isValue()) {
            return new ArrayList<String>(this.anarchyServers214);
        }
        if (this.bypassDelay.isValue()) {
            return new ArrayList<String>(this.anarchyServers165);
        }
        return null;
    }

    public boolean shouldJoinAnarchy(boolean bypass165, boolean bypass1214) {
        return this.inHub && this.hubCheckTimer.hasTimeElapsed(3000L) && (bypass165 || bypass1214);
    }

    public boolean isInHub() {
        return this.inHub;
    }

    public boolean isWaitingForServerLoad() {
        return this.waitingForServerLoad;
    }

    public void setWaitingForServerLoad(boolean value) {
        this.waitingForServerLoad = value;
    }
}

