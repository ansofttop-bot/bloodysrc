/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1657
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 *  net.minecraft.class_476
 */
package fun.bloody.utils.features.autobuy;

import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_476;

public class ClientUpdateHandler {
    private static class_310 mc = class_310.method_1551();

    public static void handleUpdate() {
        class_437 class_4372 = ClientUpdateHandler.mc.field_1755;
        if (class_4372 instanceof class_476) {
            class_476 screen = (class_476)class_4372;
            int syncId = ((class_1707)screen.method_17577()).field_7763;
            ClientUpdateHandler.mc.field_1761.method_2906(syncId, 49, 0, class_1713.field_7794, (class_1657)ClientUpdateHandler.mc.field_1724);
        }
    }
}

