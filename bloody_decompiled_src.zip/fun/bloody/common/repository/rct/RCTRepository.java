/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_2596
 *  net.minecraft.class_437
 *  net.minecraft.class_476
 *  net.minecraft.class_7439
 */
package fun.bloody.common.repository.rct;

import fun.bloody.display.hud.Notifications;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.client.packet.network.Network;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.display.interfaces.QuickLogger;
import fun.bloody.utils.interactions.inv.InventoryTask;
import fun.bloody.utils.math.time.StopWatch;
import net.minecraft.class_124;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_2596;
import net.minecraft.class_437;
import net.minecraft.class_476;
import net.minecraft.class_7439;

public class RCTRepository
implements QuickImports,
QuickLogger {
    private final StopWatch stopWatch = new StopWatch();
    private boolean lobby;
    private int anarchy;

    public RCTRepository(EventManager eventManager) {
        eventManager.register(this);
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        class_7439 message;
        String text;
        class_2596<?> class_25962;
        if (this.anarchy != 0 && (class_25962 = e.getPacket()) instanceof class_7439 && !(text = (message = (class_7439)class_25962).comp_763().getString().toLowerCase()).contains("\u0445\u0430\u0431") && text.contains("\u043d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c")) {
            Notifications.getInstance().addList("[RCT] \u041d\u0430 \u0434\u0430\u043d\u043d\u0443\u044e \u0430\u043d\u0430\u0440\u0445\u0438\u044e " + String.valueOf(class_124.field_1061) + "\u043d\u0435\u043b\u044c\u0437\u044f" + String.valueOf(class_124.field_1070) + " \u0437\u0430\u0439\u0442\u0438", 3000L);
            this.anarchy = 0;
        }
    }

    @EventHandler
    public void onTick(TickEvent e) {
        class_476 screen;
        if (this.anarchy == 0) {
            return;
        }
        if (!Network.isHolyWorld()) {
            this.anarchy = 0;
            return;
        }
        int currentAnarchy = Network.getAnarchy();
        if (this.lobby) {
            if (currentAnarchy == -1) {
                this.lobby = false;
            } else {
                RCTRepository.mc.field_1724.field_3944.method_45730("hub");
            }
            return;
        }
        if (currentAnarchy == this.anarchy) {
            this.anarchy = 0;
            return;
        }
        class_437 class_4372 = RCTRepository.mc.field_1755;
        if (class_4372 instanceof class_476 && (screen = (class_476)class_4372).method_25440().getString().equals("\u0412\u044b\u0431\u043e\u0440 \u041b\u0430\u0439\u0442 \u0430\u043d\u0430\u0440\u0445\u0438\u0438:")) {
            int[] nArray;
            boolean secondScreen;
            boolean bl = secondScreen = ((class_1707)screen.method_17577()).method_7629().method_5439() < 10;
            if (this.anarchy < 15) {
                int[] nArray2 = new int[2];
                nArray2[0] = 0;
                nArray = nArray2;
                nArray2[1] = 0;
            } else if (this.anarchy < 33) {
                int[] nArray3 = new int[2];
                nArray3[0] = 1;
                nArray = nArray3;
                nArray3[1] = 14;
            } else if (this.anarchy < 48) {
                int[] nArray4 = new int[2];
                nArray4[0] = 2;
                nArray = nArray4;
                nArray4[1] = 32;
            } else {
                int[] nArray5 = new int[2];
                nArray5[0] = 3;
                nArray = nArray5;
                nArray5[1] = 47;
            }
            int[] slots = nArray;
            if (secondScreen) {
                InventoryTask.clickSlot(slots[0], 0, class_1713.field_7790, false);
            } else {
                InventoryTask.clickSlot(17 + this.anarchy - slots[1], 0, class_1713.field_7790, false);
            }
            return;
        }
        if (this.stopWatch.every(500.0)) {
            RCTRepository.mc.field_1724.field_3944.method_45730("lite");
        }
    }

    public void reconnect(int anarchy) {
        if (anarchy > 0 && anarchy < 64) {
            this.anarchy = anarchy;
            this.lobby = true;
        } else {
            Notifications.getInstance().addList("[RCT] \u041d\u0435 \u0432\u0435\u0440\u043d\u044b\u0439 " + String.valueOf(class_124.field_1061) + "\u043b\u0430\u0439\u0442", 3000L);
        }
    }
}

