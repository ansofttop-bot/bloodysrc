/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.common.repository.macro;

public record Macro(String name, String message, int key) {
}

