/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_243
 *  net.minecraft.class_4587
 */
package fun.bloody.common.repository.way;

import fun.bloody.common.repository.way.Way;
import fun.bloody.events.render.DrawEvent;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.display.interfaces.QuickLogger;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import fun.bloody.utils.math.projection.Projection;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4587;

public class WayRepository
implements QuickImports,
QuickLogger {
    public List<Way> wayList = new ArrayList<Way>();

    public WayRepository(EventManager eventManager) {
        eventManager.register(this);
    }

    public boolean isEmpty() {
        return this.wayList.isEmpty();
    }

    public void addWay(String name, class_2338 pos, String server) {
        this.wayList.add(new Way(name, pos, server));
    }

    public boolean hasWay(String text) {
        return this.wayList.stream().anyMatch(s -> s.name().equalsIgnoreCase(text));
    }

    public void deleteWay(String name) {
        this.wayList.removeIf(macro -> macro.name().equalsIgnoreCase(name));
    }

    public void clearList() {
        if (!this.isEmpty()) {
            this.wayList.clear();
        }
    }

    @EventHandler
    public void onDraw(DrawEvent e) {
        if (this.isEmpty() || mc.method_1562() == null || mc.method_1562().method_45734() == null) {
            return;
        }
        class_4587 matrix = e.getDrawContext().method_51448();
        this.wayList.forEach(way -> {
            class_243 wayVec = way.pos().method_46558();
            class_243 vec = Projection.worldSpaceToScreenSpace(wayVec);
            if (Projection.canSee(wayVec) && way.server().equalsIgnoreCase(WayRepository.mc.method_1562().method_45734().field_3761)) {
                String text = way.name() + " - " + Calculate.round(WayRepository.mc.method_1561().field_4686.method_19326().method_1022(wayVec), 0.1f) + "m";
                FontRenderer font = Fonts.getSize(14, Fonts.Type.SEMI);
                float height = font.getStringHeight(text) / 4.0f;
                float width = font.getStringWidth(text);
                float padding = 3.0f;
                double x = vec.method_10216() - (double)(width / 2.0f);
                double y = vec.method_10214() - (double)(height / 2.0f);
                rectangle.render(ShapeProperties.create(matrix, x - (double)padding, y - (double)padding, width + padding * 2.0f, height + padding * 2.0f).round(2.0f).thickness(2.0f).outlineColor(new Color(55, 52, 55, 155).getRGB()).color(new Color(19, 19, 21, 225).getRGB(), new Color(19, 19, 21, 225).getRGB(), new Color(19, 19, 21, 225).getRGB(), new Color(19, 19, 21, 225).getRGB()).build());
                font.drawString(matrix, text, x, y + 0.5, ColorAssist.getText());
            }
        });
    }
}

