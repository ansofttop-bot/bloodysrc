/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.common.repository.friend;

public class Friend {
    String name;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Friend(String name) {
        this.name = name;
    }
}

