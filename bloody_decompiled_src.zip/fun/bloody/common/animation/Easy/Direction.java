/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.common.animation.Easy;

public enum Direction {
    FORWARDS,
    BACKWARDS;


    public Direction opposite() {
        if (this == FORWARDS) {
            return BACKWARDS;
        }
        return FORWARDS;
    }
}

