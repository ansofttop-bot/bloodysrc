/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.common.animation;

public enum Direction {
    FORWARDS,
    BACKWARDS;

}

