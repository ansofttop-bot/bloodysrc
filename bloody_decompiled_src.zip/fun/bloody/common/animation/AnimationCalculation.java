/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.common.animation;

public interface AnimationCalculation {
    default public double calculation(double value) {
        return 0.0;
    }
}

