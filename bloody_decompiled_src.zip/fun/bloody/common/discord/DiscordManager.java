/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2960
 */
package fun.bloody.common.discord;

import antidaunleak.api.UserProfile;
import fun.bloody.Bloody;
import fun.bloody.common.discord.utils.DiscordEventHandlers;
import fun.bloody.common.discord.utils.DiscordRPC;
import fun.bloody.common.discord.utils.DiscordRichPresence;
import fun.bloody.common.discord.utils.RPCButton;
import fun.bloody.utils.client.discord.Buffer;
import fun.bloody.utils.display.interfaces.QuickImports;
import java.io.IOException;
import net.minecraft.class_2960;

public class DiscordManager
implements QuickImports {
    private final DiscordDaemonThread discordDaemonThread = new DiscordDaemonThread();
    private boolean running = true;
    private DiscordInfo info = new DiscordInfo("Unknown", "", "");
    private class_2960 avatarId;

    public void init() {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("linux")) {
            return;
        }
        DiscordEventHandlers handlers = new DiscordEventHandlers.Builder().ready(user -> {
            Bloody.getInstance().getDiscordManager().setInfo(new DiscordInfo(user.username, "https://cdn.discordapp.com/avatars/" + user.userId + "/" + user.avatar + ".png", user.userId));
            DiscordRichPresence richPresence = new DiscordRichPresence.Builder().setStartTimestamp(System.currentTimeMillis() / 1000L).setDetails("User: " + UserProfile.getInstance().profile("username")).setState("Uid: " + UserProfile.getInstance().profile("uid")).setLargeImage("https://i.postimg.cc/nznMWbhM/0001-0250.gif", "https://bloody.fun/").setSmallImage(Bloody.getInstance().getDiscordManager().getInfo().avatarUrl, "https://bloody.fun/").setButtons(RPCButton.create("\u0422\u0435\u043b\u0435\u0433\u0440\u0430\u043c", "https://t.me/bloodyclient"), RPCButton.create("\u0414\u0438\u0441\u043a\u043e\u0440\u0434", "https://discord.gg/zYctK4mjZZ")).build();
            DiscordRPC.INSTANCE.Discord_UpdatePresence(richPresence);
        }).build();
        DiscordRPC.INSTANCE.Discord_Initialize("1419653405265105021", handlers, true, "");
        this.discordDaemonThread.start();
    }

    public void stopRPC() {
        DiscordRPC.INSTANCE.Discord_Shutdown();
        this.running = false;
    }

    public void load() throws IOException {
        if (this.avatarId == null && !this.info.avatarUrl.isEmpty()) {
            this.avatarId = Buffer.registerDynamicTexture("avatar-", Buffer.getHeadFromURL(this.info.avatarUrl));
        }
    }

    public class_2960 getAvatarId() {
        return this.avatarId;
    }

    public void setRunning(boolean running) {
        this.running = running;
    }

    public void setInfo(DiscordInfo info) {
        this.info = info;
    }

    public void setAvatarId(class_2960 avatarId) {
        this.avatarId = avatarId;
    }

    public DiscordDaemonThread getDiscordDaemonThread() {
        return this.discordDaemonThread;
    }

    public boolean isRunning() {
        return this.running;
    }

    public DiscordInfo getInfo() {
        return this.info;
    }

    private class DiscordDaemonThread
    extends Thread {
        private DiscordDaemonThread() {
        }

        @Override
        public void run() {
            this.setName("Discord-RPC");
            try {
                while (Bloody.getInstance().getDiscordManager().isRunning()) {
                    DiscordRPC.INSTANCE.Discord_RunCallbacks();
                    DiscordManager.this.load();
                    Thread.sleep(15000L);
                }
            }
            catch (Exception exception) {
                DiscordManager.this.stopRPC();
            }
            super.run();
        }
    }

    public record DiscordInfo(String userName, String avatarUrl, String userId) {
    }
}

