/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.sun.jna.Callback
 */
package fun.bloody.common.discord.callbacks;

import com.sun.jna.Callback;

public interface ErroredCallback
extends Callback {
    public void apply(int var1, String var2);
}

