/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.bootstrap.Bootstrap
 *  io.netty.bootstrap.ServerBootstrap
 *  io.netty.buffer.ByteBuf
 *  io.netty.channel.Channel
 *  io.netty.channel.ChannelFutureListener
 *  io.netty.channel.ChannelHandler
 *  io.netty.channel.ChannelHandlerContext
 *  io.netty.channel.ChannelInboundHandlerAdapter
 *  io.netty.channel.ChannelInitializer
 *  io.netty.channel.ChannelOption
 *  io.netty.channel.EventLoopGroup
 *  io.netty.channel.nio.NioEventLoopGroup
 *  io.netty.channel.socket.SocketChannel
 *  io.netty.channel.socket.nio.NioServerSocketChannel
 *  io.netty.channel.socket.nio.NioSocketChannel
 *  io.netty.util.concurrent.GenericFutureListener
 */
package fun.bloody.common.proxy;

import io.netty.bootstrap.Bootstrap;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.util.concurrent.GenericFutureListener;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class FakerProxy {
    private EventLoopGroup bossGroup;
    private EventLoopGroup workerGroup;
    private Channel listenChannel;
    private volatile boolean running = false;
    private String targetHost;
    private int targetPort;
    private int localPort;
    private String handshakeHost;
    volatile Channel serverChannel;
    volatile boolean serverReady = false;
    final List<byte[]> cachedServerPackets = new CopyOnWriteArrayList<byte[]>();
    volatile ClientSlot activeSlot;
    volatile ClientSlot standbySlot;
    final Object lock = new Object();
    private static boolean shutdownHookRegistered = false;

    private void log(String msg) {
    }

    public synchronized void start(String targetHost, int targetPort, int localPort, String handshakeHost) throws Exception {
        if (this.running) {
            throw new IllegalStateException("Already running");
        }
        this.targetHost = targetHost;
        this.targetPort = targetPort;
        this.localPort = localPort;
        this.handshakeHost = handshakeHost;
        this.cachedServerPackets.clear();
        this.activeSlot = null;
        this.standbySlot = null;
        this.serverChannel = null;
        this.serverReady = false;
        this.bossGroup = new NioEventLoopGroup(1, r -> {
            Thread t = new Thread(r);
            t.setDaemon(false);
            t.setName("Faker-Boss");
            return t;
        });
        this.workerGroup = new NioEventLoopGroup(0, r -> {
            Thread t = new Thread(r);
            t.setDaemon(false);
            t.setName("Faker-Worker");
            return t;
        });
        ServerBootstrap b = new ServerBootstrap();
        ((ServerBootstrap)b.group(this.bossGroup, this.workerGroup).channel(NioServerSocketChannel.class)).childHandler((ChannelHandler)new ChannelInitializer<SocketChannel>(){

            protected void initChannel(SocketChannel ch) {
                ch.pipeline().addLast(new ChannelHandler[]{new IncomingClientHandler(FakerProxy.this)});
            }
        }).option(ChannelOption.SO_BACKLOG, (Object)128);
        this.listenChannel = b.bind("0.0.0.0", localPort).sync().channel();
        this.running = true;
        if (!shutdownHookRegistered) {
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                if (this.running) {
                    this.log("\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u0435\u0442\u0441\u044f, \u043d\u043e \u043f\u0440\u043e\u043a\u0441\u0438 \u043f\u0440\u043e\u0434\u043e\u043b\u0436\u0430\u0435\u0442 \u0440\u0430\u0431\u043e\u0442\u0430\u0442\u044c...");
                }
            }));
            shutdownHookRegistered = true;
        }
        this.log("Started on :" + localPort + " -> " + targetHost + ":" + targetPort);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public synchronized void stop() {
        if (!this.running) {
            return;
        }
        this.running = false;
        Object object = this.lock;
        synchronized (object) {
            if (this.activeSlot != null) {
                this.activeSlot.close();
                this.activeSlot = null;
            }
            if (this.standbySlot != null) {
                this.standbySlot.close();
                this.standbySlot = null;
            }
            if (this.serverChannel != null) {
                this.serverChannel.close();
                this.serverChannel = null;
            }
        }
        this.cachedServerPackets.clear();
        if (this.listenChannel != null) {
            this.listenChannel.close();
            this.listenChannel = null;
        }
        if (this.bossGroup != null) {
            this.bossGroup.shutdownGracefully();
            this.bossGroup = null;
        }
        if (this.workerGroup != null) {
            this.workerGroup.shutdownGracefully();
            this.workerGroup = null;
        }
        this.log("Stopped");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    void onNewClient(Channel ch) {
        InetSocketAddress addr = (InetSocketAddress)ch.remoteAddress();
        String info = addr.getAddress().getHostAddress() + ":" + addr.getPort();
        Object object = this.lock;
        synchronized (object) {
            if (this.activeSlot == null) {
                this.log("[" + info + "] -> ACTIVE (first client)");
                this.activeSlot = new ClientSlot(ch, true);
                this.connectToServer(ch);
            } else if (this.standbySlot == null) {
                this.log("[" + info + "] -> STANDBY (second client)");
                this.standbySlot = new ClientSlot(ch, false);
                this.replayCachedData(ch);
            } else {
                this.log("[" + info + "] -> REJECTED (slots full)");
                ch.close();
            }
        }
    }

    private void connectToServer(Channel clientCh) {
        Bootstrap b = new Bootstrap();
        ((Bootstrap)((Bootstrap)((Bootstrap)b.group(this.workerGroup)).channel(NioSocketChannel.class)).option(ChannelOption.CONNECT_TIMEOUT_MILLIS, (Object)10000)).handler((ChannelHandler)new ChannelInitializer<SocketChannel>(){

            protected void initChannel(SocketChannel ch) {
                ch.pipeline().addLast(new ChannelHandler[]{new ServerDataHandler(FakerProxy.this)});
            }
        });
        b.connect(this.targetHost, this.targetPort).addListener((GenericFutureListener)((ChannelFutureListener)f -> {
            if (f.isSuccess()) {
                this.serverChannel = f.channel();
                this.log("Connected to server " + this.targetHost + ":" + this.targetPort);
                clientCh.config().setAutoRead(true);
                clientCh.read();
            } else {
                this.log("Server connect failed: " + f.cause().getMessage());
                clientCh.close();
            }
        }));
    }

    private void replayCachedData(Channel ch) {
        this.log("Replaying " + this.cachedServerPackets.size() + " cached packets to standby client...");
        for (byte[] data : this.cachedServerPackets) {
            if (!ch.isActive()) continue;
            ByteBuf buf = ch.alloc().buffer(data.length);
            buf.writeBytes(data);
            ch.write((Object)buf);
        }
        ch.flush();
        ch.config().setAutoRead(true);
        ch.read();
        this.log("Replay complete, standby client should see the game now");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    void onServerData(ByteBuf data) {
        byte[] copy = new byte[data.readableBytes()];
        data.getBytes(data.readerIndex(), copy);
        this.cachedServerPackets.add(copy);
        Object object = this.lock;
        synchronized (object) {
            ByteBuf buf;
            if (this.activeSlot != null && this.activeSlot.channel.isActive()) {
                buf = this.activeSlot.channel.alloc().buffer(copy.length);
                buf.writeBytes(copy);
                this.activeSlot.channel.writeAndFlush((Object)buf);
            }
            if (this.standbySlot != null && this.standbySlot.channel.isActive()) {
                buf = this.standbySlot.channel.alloc().buffer(copy.length);
                buf.writeBytes(copy);
                this.standbySlot.channel.writeAndFlush((Object)buf);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    void onClientData(Channel clientCh, ByteBuf data) {
        Object object = this.lock;
        synchronized (object) {
            boolean isActive;
            boolean bl = isActive = this.activeSlot != null && this.activeSlot.channel == clientCh;
            if (isActive && this.serverChannel != null && this.serverChannel.isActive()) {
                byte[] copy = new byte[data.readableBytes()];
                data.getBytes(data.readerIndex(), copy);
                ByteBuf buf = this.serverChannel.alloc().buffer(copy.length);
                buf.writeBytes(copy);
                this.serverChannel.writeAndFlush((Object)buf);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    void onClientDisconnected(Channel clientCh) {
        Object object = this.lock;
        synchronized (object) {
            if (this.activeSlot != null && this.activeSlot.channel == clientCh) {
                this.log("ACTIVE client disconnected!");
                this.activeSlot = null;
                if (this.standbySlot != null && this.standbySlot.channel.isActive()) {
                    this.log("Promoting STANDBY to ACTIVE (keeping server connection alive)...");
                    ClientSlot promoted = this.standbySlot;
                    this.standbySlot = null;
                    promoted.isActive = true;
                    this.activeSlot = promoted;
                    this.log("Promotion complete - seamless switch done");
                } else {
                    this.log("No standby client, but keeping server connection alive for future clients");
                }
            } else if (this.standbySlot != null && this.standbySlot.channel == clientCh) {
                this.log("STANDBY client disconnected");
                this.standbySlot = null;
            }
        }
    }

    public boolean isRunning() {
        return this.running;
    }

    public int getLocalPort() {
        return this.localPort;
    }

    public String getTargetHost() {
        return this.targetHost;
    }

    public int getTargetPort() {
        return this.targetPort;
    }

    public int getConnectionCount() {
        int c = 0;
        if (this.activeSlot != null) {
            ++c;
        }
        if (this.standbySlot != null) {
            ++c;
        }
        return c;
    }

    public String getStatus() {
        String a = this.activeSlot != null ? "ACTIVE" : "-";
        String s = this.standbySlot != null ? "STANDBY" : "-";
        return a + " | " + s;
    }

    static int readVarInt(ByteBuf buf) {
        byte b;
        int r = 0;
        int s = 0;
        do {
            b = buf.readByte();
            r |= (b & 0x7F) << s;
            s += 7;
        } while ((b & 0x80) != 0);
        return r;
    }

    static void writeVarInt(ByteBuf buf, int v) {
        while ((v & 0xFFFFFF80) != 0) {
            buf.writeByte(v & 0x7F | 0x80);
            v >>>= 7;
        }
        buf.writeByte(v);
    }

    static String readString(ByteBuf buf) {
        int l = FakerProxy.readVarInt(buf);
        byte[] b = new byte[l];
        buf.readBytes(b);
        return new String(b, StandardCharsets.UTF_8);
    }

    static void writeString(ByteBuf buf, String s) {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        FakerProxy.writeVarInt(buf, b.length);
        buf.writeBytes(b);
    }

    static class ClientSlot {
        final Channel channel;
        volatile boolean isActive;

        ClientSlot(Channel channel, boolean isActive) {
            this.channel = channel;
            this.isActive = isActive;
        }

        void close() {
            if (this.channel.isActive()) {
                this.channel.close();
            }
        }
    }

    static class ServerDataHandler
    extends ChannelInboundHandlerAdapter {
        private final FakerProxy proxy;

        ServerDataHandler(FakerProxy proxy) {
            this.proxy = proxy;
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        public void channelRead(ChannelHandlerContext ctx, Object msg) {
            ByteBuf data = (ByteBuf)msg;
            try {
                this.proxy.onServerData(data);
            }
            finally {
                data.release();
            }
        }

        public void channelInactive(ChannelHandlerContext ctx) {
            this.proxy.log("Server connection closed");
        }

        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
            this.proxy.log("Server error: " + cause.getMessage());
            ctx.close();
        }
    }

    static class IncomingClientHandler
    extends ChannelInboundHandlerAdapter {
        private final FakerProxy proxy;
        private boolean firstPacket = true;

        IncomingClientHandler(FakerProxy proxy) {
            this.proxy = proxy;
        }

        public void channelActive(ChannelHandlerContext ctx) {
            ctx.channel().config().setAutoRead(false);
            this.proxy.onNewClient(ctx.channel());
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        public void channelRead(ChannelHandlerContext ctx, Object msg) {
            ByteBuf data = (ByteBuf)msg;
            try {
                if (this.firstPacket && this.proxy.activeSlot != null && this.proxy.activeSlot.channel == ctx.channel()) {
                    this.firstPacket = false;
                    ByteBuf rewritten = this.rewriteHandshake(ctx, data);
                    if (rewritten != null) {
                        this.proxy.onClientData(ctx.channel(), rewritten);
                        rewritten.release();
                    } else {
                        this.proxy.onClientData(ctx.channel(), data);
                    }
                } else {
                    this.proxy.onClientData(ctx.channel(), data);
                }
            }
            finally {
                data.release();
                ctx.channel().read();
            }
        }

        public void channelInactive(ChannelHandlerContext ctx) {
            this.proxy.onClientDisconnected(ctx.channel());
        }

        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
            this.proxy.log("Client error: " + cause.getMessage());
            ctx.close();
        }

        private ByteBuf rewriteHandshake(ChannelHandlerContext ctx, ByteBuf original) {
            try {
                original.markReaderIndex();
                int packetLen = FakerProxy.readVarInt(original);
                int packetId = FakerProxy.readVarInt(original);
                if (packetId != 0) {
                    original.resetReaderIndex();
                    return null;
                }
                int protocolVer = FakerProxy.readVarInt(original);
                String address = FakerProxy.readString(original);
                int port = original.readUnsignedShort();
                int nextState = FakerProxy.readVarInt(original);
                byte[] rest = new byte[original.readableBytes()];
                original.readBytes(rest);
                Object newAddr = this.proxy.handshakeHost;
                int nullIdx = address.indexOf(0);
                if (nullIdx >= 0) {
                    newAddr = this.proxy.handshakeHost + address.substring(nullIdx);
                }
                this.proxy.log("Handshake: " + address + " -> " + (String)newAddr);
                ByteBuf pktData = ctx.alloc().buffer();
                FakerProxy.writeVarInt(pktData, 0);
                FakerProxy.writeVarInt(pktData, protocolVer);
                FakerProxy.writeString(pktData, (String)newAddr);
                pktData.writeShort(this.proxy.targetPort);
                FakerProxy.writeVarInt(pktData, nextState);
                ByteBuf result = ctx.alloc().buffer();
                FakerProxy.writeVarInt(result, pktData.readableBytes());
                result.writeBytes(pktData);
                pktData.release();
                if (rest.length > 0) {
                    result.writeBytes(rest);
                }
                return result;
            }
            catch (Exception e) {
                original.resetReaderIndex();
                return null;
            }
        }
    }
}

