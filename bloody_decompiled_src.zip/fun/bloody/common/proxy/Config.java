/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  com.google.gson.reflect.TypeToken
 *  net.minecraft.class_310
 *  org.apache.commons.io.FileUtils
 */
package fun.bloody.common.proxy;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import fun.bloody.common.proxy.Proxy;
import fun.bloody.common.proxy.ProxyServer;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import net.minecraft.class_310;
import org.apache.commons.io.FileUtils;

public class Config {
    private static final File CONFIG_DIR = new File(class_310.method_1551().field_1697, "Bloody/Proxy");
    private static final File CONFIG_FILE = new File(CONFIG_DIR, "Proxyconfig.json");
    public static HashMap<String, Proxy> accounts = new HashMap();
    public static String lastPlayerName = "";

    public static void loadConfig() {
        try {
            if (!CONFIG_DIR.exists()) {
                CONFIG_DIR.mkdirs();
            }
            if (!CONFIG_FILE.exists()) {
                if (!CONFIG_FILE.createNewFile()) {
                    // empty if block
                }
                Config.saveConfig();
                return;
            }
            String configString = FileUtils.readFileToString((File)CONFIG_FILE, (Charset)StandardCharsets.UTF_8);
            if (!configString.isEmpty()) {
                JsonObject configJson = JsonParser.parseString((String)configString).getAsJsonObject();
                if (configJson.has("proxy-enabled")) {
                    ProxyServer.proxyEnabled = configJson.get("proxy-enabled").getAsBoolean();
                }
                Type type = new TypeToken<HashMap<String, Proxy>>(){}.getType();
                if (configJson.has("accounts")) {
                    accounts = (HashMap)new Gson().fromJson(configJson.get("accounts"), type);
                }
                if (accounts == null) {
                    accounts = new HashMap();
                }
                ProxyServer.proxy = accounts.containsKey("") ? accounts.get("") : new Proxy();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void setDefaultProxy(Proxy proxy) {
        accounts.put("", proxy);
    }

    public static void saveConfig() {
        try {
            if (!CONFIG_DIR.exists()) {
                CONFIG_DIR.mkdirs();
            }
            JsonElement accountsJsonObject = new Gson().toJsonTree(accounts);
            JsonObject configJson = new JsonObject();
            configJson.addProperty("proxy-enabled", Boolean.valueOf(ProxyServer.proxyEnabled));
            configJson.add("accounts", accountsJsonObject);
            Gson gsonPretty = new GsonBuilder().setPrettyPrinting().create();
            FileUtils.write((File)CONFIG_FILE, (CharSequence)gsonPretty.toJson((JsonElement)configJson), (Charset)StandardCharsets.UTF_8);
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }
}

