/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  net.minecraft.class_310
 *  org.apache.commons.io.FileUtils
 */
package fun.bloody.common.proxy;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import net.minecraft.class_310;
import org.apache.commons.io.FileUtils;

public class FakerConfig {
    private static final File CONFIG_DIR = new File(class_310.method_1551().field_1697, "Bloody/Faker");
    private static final File CONFIG_FILE = new File(CONFIG_DIR, "fakerconfig.json");
    public static String serverAddress = "";
    public static int proxyPort = 25565;
    public static boolean fakerEnabled = false;
    public static boolean blockDisconnect = true;
    public static boolean isConnected = false;
    public static String resolvedHost = "";
    public static int resolvedPort = 25565;

    public static void loadConfig() {
        try {
            if (!CONFIG_DIR.exists()) {
                CONFIG_DIR.mkdirs();
            }
            if (!CONFIG_FILE.exists()) {
                CONFIG_FILE.createNewFile();
                FakerConfig.saveConfig();
                return;
            }
            String configString = FileUtils.readFileToString((File)CONFIG_FILE, (Charset)StandardCharsets.UTF_8);
            if (!configString.isEmpty()) {
                JsonObject configJson = JsonParser.parseString((String)configString).getAsJsonObject();
                if (configJson.has("server-address")) {
                    serverAddress = configJson.get("server-address").getAsString();
                }
                if (configJson.has("proxy-port")) {
                    proxyPort = configJson.get("proxy-port").getAsInt();
                }
                if (configJson.has("faker-enabled")) {
                    fakerEnabled = configJson.get("faker-enabled").getAsBoolean();
                }
                if (configJson.has("block-disconnect")) {
                    blockDisconnect = configJson.get("block-disconnect").getAsBoolean();
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void saveConfig() {
        try {
            if (!CONFIG_DIR.exists()) {
                CONFIG_DIR.mkdirs();
            }
            JsonObject configJson = new JsonObject();
            configJson.addProperty("server-address", serverAddress);
            configJson.addProperty("proxy-port", (Number)proxyPort);
            configJson.addProperty("faker-enabled", Boolean.valueOf(fakerEnabled));
            configJson.addProperty("block-disconnect", Boolean.valueOf(blockDisconnect));
            Gson gsonPretty = new GsonBuilder().setPrettyPrinting().create();
            FileUtils.write((File)CONFIG_FILE, (CharSequence)gsonPretty.toJson((JsonElement)configJson), (Charset)StandardCharsets.UTF_8);
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    public static String getInputHost() {
        if (serverAddress == null || serverAddress.isEmpty()) {
            return "";
        }
        String host = serverAddress;
        if (host.contains(":")) {
            host = host.split(":")[0];
        }
        return host;
    }

    public static int getInputPort() {
        if (serverAddress == null || serverAddress.isEmpty()) {
            return 25565;
        }
        if (serverAddress.contains(":")) {
            try {
                return Integer.parseInt(serverAddress.split(":")[1]);
            }
            catch (NumberFormatException e) {
                return 25565;
            }
        }
        return 25565;
    }

    public static boolean resolveServerAddress() {
        Object resolved2;
        String host = FakerConfig.getInputHost();
        int port = FakerConfig.getInputPort();
        if (host.isEmpty()) {
            return false;
        }
        try {
            resolved2 = FakerConfig.resolveSRV(host);
            if (resolved2 != null) {
                resolvedHost = resolved2[0];
                resolvedPort = Integer.parseInt((String)resolved2[1]);
                return true;
            }
        }
        catch (Exception resolved2) {
            // empty catch block
        }
        try {
            resolved2 = InetAddress.getByName(host);
            resolvedHost = ((InetAddress)resolved2).getHostAddress();
            resolvedPort = port;
            return true;
        }
        catch (UnknownHostException resolved3) {
            String[] prefixes;
            for (String prefix : prefixes = new String[]{"mc.", "play.", "hub.", "server."}) {
                try {
                    String prefixedHost = prefix + host;
                    InetAddress resolved4 = InetAddress.getByName(prefixedHost);
                    resolvedHost = resolved4.getHostAddress();
                    resolvedPort = port;
                    return true;
                }
                catch (UnknownHostException unknownHostException) {
                }
            }
            return false;
        }
    }

    private static String[] resolveSRV(String hostname) {
        try {
            String[] parts;
            Hashtable<String, String> env = new Hashtable<String, String>();
            env.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
            env.put("java.naming.provider.url", "dns:");
            env.put("com.sun.jndi.dns.timeout.retries", "1");
            InitialDirContext ctx = new InitialDirContext(env);
            Attributes attrs = ctx.getAttributes("_minecraft._tcp." + hostname, new String[]{"SRV"});
            Attribute srv = attrs.get("srv");
            if (srv != null && srv.size() > 0 && (parts = srv.get(0).toString().split(" ", 4)).length >= 4) {
                String target = parts[3];
                if (target.endsWith(".")) {
                    target = target.substring(0, target.length() - 1);
                }
                return new String[]{target, parts[2]};
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public static String getTargetHost() {
        return resolvedHost;
    }

    public static int getTargetPort() {
        return resolvedPort;
    }

    public static List<String> getLocalAddresses() {
        ArrayList<String> addresses = new ArrayList<String>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface iface = interfaces.nextElement();
                if (iface.isLoopback() || !iface.isUp()) continue;
                Enumeration<InetAddress> addrs = iface.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress addr = addrs.nextElement();
                    if (!(addr instanceof Inet4Address)) continue;
                    addresses.add(addr.getHostAddress());
                }
            }
        }
        catch (SocketException socketException) {
            // empty catch block
        }
        if (addresses.isEmpty()) {
            addresses.add("127.0.0.1");
        }
        return addresses;
    }
}

