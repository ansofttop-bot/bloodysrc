/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_2561
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  net.minecraft.class_342
 *  net.minecraft.class_364
 *  net.minecraft.class_4185
 *  net.minecraft.class_437
 */
package fun.bloody.common.proxy;

import fun.bloody.common.proxy.FakerConfig;
import fun.bloody.common.proxy.FakerProxy;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class GuiFaker
extends class_437 {
    private static final FakerProxy proxy = new FakerProxy();
    private class_342 serverAddressField;
    private class_342 portField;
    private class_4185 connectButton;
    private class_4185 backButton;
    private class_437 parentScreen;
    private String statusMsg = "";
    private int statusColor = 0xA0A0A0;

    public GuiFaker(class_437 parentScreen) {
        super((class_2561)class_2561.method_43470((String)"Faker - Savemod"));
        this.parentScreen = parentScreen;
    }

    public void method_25426() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        int fieldWidth = 200;
        this.serverAddressField = new class_342(this.field_22793, centerX - fieldWidth / 2, centerY - 60, fieldWidth, 20, (class_2561)class_2561.method_43470((String)""));
        this.serverAddressField.method_1880(256);
        this.serverAddressField.method_1852(FakerConfig.serverAddress);
        this.serverAddressField.method_47404((class_2561)class_2561.method_43470((String)"mc.example.com").method_27692(class_124.field_1063));
        this.method_25429((class_364)this.serverAddressField);
        this.portField = new class_342(this.field_22793, centerX - 30, centerY - 30, 60, 20, (class_2561)class_2561.method_43470((String)""));
        this.portField.method_1880(5);
        this.portField.method_1852(String.valueOf(FakerConfig.proxyPort));
        this.portField.method_47404((class_2561)class_2561.method_43470((String)"25565").method_27692(class_124.field_1063));
        this.method_25429((class_364)this.portField);
        String btnText = proxy.isRunning() ? "\u041e\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c" : "\u0417\u0430\u043f\u0443\u0441\u0442\u0438\u0442\u044c";
        this.connectButton = class_4185.method_46430((class_2561)class_2561.method_43470((String)btnText), button -> {
            if (proxy.isRunning()) {
                proxy.stop();
                FakerConfig.isConnected = false;
                FakerConfig.fakerEnabled = false;
                button.method_25355((class_2561)class_2561.method_43470((String)"\u0417\u0430\u043f\u0443\u0441\u0442\u0438\u0442\u044c"));
                this.statusMsg = String.valueOf(class_124.field_1054) + "\u041f\u0440\u043e\u043a\u0441\u0438 \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d";
                this.statusColor = 0xFFFF55;
                FakerConfig.saveConfig();
            } else {
                int port;
                String address = this.serverAddressField.method_1882().trim();
                if (address.isEmpty()) {
                    this.statusMsg = String.valueOf(class_124.field_1061) + "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 IP \u0441\u0435\u0440\u0432\u0435\u0440\u0430!";
                    this.statusColor = 0xFF5555;
                    return;
                }
                try {
                    port = Integer.parseInt(this.portField.method_1882().trim());
                    if (port < 1 || port > 65535) {
                        throw new NumberFormatException();
                    }
                }
                catch (NumberFormatException e) {
                    this.statusMsg = String.valueOf(class_124.field_1061) + "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043f\u043e\u0440\u0442!";
                    this.statusColor = 0xFF5555;
                    return;
                }
                FakerConfig.serverAddress = address;
                FakerConfig.proxyPort = port;
                if (!FakerConfig.resolveServerAddress()) {
                    this.statusMsg = String.valueOf(class_124.field_1061) + "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0440\u0430\u0437\u0440\u0435\u0437\u043e\u043b\u0432\u0438\u0442\u044c " + address;
                    this.statusColor = 0xFF5555;
                    return;
                }
                String targetHost = FakerConfig.getTargetHost();
                int targetPort = FakerConfig.getTargetPort();
                String handshakeHost = FakerConfig.getInputHost();
                try {
                    proxy.start(targetHost, targetPort, port, handshakeHost);
                    FakerConfig.isConnected = true;
                    FakerConfig.fakerEnabled = true;
                    button.method_25355((class_2561)class_2561.method_43470((String)"\u041e\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c"));
                    this.statusMsg = String.valueOf(class_124.field_1060) + "\u041f\u0440\u043e\u043a\u0441\u0438 \u0437\u0430\u043f\u0443\u0449\u0435\u043d! (" + targetHost + ":" + targetPort + ")";
                    this.statusColor = 0x55FF55;
                    FakerConfig.saveConfig();
                }
                catch (Exception e) {
                    this.statusMsg = String.valueOf(class_124.field_1061) + "\u041e\u0448\u0438\u0431\u043a\u0430: " + e.getMessage();
                    this.statusColor = 0xFF5555;
                    FakerConfig.isConnected = false;
                }
            }
        }).method_46434(centerX - 75, centerY + 0, 150, 20).method_46431();
        this.method_37063((class_364)this.connectButton);
        this.backButton = class_4185.method_46430((class_2561)class_2561.method_43470((String)"\u041d\u0430\u0437\u0430\u0434"), button -> class_310.method_1551().method_1507(this.parentScreen)).method_46434(centerX - 75, centerY + 100, 150, 20).method_46431();
        this.method_37063((class_364)this.backButton);
        if (proxy.isRunning()) {
            this.statusMsg = String.valueOf(class_124.field_1060) + "\u041f\u0440\u043e\u043a\u0441\u0438 \u0437\u0430\u043f\u0443\u0449\u0435\u043d!";
            this.statusColor = 0x55FF55;
        }
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float partialTicks) {
        super.method_25394(context, mouseX, mouseY, partialTicks);
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)(String.valueOf(class_124.field_1075) + String.valueOf(class_124.field_1067) + "Save" + String.valueOf(class_124.field_1070) + String.valueOf(class_124.field_1080) + " - mod")), centerX, centerY - 105, 0xFFFFFF);
        context.method_25300(this.field_22793, String.valueOf(class_124.field_1080) + "Savemod \u0434\u043b\u044f \u043e\u0431\u0445\u043e\u0434\u0430 \u043f\u0440\u043e\u0432\u0435\u0440\u043e\u043a", centerX, centerY - 92, 0x808080);
        context.method_25303(this.field_22793, "IP \u0441\u0435\u0440\u0432\u0435\u0440\u0430:", centerX - 100, centerY - 73, 0xA0A0A0);
        this.serverAddressField.method_25394(context, mouseX, mouseY, partialTicks);
        context.method_25303(this.field_22793, "\u041f\u043e\u0440\u0442:", centerX - 100, centerY - 27, 0xA0A0A0);
        this.portField.method_25394(context, mouseX, mouseY, partialTicks);
        if (proxy.isRunning()) {
            int infoY = centerY + 27;
            context.method_25300(this.field_22793, String.valueOf(class_124.field_1060) + "Savemod \u0437\u0430\u043f\u0443\u0449\u0435\u043d!", centerX, infoY, 0x55FF55);
            context.method_25300(this.field_22793, String.valueOf(class_124.field_1080) + "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0430\u0439\u0442\u0435\u0441\u044c \u043d\u0430: \u0441 \u043f\u0435\u0440\u0432\u043e\u0433\u043e \u0438 \u0432\u0442\u043e\u0440\u043e\u0433\u043e \u043a\u043b\u0438\u0435\u043d\u0442\u0430", centerX, infoY + 14, 0xA0A0A0);
            List<String> localAddresses = FakerConfig.getLocalAddresses();
            int addrY = infoY + 28;
            for (String addr : localAddresses) {
                String displayAddr = addr + ":" + proxy.getLocalPort();
                context.method_25300(this.field_22793, String.valueOf(class_124.field_1060) + String.valueOf(class_124.field_1067) + displayAddr, centerX, addrY, 0x55FF55);
                addrY += 12;
            }
        }
    }

    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            class_310.method_1551().method_1507(this.parentScreen);
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public void method_25419() {
        class_310.method_1551().method_1507(this.parentScreen);
    }

    public static void stopProxy() {
        if (proxy.isRunning()) {
            proxy.stop();
            FakerConfig.isConnected = false;
            FakerConfig.fakerEnabled = false;
        }
    }

    public static boolean isProxyRunning() {
        return proxy.isRunning();
    }
}

