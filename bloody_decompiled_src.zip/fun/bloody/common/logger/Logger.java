/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 */
package fun.bloody.common.logger;

import net.minecraft.class_2561;

public interface Logger {
    public void log(Object var1);

    public void minecraftLog(class_2561 ... var1);
}

