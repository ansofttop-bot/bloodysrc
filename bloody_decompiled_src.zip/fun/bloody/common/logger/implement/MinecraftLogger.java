/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 */
package fun.bloody.common.logger.implement;

import fun.bloody.common.logger.Logger;
import fun.bloody.utils.display.interfaces.QuickImports;
import net.minecraft.class_2561;

public class MinecraftLogger
implements Logger,
QuickImports {
    @Override
    public void log(Object message) {
    }

    @Override
    public void minecraftLog(class_2561 ... components) {
    }
}

