/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.ClientBrandRetriever
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package fun.bloody.mixins.client.brand;

import fun.bloody.utils.interactions.simulate.Simulations;
import net.minecraft.client.ClientBrandRetriever;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={ClientBrandRetriever.class})
public class ClientBrandRetrieverMixin {
    @Inject(method={"getClientModName"}, at={@At(value="RETURN")}, cancellable=true, remap=false)
    private static void onGetClientModName(CallbackInfoReturnable<String> cir) {
        cir.setReturnValue((Object)(Simulations.fpsADDS() == null ? "Fabric" : Simulations.fpsADDS()));
    }
}

