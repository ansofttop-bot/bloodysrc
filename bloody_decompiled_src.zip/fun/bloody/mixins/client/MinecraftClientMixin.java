/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1268
 *  net.minecraft.class_1269
 *  net.minecraft.class_1269$class_9860
 *  net.minecraft.class_1269$class_9861
 *  net.minecraft.class_1657
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 *  net.minecraft.class_542
 *  net.minecraft.class_634
 *  net.minecraft.class_636
 *  net.minecraft.class_746
 *  net.minecraft.class_757
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.client;

import fun.bloody.Bloody;
import fun.bloody.events.container.SetScreenEvent;
import fun.bloody.events.player.HotBarUpdateEvent;
import fun.bloody.features.impl.combat.NoInteract;
import fun.bloody.features.impl.misc.SelfDestruct;
import fun.bloody.utils.client.logs.Logger;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.client.managers.file.exception.FileProcessingException;
import fun.bloody.utils.client.window.WindowStyle;
import fun.bloody.utils.client.window.WindowTitleAnimation;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.interfaces.QuickImports;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_542;
import net.minecraft.class_634;
import net.minecraft.class_636;
import net.minecraft.class_746;
import net.minecraft.class_757;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_310.class})
public abstract class MinecraftClientMixin
implements QuickImports {
    @Shadow
    @Nullable
    public class_636 field_1761;
    @Shadow
    @Nullable
    public class_746 field_1724;
    @Shadow
    @Final
    public class_757 field_1773;
    @Shadow
    @Nullable
    public class_437 field_1755;
    private final WindowTitleAnimation titleUtil = WindowTitleAnimation.getInstance();

    @Shadow
    @Nullable
    public abstract class_634 method_1562();

    @Inject(at={@At(value="TAIL")}, method={"<init>"})
    private void onInit(class_542 args2, CallbackInfo ci) {
        if (SelfDestruct.unhooked) {
            return;
        }
        Fonts.init();
        class_310.method_1551().method_22683().method_24286(this.titleUtil.getCurrentTitle());
    }

    @Inject(at={@At(value="HEAD")}, method={"stop"})
    private void stop(CallbackInfo ci) {
        Logger.info("Stopping for MinecraftClient");
        if (Bloody.getInstance().isInitialized()) {
            try {
                Bloody.getInstance().getFileController().saveFiles();
            }
            catch (FileProcessingException e) {
                Logger.error("Error occurred while saving files: " + e.getMessage() + " " + String.valueOf(e.getCause()));
            }
            finally {
                Bloody.getInstance().getFileController().stopAutoSave();
            }
        }
    }

    @Inject(method={"doItemUse"}, at={@At(value="INVOKE", target="Lnet/minecraft/util/Hand;values()[Lnet/minecraft/util/Hand;")}, cancellable=true)
    public void doItemUseHook(CallbackInfo ci) {
        if (NoInteract.getInstance().isState()) {
            for (class_1268 hand : class_1268.values()) {
                class_1269.class_9860 success;
                class_1269 result;
                if (this.field_1724.method_5998(hand).method_7960() || !(result = this.field_1761.method_2919((class_1657)this.field_1724, hand)).method_23665()) continue;
                if (result instanceof class_1269.class_9860 && (success = (class_1269.class_9860)result).comp_2909().equals((Object)class_1269.class_9861.field_52427)) {
                    this.field_1773.field_4012.method_3215(hand);
                    this.field_1724.method_6104(hand);
                }
                ci.cancel();
            }
        }
    }

    @Inject(method={"setScreen"}, at={@At(value="HEAD")}, cancellable=true)
    public void setScreenHook(class_437 screen, CallbackInfo ci) {
        if (SelfDestruct.unhooked) {
            return;
        }
        SetScreenEvent event = new SetScreenEvent(screen);
        EventManager.callEvent(event);
        Bloody.getInstance().getDraggableRepository().draggable().forEach(drag -> drag.setScreen(event));
        class_437 eventScreen = event.getScreen();
        if (screen != eventScreen) {
            mc.method_1507(eventScreen);
            ci.cancel();
        }
    }

    @Inject(method={"onResolutionChanged"}, at={@At(value="TAIL")})
    private void applyDarkMode(CallbackInfo ci) {
        if (SelfDestruct.unhooked) {
            return;
        }
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("linux")) {
            return;
        }
        class_310 client = class_310.method_1551();
        WindowStyle.setDarkMode(client.method_22683().method_4490());
    }

    @Inject(method={"tick"}, at={@At(value="HEAD")})
    private void onTick(CallbackInfo ci) {
        if (SelfDestruct.unhooked) {
            return;
        }
        this.titleUtil.updateTitle();
        class_310.method_1551().method_22683().method_24286(this.titleUtil.getCurrentTitle());
    }

    @Inject(method={"updateWindowTitle"}, at={@At(value="HEAD")}, cancellable=true)
    private void onUpdateWindowTitle(CallbackInfo ci) {
        if (SelfDestruct.unhooked) {
            return;
        }
        class_310.method_1551().method_22683().method_24286(this.titleUtil.getCurrentTitle());
        ci.cancel();
    }

    @Inject(method={"handleInputEvents"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getInventory()Lnet/minecraft/entity/player/PlayerInventory;")}, cancellable=true)
    public void handleInputEventsHook(CallbackInfo ci) {
        HotBarUpdateEvent event = new HotBarUpdateEvent();
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }
}

