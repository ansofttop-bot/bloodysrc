/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  net.minecraft.class_751
 *  net.minecraft.class_766
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.client.screen.mainmenu;

import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_751;
import net.minecraft.class_766;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_766.class})
public class RotatingCubeMapRendererMixin {
    private static final class_751 CUSTOM_PANORAMA_RENDERER = new class_751(class_2960.method_60655((String)"minecraft", (String)"panorama/panorama"));
    private static float customPitch = 0.0f;

    @Inject(method={"render"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderCustomPanorama(class_332 context, int width, int height, float alpha, float tickDelta, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        float f = client.method_61966().method_60638();
        float g = (float)((double)f * (Double)client.field_1690.method_45581().method_41753());
        customPitch = RotatingCubeMapRendererMixin.wrapOnce(customPitch + g * 0.1f, 360.0f);
        context.method_51452();
        CUSTOM_PANORAMA_RENDERER.method_3156(client, 10.0f, -customPitch, alpha);
        context.method_51452();
        ci.cancel();
    }

    private static float wrapOnce(float a, float b) {
        return a > b ? a - b : a;
    }
}

