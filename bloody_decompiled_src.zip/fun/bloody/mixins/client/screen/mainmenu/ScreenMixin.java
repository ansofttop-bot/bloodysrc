/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2558
 *  net.minecraft.class_2583
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 *  net.minecraft.class_408
 *  net.minecraft.class_437
 *  net.minecraft.class_751
 *  net.minecraft.class_766
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package fun.bloody.mixins.client.screen.mainmenu;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.MenuScreen;
import fun.bloody.display.screens.mainmenu.MainMenu;
import fun.bloody.events.chat.ChatEvent;
import fun.bloody.utils.client.managers.event.EventManager;
import net.minecraft.class_2558;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_751;
import net.minecraft.class_766;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_437.class})
public class ScreenMixin {
    private static final class_751 CUSTOM_PANORAMA_RENDERER = new class_751(class_2960.method_60655((String)"minecraft", (String)"panorama/panorama"));
    private static final class_766 CUSTOM_ROTATING_PANORAMA_RENDERER = new class_766(CUSTOM_PANORAMA_RENDERER);

    @Inject(at={@At(value="INVOKE", target="Lorg/slf4j/Logger;error(Ljava/lang/String;Ljava/lang/Object;)V", remap=false, ordinal=1)}, method={"handleTextClick"}, cancellable=true)
    public void handleCustomClickEvent(class_2583 style, CallbackInfoReturnable<Boolean> cir) {
        class_2558 clickEvent = style.method_10970();
        if (clickEvent == null) {
            return;
        }
        EventManager.callEvent(new ChatEvent(clickEvent.method_10844()));
        cir.setReturnValue((Object)true);
        cir.cancel();
    }

    @Inject(method={"renderBackground"}, at={@At(value="HEAD")}, cancellable=true)
    private void disableBackgroundBlurAndDimming(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this instanceof MenuScreen || this instanceof MainMenu) {
            ci.cancel();
        }
    }

    @Inject(method={"renderPanoramaBackground"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderCustomPanoramaBackground(class_332 context, float delta, CallbackInfo ci) {
        if (this instanceof MainMenu) {
            ci.cancel();
        } else {
            CUSTOM_ROTATING_PANORAMA_RENDERER.method_3317(context, ((class_437)this).field_22789, ((class_437)this).field_22790, 1.0f, delta);
            ci.cancel();
        }
    }

    @Inject(method={"mouseReleased"}, at={@At(value="TAIL")})
    private void releaseHudDraggables(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (this instanceof class_408) {
            Bloody.getInstance().getDraggableRepository().draggable().forEach(draggable -> draggable.mouseReleased(mouseX, mouseY, button));
        }
    }
}

