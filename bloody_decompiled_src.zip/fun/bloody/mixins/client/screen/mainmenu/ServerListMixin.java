/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.sugar.Local
 *  net.minecraft.class_2499
 *  net.minecraft.class_2520
 *  net.minecraft.class_641
 *  net.minecraft.class_642
 *  net.minecraft.class_642$class_8678
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.client.screen.mainmenu;

import com.llamalad7.mixinextras.sugar.Local;
import fun.bloody.features.impl.misc.SelfDestruct;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_641;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_641.class})
public class ServerListMixin {
    @Unique
    private final List<class_642> sponsorServers = List.of(new class_642("FunTime", "mc.funtime.su", class_642.class_8678.field_45609), new class_642("HolyWorld", "mc.holyworld.ru", class_642.class_8678.field_45609), new class_642("ReallyWorld", "mc.reallyworld.ru", class_642.class_8678.field_45609), new class_642("SpookyTime", "mc.spookytime.net", class_642.class_8678.field_45609), new class_642("AresMine", "mc.aresmine.ru", class_642.class_8678.field_45609));
    @Shadow
    @Final
    private List<class_642> field_3749;

    @Inject(method={"loadFile"}, at={@At(value="FIELD", target="Lnet/minecraft/client/option/ServerList;hiddenServers:Ljava/util/List;", ordinal=0)})
    private void loadFileHook(CallbackInfo ci) {
        if (SelfDestruct.unhooked) {
            return;
        }
        this.removeDuplicateSponsors();
        this.addMissingSponsors();
    }

    @Redirect(method={"saveFile"}, at=@At(value="INVOKE", target="Lnet/minecraft/nbt/NbtList;add(Ljava/lang/Object;)Z", ordinal=0))
    private boolean saveFileHook(class_2499 instance, Object o, @Local(ordinal=0) class_642 info) {
        if (SelfDestruct.unhooked) {
            return instance.add((Object)((class_2520)o));
        }
        if (this.isSponsorServer(info)) {
            return true;
        }
        return instance.add((Object)((class_2520)o));
    }

    @Unique
    private void removeDuplicateSponsors() {
        HashSet<String> sponsorAddresses = new HashSet<String>();
        for (class_642 sponsor : this.sponsorServers) {
            sponsorAddresses.add(sponsor.field_3761.toLowerCase());
        }
        Iterator<class_642> iterator2 = this.field_3749.iterator();
        HashSet<String> seenAddresses = new HashSet<String>();
        while (iterator2.hasNext()) {
            class_642 server = iterator2.next();
            String address = server.field_3761.toLowerCase();
            if (!sponsorAddresses.contains(address)) continue;
            if (seenAddresses.contains(address)) {
                iterator2.remove();
                continue;
            }
            seenAddresses.add(address);
        }
    }

    @Unique
    private void addMissingSponsors() {
        HashSet<String> existingAddresses = new HashSet<String>();
        for (class_642 server : this.field_3749) {
            existingAddresses.add(server.field_3761.toLowerCase());
        }
        for (class_642 sponsor : this.sponsorServers) {
            if (existingAddresses.contains(sponsor.field_3761.toLowerCase())) continue;
            this.field_3749.add(sponsor);
        }
    }

    @Unique
    private boolean isSponsorServer(class_642 info) {
        for (class_642 sponsor : this.sponsorServers) {
            if (!sponsor.field_3761.equalsIgnoreCase(info.field_3761)) continue;
            return true;
        }
        return false;
    }
}

