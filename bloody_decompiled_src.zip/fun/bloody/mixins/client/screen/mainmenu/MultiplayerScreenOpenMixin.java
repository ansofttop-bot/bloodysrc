/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_310
 *  net.minecraft.class_364
 *  net.minecraft.class_4068
 *  net.minecraft.class_4185
 *  net.minecraft.class_437
 *  net.minecraft.class_500
 *  net.minecraft.class_6379
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.client.screen.mainmenu;

import fun.bloody.common.proxy.Config;
import fun.bloody.common.proxy.FakerConfig;
import fun.bloody.common.proxy.GuiFaker;
import fun.bloody.common.proxy.GuiProxy;
import fun.bloody.common.proxy.Proxy;
import fun.bloody.common.proxy.ProxyServer;
import fun.bloody.features.impl.misc.SelfDestruct;
import fun.bloody.mixins.client.screen.IScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_6379;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_500.class})
public class MultiplayerScreenOpenMixin {
    @Inject(method={"init()V"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/screen/multiplayer/MultiplayerScreen;updateButtonActivationStates()V")})
    public void multiplayerGuiOpen(CallbackInfo ci) {
        if (SelfDestruct.unhooked) {
            return;
        }
        String playerName = class_310.method_1551().method_1548().method_1676();
        if (!playerName.equals(Config.lastPlayerName)) {
            Config.lastPlayerName = playerName;
            ProxyServer.proxy = Config.accounts.containsKey(playerName) ? Config.accounts.get(playerName) : (Config.accounts.containsKey("") ? Config.accounts.get("") : new Proxy());
        }
        class_500 ms = (class_500)this;
        class_310 client = class_310.method_1551();
        int screenWidth = client.method_22683().method_4486();
        IScreen si = (IScreen)ms;
        int buttonWidth = 100;
        int buttonMargin = 5;
        int buttonHeight = 20;
        String proxyBtnText = ProxyServer.proxyEnabled && ProxyServer.proxy != null && !ProxyServer.proxy.ipPort.isEmpty() ? "\u041f\u0440\u043e\u043a\u0441\u0438: \u0410\u043a\u0442\u0438\u0432\u0435\u043d" : "Proxy";
        ProxyServer.proxyMenuButton = class_4185.method_46430((class_2561)class_2561.method_43470((String)proxyBtnText), buttonWidget -> class_310.method_1551().method_1507((class_437)new GuiProxy((class_437)ms))).method_46434(screenWidth - buttonWidth - buttonMargin, buttonMargin, buttonWidth, buttonHeight).method_46431();
        si.getDrawables().add((class_4068)ProxyServer.proxyMenuButton);
        si.getSelectables().add((class_6379)ProxyServer.proxyMenuButton);
        si.getChildren().add((class_364)ProxyServer.proxyMenuButton);
        String savemodBtnText = FakerConfig.isConnected ? "Savemod \u0432\u043a\u043b\u044e\u0447\u0435\u043d" : "Savemod";
        class_4185 savemodButton = class_4185.method_46430((class_2561)class_2561.method_43470((String)savemodBtnText), buttonWidget -> class_310.method_1551().method_1507((class_437)new GuiFaker((class_437)ms))).method_46434(screenWidth - buttonWidth * 2 - buttonMargin * 2, buttonMargin, buttonWidth, buttonHeight).method_46431();
        si.getDrawables().add((class_4068)savemodButton);
        si.getSelectables().add((class_6379)savemodButton);
        si.getChildren().add((class_364)savemodButton);
    }
}

