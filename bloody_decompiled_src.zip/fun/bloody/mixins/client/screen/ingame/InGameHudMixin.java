/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_266
 *  net.minecraft.class_310
 *  net.minecraft.class_329
 *  net.minecraft.class_332
 *  net.minecraft.class_9779
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.client.screen.ingame;

import fun.bloody.Bloody;
import fun.bloody.events.render.DrawEvent;
import fun.bloody.features.impl.render.CrossHair;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.features.impl.render.NoRender;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.math.calc.Calculate;
import java.util.ConcurrentModificationException;
import net.minecraft.class_1297;
import net.minecraft.class_266;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_329.class})
public abstract class InGameHudMixin
implements QuickImports {
    @Unique
    private final Hud hud = Hud.getInstance();
    @Final
    @Shadow
    private class_310 field_2035;

    @Shadow
    protected abstract void method_1760(class_332 var1);

    @Shadow
    protected abstract void method_1741(class_332 var1);

    @Inject(method={"render"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/LayeredDrawer;render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", shift=At.Shift.AFTER)})
    public void onRender(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        blur.setup();
        DrawEvent event = new DrawEvent(context, drawEngine, tickCounter.method_60637(false));
        EventManager.callEvent(event);
        Render2D.onRender(context);
        boolean debugHudVisible = this.field_2035.method_53526().method_53536();
        boolean tabVisible = this.field_2035.field_1690.field_1907.method_1434();
        if (!this.field_2035.field_1690.field_1842 && !debugHudVisible) {
            context.method_51448().method_22903();
            context.method_51448().method_46416(0.0f, 0.0f, 400.0f);
            Bloody.getInstance().getDraggableRepository().draggable().forEach(draggable -> {
                if (draggable.canDraw(this.hud, (AbstractDraggable)draggable)) {
                    draggable.startAnimation();
                } else {
                    draggable.stopAnimation();
                }
                float scale = draggable.getScaleAnimation().getOutput().floatValue();
                if (!draggable.isCloseAnimationFinished()) {
                    draggable.validPosition();
                    try {
                        Calculate.setAlpha(scale, () -> draggable.drawDraggable(context));
                    }
                    catch (ConcurrentModificationException concurrentModificationException) {
                        // empty catch block
                    }
                }
            });
            context.method_51448().method_22909();
        }
    }

    @Inject(method={"renderCrosshair"}, at={@At(value="FIELD", target="Lnet/minecraft/client/gui/hud/InGameHud;CROSSHAIR_TEXTURE:Lnet/minecraft/util/Identifier;")}, cancellable=true)
    public void renderCrosshairHook(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        CrossHair crossHair = CrossHair.getInstance();
        if (crossHair.isState()) {
            crossHair.onRenderCrossHair();
            ci.cancel();
        }
    }

    @Inject(at={@At(value="HEAD")}, method={"renderStatusEffectOverlay"}, cancellable=true)
    public void renderStatusEffectOverlayHook(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (this.hud.isState() && this.hud.interfaceSettings.isSelected("Potions")) {
            ci.cancel();
        }
    }

    @Inject(method={"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderScoreboardSidebarHook(class_332 context, class_266 objective, CallbackInfo ci) {
        if (this.hud.isState() && this.hud.interfaceSettings.isSelected("Scoreboard")) {
            ci.cancel();
        }
    }

    @Inject(method={"renderOverlayMessage"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderOverlayMessage(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (this.hud.isState() && this.hud.interfaceSettings.isSelected("HotBar")) {
            ci.cancel();
        }
    }

    @Inject(method={"renderExperienceLevel"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderExperienceLevel(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (this.hud.isState() && this.hud.interfaceSettings.isSelected("HotBar")) {
            ci.cancel();
        }
    }

    @Inject(method={"renderHotbar"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderHotbarHook(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (this.hud.isState() && this.hud.interfaceSettings.isSelected("HotBar")) {
            ci.cancel();
        }
    }

    @Inject(method={"renderVignetteOverlay"}, at={@At(value="HEAD")}, cancellable=true)
    private void onRenderVignette(class_332 context, class_1297 entity, CallbackInfo ci) {
        NoRender noRender = NoRender.getInstance();
        if (noRender != null && noRender.shouldHideVignette()) {
            ci.cancel();
        }
    }
}

