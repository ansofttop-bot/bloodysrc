/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_340
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Redirect
 */
package fun.bloody.mixins.client.screen.ingame;

import fun.bloody.features.impl.misc.SelfDestruct;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import net.minecraft.class_1297;
import net.minecraft.class_340;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={class_340.class})
public abstract class DebugHudMixin {
    @Redirect(method={"getLeftText"}, at=@At(value="INVOKE", target="Lnet/minecraft/entity/Entity;getYaw()F"))
    private float redirectYaw(class_1297 entity) {
        if (SelfDestruct.unhooked) {
            return entity.method_36454();
        }
        return TurnsConnection.INSTANCE.getRotation().getYaw();
    }

    @Redirect(method={"getLeftText"}, at=@At(value="INVOKE", target="Lnet/minecraft/entity/Entity;getPitch()F"))
    private float redirectPitch(class_1297 entity) {
        if (SelfDestruct.unhooked) {
            return entity.method_36455();
        }
        return TurnsConnection.INSTANCE.getRotation().getPitch();
    }
}

