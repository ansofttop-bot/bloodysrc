/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_364
 *  net.minecraft.class_4185
 *  net.minecraft.class_437
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.client.screen;

import java.io.File;
import java.util.ArrayList;
import net.minecraft.class_2561;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets={"net.minecraft.client.gui.screen.pack.PackScreen"})
public abstract class PackScreenMixin
extends class_437 {
    protected PackScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method={"init()V"}, at={@At(value="TAIL")})
    private void onInit(CallbackInfo ci) {
        ArrayList toRemove = new ArrayList();
        this.method_25396().stream().filter(element -> element instanceof class_4185).map(element -> (class_4185)element).forEach(button -> {
            String buttonText = button.method_25369().getString().toLowerCase();
            if (buttonText.contains("folder") || buttonText.contains("\u043f\u0430\u043f\u043a")) {
                toRemove.add(button);
            }
        });
        toRemove.forEach(button -> {
            this.method_37066((class_364)button);
            System.out.println("[PackScreenMixin] Removed original folder button");
        });
        if (!toRemove.isEmpty()) {
            class_4185 originalButton = (class_4185)toRemove.get(0);
            class_4185 customButton = class_4185.method_46430((class_2561)class_2561.method_43470((String)"Open Pack Folder"), btn -> {
                String username = System.getProperty("user.name");
                String tlauncherPath = "C:\\Users\\" + username + "\\AppData\\Roaming\\.tlauncher\\legacy\\Minecraft\\game\\resourcepacks";
                try {
                    File folder = new File(tlauncherPath);
                    if (!folder.exists()) {
                        folder.mkdirs();
                    }
                    Runtime.getRuntime().exec("explorer.exe \"" + tlauncherPath + "\"");
                    System.out.println("[PackScreenMixin] Opened TLauncher folder: " + tlauncherPath);
                }
                catch (Exception e) {
                    System.err.println("[PackScreenMixin] Error opening folder:");
                    e.printStackTrace();
                }
            }).method_46434(originalButton.method_46426(), originalButton.method_46427(), originalButton.method_25368(), originalButton.method_25364()).method_46431();
            this.method_37063((class_364)customButton);
            System.out.println("[PackScreenMixin] Added custom folder button");
        }
    }
}

