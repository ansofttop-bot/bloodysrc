/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_332
 *  net.minecraft.class_408
 *  net.minecraft.class_437
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package fun.bloody.mixins.client.screen.chat;

import fun.bloody.Bloody;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.interfaces.QuickImports;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_408.class})
public class ChatScreenMixin
extends class_437
implements QuickImports {
    @Unique
    List<AbstractDraggable> draggables = Bloody.getInstance().getDraggableRepository().draggable();

    protected ChatScreenMixin() {
        super((class_2561)class_2561.method_43473());
    }

    @Inject(method={"render"}, at={@At(value="HEAD")})
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        Hud hud = Hud.getInstance();
        this.draggables.stream().filter(draggable -> draggable.canDraw(hud, (AbstractDraggable)draggable) && draggable.isDragging()).reduce((first, second) -> second).ifPresent(active -> this.draggables.forEach(draggable -> {
            if (active == draggable) {
                draggable.render(context, mouseX, mouseY, delta);
            }
        }));
    }

    @Inject(method={"mouseClicked"}, at={@At(value="TAIL")})
    private void onMouseClicked(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        this.draggables.forEach(draggable -> draggable.mouseClicked(mouseX, mouseY, button));
    }
}

