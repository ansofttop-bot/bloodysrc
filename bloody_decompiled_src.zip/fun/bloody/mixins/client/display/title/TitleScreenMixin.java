/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.client.display.title;

import fun.bloody.features.impl.misc.SelfDestruct;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_310.class})
public class TitleScreenMixin {
    @Inject(method={"setScreen"}, at={@At(value="HEAD")}, cancellable=true)
    private void replaceTitleScreen(class_437 screen, CallbackInfo ci) {
        if (SelfDestruct.unhooked) {
            return;
        }
    }
}

