/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_4184
 *  net.minecraft.class_6854
 *  net.minecraft.class_758
 *  net.minecraft.class_758$class_4596
 *  net.minecraft.class_9958
 *  org.joml.Vector4f
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package fun.bloody.mixins.client.display.background;

import fun.bloody.features.impl.render.Ambience;
import fun.bloody.features.impl.render.NoRender;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_4184;
import net.minecraft.class_6854;
import net.minecraft.class_758;
import net.minecraft.class_9958;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_758.class})
public class BackGroundRendererMixin {
    @Inject(method={"getFogModifier(Lnet/minecraft/entity/Entity;F)Lnet/minecraft/client/render/BackgroundRenderer$StatusEffectFogModifier;"}, at={@At(value="HEAD")}, cancellable=true)
    private static void onGetFogModifier(class_1297 entity, float tickDelta, CallbackInfoReturnable<Object> info) {
        NoRender noRender = NoRender.getInstance();
        if (noRender.isState() && noRender.modeSetting.isSelected("Bad Effects")) {
            info.setReturnValue(null);
        }
        if (noRender.isState() && noRender.modeSetting.isSelected("Darkness") && entity instanceof class_1309) {
            info.setReturnValue(null);
        }
    }

    @Inject(method={"applyFog"}, at={@At(value="HEAD")}, cancellable=true)
    private static void modifyFog(class_4184 camera, class_758.class_4596 fogType, Vector4f vector4f, float viewDistance, boolean thickenFog, float tickDelta, CallbackInfoReturnable<class_9958> cir) {
        NoRender noRender = NoRender.getInstance();
        if (noRender.isState() && noRender.modeSetting.isSelected("NoFog")) {
            cir.setReturnValue((Object)new class_9958(Float.MAX_VALUE, Float.MAX_VALUE, class_6854.field_36351, 0.0f, 0.0f, 0.0f, 0.0f));
            return;
        }
        Ambience ambience = Ambience.getInstance();
        if (ambience != null && ambience.isState() && Ambience.fogEnabled) {
            int color = Ambience.fogColorValue;
            float red = (float)(color >> 16 & 0xFF) / 255.0f;
            float green = (float)(color >> 8 & 0xFF) / 255.0f;
            float blue = (float)(color & 0xFF) / 255.0f;
            float alpha = (float)(color >> 24 & 0xFF) / 255.0f;
            vector4f.x = red;
            vector4f.y = green;
            vector4f.z = blue;
            vector4f.w = alpha;
            float density = Ambience.fogDensity;
            float minDistance = 10.0f;
            float maxDistance = viewDistance;
            float fogStart = minDistance + (maxDistance - minDistance) * density;
            float fogEnd = fogStart + (maxDistance - fogStart) * 0.5f;
            cir.setReturnValue((Object)new class_9958(fogStart, fogEnd, class_6854.field_36351, red, green, blue, alpha));
        }
    }
}

