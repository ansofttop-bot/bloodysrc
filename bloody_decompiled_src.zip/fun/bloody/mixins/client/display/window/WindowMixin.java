/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1041
 *  org.lwjgl.system.MemoryUtil
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.client.display.window;

import net.minecraft.class_1041;
import org.lwjgl.system.MemoryUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1041.class})
public class WindowMixin {
    @Inject(method={"logGlError"}, at={@At(value="HEAD")}, cancellable=true)
    private void suppressInvalidKeyError(int error, long description, CallbackInfo ci) {
        String desc;
        if (error == 65539 && description != 0L && "Invalid key -1".equals(desc = MemoryUtil.memUTF8((long)description))) {
            ci.cancel();
        }
    }
}

