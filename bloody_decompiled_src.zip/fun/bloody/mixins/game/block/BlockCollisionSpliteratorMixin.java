/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.class_1922
 *  net.minecraft.class_2338
 *  net.minecraft.class_2680
 *  net.minecraft.class_5329
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package fun.bloody.mixins.game.block;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import fun.bloody.events.block.BlockCollisionEvent;
import fun.bloody.utils.client.managers.event.EventManager;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_5329.class})
public abstract class BlockCollisionSpliteratorMixin {
    @WrapOperation(method={"computeNext"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/BlockView;getBlockState(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/BlockState;")})
    private class_2680 computeNext(class_1922 instance, class_2338 blockPos, Operation<class_2680> original) {
        BlockCollisionEvent event = new BlockCollisionEvent(blockPos, (class_2680)original.call(new Object[]{instance, blockPos}));
        EventManager.callEvent(event);
        return event.getState();
    }
}

