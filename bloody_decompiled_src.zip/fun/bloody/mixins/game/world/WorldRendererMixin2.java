/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_243
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_757
 *  net.minecraft.class_761
 *  net.minecraft.class_9779
 *  net.minecraft.class_9922
 *  org.joml.Matrix4f
 *  org.lwjgl.opengl.GL11
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.game.world;

import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.features.impl.render.TargetESP;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_761.class}, priority=10000)
public class WorldRendererMixin2 {
    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Inject(method={"render"}, at={@At(value="TAIL")})
    private void onRenderTail(class_9922 objectAllocator, class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, Matrix4f positionMatrix, Matrix4f projectionMatrix, CallbackInfo ci) {
        if (TargetESP.getInstance() != null && TargetESP.getInstance().isState()) {
            int oldDepthFunc = GL11.glGetInteger((int)2932);
            try {
                GL11.glClear((int)256);
                GL11.glDepthRange((double)0.0, (double)0.0);
                GL11.glEnable((int)32823);
                GL11.glEnable((int)10754);
                GL11.glPolygonOffset((float)-100.0f, (float)-100.0f);
                GL11.glDepthFunc((int)519);
                GL11.glDepthMask((boolean)false);
                RenderSystem.depthMask((boolean)false);
                class_4587 matrices = new class_4587();
                matrices.method_34425(positionMatrix);
                class_243 cameraPos = camera.method_19326();
                matrices.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
                TargetESP.getInstance().renderAfterWorld(matrices, tickCounter.method_60637(false));
                GL11.glClear((int)256);
            }
            finally {
                GL11.glDepthRange((double)0.0, (double)1.0);
                GL11.glDisable((int)32823);
                GL11.glDisable((int)10754);
                GL11.glPolygonOffset((float)0.0f, (float)0.0f);
                GL11.glDepthFunc((int)oldDepthFunc);
                GL11.glDepthMask((boolean)true);
                RenderSystem.depthMask((boolean)true);
            }
        }
    }
}

