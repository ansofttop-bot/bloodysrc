/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1937
 *  net.minecraft.class_2338
 *  net.minecraft.class_2680
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.game.world;

import fun.bloody.events.block.BlockUpdateEvent;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.display.interfaces.QuickImports;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1937.class})
public abstract class WorldMixin
implements QuickImports {
    @Inject(method={"onBlockChanged"}, at={@At(value="RETURN")})
    private void onBlockChangedHook(class_2338 pos, class_2680 oldBlock, class_2680 newBlock, CallbackInfo ci) {
        if (WorldMixin.mc.field_1687 != this) {
            return;
        }
        EventManager.callEvent(new BlockUpdateEvent(newBlock, pos.method_10062(), BlockUpdateEvent.Type.UPDATE));
    }
}

