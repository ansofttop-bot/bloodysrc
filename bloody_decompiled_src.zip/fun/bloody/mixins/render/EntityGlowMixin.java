/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package fun.bloody.mixins.render;

import fun.bloody.features.impl.render.Esp;
import fun.bloody.utils.display.interfaces.QuickImports;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1297.class})
public class EntityGlowMixin
implements QuickImports {
    @Inject(method={"isGlowing"}, at={@At(value="HEAD")}, cancellable=true)
    private void onIsGlowing(CallbackInfoReturnable<Boolean> cir) {
        class_1657 player;
        class_1297 entity = (class_1297)this;
        if (entity instanceof class_1657 && (player = (class_1657)entity) != EntityGlowMixin.mc.field_1724) {
            Esp esp = Esp.getInstance();
            if (esp.state && esp.entityType.isSelected("Player") && esp.playerSetting.isSelected("Glow")) {
                cir.setReturnValue((Object)true);
            }
        }
    }
}

