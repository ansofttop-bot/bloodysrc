/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.class_10039
 *  net.minecraft.class_4587
 *  net.minecraft.class_4597
 *  net.minecraft.class_7833
 *  net.minecraft.class_916
 *  org.joml.Quaternionf
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.render;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import fun.bloody.features.impl.render.ItemPhysic;
import net.minecraft.class_10039;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_916.class})
public class ItemEntityRendererMixin {
    @WrapOperation(method={"render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionf;)V")})
    private void cancelRotation(class_4587 instance, Quaternionf quaternion, Operation<Void> original) {
        if (ItemPhysic.getInstance() != null && ItemPhysic.getInstance().isState() && ItemPhysic.getInstance().mode.isSelected("\u041f\u043b\u043e\u0441\u043a\u0430\u044f")) {
            return;
        }
        original.call(new Object[]{instance, quaternion});
    }

    @WrapOperation(method={"render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V")})
    private void cancelBobbing(class_4587 instance, float x, float y, float z, Operation<Void> original) {
        if (ItemPhysic.getInstance() != null && ItemPhysic.getInstance().isState() && ItemPhysic.getInstance().mode.isSelected("\u041f\u043b\u043e\u0441\u043a\u0430\u044f")) {
            instance.method_46416(x, 0.1f, z);
            return;
        }
        original.call(new Object[]{instance, Float.valueOf(x), Float.valueOf(y), Float.valueOf(z)});
    }

    @Inject(method={"render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at={@At(value="HEAD")})
    private void applyItemPhysics(class_10039 renderState, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        if (ItemPhysic.getInstance() != null && ItemPhysic.getInstance().isState() && ItemPhysic.getInstance().mode.isSelected("\u041f\u043b\u043e\u0441\u043a\u0430\u044f")) {
            matrices.method_22903();
            matrices.method_22907(class_7833.field_40714.rotationDegrees(90.0f));
        }
    }

    @Inject(method={"render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at={@At(value="RETURN")})
    private void popMatrix(class_10039 renderState, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        if (ItemPhysic.getInstance() != null && ItemPhysic.getInstance().isState() && ItemPhysic.getInstance().mode.isSelected("\u041f\u043b\u043e\u0441\u043a\u0430\u044f")) {
            matrices.method_22909();
        }
    }
}

