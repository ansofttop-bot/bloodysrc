/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  net.minecraft.class_1282
 *  net.minecraft.class_1291
 *  net.minecraft.class_1292
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_3532
 *  net.minecraft.class_6880
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package fun.bloody.mixins.player.entity;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import fun.bloody.events.block.PushEvent;
import fun.bloody.events.item.SwingDurationEvent;
import fun.bloody.events.player.EntityDeathEvent;
import fun.bloody.events.player.JumpEvent;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1309.class})
public abstract class LivingEntityMixin {
    @Shadow
    public float field_6283;
    @Unique
    private final class_310 client = class_310.method_1551();

    @Shadow
    public abstract boolean method_6059(class_6880<class_1291> var1);

    @Shadow
    @Nullable
    public abstract class_1293 method_6112(class_6880<class_1291> var1);

    @Shadow
    public abstract boolean method_20232();

    @Inject(method={"isPushable"}, at={@At(value="HEAD")}, cancellable=true)
    public void isPushable(CallbackInfoReturnable<Boolean> infoReturnable) {
        PushEvent event = new PushEvent(PushEvent.Type.COLLISION);
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            infoReturnable.setReturnValue((Object)false);
        }
    }

    @Inject(method={"jump"}, at={@At(value="HEAD")}, cancellable=true)
    private void jump(CallbackInfo info) {
        LivingEntityMixin livingEntityMixin = this;
        if (livingEntityMixin instanceof class_746) {
            class_746 player = (class_746)livingEntityMixin;
            JumpEvent event = new JumpEvent((class_1657)player);
            EventManager.callEvent(event);
            if (event.isCancelled()) {
                info.cancel();
            }
        }
    }

    @ModifyExpressionValue(method={"jump"}, at={@At(value="NEW", target="(DDD)Lnet/minecraft/util/math/Vec3d;")})
    private class_243 hookFixRotation(class_243 original) {
        if (this != this.client.field_1724) {
            return original;
        }
        float yaw = TurnsConnection.INSTANCE.getMoveRotation().getYaw() * ((float)Math.PI / 180);
        return new class_243((double)(-class_3532.method_15374((float)yaw) * 0.2f), 0.0, (double)(class_3532.method_15362((float)yaw) * 0.2f));
    }

    @ModifyExpressionValue(method={"calcGlidingVelocity"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/LivingEntity;getPitch()F")})
    private float hookModifyFallFlyingPitch(float original) {
        if (this != this.client.field_1724) {
            return original;
        }
        return TurnsConnection.INSTANCE.getMoveRotation().getPitch();
    }

    @ModifyExpressionValue(method={"calcGlidingVelocity"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/LivingEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;")})
    private class_243 hookModifyFallFlyingRotationVector(class_243 original) {
        if (this != this.client.field_1724) {
            return original;
        }
        return TurnsConnection.INSTANCE.getMoveRotation().toVector();
    }

    @Inject(method={"getHandSwingDuration"}, at={@At(value="HEAD")}, cancellable=true)
    private void swingProgressHook(CallbackInfoReturnable<Integer> cir) {
        if (this != this.client.field_1724) {
            return;
        }
        SwingDurationEvent event = new SwingDurationEvent();
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            float animation = event.getAnimation();
            animation = class_1292.method_5576((class_1309)this.client.field_1724) ? (animation *= (float)(6 - (1 + class_1292.method_5575((class_1309)this.client.field_1724)))) : (animation *= (float)(this.method_6059((class_6880<class_1291>)class_1294.field_5901) ? 6 + (1 + this.method_6112((class_6880<class_1291>)class_1294.field_5901).method_5578()) * 2 : 6));
            cir.setReturnValue((Object)((int)animation));
        }
    }

    @Inject(method={"onDeath"}, at={@At(value="HEAD")})
    private void onDeath(class_1282 source, CallbackInfo ci) {
        class_1309 entity = (class_1309)this;
        EntityDeathEvent event = new EntityDeathEvent((class_1297)entity, source);
        EventManager.callEvent(event);
    }

    @Inject(method={"handleStatus"}, at={@At(value="HEAD")})
    private void handleStatus(byte status, CallbackInfo ci) {
        if (status == 3) {
            class_1309 entity = (class_1309)this;
            EntityDeathEvent event = new EntityDeathEvent((class_1297)entity, null);
            EventManager.callEvent(event);
        }
    }
}

