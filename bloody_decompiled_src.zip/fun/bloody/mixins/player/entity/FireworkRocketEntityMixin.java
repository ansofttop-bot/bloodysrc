/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.class_1309
 *  net.minecraft.class_1671
 *  net.minecraft.class_243
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 */
package fun.bloody.mixins.player.entity;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import fun.bloody.events.player.FireworkEvent;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import net.minecraft.class_1309;
import net.minecraft.class_1671;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_1671.class})
public class FireworkRocketEntityMixin
implements QuickImports {
    @Shadow
    @Nullable
    private class_1309 field_7616;

    @WrapOperation(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/LivingEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;")})
    public class_243 getRotationVectorHook(class_1309 instance, Operation<class_243> original) {
        if (this.field_7616 == FireworkRocketEntityMixin.mc.field_1724) {
            return TurnsConnection.INSTANCE.getMoveRotation().toVector();
        }
        return (class_243)original.call(new Object[]{instance});
    }

    @WrapOperation(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/LivingEntity;getVelocity()Lnet/minecraft/util/math/Vec3d;", ordinal=0)})
    public class_243 getVelocityHook(class_1309 instance, Operation<class_243> original) {
        if (this.field_7616 == FireworkRocketEntityMixin.mc.field_1724) {
            FireworkEvent event = new FireworkEvent((class_243)original.call(new Object[]{instance}));
            EventManager.callEvent(event);
            return event.getVector();
        }
        return (class_243)original.call(new Object[]{instance});
    }
}

