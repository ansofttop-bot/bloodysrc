/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package fun.bloody.mixins.player.entity;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import fun.bloody.events.player.BoundingBoxControlEvent;
import fun.bloody.events.player.PlayerVelocityStrafeEvent;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1297.class})
public abstract class EntityMixin
implements QuickImports {
    @Shadow
    private class_238 field_6005;
    @Shadow
    public float field_6031;
    @Unique
    private final class_310 client = class_310.method_1551();

    @Redirect(method={"updateVelocity"}, at=@At(value="INVOKE", target="Lnet/minecraft/entity/Entity;movementInputToVelocity(Lnet/minecraft/util/math/Vec3d;FF)Lnet/minecraft/util/math/Vec3d;"))
    public class_243 hookVelocity(class_243 movementInput, float speed, float yaw) {
        if (this == EntityMixin.mc.field_1724) {
            PlayerVelocityStrafeEvent event = new PlayerVelocityStrafeEvent(movementInput, speed, yaw, class_1297.method_18795((class_243)movementInput, (float)speed, (float)yaw));
            EventManager.callEvent(event);
            return event.getVelocity();
        }
        return class_1297.method_18795((class_243)movementInput, (float)speed, (float)yaw);
    }

    @Inject(method={"getBoundingBox"}, at={@At(value="HEAD")}, cancellable=true)
    public final void getBoundingBox(CallbackInfoReturnable<class_238> cir) {
        BoundingBoxControlEvent event = new BoundingBoxControlEvent(this.field_6005, (class_1297)this);
        EventManager.callEvent(event);
        cir.setReturnValue((Object)event.getBox());
    }

    @ModifyVariable(method={"getRotationVector(FF)Lnet/minecraft/util/math/Vec3d;"}, at=@At(value="HEAD"), ordinal=0, argsOnly=true)
    private float modifyPitch(float pitch) {
        if (this instanceof class_746 && TurnsConnection.INSTANCE.getCurrentAngle() != null) {
            return TurnsConnection.INSTANCE.getCurrentAngle().getPitch();
        }
        return pitch;
    }

    @ModifyExpressionValue(method={"move"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/Entity;isControlledByPlayer()Z")})
    public boolean isControlledByPlayerHook(boolean original) {
        if (this == EntityMixin.mc.field_1724) {
            return false;
        }
        return original;
    }
}

