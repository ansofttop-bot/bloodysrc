/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.class_1313
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_638
 *  net.minecraft.class_742
 *  net.minecraft.class_744
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package fun.bloody.mixins.player.entity;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.authlib.GameProfile;
import fun.bloody.events.block.PushEvent;
import fun.bloody.events.container.CloseScreenEvent;
import fun.bloody.events.item.UsingItemEvent;
import fun.bloody.events.player.MotionEvent;
import fun.bloody.events.player.MoveEvent;
import fun.bloody.events.player.PlayerTravelEvent;
import fun.bloody.events.player.PostMotionEvent;
import fun.bloody.events.player.PostTickEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.impl.movement.AutoSprint;
import fun.bloody.features.impl.movement.NoSlow;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import fun.bloody.utils.interactions.inv.InventoryFlowManager;
import fun.bloody.utils.interactions.simulate.Simulations;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_744;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_746.class})
public abstract class ClientPlayerEntityMixin
extends class_742 {
    @Final
    @Shadow
    protected class_310 field_3937;
    @Shadow
    public class_744 field_3913;
    private double prevX = 0.0;
    private double prevZ = 0.0;
    private float prevBodyYaw = 0.0f;
    private boolean initialized = false;

    @Shadow
    public abstract float method_5695(float var1);

    @Shadow
    public abstract float method_5705(float var1);

    @Shadow
    protected abstract void method_3148(float var1, float var2);

    public ClientPlayerEntityMixin(class_638 world, GameProfile profile) {
        super(world, profile);
    }

    @Inject(method={"tick"}, at={@At(value="HEAD")})
    public void tick(CallbackInfo info) {
        if (this.field_3937.field_1724 != null && this.field_3937.field_1687 != null) {
            EventManager.callEvent(new TickEvent());
        }
    }

    @Inject(method={"tick"}, at={@At(value="HEAD")})
    public void onTick(CallbackInfo ci) {
        if (!this.initialized && QuickImports.mc.field_1724 != null) {
            this.prevX = QuickImports.mc.field_1724.method_23317();
            this.prevZ = QuickImports.mc.field_1724.method_23321();
            this.prevBodyYaw = QuickImports.mc.field_1724.method_43078();
            this.initialized = true;
        }
    }

    @Inject(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/AbstractClientPlayerEntity;tick()V", shift=At.Shift.AFTER)})
    public void postTick(CallbackInfo callbackInfo) {
        if (this.field_3937.field_1724 != null && this.field_3937.field_1687 != null) {
            EventManager.callEvent(new PostTickEvent());
        }
    }

    @Inject(method={"tickMovement"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/input/Input;tick()V", shift=At.Shift.AFTER)})
    private void onInputTick(CallbackInfo ci) {
        if (QuickImports.mc.field_1724 == null) {
            return;
        }
        PlayerTravelEvent event = new PlayerTravelEvent(class_243.field_1353, false);
        EventManager.callEvent(event);
    }

    @ModifyExpressionValue(method={"sendMovementPackets", "tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F")})
    private float hookSilentRotationYaw(float original) {
        if (QuickImports.mc.field_1724 != null) {
            float newBodyYaw;
            float currentYaw = TurnsConnection.INSTANCE.getRotation().getYaw();
            this.prevBodyYaw = newBodyYaw = Simulations.calculateBodyYaw(currentYaw, this.prevBodyYaw, this.prevX, this.prevZ, QuickImports.mc.field_1724.method_23317(), QuickImports.mc.field_1724.method_23321(), QuickImports.mc.field_1724.field_6251);
            this.prevX = QuickImports.mc.field_1724.method_23317();
            this.prevZ = QuickImports.mc.field_1724.method_23321();
            QuickImports.mc.field_1724.method_5636(newBodyYaw);
            return currentYaw;
        }
        return original;
    }

    @ModifyExpressionValue(method={"sendMovementPackets", "tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getPitch()F")})
    private float hookSilentRotationPitch(float original) {
        return TurnsConnection.INSTANCE.getRotation().getPitch();
    }

    @Inject(method={"closeHandledScreen"}, at={@At(value="HEAD")}, cancellable=true)
    private void closeHandledScreenHook(CallbackInfo info) {
        CloseScreenEvent event = new CloseScreenEvent(this.field_3937.field_1755);
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            info.cancel();
        }
    }

    @ModifyExpressionValue(method={"tickMovement"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z")})
    private boolean usingItemHook(boolean original) {
        if (original) {
            UsingItemEvent event = new UsingItemEvent(1);
            EventManager.callEvent(event);
            if (event.isCancelled()) {
                return false;
            }
            AutoSprint.getInstance();
            AutoSprint.tickStop = 1;
        }
        return original;
    }

    @Inject(method={"sendMovementPackets"}, at={@At(value="HEAD")}, cancellable=true)
    private void preMotion(CallbackInfo ci) {
        MotionEvent event = new MotionEvent(this.method_23317(), this.method_23318(), this.method_23321(), this.method_5705(1.0f), this.method_5695(1.0f), this.method_24828());
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method={"move"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/AbstractClientPlayerEntity;move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V")}, cancellable=true)
    public void onMoveHook(class_1313 movementType, class_243 movement, CallbackInfo ci) {
        MoveEvent event = new MoveEvent(movement);
        EventManager.callEvent(event);
        double d = this.method_23317();
        double e = this.method_23321();
        super.method_5784(movementType, event.getMovement());
        this.method_3148((float)(this.method_23317() - d), (float)(this.method_23321() - e));
        ci.cancel();
    }

    @Inject(method={"sendMovementPackets"}, at={@At(value="RETURN")}, cancellable=true)
    private void postMotion(CallbackInfo ci) {
        PostMotionEvent postMotionEvent = new PostMotionEvent();
        EventManager.callEvent(postMotionEvent);
        InventoryFlowManager.postMotion();
        if (postMotionEvent.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method={"pushOutOfBlocks"}, at={@At(value="HEAD")}, cancellable=true)
    public void pushOutOfBlocks(double x, double z, CallbackInfo ci) {
        PushEvent event = new PushEvent(PushEvent.Type.BLOCK);
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method={"shouldStopSprinting"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z")}, cancellable=true)
    public void shouldStopSprintingHook(CallbackInfoReturnable<Boolean> cir) {
        if (AutoSprint.getInstance().isState() && NoSlow.getInstance().isState()) {
            cir.setReturnValue((Object)false);
        }
    }

    @Inject(method={"canStartSprinting"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z")}, cancellable=true)
    public void canStartSprintingHook(CallbackInfoReturnable<Boolean> cir) {
        if (AutoSprint.getInstance().isState() && NoSlow.getInstance().isState()) {
            cir.setReturnValue((Object)false);
        }
    }
}

