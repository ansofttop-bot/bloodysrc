/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  com.llamalad7.mixinextras.sugar.Local
 *  net.minecraft.class_10042
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1921
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_4588
 *  net.minecraft.class_465
 *  net.minecraft.class_583
 *  net.minecraft.class_922
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.player.entity;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import fun.bloody.events.render.EntityColorEvent;
import fun.bloody.features.impl.combat.Aura;
import fun.bloody.features.impl.render.Esp;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_10042;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_465;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_922.class})
public abstract class LivingEntityRendererMixin
implements QuickImports {
    @Unique
    private static final Map<class_10042, class_1309> entityMap = new ConcurrentHashMap<class_10042, class_1309>();

    @Shadow
    @Nullable
    protected abstract class_1921 method_24302(class_10042 var1, boolean var2, boolean var3, boolean var4);

    @Inject(method={"updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V"}, at={@At(value="HEAD")})
    private void captureEntity(class_1309 entity, class_10042 state, float tickDelta, CallbackInfo ci) {
        entityMap.put(state, entity);
    }

    @Redirect(method={"render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/render/entity/LivingEntityRenderer;getRenderLayer(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/render/RenderLayer;"))
    private class_1921 renderHook(class_922 instance, class_10042 state, boolean showBody, boolean translucent, boolean showOutline) {
        class_1657 player;
        class_1309 entity = entityMap.get(state);
        if (entity instanceof class_1657 && (player = (class_1657)entity) != LivingEntityRendererMixin.mc.field_1724) {
            Esp esp = Esp.getInstance();
            if (esp.state && esp.entityType.isSelected("Player") && esp.playerSetting.isSelected("Glow")) {
                showOutline = true;
            }
        }
        if (!translucent && entity != null && state.field_53329 == 0.6f) {
            EntityColorEvent event = new EntityColorEvent((class_1297)entity, -1);
            EventManager.callEvent(event);
            if (event.isCancelled()) {
                translucent = true;
            }
        }
        return this.method_24302(state, showBody, translucent, showOutline);
    }

    @Redirect(method={"render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/render/entity/model/EntityModel;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V"))
    private void renderModelHook(class_583<?> instance, class_4587 matrixStack, class_4588 vertexConsumer, int i, int j, int l, @Local(ordinal=0, argsOnly=true) class_10042 renderState) {
        class_1309 entity = entityMap.get(renderState);
        EntityColorEvent event = new EntityColorEvent((class_1297)entity, l);
        EventManager.callEvent(event);
        instance.method_62100(matrixStack, vertexConsumer, i, j, event.getColor());
    }

    @ModifyExpressionValue(method={"updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/util/math/MathHelper;lerpAngleDegrees(FFF)F")})
    private float lerpAngleDegreesHook(float original, @Local(ordinal=0, argsOnly=true) class_1309 entity, @Local(ordinal=0, argsOnly=true) float delta) {
        TurnsConnection controller = TurnsConnection.INSTANCE;
        Aura aura = Aura.getInstance();
        if (entity.equals((Object)LivingEntityRendererMixin.mc.field_1724) && controller.getPreviousRotation().getYaw() != LivingEntityRendererMixin.mc.field_1724.method_36454() && controller.getFakeRotation().getYaw() != LivingEntityRendererMixin.mc.field_1724.method_36454() && !(LivingEntityRendererMixin.mc.field_1755 instanceof class_465)) {
            float currentYaw;
            boolean isLony = Aura.fakeRotate;
            float prevYaw = isLony ? controller.getFakeRotation().getYaw() : controller.getPreviousRotation().getYaw();
            float f = currentYaw = isLony ? controller.getFakeRotation().getYaw() : controller.getRotation().getYaw();
            if (Aura.getInstance().getTarget() == null) {
                prevYaw = controller.getPreviousRotation().getYaw();
                currentYaw = controller.getRotation().getYaw();
            }
            return class_3532.method_16439((float)delta, (float)prevYaw, (float)currentYaw);
        }
        return original;
    }

    @ModifyExpressionValue(method={"updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/LivingEntity;getLerpedPitch(F)F")})
    private float getLerpedPitchHook(float original, @Local(ordinal=0, argsOnly=true) class_1309 entity, @Local(ordinal=0, argsOnly=true) float delta) {
        TurnsConnection controller = TurnsConnection.INSTANCE;
        Aura aura = Aura.getInstance();
        if (entity.equals((Object)LivingEntityRendererMixin.mc.field_1724) && controller.getPreviousRotation().getPitch() != LivingEntityRendererMixin.mc.field_1724.method_36455() && controller.getFakeRotation().getPitch() != LivingEntityRendererMixin.mc.field_1724.method_36455() && !(LivingEntityRendererMixin.mc.field_1755 instanceof class_465)) {
            float currentPitch;
            boolean isLony = Aura.fakeRotate;
            float prevPitch = isLony ? controller.getFakeRotation().getPitch() : controller.getPreviousRotation().getPitch();
            float f = currentPitch = isLony ? controller.getFakeRotation().getPitch() : controller.getRotation().getPitch();
            if (Aura.getInstance().getTarget() == null) {
                prevPitch = controller.getPreviousRotation().getPitch();
                currentPitch = controller.getRotation().getPitch();
            }
            return class_3532.method_16439((float)delta, (float)prevPitch, (float)currentPitch);
        }
        return original;
    }
}

