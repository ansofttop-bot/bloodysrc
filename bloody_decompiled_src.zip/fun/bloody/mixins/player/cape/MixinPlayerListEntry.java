/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.class_2960
 *  net.minecraft.class_640
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 */
package fun.bloody.mixins.player.cape;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_2960;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={class_640.class})
public class MixinPlayerListEntry {
    @Shadow
    @Final
    private GameProfile field_3741;
    @Unique
    private static final class_2960 CUSTOM_CAPE = class_2960.method_60655((String)"minecraft", (String)"textures/cape/cape.png");
}

