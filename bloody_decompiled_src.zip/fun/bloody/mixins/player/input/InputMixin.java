/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_744
 *  org.spongepowered.asm.mixin.Mixin
 */
package fun.bloody.mixins.player.input;

import fun.bloody.utils.display.interfaces.QuickImports;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={class_744.class})
public class InputMixin
implements QuickImports {
}

