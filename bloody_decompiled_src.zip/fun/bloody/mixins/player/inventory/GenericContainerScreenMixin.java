/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1657
 *  net.minecraft.class_1661
 *  net.minecraft.class_1703
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_2561
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  net.minecraft.class_364
 *  net.minecraft.class_4185
 *  net.minecraft.class_465
 *  net.minecraft.class_476
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package fun.bloody.mixins.player.inventory;

import fun.bloody.features.impl.misc.SelfDestruct;
import fun.bloody.utils.display.widget.ContainerBackgroundRender;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_476;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_476.class})
public abstract class GenericContainerScreenMixin
extends class_465<class_1707> {
    private class_4185 takeAllButton;
    private class_4185 dropAllButton;
    private class_4185 storeAllButton;
    private boolean buttonsAdded = false;
    @Unique
    private static final ContainerBackgroundRender BACKGROUND_RENDER = new ContainerBackgroundRender();

    public GenericContainerScreenMixin(class_1707 handler, class_1661 inventory, class_2561 title) {
        super((class_1703)handler, inventory, title);
    }

    @Inject(method={"render"}, at={@At(value="TAIL")})
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (SelfDestruct.unhooked) {
            return;
        }
        class_310 mc = class_310.method_1551();
        String title = this.method_25440().getString();
        if (!this.buttonsAdded) {
            this.addButtons(mc, title);
            this.buttonsAdded = true;
        }
    }

    private void addButtons(class_310 mc, String titleText) {
        int baseX = (this.field_22789 + this.field_2792) / 2;
        int baseY = (this.field_22790 - this.field_2779) / 2;
        this.dropAllButton = class_4185.method_46430((class_2561)class_2561.method_43470((String)"\u0412\u044b\u0431\u0440\u043e\u0441\u0438\u0442\u044c"), button -> this.dropAll(mc)).method_46434(baseX, baseY, 80, 20).method_46431();
        this.takeAllButton = class_4185.method_46430((class_2561)class_2561.method_43470((String)"\u0412\u0437\u044f\u0442\u044c \u0432\u0441\u0451"), button -> this.takeAll(mc)).method_46434(baseX, baseY + 22, 80, 20).method_46431();
        this.storeAllButton = class_4185.method_46430((class_2561)class_2561.method_43470((String)"\u0421\u043b\u043e\u0436\u0438\u0442\u044c \u0432\u0441\u0451"), button -> this.storeAll(mc)).method_46434(baseX, baseY + 44, 80, 20).method_46431();
        this.method_37063((class_364)this.dropAllButton);
        this.method_37063((class_364)this.takeAllButton);
        this.method_37063((class_364)this.storeAllButton);
    }

    private void takeAll(class_310 mc) {
        class_746 player = mc.field_1724;
        if (player == null || player.field_7512 == null) {
            return;
        }
        for (class_1735 slot : player.field_7512.field_7761) {
            if (slot.field_7871 == player.method_31548() || !slot.method_7681()) continue;
            mc.field_1761.method_2906(player.field_7512.field_7763, slot.field_7874, 0, class_1713.field_7794, (class_1657)player);
        }
    }

    private void dropAll(class_310 mc) {
        class_746 player = mc.field_1724;
        if (player == null || player.field_7512 == null) {
            return;
        }
        for (class_1735 slot : player.field_7512.field_7761) {
            if (slot.field_7871 == player.method_31548() || !slot.method_7681()) continue;
            mc.field_1761.method_2906(player.field_7512.field_7763, slot.field_7874, 1, class_1713.field_7795, (class_1657)player);
        }
    }

    private void storeAll(class_310 mc) {
        class_746 player = mc.field_1724;
        if (player == null || player.field_7512 == null) {
            return;
        }
        for (class_1735 slot : player.field_7512.field_7761) {
            if (slot.field_7871 != player.method_31548() || !slot.method_7681()) continue;
            mc.field_1761.method_2906(player.field_7512.field_7763, slot.field_7874, 0, class_1713.field_7794, (class_1657)player);
        }
    }
}

