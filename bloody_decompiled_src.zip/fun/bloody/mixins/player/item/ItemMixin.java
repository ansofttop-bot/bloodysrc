/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.class_1657
 *  net.minecraft.class_1792
 *  net.minecraft.class_243
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package fun.bloody.mixins.player.item;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_1792.class})
public class ItemMixin {
    @WrapOperation(method={"raycast"}, at={@At(value="INVOKE", target="Lnet/minecraft/entity/player/PlayerEntity;getRotationVector(FF)Lnet/minecraft/util/math/Vec3d;")})
    private static class_243 raycastHook(class_1657 player, float pitch, float yaw, Operation<class_243> original) {
        if (TurnsConnection.INSTANCE.getRotation() == null) {
            return (class_243)original.call(new Object[]{player, Float.valueOf(pitch), Float.valueOf(yaw)});
        }
        return TurnsConnection.INSTANCE.getRotation().toVector();
    }
}

