/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.util.krushprovider;

import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.AutoBuyableItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.settings.AutoBuyItemSettings;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.settings.AutoBuySettingsManager;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class KrushItem
implements AutoBuyableItem {
    private final String displayName;
    private final class_1799 reference;
    private final class_1792 material;
    private final int price;
    private final AutoBuyItemSettings settings;
    private boolean enabled;

    public KrushItem(String displayName, class_1792 material, class_1799 reference, int price) {
        this.displayName = displayName;
        this.material = material;
        this.reference = reference;
        this.price = price;
        this.enabled = true;
        this.settings = new AutoBuyItemSettings(price, material, displayName);
        AutoBuySettingsManager.getInstance().loadSettings(displayName, this.settings);
    }

    @Override
    public String getDisplayName() {
        return this.displayName;
    }

    @Override
    public class_1799 createItemStack() {
        return this.reference.method_7972();
    }

    @Override
    public int getPrice() {
        return this.price;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public AutoBuyItemSettings getSettings() {
        return this.settings;
    }
}

