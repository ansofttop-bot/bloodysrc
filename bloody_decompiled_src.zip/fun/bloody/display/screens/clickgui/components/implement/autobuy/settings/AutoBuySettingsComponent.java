/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.settings;

import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.originalitems.ItemRegistry;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.settings.AutoBuyItemSettings;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.settings.AutoBuySettingsManager;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public abstract class AutoBuySettingsComponent
extends AbstractComponent {
    protected final AutoBuyItemSettings settings;

    public AutoBuySettingsComponent(AutoBuyItemSettings settings) {
        this.settings = settings;
        this.height = 15.0f;
    }

    public static class MinQuantityComponent
    extends AutoBuySettingsComponent {
        private boolean editing = false;
        private String inputText = "";

        public MinQuantityComponent(AutoBuyItemSettings settings) {
            super(settings);
        }

        @Override
        public void render(class_332 context, int mouseX, int mouseY, float delta) {
            class_4587 matrix = context.method_51448();
            Fonts.getSize(13, Fonts.Type.SEMI).drawString(matrix, "\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u043e\u0442:", this.x + 10.0f, this.y + 8.0f, ColorAssist.getText(0.8f));
            Object displayText = this.editing ? this.inputText + "_" : String.valueOf(this.settings.getMinQuantity());
            float textWidth = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth((String)displayText);
            rectangle.render(ShapeProperties.create(matrix, this.x + this.width - textWidth - 16.0f, this.y + 5.0f, textWidth + 9.0f, 12.0).round(3.0f).thickness(2.5f).outlineColor(this.editing ? new Color(41, 42, 40, 40).getRGB() : new Color(41, 42, 40, 140).getRGB()).color(new Color(41, 42, 40, 40).getRGB()).build());
            Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(matrix, (String)displayText, this.x + this.width - textWidth - 11.5f, this.y + 10.0f, ColorAssist.getText());
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            Object displayText = this.editing ? this.inputText + "_" : String.valueOf(this.settings.getMinQuantity());
            float textWidth = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth((String)displayText);
            if (Calculate.isHovered(mouseX, mouseY, this.x + this.width - textWidth - 20.0f, this.y + 5.0f, textWidth + 15.0f, 15.0) && button == 0) {
                this.editing = true;
                this.inputText = String.valueOf(this.settings.getMinQuantity());
                return true;
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
            if (this.editing) {
                if (keyCode == 257) {
                    try {
                        int value = Integer.parseInt(this.inputText);
                        this.settings.setMinQuantity(Math.max(1, Math.min(64, value)));
                        AutoBuySettingsManager.getInstance().saveSettings(this.settings.getItemName(), this.settings);
                        ItemRegistry.reloadSettings();
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                    this.editing = false;
                    return true;
                }
                if (keyCode == 256) {
                    this.editing = false;
                    return true;
                }
                if (keyCode == 259 && !this.inputText.isEmpty()) {
                    this.inputText = this.inputText.substring(0, this.inputText.length() - 1);
                    return true;
                }
            }
            return super.keyPressed(keyCode, scanCode, modifiers);
        }

        @Override
        public boolean charTyped(char chr, int modifiers) {
            if (this.editing && Character.isDigit(chr) && this.inputText.length() < 2) {
                this.inputText = this.inputText + chr;
                return true;
            }
            return super.charTyped(chr, modifiers);
        }

        @Override
        public boolean isHover(double mouseX, double mouseY) {
            return Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, this.height);
        }
    }

    public static class BuyBelowComponent
    extends AutoBuySettingsComponent {
        private boolean editing = false;
        private String inputText = "";

        public BuyBelowComponent(AutoBuyItemSettings settings) {
            super(settings);
        }

        @Override
        public void render(class_332 context, int mouseX, int mouseY, float delta) {
            class_4587 matrix = context.method_51448();
            Fonts.getSize(13, Fonts.Type.SEMI).drawString(matrix, "\u041f\u043e\u043a\u0443\u043f\u0430\u0442\u044c \u043d\u0438\u0436\u0435:", this.x + 10.0f, this.y + 10.0f, ColorAssist.getText(0.8f));
            String displayText = this.editing ? this.inputText + "_" : this.settings.getBuyBelow() + "$";
            float textWidth = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth(displayText);
            rectangle.render(ShapeProperties.create(matrix, this.x + this.width - textWidth - 16.0f, this.y + 5.0f, textWidth + 9.0f, 12.0).round(3.0f).thickness(2.5f).outlineColor(this.editing ? new Color(41, 42, 40, 40).getRGB() : new Color(41, 42, 40, 140).getRGB()).color(new Color(41, 42, 40, 40).getRGB()).build());
            Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(matrix, displayText, this.x + this.width - textWidth - 12.0f, this.y + 10.0f, ColorAssist.getText());
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            String displayText = this.editing ? this.inputText + "_" : this.settings.getBuyBelow() + "$";
            float textWidth = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth(displayText);
            if (Calculate.isHovered(mouseX, mouseY, this.x + this.width - textWidth - 20.0f, this.y + 5.0f, textWidth + 15.0f, 15.0) && button == 0) {
                this.editing = true;
                this.inputText = String.valueOf(this.settings.getBuyBelow());
                return true;
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
            if (this.editing) {
                if (keyCode == 257) {
                    try {
                        int value = Integer.parseInt(this.inputText);
                        this.settings.setBuyBelow(Math.max(1, value));
                        AutoBuySettingsManager.getInstance().saveSettings(this.settings.getItemName(), this.settings);
                        ItemRegistry.reloadSettings();
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                    this.editing = false;
                    return true;
                }
                if (keyCode == 256) {
                    this.editing = false;
                    return true;
                }
                if (keyCode == 259 && !this.inputText.isEmpty()) {
                    this.inputText = this.inputText.substring(0, this.inputText.length() - 1);
                    return true;
                }
            }
            return super.keyPressed(keyCode, scanCode, modifiers);
        }

        @Override
        public boolean charTyped(char chr, int modifiers) {
            if (this.editing && Character.isDigit(chr) && this.inputText.length() < 9) {
                this.inputText = this.inputText + chr;
                return true;
            }
            return super.charTyped(chr, modifiers);
        }

        @Override
        public boolean isHover(double mouseX, double mouseY) {
            return Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, this.height);
        }
    }
}

