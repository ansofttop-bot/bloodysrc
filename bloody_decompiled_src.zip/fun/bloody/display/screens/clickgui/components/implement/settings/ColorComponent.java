/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.settings;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.display.screens.clickgui.components.implement.window.AbstractWindow;
import fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color.ColorWindow;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class ColorComponent
extends AbstractSettingComponent {
    private final ColorSetting setting;
    private float currentScroll = 0.0f;
    private float targetScroll = 0.0f;
    private boolean isHovered = false;

    public ColorComponent(ColorSetting setting) {
        super(setting);
        this.setting = setting;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        class_4587 matrix = context.method_51448();
        this.height = 18.0f;
        float maxWidth = this.width - 20.0f;
        String settingName = this.setting.getName();
        float textWidth = Fonts.getSize(14, Fonts.Type.DEFAULT).getStringWidth(settingName);
        boolean needsScroll = textWidth > maxWidth;
        boolean currentlyHovered = Calculate.isHovered(mouseX, mouseY, this.x + 5.0f, this.y + 5.0f, maxWidth, 14.0);
        if (currentlyHovered != this.isHovered) {
            this.isHovered = currentlyHovered;
        }
        if (needsScroll) {
            float maxScroll = textWidth - maxWidth;
            this.targetScroll = this.isHovered ? maxScroll : 0.0f;
            float lerpSpeed = 0.05f;
            this.currentScroll += (this.targetScroll - this.currentScroll) * lerpSpeed;
            if (Math.abs(this.targetScroll - this.currentScroll) < 0.1f) {
                this.currentScroll = this.targetScroll;
            }
        } else {
            this.currentScroll = 0.0f;
            this.targetScroll = 0.0f;
        }
        float scrollOffset = this.currentScroll;
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        int nameColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(0, 0, 0, 255).getRGB() : -2828575;
        float scissorWidth = this.width - 23.5f;
        scissor.push(context.method_51448().method_23760().method_23761(), this.x + 5.0f, this.y, scissorWidth, this.height);
        if (clickGuiModule != null) {
            nameColor = clickGuiModule.getTextColor();
        }
        Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(context.method_51448(), settingName, this.x + 5.0f - scrollOffset, this.y + 5.0f, nameColor);
        scissor.pop();
        float circleSize = 6.0f;
        float circleX = this.x + this.width - 19.0f + 6.0f;
        float circleY = this.y + 7.0f;
        rectangle.render(ShapeProperties.create(matrix, circleX - circleSize / 2.0f, circleY - circleSize / 2.0f, circleSize, circleSize).round(circleSize / 2.0f).color(this.setting.getColor()).build());
        float outlineGap = 2.0f;
        float outlineSize = circleSize + outlineGap * 2.0f;
        float outlineThickness = 4.8f;
        rectangle.render(ShapeProperties.create(matrix, circleX - outlineSize / 2.0f, circleY - outlineSize / 2.0f, outlineSize, outlineSize).round(outlineSize / 2.0f).thickness(outlineThickness).outlineColor(this.setting.getColor()).color(0).build());
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        boolean isClickOnCircle;
        float circleX = this.x + this.width - 19.0f + 6.0f;
        float dx = (float)mouseX - circleX;
        float circleY = this.y + 7.0f;
        float dy = (float)mouseY - circleY;
        float circleSize = 6.0f;
        float outlineGap = 2.0f;
        float clickRadius = (circleSize + outlineGap * 2.0f) / 2.0f;
        boolean bl = isClickOnCircle = dx * dx + dy * dy <= clickRadius * clickRadius;
        if (isClickOnCircle && button == 0) {
            AbstractWindow existingWindow = null;
            for (AbstractWindow window : windowManager.getWindows()) {
                if (!(window instanceof ColorWindow)) continue;
                existingWindow = window;
                break;
            }
            if (existingWindow != null) {
                windowManager.delete(existingWindow);
            } else {
                AbstractWindow colorWindow = new ColorWindow(this.setting).position((int)(mouseX - 110.0), (int)(mouseY - 20.0)).size(100.0f, 155.0f).draggable(true);
                windowManager.add(colorWindow);
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}

