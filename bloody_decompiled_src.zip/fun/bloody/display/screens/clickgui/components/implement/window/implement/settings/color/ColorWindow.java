/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 */
package fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color;

import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.components.implement.window.AbstractWindow;
import fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color.component.AlphaComponent;
import fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color.component.ColorEditorComponent;
import fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color.component.ColorPresetComponent;
import fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color.component.HueComponent;
import fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color.component.SaturationComponent;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_332;

public class ColorWindow
extends AbstractWindow {
    private final List<AbstractComponent> components = new ArrayList<AbstractComponent>();
    private final ColorSetting setting;
    private final HueComponent hueComponent;
    private final SaturationComponent saturationComponent;
    private final AlphaComponent alphaComponent;
    private final ColorEditorComponent colorEditorComponent;
    private final ColorPresetComponent colorPresetComponent;

    public ColorWindow(ColorSetting setting) {
        this.setting = setting;
        AbstractComponent[] abstractComponentArray = new AbstractComponent[5];
        this.hueComponent = new HueComponent(setting);
        abstractComponentArray[0] = this.hueComponent;
        this.saturationComponent = new SaturationComponent(setting);
        abstractComponentArray[1] = this.saturationComponent;
        this.alphaComponent = new AlphaComponent(setting);
        abstractComponentArray[2] = this.alphaComponent;
        this.colorEditorComponent = new ColorEditorComponent(setting);
        abstractComponentArray[3] = this.colorEditorComponent;
        this.colorPresetComponent = new ColorPresetComponent(setting);
        abstractComponentArray[4] = this.colorPresetComponent;
        this.components.addAll(Arrays.asList(abstractComponentArray));
        this.width = 100.0f;
        this.height = 155.0f;
    }

    @Override
    public void drawWindow(class_332 context, int mouseX, int mouseY, float delta) {
        int blurColor = new Color(0, 0, 0, 180).getRGB();
        blur.render(ShapeProperties.create(context.method_51448(), this.x, this.y + 10.0f, this.width, this.height - 10.0f).round(8.0f).quality(32.0f).color(blurColor).build());
        int outlineColor = new Color(255, 255, 255, 150).getRGB();
        rectangle.render(ShapeProperties.create(context.method_51448(), this.x, this.y + 10.0f, this.width, this.height - 10.0f).round(8.0f).thickness(2.0f).outlineColor(outlineColor).color(0).build());
        this.updateComponentPositions();
        this.components.forEach(component -> component.render(context, mouseX, mouseY, delta));
    }

    private void updateComponentPositions() {
        this.alphaComponent.position(this.x, this.y);
        this.hueComponent.position(this.x, this.y);
        this.saturationComponent.position(this.x, this.y);
        this.colorEditorComponent.position(this.x, this.y);
        this.colorPresetComponent.position(this.x, this.y);
        this.colorPresetComponent.setWindowWidth(this.width);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        this.updateComponentPositions();
        boolean componentHandled = false;
        for (AbstractComponent component : this.components) {
            if (!component.mouseClicked(mouseX, mouseY, button)) continue;
            componentHandled = true;
        }
        if (componentHandled) {
            this.draggable(false);
            return true;
        }
        boolean headerHovered = Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, 20.0);
        this.draggable(headerHovered);
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        this.updateComponentPositions();
        this.components.forEach(component -> component.mouseScrolled(mouseX, mouseY, amount));
        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.components.forEach(component -> component.mouseReleased(mouseX, mouseY, button));
        return super.mouseReleased(mouseX, mouseY, button);
    }

    public ColorSetting getSetting() {
        return this.setting;
    }
}

