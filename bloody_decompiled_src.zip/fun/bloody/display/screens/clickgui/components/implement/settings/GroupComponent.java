/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 */
package fun.bloody.display.screens.clickgui.components.implement.settings;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.components.implement.other.CheckComponent;
import fun.bloody.display.screens.clickgui.components.implement.other.SettingComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.display.screens.clickgui.components.implement.window.AbstractWindow;
import fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.group.GroupWindow;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.setting.implement.GroupSetting;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_332;

public class GroupComponent
extends AbstractSettingComponent {
    private final CheckComponent checkComponent = new CheckComponent();
    private final SettingComponent settingComponent = new SettingComponent();
    private final GroupSetting setting;
    private float currentScroll = 0.0f;
    private float targetScroll = 0.0f;
    private boolean isHovered = false;

    public GroupComponent(GroupSetting setting) {
        super(setting);
        this.setting = setting;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        this.height = 18.0f;
        float maxWidth = this.width - 20.0f;
        String settingName = this.setting.getName();
        float textWidth = Fonts.getSize(14, Fonts.Type.DEFAULT).getStringWidth(settingName);
        boolean needsScroll = textWidth > maxWidth;
        boolean currentlyHovered = Calculate.isHovered(mouseX, mouseY, this.x + 5.0f, this.y + 8.0f, maxWidth, 14.0);
        if (currentlyHovered != this.isHovered) {
            this.isHovered = currentlyHovered;
        }
        if (needsScroll) {
            float maxScroll = textWidth - maxWidth + 10.0f;
            this.targetScroll = this.isHovered ? maxScroll : 0.0f;
            float lerpSpeed = 0.05f;
            this.currentScroll += (this.targetScroll - this.currentScroll) * lerpSpeed;
            if (Math.abs(this.targetScroll - this.currentScroll) < 0.1f) {
                this.currentScroll = this.targetScroll;
            }
        } else {
            this.currentScroll = 0.0f;
            this.targetScroll = 0.0f;
        }
        float scrollOffset = this.currentScroll;
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        int nameColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(0, 0, 0, 255).getRGB() : -2828575;
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        scissor.push(context.method_51448().method_23760().method_23761(), this.x + 5.0f, this.y, maxWidth, 18.0f);
        if (clickGuiModule != null) {
            nameColor = clickGuiModule.getTextColor();
        }
        Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(context.method_51448(), settingName, this.x + 5.0f - scrollOffset, this.y + 13.0f, nameColor);
        scissor.pop();
        this.checkComponent.position(this.x + this.width - 19.0f, this.y + 9.5f).setRunnable(() -> this.setting.setValue(!this.setting.isValue())).setState(this.setting.isValue()).render(context, mouseX, mouseY, delta);
        ((SettingComponent)this.settingComponent.position(this.x + this.width - 31.0f, this.y + 9.0f)).setRunnable(() -> this.spawnWindow(mouseX, mouseY)).render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        this.checkComponent.mouseClicked(mouseX, mouseY, button);
        this.settingComponent.mouseClicked(mouseX, mouseY, button);
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void spawnWindow(int mouseX, int mouseY) {
        AbstractWindow existingWindow = null;
        for (AbstractWindow window : windowManager.getWindows()) {
            if (!(window instanceof GroupWindow) || ((GroupWindow)window).getSetting() != this.setting) continue;
            existingWindow = window;
            break;
        }
        if (existingWindow != null) {
            windowManager.delete(existingWindow);
        } else {
            AbstractWindow groupWindow = new GroupWindow(this.setting).position(mouseX + 10, mouseY).size(137.0f, 23.0f).draggable(false);
            windowManager.add(groupWindow);
        }
    }
}

