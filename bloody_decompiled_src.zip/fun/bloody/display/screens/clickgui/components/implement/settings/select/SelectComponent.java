/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.settings.select;

import fun.bloody.Bloody;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class SelectComponent
extends AbstractSettingComponent {
    private final SelectSetting setting;
    private float currentScroll = 0.0f;
    private float targetScroll = 0.0f;
    private boolean isHovered = false;
    private final Map<String, Animation> optionAnimations = new HashMap<String, Animation>();

    public SelectComponent(SelectSetting setting) {
        super(setting);
        this.setting = setting;
        for (String option : setting.getList()) {
            Animation anim = new Decelerate().setMs(250).setValue(1.0);
            anim.setDirection(option.equals(setting.getSelected()) ? Direction.FORWARDS : Direction.BACKWARDS);
            this.optionAnimations.put(option, anim);
        }
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        class_4587 matrices = context.method_51448();
        List<String> options = this.setting.getList();
        String selected = this.setting.getSelected();
        float maxWidth = this.width - 20.0f;
        String settingName = this.setting.getName();
        float textWidth = Fonts.getSize(14, Fonts.Type.DEFAULT).getStringWidth(settingName);
        boolean needsScroll = textWidth > maxWidth;
        boolean currentlyHovered = Calculate.isHovered(mouseX, mouseY, this.x + 5.0f, this.y, maxWidth, 14.0);
        if (currentlyHovered != this.isHovered) {
            this.isHovered = currentlyHovered;
        }
        if (needsScroll) {
            float maxScroll = textWidth - maxWidth + 10.0f;
            this.targetScroll = this.isHovered ? maxScroll : 0.0f;
            float lerpSpeed = 0.05f;
            this.currentScroll += (this.targetScroll - this.currentScroll) * lerpSpeed;
            if (Math.abs(this.targetScroll - this.currentScroll) < 0.1f) {
                this.currentScroll = this.targetScroll;
            }
        } else {
            this.currentScroll = 0.0f;
            this.targetScroll = 0.0f;
        }
        float scrollOffset = this.currentScroll;
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        scissor.push(matrices.method_23760().method_23761(), this.x + 5.0f, this.y, maxWidth, 14.0f);
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        int nameColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(0, 0, 0, 255).getRGB() : -2828575;
        if (clickGuiModule != null) {
            nameColor = clickGuiModule.getTextColor();
        }
        Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(matrices, settingName, this.x + 5.0f - scrollOffset, this.y + 5.0f, nameColor);
        scissor.pop();
        this.renderOptions(matrices, mouseX, mouseY, options, selected, clickGuiModule);
    }

    private void renderOptions(class_4587 matrices, int mouseX, int mouseY, List<String> options, String selected, ClickGui clickGuiModule) {
        float startY = this.y + 18.0f;
        float buttonHeight = 12.0f;
        float totalWidth = this.width - 10.0f;
        float buttonSpacing = 2.0f;
        float rowSpacing = 2.0f;
        float[] buttonWidths = new float[options.size()];
        for (int i = 0; i < options.size(); ++i) {
            float textWidth = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth(options.get(i));
            buttonWidths[i] = textWidth + 4.0f;
        }
        float currentX = this.x + 5.0f;
        float currentY = startY;
        int currentRow = 0;
        for (int i = 0; i < options.size(); ++i) {
            int textColor;
            String option = options.get(i);
            float buttonWidth = buttonWidths[i];
            if (currentX + buttonWidth > this.x + 5.0f + totalWidth && currentX > this.x + 5.0f) {
                currentX = this.x + 5.0f;
                currentY += buttonHeight + rowSpacing;
                ++currentRow;
            }
            float buttonX = currentX;
            float buttonY = currentY;
            boolean isSelected = option.equals(selected);
            boolean isHovered = Calculate.isHovered(mouseX, mouseY, buttonX, buttonY, buttonWidth, buttonHeight);
            Animation anim = this.optionAnimations.get(option);
            if (anim != null) {
                anim.setDirection(isSelected ? Direction.FORWARDS : Direction.BACKWARDS);
                float animProgress = anim.getOutput().floatValue();
                int bgColorOff = new Color(82, 84, 157, 31).getRGB();
                int bgColorOn = new Color(70, 100, 200, 180).getRGB();
                if (clickGuiModule != null) {
                    bgColorOff = clickGuiModule.getControlOffColor();
                    bgColorOn = clickGuiModule.getControlOnColor();
                }
                int r1 = bgColorOff >> 16 & 0xFF;
                int g1 = bgColorOff >> 8 & 0xFF;
                int b1 = bgColorOff & 0xFF;
                int a1 = bgColorOff >> 24 & 0xFF;
                int r2 = bgColorOn >> 16 & 0xFF;
                int g2 = bgColorOn >> 8 & 0xFF;
                int b2 = bgColorOn & 0xFF;
                int a2 = bgColorOn >> 24 & 0xFF;
                int r = (int)((float)r1 + (float)(r2 - r1) * animProgress);
                int g = (int)((float)g1 + (float)(g2 - g1) * animProgress);
                int b = (int)((float)b1 + (float)(b2 - b1) * animProgress);
                int a = (int)((float)a1 + (float)(a2 - a1) * animProgress);
                int bgColor = a << 24 | r << 16 | g << 8 | b;
                rectangle.render(ShapeProperties.create(matrices, buttonX, buttonY, buttonWidth, buttonHeight).round(3.0f, 1.0f, 1.0f, 3.0f).thickness(1.0f).outlineColor(clickGuiModule != null ? clickGuiModule.getControlOutlineColor(isHovered) : (isHovered ? new Color(255, 255, 255, 200).getRGB() : new Color(55, 55, 55, 150).getRGB())).color(bgColor).build());
            }
            float textWidth = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth(option);
            float textX = buttonX + (buttonWidth - textWidth) / 2.0f;
            float textY = buttonY + (buttonHeight - 9.0f) / 2.0f + 2.6f;
            if (clickGuiModule != null && clickGuiModule.isWhite()) {
                textColor = isSelected ? new Color(0, 0, 0, 255).getRGB() : new Color(80, 80, 80, 255).getRGB();
            } else {
                int n = textColor = isSelected ? -1 : -2828575;
            }
            if (clickGuiModule != null) {
                textColor = isSelected ? clickGuiModule.getTextColor() : clickGuiModule.getInactiveTextColor();
            }
            Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(matrices, option, textX, textY, textColor);
            currentX += buttonWidth + buttonSpacing;
        }
        this.height = (int)(currentY - this.y + buttonHeight);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            List<String> options = this.setting.getList();
            float startY = this.y + 18.0f;
            float buttonHeight = 12.0f;
            float totalWidth = this.width - 10.0f;
            float buttonSpacing = 2.0f;
            float rowSpacing = 2.0f;
            float[] buttonWidths = new float[options.size()];
            for (int i = 0; i < options.size(); ++i) {
                float textWidth = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth(options.get(i));
                buttonWidths[i] = textWidth + 4.0f;
            }
            float currentX = this.x + 5.0f;
            float currentY = startY;
            for (int i = 0; i < options.size(); ++i) {
                float buttonY;
                float buttonX;
                String option = options.get(i);
                float buttonWidth = buttonWidths[i];
                if (currentX + buttonWidth > this.x + 5.0f + totalWidth && currentX > this.x + 5.0f) {
                    currentX = this.x + 5.0f;
                    currentY += buttonHeight + rowSpacing;
                }
                if (Calculate.isHovered(mouseX, mouseY, buttonX = currentX, buttonY = currentY, buttonWidth, buttonHeight)) {
                    this.setting.setSelected(option);
                    return true;
                }
                currentX += buttonWidth + buttonSpacing;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}

