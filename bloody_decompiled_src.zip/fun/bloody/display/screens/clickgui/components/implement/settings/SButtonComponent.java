/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 */
package fun.bloody.display.screens.clickgui.components.implement.settings;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.components.implement.other.ButtonComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.setting.implement.ButtonSetting;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_332;

public class SButtonComponent
extends AbstractSettingComponent {
    private final ButtonComponent buttonComponent = new ButtonComponent();
    private final ButtonSetting setting;
    private float currentScroll = 0.0f;
    private float targetScroll = 0.0f;
    private boolean isHovered = false;

    public SButtonComponent(ButtonSetting setting) {
        super(setting);
        this.setting = setting;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        this.height = 22.0f;
        float maxWidth = this.width - this.buttonComponent.width - 20.0f;
        String settingName = this.setting.getName();
        float textWidth = Fonts.getSize(14, Fonts.Type.BOLD).getStringWidth(settingName);
        boolean needsScroll = textWidth > maxWidth;
        boolean currentlyHovered = Calculate.isHovered(mouseX, mouseY, this.x + 5.0f, this.y + 4.0f, maxWidth, 14.0);
        if (currentlyHovered != this.isHovered) {
            this.isHovered = currentlyHovered;
        }
        if (needsScroll) {
            float maxScroll = textWidth - maxWidth + 10.0f;
            this.targetScroll = this.isHovered ? maxScroll : 0.0f;
            float lerpSpeed = 0.05f;
            this.currentScroll += (this.targetScroll - this.currentScroll) * lerpSpeed;
            if (Math.abs(this.targetScroll - this.currentScroll) < 0.1f) {
                this.currentScroll = this.targetScroll;
            }
        } else {
            this.currentScroll = 0.0f;
            this.targetScroll = 0.0f;
        }
        float scrollOffset = this.currentScroll;
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        int nameColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(0, 0, 0, 255).getRGB() : -2828575;
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        scissor.push(context.method_51448().method_23760().method_23761(), this.x + 5.0f, this.y, maxWidth, 22.0f);
        if (clickGuiModule != null) {
            nameColor = clickGuiModule.getTextColor();
        }
        Fonts.getSize(14, Fonts.Type.BOLD).drawString(context.method_51448(), settingName, this.x + 5.0f - scrollOffset, this.y + 9.0f, nameColor);
        scissor.pop();
        ((ButtonComponent)this.buttonComponent.setText("Click on me").setColor(clickGuiModule != null ? clickGuiModule.getControlOnColor() : -8288257).setRunnable(this.setting.getRunnable()).position(this.x + this.width - 9.0f - this.buttonComponent.width, this.y + 9.0f)).render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        this.buttonComponent.mouseClicked(mouseX, mouseY, button);
        return super.mouseClicked(mouseX, mouseY, button);
    }
}

