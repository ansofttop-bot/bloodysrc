/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_437
 *  net.minecraft.class_4587
 *  org.lwjgl.glfw.GLFW
 */
package fun.bloody.display.screens.clickgui.components.implement.other;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.MenuScreen;
import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.theme.ThemeManager;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import org.lwjgl.glfw.GLFW;

public class SearchComponent
extends AbstractComponent {
    public static boolean typing = false;
    private boolean dragging;
    private int cursorPosition = 0;
    private int selectionStart = -1;
    private int selectionEnd = -1;
    private long lastClickTime = 0L;
    private float xOffset = 0.0f;
    private String text = "";

    public void setText(String text) {
        this.text = text;
        this.cursorPosition = 0;
        this.clearSelection();
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        boolean focused;
        int end;
        int start;
        class_4587 matrix = context.method_51448();
        ThemeManager themeManager = ThemeManager.getInstance();
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        FontRenderer font = Fonts.getSize(14);
        this.updateXOffset(font, this.cursorPosition);
        this.width = 160.0f;
        this.height = 24.0f;
        int bgColor = clickGuiModule != null && !clickGuiModule.isTransparent() ? clickGuiModule.getPanelColor() : themeManager.getWindowBackgroundColor();
        blur.render(ShapeProperties.create(matrix, this.x, this.y, this.width, this.height).round(5.0f).color(ColorAssist.reAlphaInt(bgColor, 200)).build());
        int boxCol = ColorAssist.multBright(bgColor, 1.15f);
        rectangle.render(ShapeProperties.create(matrix, this.x, this.y, this.width, this.height).round(5.0f).outlineColor(0).color(ColorAssist.reAlphaInt(boxCol, 220)).build());
        int headColor = clickGuiModule != null && !clickGuiModule.isTransparent() ? clickGuiModule.getControlOffColor() : themeManager.getHeaderColor();
        rectangle.render(ShapeProperties.create(matrix, this.x + 5.0f, this.y + 5.0f, this.width - 10.0f, this.height - 10.0f).round(4.0f).outlineColor(ColorAssist.reAlphaInt(headColor, 225)).color(ColorAssist.reAlphaInt(headColor, 155), ColorAssist.reAlphaInt(headColor, 155), ColorAssist.reAlphaInt(headColor, 155), ColorAssist.reAlphaInt(headColor, 155)).build());
        if (Calculate.isHovered(mouseX, mouseY, this.x + 5.0f, this.y + 5.0f, this.width - 10.0f, this.height - 10.0f)) {
            rectangle.render(ShapeProperties.create(matrix, this.x + 5.0f, this.y + 5.0f, this.width - 10.0f, this.height - 10.0f).round(4.0f).color(ColorAssist.reAlphaInt(clickGuiModule != null ? clickGuiModule.getAccentColor() : themeManager.getPrimaryColor(), 55)).build());
        }
        Fonts.getSize(40, Fonts.Type.ICONS).drawString(context.method_51448(), "U", this.x + this.width - 24.0f, this.y + 4.0f, typing ? -1 : -7894892);
        String displayText = this.text.equalsIgnoreCase("") && !typing ? "Search module..." : this.text;
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        scissor.push(matrix.method_23760().method_23761(), this.x + 4.0f, this.y, this.width - 30.0f, this.height);
        if (typing && this.selectionStart != -1 && this.selectionEnd != -1 && this.selectionStart != this.selectionEnd && (start = Math.max(0, Math.min(this.getStartOfSelection(), this.text.length()))) < (end = Math.max(0, Math.min(this.getEndOfSelection(), this.text.length())))) {
            float selectionXStart = this.x + 6.0f - this.xOffset + font.getStringWidth(this.text.substring(0, start));
            float selectionXEnd = this.x + 6.0f - this.xOffset + font.getStringWidth(this.text.substring(0, end));
            float selectionWidth = selectionXEnd - selectionXStart;
            rectangle.render(ShapeProperties.create(matrix, selectionXStart, this.y + this.height / 2.0f - 5.0f, selectionWidth, 10.0).color(clickGuiModule != null ? clickGuiModule.getControlOnColor() : -11172376).build());
        }
        int textColor = clickGuiModule != null ? (typing ? clickGuiModule.getTextColor() : clickGuiModule.getInactiveTextColor()) : (typing ? themeManager.getTextColor() : themeManager.getInactiveTextColor());
        font.drawString(context.method_51448(), displayText, this.x + 6.0f - this.xOffset, this.y + this.height / 2.0f - 2.0f, textColor);
        scissor.pop();
        long currentTime = System.currentTimeMillis();
        boolean bl = focused = typing && currentTime % 1000L < 500L;
        if (focused && (this.selectionStart == -1 || this.selectionStart == this.selectionEnd)) {
            float cursorX = font.getStringWidth(this.text.substring(0, this.cursorPosition));
            rectangle.render(ShapeProperties.create(matrix, this.x + 6.0f - this.xOffset + cursorX, this.y + this.height / 2.0f - 4.5f, 0.8f, 9.0).color(-1).build());
        }
        if (this.dragging) {
            double[] transformed = this.transformMouseCoords(mouseX, mouseY);
            this.cursorPosition = this.getCursorIndexAt(transformed[0]);
            if (this.selectionStart == -1) {
                this.selectionStart = this.cursorPosition;
            }
            this.selectionEnd = this.cursorPosition;
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double[] transformed = this.transformMouseCoords(mouseX, mouseY);
        boolean isHovered = Calculate.isHovered(transformed[0], transformed[1], this.x, this.y, this.width, this.height);
        if (isHovered && button == 0) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - this.lastClickTime < 250L) {
                this.selectionStart = 0;
                this.selectionEnd = this.text.length();
            } else {
                typing = true;
                this.dragging = true;
                this.lastClickTime = currentTime;
                this.selectionStart = this.cursorPosition = this.getCursorIndexAt(transformed[0]);
                this.selectionEnd = this.cursorPosition;
            }
        } else if (!isHovered) {
            typing = false;
            this.clearSelection();
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            this.dragging = false;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (typing && Fonts.getSize(12).getStringWidth(this.text) < 55.0f) {
            this.deleteSelectedText();
            this.text = this.text.substring(0, this.cursorPosition) + chr + this.text.substring(this.cursorPosition);
            ++this.cursorPosition;
            this.clearSelection();
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (typing) {
            if (class_437.method_25441()) {
                switch (keyCode) {
                    case 65: {
                        this.selectAllText();
                        break;
                    }
                    case 86: {
                        this.pasteFromClipboard();
                        break;
                    }
                    case 67: {
                        this.copyToClipboard();
                    }
                }
            } else {
                switch (keyCode) {
                    case 257: 
                    case 259: {
                        this.handleTextModification(keyCode);
                        break;
                    }
                    case 262: 
                    case 263: {
                        this.moveCursor(keyCode);
                    }
                }
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private double[] transformMouseCoords(double mouseX, double mouseY) {
        MenuScreen menu = MenuScreen.INSTANCE;
        float scale = menu.getScaleAnimation();
        float centerX = (float)menu.x + (float)menu.width / 2.0f;
        float centerY = (float)menu.y + (float)menu.height / 2.0f;
        double transformedX = (mouseX - (double)centerX) / (double)scale + (double)centerX;
        double transformedY = (mouseY - (double)centerY) / (double)scale + (double)centerY;
        return new double[]{transformedX, transformedY};
    }

    private void pasteFromClipboard() {
        String clipboardText = GLFW.glfwGetClipboardString((long)window.method_4490());
        if (clipboardText != null) {
            this.deleteSelectedText();
            this.replaceText(this.cursorPosition, this.cursorPosition, clipboardText);
        }
    }

    private void copyToClipboard() {
        if (this.hasSelection()) {
            GLFW.glfwSetClipboardString((long)window.method_4490(), (CharSequence)this.getSelectedText());
        }
    }

    private void selectAllText() {
        this.selectionStart = 0;
        this.selectionEnd = this.text.length();
        this.cursorPosition = this.text.length();
    }

    private void handleTextModification(int keyCode) {
        if (keyCode == 259) {
            if (this.hasSelection()) {
                this.replaceText(this.getStartOfSelection(), this.getEndOfSelection(), "");
            } else if (this.cursorPosition > 0) {
                this.replaceText(this.cursorPosition - 1, this.cursorPosition, "");
            }
        } else if (keyCode == 257) {
            typing = false;
            this.clearSelection();
        }
    }

    private void moveCursor(int keyCode) {
        if (class_437.method_25442()) {
            if (this.selectionStart == -1) {
                this.selectionStart = this.cursorPosition;
            }
        } else {
            this.clearSelection();
        }
        if (keyCode == 263 && this.cursorPosition > 0) {
            --this.cursorPosition;
        } else if (keyCode == 262 && this.cursorPosition < this.text.length()) {
            ++this.cursorPosition;
        }
        if (class_437.method_25442()) {
            this.selectionEnd = this.cursorPosition;
        }
    }

    private void replaceText(int start, int end, String replacement) {
        if (start < 0) {
            start = 0;
        }
        if (end > this.text.length()) {
            end = this.text.length();
        }
        if (start > end) {
            int temp = start;
            start = end;
            end = temp;
        }
        this.text = this.text.substring(0, start) + replacement + this.text.substring(end);
        this.cursorPosition = start + replacement.length();
        this.clearSelection();
    }

    private boolean hasSelection() {
        return this.selectionStart != -1 && this.selectionEnd != -1 && this.selectionStart != this.selectionEnd;
    }

    private String getSelectedText() {
        return this.text.substring(this.getStartOfSelection(), this.getEndOfSelection());
    }

    private int getStartOfSelection() {
        return Math.min(this.selectionStart, this.selectionEnd);
    }

    private int getEndOfSelection() {
        return Math.max(this.selectionStart, this.selectionEnd);
    }

    private void clearSelection() {
        this.selectionStart = -1;
        this.selectionEnd = -1;
    }

    private int getCursorIndexAt(double mouseX) {
        int position;
        FontRenderer font = Fonts.getSize(12);
        float relativeX = (float)mouseX - this.x - 4.0f + this.xOffset;
        for (position = 0; position < this.text.length(); ++position) {
            float charWidth = font.getStringWidth(this.text.substring(position, position + 1));
            float textWidth = font.getStringWidth(this.text.substring(0, position));
            if (textWidth + charWidth / 2.0f > relativeX) break;
        }
        return Math.max(0, Math.min(position, this.text.length()));
    }

    private void updateXOffset(FontRenderer font, int cursorPosition) {
        float cursorX = font.getStringWidth(this.text.substring(0, Math.min(cursorPosition, this.text.length())));
        float visibleWidth = this.width - 8.0f;
        if (cursorX < this.xOffset) {
            this.xOffset = Math.max(0.0f, cursorX - 10.0f);
        } else if (cursorX - this.xOffset > visibleWidth) {
            this.xOffset = cursorX - visibleWidth + 10.0f;
        }
        if (this.xOffset < 0.0f) {
            this.xOffset = 0.0f;
        }
    }

    private void deleteSelectedText() {
        if (this.hasSelection()) {
            this.replaceText(this.getStartOfSelection(), this.getEndOfSelection(), "");
        }
    }

    public String getText() {
        return this.text;
    }
}

