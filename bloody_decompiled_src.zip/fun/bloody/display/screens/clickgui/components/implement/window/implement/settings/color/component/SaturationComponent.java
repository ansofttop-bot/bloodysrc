/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color.component;

import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class SaturationComponent
extends AbstractComponent {
    private final ColorSetting setting;
    private boolean saturationDragging;

    private float getSliderX() {
        return this.x + 6.0f;
    }

    private float getSliderY() {
        return this.y + 73.5f;
    }

    private float getSliderW() {
        return 88.0f;
    }

    private float getSliderH() {
        return 4.0f;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        class_4587 matrix = context.method_51448();
        float X = this.getSliderX();
        float Y = this.getSliderY();
        float W = this.getSliderW();
        float H = this.getSliderH();
        float clampedX = class_3532.method_15363((float)(X + W * this.setting.getHue()), (float)X, (float)(X + W - 4.0f));
        image.setTexture("textures/gui/sliderhue.png").render(ShapeProperties.create(matrix, X, (double)Y + 0.5, W, H - 1.0f).build());
        rectangle.render(ShapeProperties.create(matrix, clampedX, Y, H, H).round(H / 2.0f).thickness(3.0f).color(0xFFFFFF).outlineColor(-1).build());
        if (this.saturationDragging) {
            this.setting.setHue(class_3532.method_15363((float)(((float)mouseX - X) / W), (float)0.0f, (float)1.0f));
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        this.saturationDragging = button == 0 && Calculate.isHovered(mouseX, mouseY, this.getSliderX(), this.getSliderY(), this.getSliderW(), this.getSliderH());
        return this.saturationDragging || super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.saturationDragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    public SaturationComponent(ColorSetting setting) {
        this.setting = setting;
    }
}

