/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.settings;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.display.screens.clickgui.theme.ThemeManager;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class SliderComponent
extends AbstractSettingComponent {
    public static final int SLIDER_WIDTH = 110;
    private final SliderSettings setting;
    private boolean dragging;
    private double animation;
    private float currentScroll = 0.0f;
    private float targetScroll = 0.0f;
    private boolean isHovered = false;

    public SliderComponent(SliderSettings setting) {
        super(setting);
        this.setting = setting;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        String value;
        class_4587 matrix = context.method_51448();
        ThemeManager themeManager = ThemeManager.getInstance();
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        int textColor = clickGuiModule != null ? clickGuiModule.getTextColor() : themeManager.getTextColor();
        float nameWidth = Fonts.getSize(14, Fonts.Type.DEFAULT).getStringWidth(this.setting.getName());
        this.height = 26.0f;
        if (this.setting.isInteger()) {
            value = String.valueOf((int)this.setting.getValue());
        } else {
            double val = this.setting.getValue();
            if (val == Math.floor(val)) {
                value = String.valueOf((int)val);
            } else {
                value = String.format("%.2f", val);
                value = value.replaceAll("0+$", "").replaceAll("\\.$", "");
            }
        }
        float knobPosition = this.changeValue(this.getDifference(mouseX, matrix));
        float maxWidth = this.width - 35.0f;
        String settingName = this.setting.getName();
        float textWidth = Fonts.getSize(14, Fonts.Type.DEFAULT).getStringWidth(settingName);
        boolean needsScroll = textWidth > maxWidth;
        boolean currentlyHovered = Calculate.isHovered(mouseX, mouseY, this.x + 5.0f, this.y + 5.0f, maxWidth, 14.0);
        if (currentlyHovered != this.isHovered) {
            this.isHovered = currentlyHovered;
        }
        if (needsScroll) {
            float maxScroll = textWidth - maxWidth;
            this.targetScroll = this.isHovered ? maxScroll : 0.0f;
            float lerpSpeed = 0.05f;
            this.currentScroll += (this.targetScroll - this.currentScroll) * lerpSpeed;
            if (Math.abs(this.targetScroll - this.currentScroll) < 0.1f) {
                this.currentScroll = this.targetScroll;
            }
        } else {
            this.currentScroll = 0.0f;
            this.targetScroll = 0.0f;
        }
        float scrollOffset = this.currentScroll;
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        float scissorWidth = this.width - 30.0f;
        scissor.push(matrix.method_23760().method_23761(), this.x + 5.0f, this.y, scissorWidth, 34.0f);
        Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(matrix, settingName, this.x + 5.0f - scrollOffset, this.y + 5.0f, textColor);
        scissor.pop();
        float sliderEndX = this.x + 5.0f + (this.width - 30.0f);
        Fonts.getSize(14, Fonts.Type.BOLD).drawString(matrix, value, sliderEndX + 3.0f, this.y + 17.5f, textColor);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        float sliderX = this.x + 6.0f;
        float sliderWidth = this.width - 30.0f;
        if (Calculate.isHovered(mouseX, mouseY, sliderX, this.y + 16.0f, sliderWidth, 10.0) && button == 0) {
            this.dragging = true;
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.dragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private float getDifference(int mouseX, class_4587 matrix) {
        ThemeManager themeManager = ThemeManager.getInstance();
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        float sliderX = this.x + 5.0f;
        float sliderWidth = this.width - 30.0f;
        float percentValue = sliderWidth * (this.setting.getValue() - this.setting.getMin()) / (this.setting.getMax() - this.setting.getMin());
        float difference = class_3532.method_15363((float)((float)mouseX - sliderX), (float)0.0f, (float)sliderWidth);
        this.animation = Calculate.interpolate(this.animation, (double)percentValue);
        int trackBg = new Color(70, 100, 200, 40).getRGB();
        int activeBg = new Color(70, 100, 200, 180).getRGB();
        if (clickGuiModule != null) {
            trackBg = clickGuiModule.getControlOffColor();
            activeBg = clickGuiModule.getControlOnColor();
        }
        rectangle.render(ShapeProperties.create(matrix, sliderX, this.y + 19.0f, sliderWidth, 4.0).round(2.0f).color(trackBg).build());
        rectangle.render(ShapeProperties.create(matrix, sliderX, this.y + 19.0f, (float)this.animation, 4.0).round(2.0f).color(activeBg).build());
        float knobCenterX = sliderX + (float)this.animation;
        rectangle.render(ShapeProperties.create(matrix, knobCenterX - 4.0f, this.y + 17.0f, 8.0, 8.0).round(4.0f).color(activeBg).build());
        rectangle.render(ShapeProperties.create(matrix, knobCenterX - 3.0f, this.y + 18.0f, 6.0, 6.0).round(3.0f).color(clickGuiModule != null ? clickGuiModule.getCheckColor(255) : -1).build());
        return knobCenterX;
    }

    private float changeValue(float knobPosition) {
        if (this.dragging) {
            float sliderX = this.x + 5.0f;
            float sliderWidth = this.width - 30.0f;
            float difference = class_3532.method_15363((float)((float)(SliderComponent.mc.field_1729.method_1603() / mc.method_22683().method_4495()) - sliderX), (float)0.0f, (float)sliderWidth);
            float value = difference / sliderWidth * (this.setting.getMax() - this.setting.getMin()) + this.setting.getMin();
            if (this.setting.isInteger()) {
                value = (int)value;
            }
            this.setting.setValue(value);
        }
        return knobPosition;
    }
}

