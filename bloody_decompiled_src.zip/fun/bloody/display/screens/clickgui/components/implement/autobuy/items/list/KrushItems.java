/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1893
 *  net.minecraft.class_1935
 *  net.minecraft.class_2487
 *  net.minecraft.class_2561
 *  net.minecraft.class_310
 *  net.minecraft.class_5321
 *  net.minecraft.class_5455
 *  net.minecraft.class_6880
 *  net.minecraft.class_7225$class_7226
 *  net.minecraft.class_7924
 *  net.minecraft.class_9279
 *  net.minecraft.class_9290
 *  net.minecraft.class_9304
 *  net.minecraft.class_9304$class_9305
 *  net.minecraft.class_9334
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1893;
import net.minecraft.class_1935;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class KrushItems {
    public static class_1799 getHelmet() {
        class_1799 stack = new class_1799((class_1935)class_1802.field_22027);
        KrushItems.addEnchantments(stack, class_1893.field_9095, 5, class_1893.field_9111, 5, class_1893.field_9127, 3, class_1893.field_9096, 5, class_1893.field_9101, 1, class_1893.field_9119, 5, class_1893.field_9107, 5, class_1893.field_9105, 1);
        KrushItems.setupItem(stack, KrushItems.createStyledName("\u0428\u043b\u0435\u043c \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f"), List.of(class_2561.method_43470((String)"[\u2605] \u041e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442").method_27692(class_124.field_1080)));
        return stack;
    }

    public static class_1799 getChestplate() {
        class_1799 stack = new class_1799((class_1935)class_1802.field_22028);
        KrushItems.addEnchantments(stack, class_1893.field_9095, 5, class_1893.field_9096, 5, class_1893.field_9111, 5, class_1893.field_9101, 1, class_1893.field_9119, 5, class_1893.field_9107, 5);
        KrushItems.setupItem(stack, KrushItems.createStyledName("\u041d\u0430\u0433\u0440\u0443\u0434\u043d\u0438\u043a \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f"), List.of(class_2561.method_43470((String)"[\u2605] \u041e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442").method_27692(class_124.field_1080)));
        return stack;
    }

    public static class_1799 getLeggings() {
        class_1799 stack = new class_1799((class_1935)class_1802.field_22029);
        KrushItems.addEnchantments(stack, class_1893.field_9095, 5, class_1893.field_9096, 5, class_1893.field_9111, 5, class_1893.field_9101, 1, class_1893.field_9119, 5, class_1893.field_9107, 5);
        KrushItems.setupItem(stack, KrushItems.createStyledName("\u041f\u043e\u043d\u043e\u0436\u0438 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f"), List.of(class_2561.method_43470((String)"[\u2605] \u041e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442").method_27692(class_124.field_1080)));
        return stack;
    }

    public static class_1799 getBoots() {
        class_1799 stack = new class_1799((class_1935)class_1802.field_22030);
        KrushItems.addEnchantments(stack, class_1893.field_9095, 5, class_1893.field_9111, 5, class_1893.field_23071, 3, class_1893.field_9129, 4, class_1893.field_9128, 3, class_1893.field_9096, 5, class_1893.field_9101, 1, class_1893.field_9119, 5, class_1893.field_9107, 5);
        KrushItems.setupItem(stack, KrushItems.createStyledName("\u0411\u043e\u0442\u0438\u043d\u043a\u0438 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f"), List.of(class_2561.method_43470((String)"[\u2605] \u041e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442").method_27692(class_124.field_1080)));
        return stack;
    }

    public static class_1799 getSword() {
        class_1799 stack = new class_1799((class_1935)class_1802.field_22022);
        KrushItems.addEnchantments(stack, class_1893.field_9118, 7, class_1893.field_9112, 7, class_1893.field_9124, 2, class_1893.field_9115, 3, class_1893.field_9101, 1, class_1893.field_9110, 5, class_1893.field_9123, 7, class_1893.field_9119, 5);
        KrushItems.setupItem(stack, KrushItems.createStyledName("\u041c\u0435\u0447 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f"), List.of(class_2561.method_43470((String)"\u041e\u043f\u044b\u0442\u043d\u044b\u0439 III").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u0412\u0430\u043c\u043f\u0438\u0440\u0438\u0437\u043c II").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u041e\u043a\u0438\u0441\u043b\u0435\u043d\u0438\u0435 II").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u042f\u0434 III").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u0414\u0435\u0442\u0435\u043a\u0446\u0438\u044f III").method_27692(class_124.field_1080), class_2561.method_43470((String)"[\u2605] \u041e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442").method_27692(class_124.field_1080)));
        return stack;
    }

    public static class_1799 getPickaxe() {
        class_1799 stack = new class_1799((class_1935)class_1802.field_22024);
        KrushItems.addEnchantments(stack, class_1893.field_9131, 10, class_1893.field_9101, 1, class_1893.field_9130, 5, class_1893.field_9119, 5);
        KrushItems.setupItem(stack, KrushItems.createStyledName("\u041a\u0438\u0440\u043a\u0430 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f"), List.of(class_2561.method_43470((String)"\u0411\u0443\u043b\u044c\u0434\u043e\u0437\u0435\u0440 II").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u041e\u043f\u044b\u0442\u043d\u044b\u0439 III").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u041c\u0430\u0433\u043d\u0438\u0442").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u0410\u0432\u0442\u043e-\u041f\u043b\u0430\u0432\u043a\u0430").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u041f\u0430\u0443\u0442\u0438\u043d\u0430").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u041f\u0438\u043d\u0433\u0435\u0440").method_27692(class_124.field_1080), class_2561.method_43470((String)"[\u2605] \u041e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442").method_27692(class_124.field_1080)));
        return stack;
    }

    public static class_1799 getCrossbow() {
        class_1799 stack = new class_1799((class_1935)class_1802.field_8399);
        KrushItems.addEnchantments(stack, class_1893.field_9108, 1, class_1893.field_9101, 1, class_1893.field_9132, 5, class_1893.field_9119, 3, class_1893.field_9098, 3);
        KrushItems.setupItem(stack, KrushItems.createStyledName("\u0410\u0440\u0431\u0430\u043b\u0435\u0442 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f"), List.of(class_2561.method_43470((String)"[\u2605] \u041e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442").method_27692(class_124.field_1080)));
        return stack;
    }

    public static class_1799 getTrident() {
        class_1799 stack = new class_1799((class_1935)class_1802.field_8547);
        KrushItems.addEnchantments(stack, class_1893.field_9117, 1, class_1893.field_9118, 7, class_1893.field_9124, 2, class_1893.field_9101, 1, class_1893.field_9119, 5, class_1893.field_9120, 3, class_1893.field_9106, 5);
        KrushItems.setupItem(stack, KrushItems.createStyledName("\u0422\u0440\u0435\u0437\u0443\u0431\u0435\u0446 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f"), List.of(class_2561.method_43470((String)"\u0421\u043a\u0430\u0443\u0442 III").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u041e\u043f\u044b\u0442\u043d\u044b\u0439 III").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u0412\u0430\u043c\u043f\u0438\u0440\u0438\u0437\u043c II").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u0421\u0442\u0443\u043f\u043e\u0440 III").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u041f\u0440\u0438\u0442\u044f\u0436\u0435\u043d\u0438\u0435 II").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u041e\u043a\u0438\u0441\u043b\u0435\u043d\u0438\u0435 II").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u0412\u043e\u0437\u0432\u0440\u0430\u0449\u0435\u043d\u0438\u0435").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u041f\u043e\u0434\u0440\u044b\u0432\u043d\u0438\u043a").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u042f\u0434 III").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u0414\u0435\u0442\u0435\u043a\u0446\u0438\u044f III").method_27692(class_124.field_1080), class_2561.method_43470((String)"[\u2605] \u041e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442").method_27692(class_124.field_1080)));
        return stack;
    }

    public static class_1799 getMace() {
        class_1799 stack = new class_1799((class_1935)class_1802.field_49814);
        KrushItems.addEnchantments(stack, class_1893.field_9118, 7, class_1893.field_9123, 7, class_1893.field_9112, 7, class_1893.field_50157, 5, class_1893.field_50158, 3, class_1893.field_9115, 3, class_1893.field_9124, 2, class_1893.field_9110, 5, class_1893.field_9119, 5, class_1893.field_9101, 1);
        KrushItems.setupItem(stack, KrushItems.createStyledName("\u0411\u0443\u043b\u0430\u0432\u0430 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f"), List.of(class_2561.method_43470((String)"\u041e\u043f\u044b\u0442\u043d\u044b\u0439 III").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u0412\u0430\u043c\u043f\u0438\u0440\u0438\u0437\u043c II").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u041e\u043a\u0438\u0441\u043b\u0435\u043d\u0438\u0435 II").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u042f\u0434 III").method_27692(class_124.field_1080), class_2561.method_43470((String)"\u0414\u0435\u0442\u0435\u043a\u0446\u0438\u044f III").method_27692(class_124.field_1080), class_2561.method_43470((String)"[\u2605] \u041e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442").method_27692(class_124.field_1080)));
        return stack;
    }

    private static void addEnchantments(class_1799 stack, Object ... enchantments) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return;
        }
        try {
            class_5455 registryLookup = client.field_1687.method_30349();
            class_7225.class_7226 enchantmentRegistry = registryLookup.method_46762(class_7924.field_41265);
            class_9304.class_9305 builder = new class_9304.class_9305((class_9304)stack.method_57825(class_9334.field_49633, (Object)class_9304.field_49385));
            for (int i = 0; i < enchantments.length; i += 2) {
                try {
                    class_5321 enchantKey = (class_5321)enchantments[i];
                    int level = (Integer)enchantments[i + 1];
                    Optional enchantmentOpt = enchantmentRegistry.method_46746(enchantKey);
                    if (!enchantmentOpt.isPresent()) continue;
                    builder.method_57550((class_6880)enchantmentOpt.get(), level);
                    continue;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            stack.method_57379(class_9334.field_49633, (Object)builder.method_57549());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void setupItem(class_1799 stack, class_2561 name, List<class_2561> lore) {
        stack.method_57379(class_9334.field_49631, (Object)name);
        class_2487 nbt = new class_2487();
        nbt.method_10569("HideFlags", 127);
        nbt.method_10556("Unbreakable", true);
        stack.method_57379(class_9334.field_49628, (Object)class_9279.method_57456((class_2487)nbt));
        if (!lore.isEmpty()) {
            stack.method_57379(class_9334.field_49632, (Object)new class_9290(lore));
        }
    }

    private static class_2561 createStyledName(String baseName) {
        return class_2561.method_43470((String)baseName).method_27695(new class_124[]{class_124.field_1067, class_124.field_1079});
    }
}

