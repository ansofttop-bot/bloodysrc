/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.properties.Property
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1844
 *  net.minecraft.class_1935
 *  net.minecraft.class_2487
 *  net.minecraft.class_2499
 *  net.minecraft.class_2561
 *  net.minecraft.class_9279
 *  net.minecraft.class_9290
 *  net.minecraft.class_9296
 *  net.minecraft.class_9334
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.items.customitem;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.AutoBuyableItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.settings.AutoBuyItemSettings;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.settings.AutoBuySettingsManager;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1935;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9296;
import net.minecraft.class_9334;

public class CustomItem
implements AutoBuyableItem {
    private final String displayName;
    private final class_2487 nbt;
    private final class_1792 material;
    private final int price;
    private final class_1844 potionContents;
    private final List<class_2561> loreTexts;
    private final AutoBuyItemSettings settings;
    private boolean enabled;

    public CustomItem(String displayName, class_2487 nbt, class_1792 material, int price, class_1844 potionContents, List<class_2561> loreTexts) {
        this.displayName = displayName;
        this.nbt = nbt;
        this.material = material;
        this.price = price;
        this.potionContents = potionContents;
        this.loreTexts = loreTexts;
        this.enabled = true;
        this.settings = new AutoBuyItemSettings(price, material, displayName);
        AutoBuySettingsManager.getInstance().loadSettings(displayName, this.settings);
    }

    public CustomItem(String displayName, class_2487 nbt, class_1792 material, int price) {
        this(displayName, nbt, material, price, null, null);
    }

    @Override
    public String getDisplayName() {
        return this.displayName;
    }

    @Override
    public class_1799 createItemStack() {
        class_1799 stack = new class_1799((class_1935)this.material);
        stack.method_57379(class_9334.field_49631, (Object)class_2561.method_43470((String)this.displayName));
        if (this.material == class_1802.field_8574) {
            int color = switch (this.displayName) {
                case "\u0417\u0435\u043b\u044c\u0435 \u043e\u0442\u0440\u044b\u0436\u043a\u0438" -> 16735488;
                case "\u0417\u0435\u043b\u044c\u0435 \u0441\u0435\u0440\u043d\u043e\u0439 \u043a\u0438\u0441\u043b\u043e\u0442\u044b" -> 49664;
                case "\u0417\u0435\u043b\u044c\u0435 \u0432\u0441\u043f\u044b\u0448\u043a\u0438" -> 0xFFFFFF;
                case "\u0417\u0435\u043b\u044c\u0435 \u043c\u043e\u0447\u0438 \u0424\u043b\u0435\u0448\u0430" -> 6092799;
                case "\u0417\u0435\u043b\u044c\u0435 \u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f" -> 65280;
                case "\u0417\u0435\u043b\u044c\u0435 \u0430\u0433\u0435\u043d\u0442\u0430" -> 0xFFFB00;
                case "\u0417\u0435\u043b\u044c\u0435 \u043c\u0435\u0434\u0438\u043a\u0430" -> 16711902;
                case "\u0417\u0435\u043b\u044c\u0435 \u043a\u0438\u043b\u043b\u0435\u0440\u0430" -> 0xFF0000;
                default -> 3694022;
            };
            stack.method_57379(class_9334.field_49651, (Object)new class_1844(Optional.empty(), Optional.of(color), List.of(), Optional.empty()));
        } else if (this.potionContents != null) {
            stack.method_57379(class_9334.field_49651, (Object)this.potionContents);
        }
        if (this.loreTexts != null) {
            stack.method_57379(class_9334.field_49632, (Object)new class_9290(this.loreTexts));
        }
        if (this.material == class_1802.field_8288) {
            stack.method_57379(class_9334.field_49641, (Object)true);
        }
        if (this.nbt != null) {
            class_2487 nbtCopy = this.nbt.method_10553();
            if (this.material == class_1802.field_8575 && nbtCopy.method_10573("SkullOwner", 10)) {
                class_2499 textures;
                class_2487 properties;
                class_2487 skullOwner = nbtCopy.method_10562("SkullOwner");
                UUID id = skullOwner.method_25926("Id");
                GameProfile profile = new GameProfile(id, "");
                if (skullOwner.method_10573("Properties", 10) && (properties = skullOwner.method_10562("Properties")).method_10573("textures", 9) && !(textures = properties.method_10554("textures", 10)).isEmpty()) {
                    class_2487 textureNbt = textures.method_10602(0);
                    String value = textureNbt.method_10558("Value");
                    profile.getProperties().put((Object)"textures", (Object)new Property("textures", value));
                }
                stack.method_57379(class_9334.field_49617, (Object)new class_9296(profile));
                nbtCopy.method_10551("SkullOwner");
            }
            if (!nbtCopy.method_33133()) {
                stack.method_57379(class_9334.field_49628, (Object)class_9279.method_57456((class_2487)nbtCopy));
            }
        }
        return stack;
    }

    @Override
    public int getPrice() {
        return this.price;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public AutoBuyItemSettings getSettings() {
        return this.settings;
    }
}

