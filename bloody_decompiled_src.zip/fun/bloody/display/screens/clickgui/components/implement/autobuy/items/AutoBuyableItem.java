/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.items;

import fun.bloody.display.screens.clickgui.components.implement.autobuy.settings.AutoBuyItemSettings;
import net.minecraft.class_1799;

public interface AutoBuyableItem {
    public String getDisplayName();

    public class_1799 createItemStack();

    public int getPrice();

    public boolean isEnabled();

    public void setEnabled(boolean var1);

    public AutoBuyItemSettings getSettings();
}

