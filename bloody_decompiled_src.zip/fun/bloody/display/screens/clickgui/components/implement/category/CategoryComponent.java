/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  org.joml.Matrix4f
 */
package fun.bloody.display.screens.clickgui.components.implement.category;

import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.Bloody;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.display.screens.clickgui.MenuScreen;
import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.components.implement.module.ModuleComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.SettingComponentAdder;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

public class CategoryComponent
extends AbstractComponent {
    private final List<ModuleComponent> moduleComponents = new ArrayList<ModuleComponent>();
    private final ModuleCategory category;
    private float fixedBackgroundHeight = 0.0f;
    private float moduleScroll = 0.0f;
    private float moduleSmoothedScroll = 0.0f;
    private float scrollVelocity = 0.0f;
    private float settingScroll = 0.0f;
    private float settingSmoothedScroll = 0.0f;
    private boolean isDraggingScrollbar = false;
    private float scrollbarDragOffset = 0.0f;
    private ModuleComponent settingsModule = null;
    private final Animation settingsAnimation = new Decelerate().setMs(350).setValue(1.0);
    private final List<AbstractSettingComponent> settingComponents = new ArrayList<AbstractSettingComponent>();
    private final SettingComponentAdder componentAdder = new SettingComponentAdder();

    public List<ModuleComponent> getModuleComponents() {
        return this.moduleComponents;
    }

    private void initializeModules() {
        List<Module> modules = Bloody.getInstance().getModuleRepository().modules();
        for (Module module : modules) {
            if (!module.getCategory().equals((Object)this.category)) continue;
            this.moduleComponents.add(new ModuleComponent(module));
        }
    }

    public CategoryComponent(ModuleCategory category) {
        this.category = category;
        this.initializeModules();
        this.settingsAnimation.setDirection(Direction.BACKWARDS);
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        float offsetY;
        int alpha;
        float animAlpha;
        String moduleName;
        int outlineColor;
        int blurColor;
        class_4587 matrix = context.method_51448();
        Matrix4f positionMatrix = matrix.method_23760().method_23761();
        ScissorAssist scissorManager = Bloody.getInstance().getScissorManager();
        float headerHeight = 28.0f;
        float moduleHeight = 17.0f;
        float gap = 2.0f;
        float moduleGap = 4.0f;
        float progress = this.settingsAnimation.getOutput().floatValue();
        String search = MenuScreen.INSTANCE.getSearchComponent().getText().toLowerCase();
        float modulesHeight = 0.0f;
        for (ModuleComponent component : this.moduleComponents) {
            if (!search.isEmpty() && !component.getModule().getVisibleName().toLowerCase().contains(search)) continue;
            modulesHeight += moduleHeight + moduleGap;
            float totalSettingsHeight = 0.0f;
            if (component.isExpanded() || component.getSmoothExpansion() > 0.01f) {
                for (AbstractSettingComponent sc : component.getSettingComponents()) {
                    float vis = sc.getVisibilityProgress();
                    if (vis < 0.05f) continue;
                    totalSettingsHeight += (sc.height + gap) * vis;
                }
            }
            float p = component.getSmoothExpansion();
            modulesHeight += Math.max(0.0f, totalSettingsHeight * p);
        }
        float contentHeight = modulesHeight;
        float currentHeight = headerHeight + contentHeight + 2.0f;
        float h = this.fixedBackgroundHeight > 0.0f ? this.fixedBackgroundHeight : currentHeight;
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        if (clickGuiModule != null && !clickGuiModule.isTransparent()) {
            blurColor = clickGuiModule.getPanelColor();
            outlineColor = clickGuiModule.getOutlineColor();
        } else if (clickGuiModule != null && clickGuiModule.isBlack()) {
            blurColor = new Color(0, 0, 0, 255).getRGB();
            outlineColor = new Color(50, 50, 50, 255).getRGB();
        } else {
            blurColor = new Color(0, 0, 0, 180).getRGB();
            outlineColor = new Color(82, 84, 157, 84).getRGB();
        }
        blur.render(ShapeProperties.create(matrix, this.x, this.y, this.width, h).round(8.0f).quality(32.0f).color(blurColor).build());
        rectangle.render(ShapeProperties.create(matrix, this.x, this.y, this.width, h).round(8.0f).thickness(1.0f).outlineColor(outlineColor).color(0).build());
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        progress = this.settingsAnimation.getOutput().floatValue();
        boolean inSettings = this.settingsModule != null || progress > 0.0f;
        String categoryName = this.category.getReadableName();
        String string = moduleName = this.settingsModule != null ? this.settingsModule.getModule().getVisibleName() : "";
        int headerTextColor = clickGuiModule != null && clickGuiModule.isWhite() ? -16777216 : (clickGuiModule != null && clickGuiModule.isBlack() ? -1 : -1);
        if (clickGuiModule != null && !clickGuiModule.isTransparent()) {
            headerTextColor = clickGuiModule.getTextColor();
        }
        if (progress < 1.1f) {
            animAlpha = 1.0f - progress;
            alpha = (int)(255.0f * animAlpha);
            offsetY = progress * 10.0f;
            if (alpha > 5) {
                Fonts.getSize(18, Fonts.Type.DEFAULT).drawString(matrix, categoryName, this.x + 10.0f, this.y + 8.5f - offsetY, ColorAssist.reAlphaInt(headerTextColor, alpha));
            }
        }
        if (progress > -0.1f && !moduleName.isEmpty()) {
            animAlpha = progress;
            alpha = (int)(255.0f * animAlpha);
            offsetY = (1.0f - progress) * 10.0f;
            if (alpha > 5) {
                Fonts.getSize(18, Fonts.Type.DEFAULT).drawString(matrix, moduleName, this.x + 10.0f, this.y + 8.5f + offsetY, ColorAssist.reAlphaInt(headerTextColor, alpha));
            }
        }
        int iconColor = clickGuiModule != null && clickGuiModule.isWhite() ? -16777216 : (clickGuiModule != null && clickGuiModule.isBlack() ? -1 : -1);
        if (clickGuiModule != null && !clickGuiModule.isTransparent()) {
            iconColor = clickGuiModule.getTextColor();
        }
        String icon = this.getIconForCategory(this.category);
        float iconW = Fonts.getSize(28, Fonts.Type.ICONSCATEGORY).getStringWidth(icon);
        Fonts.getSize(28, Fonts.Type.ICONSCATEGORY).drawString(matrix, icon, this.x + this.width - iconW - 6.0f, this.y + 6.0f, iconColor);
        float viewHeight = h - headerHeight - 4.0f;
        this.moduleScroll += this.scrollVelocity;
        this.scrollVelocity *= 0.85f;
        if (Math.abs(this.scrollVelocity) < 0.05f) {
            this.scrollVelocity = 0.0f;
        }
        float maxScrollValue = Math.max(0.0f, modulesHeight - viewHeight);
        this.moduleScroll = class_3532.method_15363((float)this.moduleScroll, (float)(-maxScrollValue), (float)0.0f);
        if (this.moduleScroll <= -maxScrollValue || this.moduleScroll >= 0.0f) {
            this.scrollVelocity = 0.0f;
        }
        this.moduleSmoothedScroll = this.moduleScroll;
        float scissorY = this.y + headerHeight - 10.0f;
        float scissorHeight = viewHeight + 14.0f;
        scissorManager.push(positionMatrix, this.x, scissorY, this.width, scissorHeight);
        float currentY = this.y + headerHeight - 4.0f + this.moduleSmoothedScroll;
        for (ModuleComponent component : this.moduleComponents) {
            if (!search.isEmpty() && !component.getModule().getVisibleName().toLowerCase().contains(search)) continue;
            float totalSettingsHeight = 0.0f;
            float p = component.getSmoothExpansion();
            if (component.isExpanded() || component.getSmoothExpansion() > 0.01f) {
                for (AbstractSettingComponent sc : component.getSettingComponents()) {
                    float vis = sc.getVisibilityProgress();
                    if (vis < 0.05f) continue;
                    totalSettingsHeight += (sc.height + gap) * vis;
                }
            }
            component.setExpansionProgress(p);
            component.setDynamicHeight(moduleHeight + Math.max(0.0f, totalSettingsHeight * p));
            component.x = this.x + 2.0f;
            component.y = currentY;
            component.width = this.width - 8.0f;
            if (component.y + component.getDynamicHeight() + 50.0f > this.y + headerHeight && component.y - 50.0f < this.y + h) {
                component.render(context, mouseX, mouseY, delta);
            }
            currentY += moduleHeight;
            if (p > 0.0f) {
                component.renderSettings(context, mouseX, mouseY, delta, this.x + 5.0f, currentY, this.width - 10.0f, gap);
                currentY += Math.max(0.0f, totalSettingsHeight * p);
            }
            currentY += moduleGap;
        }
        scissorManager.pop();
        if (maxScrollValue > 0.0f) {
            float scrollBarWidth = 3.0f;
            float scrollBarX = this.x + this.width - scrollBarWidth - 2.0f;
            float scrollBarY = this.y + headerHeight + 2.0f;
            float scrollBarHeight = viewHeight - 4.0f;
            int scrollBgColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(200, 200, 200, 100).getRGB() : (clickGuiModule != null && clickGuiModule.isBlack() ? new Color(50, 50, 50, 100).getRGB() : new Color(255, 255, 255, 30).getRGB());
            if (clickGuiModule != null && !clickGuiModule.isTransparent()) {
                scrollBgColor = clickGuiModule.getOutlineColor(80);
            }
            rectangle.render(ShapeProperties.create(matrix, scrollBarX, scrollBarY, scrollBarWidth, scrollBarHeight).round(1.5f).color(scrollBgColor).build());
            float scrollRatio = Math.abs(this.moduleScroll) / maxScrollValue;
            float thumbHeight = Math.max(20.0f, scrollBarHeight * (viewHeight / modulesHeight));
            float thumbY = scrollBarY + (scrollBarHeight - thumbHeight) * scrollRatio;
            int scrollThumbColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(100, 100, 100, 200).getRGB() : (clickGuiModule != null && clickGuiModule.isBlack() ? new Color(200, 200, 200, 200).getRGB() : new Color(255, 255, 255, 150).getRGB());
            if (clickGuiModule != null && !clickGuiModule.isTransparent()) {
                scrollThumbColor = clickGuiModule.getAccentColor(210);
            }
            rectangle.render(ShapeProperties.create(matrix, scrollBarX, thumbY, scrollBarWidth, thumbHeight).round(1.5f).color(scrollThumbColor).build());
        }
        if (progress <= 0.0f && this.settingsAnimation.getDirection() == Direction.BACKWARDS) {
            this.settingsModule = null;
            this.settingComponents.clear();
        }
    }

    private String getIconForCategory(ModuleCategory category) {
        return switch (category) {
            case ModuleCategory.COMBAT -> "A";
            case ModuleCategory.MOVEMENT -> "B";
            case ModuleCategory.RENDER -> "C";
            case ModuleCategory.PLAYER -> "D";
            case ModuleCategory.MISC -> "E";
            default -> "F";
        };
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        String search = MenuScreen.INSTANCE.getSearchComponent().getText().toLowerCase();
        if (ModuleComponent.selectedModule != null && ModuleComponent.selectedModule.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        float headerHeight = 28.0f;
        float h = this.fixedBackgroundHeight > 0.0f ? this.fixedBackgroundHeight : 0.0f;
        float progress = this.settingsAnimation.getOutput().floatValue();
        float moduleHeight = 17.0f;
        float gap = 2.0f;
        float moduleGap = 4.0f;
        float modulesHeight = 0.0f;
        for (ModuleComponent component : this.moduleComponents) {
            if (!search.isEmpty() && !component.getModule().getVisibleName().toLowerCase().contains(search)) continue;
            modulesHeight += moduleHeight + moduleGap;
            float totalSettingsHeight = 0.0f;
            if (component.isExpanded() || component.getSmoothExpansion() > 0.01f) {
                for (AbstractSettingComponent sc : component.getSettingComponents()) {
                    float vis = sc.getVisibilityProgress();
                    if (vis < 0.05f) continue;
                    totalSettingsHeight += (sc.height + gap) * vis;
                }
            }
            float p = component.getSmoothExpansion();
            modulesHeight += Math.max(0.0f, totalSettingsHeight * p);
        }
        float viewHeight = h - headerHeight - 4.0f;
        float maxScrollValue = Math.max(0.0f, modulesHeight - viewHeight);
        if (maxScrollValue > 0.0f && button == 0) {
            float scrollBarWidth = 3.0f;
            float scrollBarX = this.x + this.width - scrollBarWidth - 2.0f;
            float scrollBarY = this.y + headerHeight + 2.0f;
            float scrollBarHeight = viewHeight - 4.0f;
            float scrollRatio = Math.abs(this.moduleScroll) / maxScrollValue;
            float thumbHeight = Math.max(20.0f, scrollBarHeight * (viewHeight / modulesHeight));
            float thumbY = scrollBarY + (scrollBarHeight - thumbHeight) * scrollRatio;
            if (Calculate.isHovered(mouseX, mouseY, scrollBarX, thumbY, scrollBarWidth, thumbHeight)) {
                this.isDraggingScrollbar = true;
                this.scrollbarDragOffset = (float)(mouseY - (double)thumbY);
                return true;
            }
            if (Calculate.isHovered(mouseX, mouseY, scrollBarX, scrollBarY, scrollBarWidth, scrollBarHeight)) {
                float clickRatio = (float)((mouseY - (double)scrollBarY) / (double)scrollBarHeight);
                this.moduleScroll = -maxScrollValue * clickRatio;
                this.scrollVelocity = 0.0f;
                this.isDraggingScrollbar = true;
                this.scrollbarDragOffset = thumbHeight / 2.0f;
                return true;
            }
        }
        if (Calculate.isHovered(mouseX, mouseY, this.x, this.y + headerHeight, this.width, h - headerHeight)) {
            for (ModuleComponent component : this.moduleComponents) {
                if (!search.isEmpty() && !component.getModule().getVisibleName().toLowerCase().contains(search)) continue;
                if (Calculate.isHovered(mouseX, mouseY, component.x, component.y, component.width, 17.0)) {
                    if (button == 1) {
                        if (component.getModule().settings().isEmpty()) {
                            component.triggerNoSettingsAnimation();
                            return true;
                        }
                        component.setExpanded(!component.isExpanded());
                        return true;
                    }
                    return component.mouseClicked(mouseX, mouseY, button);
                }
                if (!component.isExpanded() || !(component.getSmoothExpansion() >= 0.9f) || !component.mouseClickedSettings(mouseX, mouseY, button)) continue;
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ModuleComponent.selectedModule != null) {
            return ModuleComponent.selectedModule.keyPressed(keyCode, scanCode, modifiers);
        }
        for (ModuleComponent mc : this.moduleComponents) {
            if (!mc.isExpanded()) continue;
            mc.getSettingComponents().forEach(c -> c.keyPressed(keyCode, scanCode, modifiers));
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            this.isDraggingScrollbar = false;
        }
        this.moduleComponents.forEach(c -> c.mouseReleased(mouseX, mouseY, button));
        this.settingComponents.forEach(c -> c.mouseReleased(mouseX, mouseY, button));
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.isDraggingScrollbar && button == 0) {
            float headerHeight;
            String search = MenuScreen.INSTANCE.getSearchComponent().getText().toLowerCase();
            float moduleHeight = 17.0f;
            float gap = 2.0f;
            float moduleGap = 4.0f;
            float modulesHeight = 0.0f;
            for (ModuleComponent component : this.moduleComponents) {
                if (!search.isEmpty() && !component.getModule().getVisibleName().toLowerCase().contains(search)) continue;
                modulesHeight += moduleHeight + moduleGap;
                float totalSettingsHeight = 0.0f;
                if (component.isExpanded() || component.getSmoothExpansion() > 0.01f) {
                    for (AbstractSettingComponent sc : component.getSettingComponents()) {
                        float vis = sc.getVisibilityProgress();
                        if (vis < 0.05f) continue;
                        totalSettingsHeight += (sc.height + gap) * vis;
                    }
                }
                float p = component.getSmoothExpansion();
                modulesHeight += Math.max(0.0f, totalSettingsHeight * p);
            }
            float h = this.fixedBackgroundHeight > 0.0f ? this.fixedBackgroundHeight : 0.0f;
            float viewHeight = h - (headerHeight = 28.0f) - 4.0f;
            float maxScrollValue = Math.max(0.0f, modulesHeight - viewHeight);
            if (maxScrollValue > 0.0f) {
                float scrollBarY = this.y + headerHeight + 2.0f;
                float scrollBarHeight = viewHeight - 4.0f;
                float thumbHeight = Math.max(20.0f, scrollBarHeight * (viewHeight / modulesHeight));
                float newThumbY = (float)(mouseY - (double)this.scrollbarDragOffset);
                float minThumbY = scrollBarY;
                float maxThumbY = scrollBarY + scrollBarHeight - thumbHeight;
                newThumbY = class_3532.method_15363((float)newThumbY, (float)minThumbY, (float)maxThumbY);
                float scrollRatio = (newThumbY - scrollBarY) / (scrollBarHeight - thumbHeight);
                this.moduleScroll = -maxScrollValue * scrollRatio;
                this.scrollVelocity = 0.0f;
            }
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, this.fixedBackgroundHeight)) {
            this.scrollVelocity += (float)(amount * 5.0);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public void tick() {
        this.moduleComponents.forEach(ModuleComponent::tick);
        this.settingComponents.forEach(AbstractComponent::tick);
        super.tick();
    }

    public void setFixedBackgroundHeight(float fixedBackgroundHeight) {
        this.fixedBackgroundHeight = fixedBackgroundHeight;
    }
}

