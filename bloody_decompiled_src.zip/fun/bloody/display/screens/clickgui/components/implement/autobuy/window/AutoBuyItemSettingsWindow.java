/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.window;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.AutoBuyableItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.settings.AutoBuyItemSettings;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.settings.AutoBuySettingsComponent;
import fun.bloody.display.screens.clickgui.components.implement.window.AbstractWindow;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class AutoBuyItemSettingsWindow
extends AbstractWindow {
    private final List<AutoBuySettingsComponent> components = new ArrayList<AutoBuySettingsComponent>();
    public final AutoBuyableItem item;
    private final AutoBuyItemSettings settings;

    public AutoBuyItemSettingsWindow(AutoBuyableItem item, AutoBuyItemSettings settings) {
        this.item = item;
        this.settings = settings;
        this.initializeComponents();
        this.draggable(true);
    }

    private void initializeComponents() {
        this.components.add(new AutoBuySettingsComponent.BuyBelowComponent(this.settings));
        if (this.settings.isCanHaveQuantity()) {
            this.components.add(new AutoBuySettingsComponent.MinQuantityComponent(this.settings));
        }
    }

    @Override
    public void drawWindow(class_332 context, int mouseX, int mouseY, float delta) {
        boolean isLimitedHeight;
        class_4587 matrix = context.method_51448();
        ScissorAssist scissorManager = Bloody.getInstance().getScissorManager();
        this.height = class_3532.method_15340((int)(this.getComponentHeight() + 5), (int)0, (int)200);
        blur.render(ShapeProperties.create(context.method_51448(), this.x, this.y, this.width, this.height).round(8.0f).quality(64.0f).color(new Color(0, 0, 0, 200).getRGB()).build());
        rectangle.render(ShapeProperties.create(context.method_51448(), this.x, this.y, this.width, this.height).round(8.0f).softness(2.0f).thickness(0.5f).outlineColor(new Color(18, 19, 20, 225).getRGB()).color(new Color(18, 19, 20, 175).getRGB(), new Color(0, 2, 5, 175).getRGB(), new Color(0, 2, 5, 175).getRGB(), new Color(18, 19, 20, 175).getRGB()).build());
        rectangle.render(ShapeProperties.create(matrix, this.x, this.y + 22.0f, this.width, 0.5).round(8.0f).color(new Color(155, 155, 155, 55).getRGB()).build());
        class_1799 itemStack = this.item.createItemStack();
        Render2D.defaultDrawStack(context, itemStack, this.x + 7.0f, this.y + 4.0f, false, false, 0.8f);
        String title = this.item.getDisplayName();
        Fonts.getSize(15, Fonts.Type.SEMI).drawGradientString(context.method_51448(), title, this.x + 25.0f, this.y + 10.0f, ColorAssist.getText(), new Color(165, 165, 165, 255).getRGB());
        Fonts.getSize(17, Fonts.Type.ICONS).drawString(context.method_51448(), "K", this.x + this.width - 15.0f, this.y + 10.0f, ColorAssist.getText(0.5f));
        boolean bl = isLimitedHeight = class_3532.method_15363((float)this.height, (float)0.0f, (float)200.0f) == 200.0f;
        if (isLimitedHeight) {
            scissorManager.push(matrix.method_23760().method_23761(), this.x, this.y + 23.0f, this.width, this.height - 24.0f);
        }
        float offset = 0.0f;
        int totalHeight = 0;
        for (int i = this.components.size() - 1; i >= 0; --i) {
            AutoBuySettingsComponent component = this.components.get(i);
            component.x = this.x;
            component.y = (float)((double)(this.y + 22.0f + offset + ((float)(this.getComponentHeight() - 25) - component.height)) + this.smoothedScroll);
            component.width = this.width;
            component.render(context, mouseX, mouseY, delta);
            offset -= component.height;
            totalHeight += (int)component.height;
        }
        if (isLimitedHeight) {
            scissorManager.pop();
        }
        int maxScroll = (int)Math.max(0.0f, (float)totalHeight - (this.height - 28.0f));
        this.scroll = class_3532.method_15350((double)this.scroll, (double)(-maxScroll), (double)0.0);
        this.smoothedScroll = class_3532.method_16436((double)0.1f, (double)this.smoothedScroll, (double)this.scroll);
        if (isLimitedHeight) {
            float viewableHeight = this.height - 30.0f;
            float scrollbarHeight = Math.max(20.0f, viewableHeight / (float)totalHeight * viewableHeight);
            float scrollPercent = (float)(-this.smoothedScroll / (double)maxScroll);
            float scrollbarY = this.y + 30.0f + scrollPercent * (viewableHeight - scrollbarHeight);
            float scrollbarX = this.x + this.width - 6.0f;
            float scrollbarWidth = 3.0f;
            rectangle.render(ShapeProperties.create(matrix, scrollbarX, this.y + 30.0f, scrollbarWidth, viewableHeight - 6.0f).round(1.0f).color(new Color(30, 30, 30, 100).getRGB()).build());
            rectangle.render(ShapeProperties.create(matrix, scrollbarX, scrollbarY, scrollbarWidth, scrollbarHeight - 6.0f).round(1.5f).color(new Color(100, 100, 100, 180).getRGB()).build());
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        boolean isAnyComponentHovered;
        if (button == 0) {
            if (Calculate.isHovered(mouseX, mouseY, this.x + this.width - 20.0f, this.y + 5.0f, 15.0, 15.0)) {
                this.startCloseAnimation();
                return true;
            }
            if (Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, 19.0)) {
                this.dragging = true;
                this.dragX = (int)((double)this.x - mouseX);
                this.dragY = (int)((double)this.y - mouseY);
                return true;
            }
        }
        if (isAnyComponentHovered = this.components.stream().anyMatch(abstractComponent -> abstractComponent.isHover(mouseX, mouseY))) {
            this.components.forEach(abstractComponent -> {
                if (abstractComponent.isHover(mouseX, mouseY)) {
                    abstractComponent.mouseClicked(mouseX, mouseY, button);
                }
            });
            return true;
        }
        this.components.forEach(abstractComponent -> abstractComponent.mouseClicked(mouseX, mouseY, button));
        return true;
    }

    @Override
    public boolean isHover(double mouseX, double mouseY) {
        this.components.forEach(abstractComponent -> abstractComponent.isHover(mouseX, mouseY));
        for (AbstractComponent abstractComponent2 : this.components) {
            if (!abstractComponent2.isHover(mouseX, mouseY)) continue;
            return true;
        }
        return super.isHovered(mouseX, mouseY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.dragging = false;
        this.components.forEach(abstractComponent -> abstractComponent.mouseReleased(mouseX, mouseY, button));
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        boolean scrolled;
        boolean bl = scrolled = class_3532.method_15363((float)this.height, (float)0.0f, (float)200.0f) == 200.0f && Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, this.height);
        if (scrolled) {
            this.scroll += amount * 20.0;
        }
        this.components.forEach(abstractComponent -> abstractComponent.mouseScrolled(mouseX, mouseY, amount));
        return scrolled;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        this.components.forEach(abstractComponent -> abstractComponent.keyPressed(keyCode, scanCode, modifiers));
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        this.components.forEach(abstractComponent -> abstractComponent.charTyped(chr, modifiers));
        return super.charTyped(chr, modifiers);
    }

    public int getComponentHeight() {
        float offsetY = 0.0f;
        for (AutoBuySettingsComponent component : this.components) {
            offsetY += component.height;
        }
        return (int)(offsetY + 25.0f);
    }
}

