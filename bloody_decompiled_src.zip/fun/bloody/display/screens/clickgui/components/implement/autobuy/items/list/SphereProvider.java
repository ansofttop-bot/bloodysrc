/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1802
 *  net.minecraft.class_2487
 *  net.minecraft.class_2499
 *  net.minecraft.class_2520
 *  net.minecraft.class_2561
 *  net.minecraft.class_5250
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list;

import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.AutoBuyableItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.customitem.CustomItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.defaultsetpricec.Defaultpricec;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class SphereProvider {
    public static List<AutoBuyableItem> getSpheres() {
        ArrayList<AutoBuyableItem> spheres = new ArrayList<AutoBuyableItem>();
        List<class_5250> andromedaLore = List.of(class_2561.method_43470((String)"\u0421\u0444\u0435\u0440\u0430 \u0445\u0440\u0430\u043d\u0438\u0442 \u0432\u0437\u0433\u043b\u044f\u0434"), class_2561.method_43470((String)"\u0410\u043d\u0434\u0440\u043e\u043c\u0435\u0434\u044b, \u0432\u0435\u0434\u0443\u0449\u0438\u0439"), class_2561.method_43470((String)"\u0441\u043a\u0432\u043e\u0437\u044c \u043c\u0440\u0430\u043a \u0438 \u0437\u0432\u0451\u0437\u0434\u044b"));
        spheres.add(SphereProvider.createSphere("[\u2605] \u0421\u0444\u0435\u0440\u0430 \u0410\u043d\u0434\u0440\u043e\u043c\u0435\u0434\u044b", "9d1ee31a-65ad-4d5c-850e-b8dda3875e1e", "ewogICJ0aW1lc3RhbXAiIDogMTcxNzM2NTEwODQzNywKICAicHJvZmlsZUlkIiA6ICIzMjNiYjlkYzkwZWU0Nzk5YjUxYzE3NjRmZDRhNjI3OSIsCiAgInByb2ZpbGVOYW1lIiA6ICJOcGllIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzQ0ZmZlM2YzNThmMjA5YmFkOGZmZjRkYzQ4MjQ1ZDliYWYwYTAzMWIzYzFlZTZiNzU4NDYwYTMzOWIxNTE5ZTIiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ==", Defaultpricec.getPrice("\u0421\u0444\u0435\u0440\u0430 \u0410\u043d\u0434\u0440\u043e\u043c\u0435\u0434\u044b"), andromedaLore));
        List<class_5250> pandoraLore = List.of(class_2561.method_43470((String)"\u0421\u0444\u0435\u0440\u0430 \u0442\u0430\u0438\u0442 \u0441\u0435\u043a\u0440\u0435\u0442\u044b"), class_2561.method_43470((String)"\u041f\u0430\u043d\u0434\u043e\u0440\u044b, \u0434\u0430\u0440\u0443\u044e\u0449\u0438\u0435"), class_2561.method_43470((String)"\u0431\u043b\u0430\u0433\u043e\u0434\u0430\u0442\u044c \u0435\u0451 \u0445\u043e\u0437\u044f\u0438\u043d\u0443"));
        spheres.add(SphereProvider.createSphere("[\u2605] \u0421\u0444\u0435\u0440\u0430 \u041f\u0430\u043d\u0434\u043e\u0440\u044b", "812d254a-5d3b-41b6-93f8-bd8b08a0c07c", "ewogICJ0aW1lc3RhbXAiIDogMTcxNzM2NTY2NTExNCwKICAicHJvZmlsZUlkIiA6ICJkNzJlNGJjZDIyZGI0NjQ4OTUxNTc0M2UyYTRmMWFjMCIsCiAgInByb2ZpbGVOYW1lIiA6ICJhdnZheSIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS84ZTUxZTY1ZWI0MDUyNzcyMzgyYzllNTA3YTU0YmRlZDQzZTM5Zjc1NWI1ZGRmNTViM2YzOTQ0M2NlZDQ2N2Y0IiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0=", Defaultpricec.getPrice("\u0421\u0444\u0435\u0440\u0430 \u041f\u0430\u043d\u0434\u043e\u0440\u044b"), pandoraLore));
        List<class_5250> titanLore = List.of(class_2561.method_43470((String)"\u041c\u0438\u0444\u0438\u0447\u0435\u0441\u043a\u0430\u044f \u0441\u0444\u0435\u0440\u0430 \u0434\u0440\u0435\u0432\u043d\u0438\u0445"), class_2561.method_43470((String)"\u0422\u0438\u0442\u0430\u043d\u043e\u0432, \u043e\u0431\u043b\u0430\u0434\u0430\u044e\u0449\u0430\u044f"), class_2561.method_43470((String)"\u0438\u0445 \u043c\u043e\u0449\u044c\u044e \u0438 \u043f\u0440\u043e\u0447\u043d\u043e\u0441\u0442\u044c\u044e"));
        spheres.add(SphereProvider.createSphere("[\u2605] \u0421\u0444\u0435\u0440\u0430 \u0422\u0438\u0442\u0430\u043d\u0430", "05c21710-125c-4738-a102-2e1a4cd577e1", "ewogICJ0aW1lc3RhbXAiIDogMTc1MDM1NDQ1NTE5MiwKICAicHJvZmlsZUlkIiA6ICJkOTcwYzEzZTM4YWI0NzlhOTY1OGM1ZDQ1MjZkMTM0YiIsCiAgInByb2ZpbGVOYW1lIiA6ICJDcmltcHlMYWNlODUxMjciLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvODFlOTY5ODQ1OGI3ODQxYzk2YWU0ZjI0ZWM4NGFlMDE3MjQxMDA2NDFjNTY0ZTJhN2IxODVmNDA2ZThlZDIzIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0=", Defaultpricec.getPrice("\u0421\u0444\u0435\u0440\u0430 \u0422\u0438\u0442\u0430\u043d\u0430"), titanLore));
        List<class_5250> apolloLore = List.of(class_2561.method_43470((String)"\u0421\u0432\u044f\u0442\u043e\u0439 \u0441\u0432\u0435\u0442 \u0410\u043f\u043e\u043b\u043b\u043e\u043d\u0430,"), class_2561.method_43470((String)"\u043f\u0435\u0440\u0435\u043f\u043e\u043b\u043d\u044f\u044e\u0449\u0438\u0439 \u0441\u0438\u043b\u043e\u0439,"), class_2561.method_43470((String)"\u0442\u0430\u0438\u0442\u0441\u044f \u0432 \u044d\u0442\u043e\u0439 \u0441\u0444\u0435\u0440\u0435"));
        spheres.add(SphereProvider.createSphere("[\u2605] \u0421\u0444\u0435\u0440\u0430 \u0410\u043f\u043e\u043b\u043b\u043e\u043d\u0430", "478bd194-bd00-4c33-b3df-31115657f9a3", "ewogICJ0aW1lc3RhbXAiIDogMTcxNzM2NjYyNTM0NywKICAicHJvZmlsZUlkIiA6ICJhMjk1ODZmYmU1ZDk0Nzk2OWZjOGQ4ZGE0NzlhNDNlZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJMZXZlMjQiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNjQxMTdiNjAxOGZlZjBkNTE1NjcyMTczZTNiMjZlNjYwZDY1MWU1ODc2YmE2ZDAzZTUzNDIyNzBjNDliZWM4MCIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9", Defaultpricec.getPrice("\u0421\u0444\u0435\u0440\u0430 \u0410\u043f\u043e\u043b\u043b\u043e\u043d\u0430"), apolloLore));
        List<class_5250> astreaLore = List.of(class_2561.method_43470((String)"\u0421\u043f\u0440\u0430\u0432\u0435\u0434\u043b\u0438\u0432\u043e\u0441\u0442\u044c \u0410\u0441\u0442\u0440\u0435\u0438"), class_2561.method_43470((String)"\u0434\u0430\u0440\u0443\u0435\u0442 \u0436\u0438\u0437\u043d\u044c \u043a\u0430\u0436\u0434\u043e\u043c\u0443,"), class_2561.method_43470((String)"\u043a\u0442\u043e \u0435\u0451 \u0434\u043e\u0441\u0442\u043e\u0438\u043d"));
        spheres.add(SphereProvider.createSphere("[\u2605] \u0421\u0444\u0435\u0440\u0430 \u0410\u0441\u0442\u0440\u0435\u044f", "89e3c3fb-65c0-4960-964a-62416b1b3f14", "ewogICJ0aW1lc3RhbXAiIDogMTcxNzM2NTA2MjQwNywKICAicHJvZmlsZUlkIiA6ICJlMzcxMWU2Y2E0ZmY0NzA4YjY5ZjhiNGZlYzNhZjdhMSIsCiAgInByb2ZpbGVOYW1lIiA6ICJNckJ1cnN0IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzFhNWFhZGQ1MmE1ZmFiOTcwODgxNDUxYWRmNTZmYmI0OTNhMzU4NTZlYTk2ZjU0ZTMyZWVhNjYyZDc4N2VkMjAiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ==", Defaultpricec.getPrice("\u0421\u0444\u0435\u0440\u0430 \u0410\u0441\u0442\u0440\u0435\u044f"), astreaLore));
        List<class_5250> osirisLore = List.of(class_2561.method_43470((String)"\u0421\u0438\u043b\u044b \u0438 \u043c\u043e\u0449\u044c \u043c\u0451\u0440\u0442\u0432\u044b\u0445,"), class_2561.method_43470((String)"\u0434\u0430\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0435 \u041e\u0441\u0438\u0440\u0438\u0441\u043e\u043c,"), class_2561.method_43470((String)"\u0442\u0430\u044f\u0442\u0441\u044f \u0432 \u044d\u0442\u043e\u0439 \u0441\u0444\u0435\u0440\u0435"));
        spheres.add(SphereProvider.createSphere("[\u2605] \u0421\u0444\u0435\u0440\u0430 \u041e\u0441\u0438\u0440\u0438\u0441\u0430", "5053c3bc-dda9-437f-8caf-e8517e0154ba", "ewogICJ0aW1lc3RhbXAiIDogMTcxNzM2NjY2Mzg3NiwKICAicHJvZmlsZUlkIiA6ICI3NGEwMzQxNWY1OTI0ZTA4YjMyMGM2MmU1NGE3ZjJhYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJNZXp6aXIiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZDgxMzYzNWJkODZiMTcxYmJlMTQzYWQ3MWUwOTAyMjkyNjQ5Y2IzYWI4NDQwZWQwMGY4NWNhNmNhMzgyOTkzNiIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9", Defaultpricec.getPrice("\u0421\u0444\u0435\u0440\u0430 \u041e\u0441\u0438\u0440\u0438\u0441\u0430"), osirisLore));
        List<class_5250> chimeraLore = List.of(class_2561.method_43470((String)"\u0421\u0444\u0435\u0440\u0430 \u0440\u043e\u0436\u0434\u0435\u043d\u0430 \u0432"), class_2561.method_43470((String)"\u0431\u043e\u0436\u0435\u0441\u0442\u0432\u0435\u043d\u043d\u043e-\u0436\u0433\u0443\u0447\u0435\u043c"), class_2561.method_43470((String)"\u043f\u043b\u0430\u043c\u0435\u043d\u0438 \u0425\u0438\u043c\u0435\u0440\u044b"));
        spheres.add(SphereProvider.createSphere("[\u2605] \u0421\u0444\u0435\u0440\u0430 \u0425\u0438\u043c\u0435\u0440\u044b", "8ac3951d-c8f9-463c-be7a-f29b558f6376", "ewogICJ0aW1lc3RhbXAiIDogMTcxNzM2NjE4MTEwOSwKICAicHJvZmlsZUlkIiA6ICJiNzRiMGQzNTBkNTk0NTU4YmYyYjBlMDJlYmE4NjE4NCIsCiAgInByb2ZpbGVOYW1lIiA6ICJCcmFuZG9uYnBtMjg0IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzlmYWJlZWQ0MjRiMjUyYTg5NDVhNjQ0MmI0NjJkNWYzMTQ3MDFhODE2ZGEyZDBhNjljY2RmY2ZkNzQ2ZTU4OGUiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ==", Defaultpricec.getPrice("\u0421\u0444\u0435\u0440\u0430 \u0425\u0438\u043c\u0435\u0440\u044b"), chimeraLore));
        return spheres;
    }

    private static AutoBuyableItem createSphere(String displayName, String headUuid, String texture, int price, List<class_2561> lore) {
        class_2487 nbt = new class_2487();
        nbt.method_10556("HideFlags", true);
        nbt.method_10556("Unbreakable", true);
        class_2487 skullOwner = new class_2487();
        skullOwner.method_25927("Id", UUID.fromString(headUuid));
        class_2487 properties = new class_2487();
        class_2499 textures = new class_2499();
        class_2487 textureNbt = new class_2487();
        textureNbt.method_10582("Value", texture);
        textures.add((Object)textureNbt);
        properties.method_10566("textures", (class_2520)textures);
        skullOwner.method_10566("Properties", (class_2520)properties);
        nbt.method_10566("SkullOwner", (class_2520)skullOwner);
        return new CustomItem(displayName, nbt, class_1802.field_8575, price, null, lore);
    }
}

