/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_9848
 */
package fun.bloody.display.screens.clickgui.components.implement.settings;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.utils.client.chat.StringHelper;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_9848;

public class IconBindComponent
extends AbstractSettingComponent {
    private final BindSetting setting;
    private boolean binding;
    private float currentScroll = 0.0f;
    private float targetScroll = 0.0f;
    private boolean isHovered = false;

    public IconBindComponent(BindSetting setting) {
        super(setting);
        this.setting = setting;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        class_4587 matrix = context.method_51448();
        String bindName = StringHelper.getBindName(this.setting.getKey());
        Object name = this.binding ? "(" + bindName + ") ..." : bindName;
        float stringWidth = Fonts.getSize(13, Fonts.Type.SEMI).getStringWidth((String)name) - 2.0f;
        this.height = 22.0f;
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        rectangle.render(ShapeProperties.create(matrix, this.x + this.width - stringWidth - 17.0f, this.y + 7.5f, stringWidth + 10.0f, 14.0).round(3.0f).outlineColor(clickGuiModule != null ? clickGuiModule.getControlOutlineColor(this.binding) : new Color(200, 200, 200, 255).getRGB()).color(clickGuiModule != null ? clickGuiModule.getControlOffColor() : new Color(61, 67, 71, 80).getRGB(), clickGuiModule != null ? clickGuiModule.getControlOffColor() : new Color(71, 77, 81, 80).getRGB(), clickGuiModule != null ? clickGuiModule.getControlOffColor() : new Color(81, 87, 91, 80).getRGB(), clickGuiModule != null ? clickGuiModule.getControlOffColor() : new Color(91, 97, 101, 80).getRGB()).build());
        int bindingColor = clickGuiModule != null ? clickGuiModule.getInactiveTextColor() : class_9848.method_61324((int)255, (int)135, (int)136, (int)148);
        Fonts.getSize(13, Fonts.Type.SEMI).drawString(matrix, (String)name, this.x + this.width - 12.0f - stringWidth - 1.0f, this.y + 14.5f, bindingColor);
        float maxWidth = this.width - stringWidth - 30.0f;
        String settingName = this.setting.getName();
        float textWidth = Fonts.getSize(14, Fonts.Type.DEFAULT).getStringWidth(settingName);
        boolean needsScroll = textWidth > maxWidth;
        boolean currentlyHovered = Calculate.isHovered(mouseX, mouseY, this.x + 5.0f, this.y + 8.0f, maxWidth, 14.0);
        if (currentlyHovered != this.isHovered) {
            this.isHovered = currentlyHovered;
        }
        if (needsScroll) {
            float maxScroll = textWidth - maxWidth + 10.0f;
            this.targetScroll = this.isHovered ? maxScroll : 0.0f;
            float lerpSpeed = 0.05f;
            this.currentScroll += (this.targetScroll - this.currentScroll) * lerpSpeed;
            if (Math.abs(this.targetScroll - this.currentScroll) < 0.1f) {
                this.currentScroll = this.targetScroll;
            }
        } else {
            this.currentScroll = 0.0f;
            this.targetScroll = 0.0f;
        }
        float scrollOffset = this.currentScroll;
        clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        int nameColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(0, 0, 0, 255).getRGB() : -2828575;
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        scissor.push(context.method_51448().method_23760().method_23761(), this.x + 5.0f, this.y, maxWidth, 22.0f);
        if (clickGuiModule != null) {
            nameColor = clickGuiModule.getTextColor();
        }
        Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(context.method_51448(), settingName, this.x + 5.0f - scrollOffset, this.y + 14.0f, nameColor);
        scissor.pop();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            this.binding = Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, this.height) ? !this.binding : false;
        }
        if (this.binding && button > 1) {
            this.setting.setKey(button);
            this.binding = false;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        int key;
        int n = key = keyCode == 261 ? -1 : keyCode;
        if (this.binding) {
            this.setting.setKey(key);
            this.binding = false;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}

