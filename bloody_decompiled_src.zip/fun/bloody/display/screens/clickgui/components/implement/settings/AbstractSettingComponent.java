/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.display.screens.clickgui.components.implement.settings;

import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.features.module.setting.Setting;

public abstract class AbstractSettingComponent
extends AbstractComponent {
    private final Setting setting;
    private final Animation visibilityAnimation = new Decelerate().setMs(250).setValue(1.0);
    private boolean firstRender = true;

    public AbstractSettingComponent(Setting setting) {
        this.setting = setting;
    }

    public float getVisibilityProgress() {
        if (this.firstRender) {
            this.firstRender = false;
            if (this.setting.isVisible()) {
                this.visibilityAnimation.setDirection(Direction.FORWARDS);
                return 1.0f;
            }
            this.visibilityAnimation.setDirection(Direction.BACKWARDS);
            return 0.0f;
        }
        this.visibilityAnimation.setDirection(this.setting.isVisible() ? Direction.FORWARDS : Direction.BACKWARDS);
        return this.visibilityAnimation.getOutput().floatValue();
    }

    public Setting getSetting() {
        return this.setting;
    }

    public Animation getVisibilityAnimation() {
        return this.visibilityAnimation;
    }

    public boolean isFirstRender() {
        return this.firstRender;
    }
}

