/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.module;

import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.Bloody;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.display.screens.clickgui.theme.ThemeManager;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.setting.SettingComponentAdder;
import fun.bloody.utils.client.chat.StringHelper;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.display.shape.implement.Rectangle;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class ModuleComponent
extends AbstractComponent {
    public static ModuleComponent selectedModule = null;
    public static final Animation popupAnimation = new Decelerate().setMs(250).setValue(1.0);
    private final Module module;
    private final Rectangle rectangle = new Rectangle();
    private final Animation colorAnimation = new Decelerate().setMs(400).setValue(40.0);
    private boolean binding;
    private long noSettingsTime = 0L;
    private boolean expanded = false;
    private final Animation expansionAnimation = new Decelerate().setMs(350).setValue(1.0);
    private float smoothExpansion = 0.0f;
    private float smoothBgProgress = 0.0f;
    private final List<AbstractSettingComponent> settingComponents = new ArrayList<AbstractSettingComponent>();
    private final SettingComponentAdder componentAdder = new SettingComponentAdder();
    private float dynamicHeight = 20.0f;
    private float expansionProgress = 0.0f;

    public boolean isExpanded() {
        return this.expanded;
    }

    public void setExpanded(boolean expanded) {
        if (this.expanded != expanded) {
            this.expanded = expanded;
            if (expanded && this.settingComponents.isEmpty()) {
                this.componentAdder.addSettingComponent(this.module.settings(), this.settingComponents);
            }
        }
    }

    public Animation getExpansionAnimation() {
        return this.expansionAnimation;
    }

    public float getSmoothExpansion() {
        return this.smoothExpansion;
    }

    public List<AbstractSettingComponent> getSettingComponents() {
        return this.settingComponents;
    }

    public ModuleComponent(Module module) {
        this.module = module;
        this.colorAnimation.setDirection(module.isState() ? Direction.FORWARDS : Direction.BACKWARDS);
        this.expansionAnimation.setDirection(Direction.BACKWARDS);
    }

    public void triggerNoSettingsAnimation() {
        this.noSettingsTime = System.currentTimeMillis();
    }

    public static void setSelectedModule(ModuleComponent component) {
        if (selectedModule != component) {
            selectedModule = component;
            popupAnimation.setDirection(component != null ? Direction.FORWARDS : Direction.BACKWARDS);
            popupAnimation.reset();
        } else if (component == null) {
            popupAnimation.setDirection(Direction.BACKWARDS);
        }
    }

    public float getDynamicHeight() {
        return this.dynamicHeight;
    }

    public void setDynamicHeight(float dynamicHeight) {
        this.dynamicHeight = dynamicHeight;
    }

    public void setExpansionProgress(float expansionProgress) {
        this.expansionProgress = expansionProgress;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        int textColor;
        int moduleOutline;
        int moduleBg;
        float targetExpansion = this.expanded ? 1.0f : 0.0f;
        this.smoothExpansion += (targetExpansion - this.smoothExpansion) * 0.15f;
        if (Math.abs(this.smoothExpansion - targetExpansion) < 0.01f) {
            this.smoothExpansion = targetExpansion;
        }
        boolean enabled = this.module.isState();
        float height = this.dynamicHeight;
        this.colorAnimation.setDirection(enabled ? Direction.FORWARDS : Direction.BACKWARDS);
        float progress = this.colorAnimation.getOutput().floatValue() / 40.0f;
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        ThemeManager themeManager = ThemeManager.getInstance();
        float bgTarget = enabled ? 1.0f : 0.0f;
        this.smoothBgProgress += (bgTarget - this.smoothBgProgress) * 0.12f;
        if (Math.abs(this.smoothBgProgress - bgTarget) < 0.01f) {
            this.smoothBgProgress = bgTarget;
        }
        if (clickGuiModule != null && clickGuiModule.isWhite()) {
            moduleBg = new Color(255, 255, 255, 255).getRGB();
            moduleOutline = new Color(200, 200, 200, 255).getRGB();
        } else if (clickGuiModule != null && clickGuiModule.isBlack()) {
            moduleBg = new Color(0, 0, 0, 255).getRGB();
            moduleOutline = new Color(50, 50, 50, 255).getRGB();
        } else {
            int r = (int)(82.0f + -12.0f * this.smoothBgProgress);
            int g = (int)(84.0f + 16.0f * this.smoothBgProgress);
            int b = (int)(157.0f + 43.0f * this.smoothBgProgress);
            int a = (int)(26.0f + 14.0f * this.smoothBgProgress);
            moduleBg = new Color(r, g, b, a).getRGB();
            moduleOutline = new Color(255, 255, 255, 150).getRGB();
        }
        if (clickGuiModule != null) {
            moduleBg = clickGuiModule.getModuleColor(enabled, this.smoothBgProgress);
            moduleOutline = clickGuiModule.getModuleOutlineColor(enabled);
        }
        float bgWidth = this.width - 4.0f;
        float bgX = this.x + 4.0f;
        float bgHeight = Math.round(Math.max(18.0f, this.dynamicHeight + 1.0f));
        float bgY = Math.round(this.y - 0.5f);
        this.rectangle.render(ShapeProperties.create(context.method_51448(), bgX, bgY, bgWidth, bgHeight).round(4.0f, 4.0f, 4.0f, 4.0f).thickness(1.1f).outlineColor(moduleOutline).color(moduleBg).build());
        if (clickGuiModule != null && clickGuiModule.isWhite()) {
            textColor = enabled ? new Color(0, 0, 0, 255).getRGB() : new Color(80, 80, 80, 255).getRGB();
        } else if (clickGuiModule != null && clickGuiModule.isBlack()) {
            textColor = enabled ? new Color(255, 255, 255, 255).getRGB() : new Color(180, 180, 180, 255).getRGB();
        } else {
            int n = textColor = enabled ? themeManager.getTextColor() : themeManager.getInactiveTextColor();
        }
        if (clickGuiModule != null) {
            textColor = enabled ? clickGuiModule.getTextColor() : clickGuiModule.getInactiveTextColor();
        }
        long elapsed = System.currentTimeMillis() - this.noSettingsTime;
        float textY = this.y + 4.0f + 1.8f;
        if (elapsed < 800L) {
            progress = (float)elapsed / 800.0f;
            float offsetX = (float)Math.sin((double)progress * Math.PI * 4.0) * 2.0f * (1.0f - progress);
            float intensity = (float)Math.sin((double)progress * Math.PI);
            int r = textColor >> 16 & 0xFF;
            int g = textColor >> 8 & 0xFF;
            int b = textColor & 0xFF;
            r = (int)((float)r + (float)(255 - r) * intensity);
            g = (int)((float)g + (float)(50 - g) * intensity);
            b = (int)((float)b + (float)(50 - b) * intensity);
            textColor = new Color(r, g, b).getRGB();
            Fonts.getSize(16, Fonts.Type.DEFAULT).drawString(context.method_51448(), this.module.getVisibleName(), this.x + 9.0f + offsetX, textY, textColor);
        } else {
            Fonts.getSize(16, Fonts.Type.DEFAULT).drawString(context.method_51448(), this.module.getVisibleName(), this.x + 9.0f, textY, textColor);
        }
        float iconRightEdge = this.x + this.width - 12.0f;
        if (!this.module.settings().isEmpty()) {
            float iconSize = 22.0f;
            float iconX = iconRightEdge;
            float iconY = textY;
            int iconColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(0, 0, 0, 180).getRGB() : (clickGuiModule != null && clickGuiModule.isBlack() ? new Color(255, 255, 255, 180).getRGB() : new Color(255, 255, 255, 180).getRGB());
            if (clickGuiModule != null) {
                iconColor = ColorAssist.reAlphaInt(clickGuiModule.getTextColor(), 180);
            }
            Fonts.getSize((int)iconSize, Fonts.Type.GUIICONS).drawString(context.method_51448(), "A", iconX, iconY, iconColor);
        }
        if (this.module.getKey() != -1) {
            String bindName = StringHelper.getBindName(this.module.getKey());
            float bindHeight = 12.0f;
            float bindWidth = Math.max(bindHeight, Fonts.getSize(14, Fonts.Type.SEMI).getStringWidth(bindName) + 7.0f);
            boolean hasSettings = !this.module.settings().isEmpty();
            float bindX = hasSettings ? iconRightEdge - bindWidth - 4.0f : iconRightEdge + (10.0f - bindWidth) / 2.0f;
            float bindY = this.y + (17.0f - bindHeight) / 2.0f;
            this.rectangle.render(ShapeProperties.create(context.method_51448(), bindX, bindY, bindWidth, bindHeight).round(3.0f, 1.0f, 1.0f, 3.0f).color(clickGuiModule != null ? clickGuiModule.getControlOnColor() : new Color(70, 100, 200, 180).getRGB()).build());
            float textW = Fonts.getSize(14, Fonts.Type.SEMI).getStringWidth(bindName);
            Fonts.getSize(14, Fonts.Type.SEMI).drawString(context.method_51448(), bindName, bindX + (bindWidth - textW) / 2.0f, bindY + 4.0f, -1);
        }
    }

    public void renderSettings(class_332 context, int mouseX, int mouseY, float delta, float x, float y, float width, float gap) {
        if (this.smoothExpansion <= 0.01f) {
            return;
        }
        class_4587 matrix = context.method_51448();
        if (this.smoothExpansion > 0.0f) {
            float lineX = x + 4.0f;
            float lineWidth = width - 4.0f;
            float lineY = y - 2.0f;
            int lineColor = new Color(255, 255, 255, (int)(150.0f * this.smoothExpansion)).getRGB();
            ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
            if (clickGuiModule != null) {
                lineColor = clickGuiModule.getOutlineColor((int)(150.0f * this.smoothExpansion));
            }
            this.rectangle.render(ShapeProperties.create(matrix, lineX, lineY, lineWidth, 1.0).thickness(1.1f).outlineColor(lineColor).color(0).build());
        }
        float currentY = y;
        for (AbstractSettingComponent sc : this.settingComponents) {
            float vis = sc.getVisibilityProgress();
            if (vis < 0.05f) continue;
            sc.x = x;
            sc.y = currentY;
            sc.width = width;
            if (sc.y + sc.height > y - 100.0f && sc.y < y + 500.0f) {
                matrix.method_22903();
                if (vis < 1.0f || this.smoothExpansion < 1.0f) {
                    float totalAlpha = vis * this.smoothExpansion;
                    float totalScale = vis * (0.9f + 0.1f * this.smoothExpansion);
                    matrix.method_46416(sc.x + sc.width / 2.0f, sc.y + sc.height * totalScale / 2.0f, 0.0f);
                    matrix.method_22905(1.0f, totalScale, 1.0f);
                    matrix.method_46416(-(sc.x + sc.width / 2.0f), -(sc.y + sc.height * totalScale / 2.0f), 0.0f);
                    RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)totalAlpha);
                }
                sc.render(context, mouseX, mouseY, delta);
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                matrix.method_22909();
            }
            currentY += (sc.height + gap) * this.smoothExpansion * vis;
        }
    }

    public boolean mouseClickedSettings(double mouseX, double mouseY, int button) {
        if (this.smoothExpansion < 0.8f) {
            return false;
        }
        for (AbstractSettingComponent sc : this.settingComponents) {
            if (sc.getVisibilityProgress() < 0.8f || !Calculate.isHovered(mouseX, mouseY, sc.x, sc.y, sc.width, sc.height) || !sc.mouseClicked(mouseX, mouseY, button)) continue;
            return true;
        }
        return false;
    }

    public void drawContextMenu(class_332 context, int mouseX, int mouseY) {
        float alpha = popupAnimation.getOutput().floatValue();
        if (alpha <= 0.0f) {
            if (popupAnimation.getDirection() == Direction.BACKWARDS) {
                selectedModule = null;
            }
            return;
        }
        ThemeManager themeManager = ThemeManager.getInstance();
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        float menuWidth = 92.0f;
        float menuHeight = 20.0f;
        float menuX = this.x - menuWidth - 3.0f;
        float menuY = this.y;
        context.method_51448().method_22903();
        float scale = 0.96f + alpha * 0.04f;
        context.method_51448().method_46416(menuX + menuWidth / 2.0f, menuY + menuHeight / 2.0f, 0.0f);
        context.method_51448().method_22905(scale, scale, 1.0f);
        context.method_51448().method_46416(-(menuX + menuWidth / 2.0f), -(menuY + menuHeight / 2.0f), 0.0f);
        int bgColor = clickGuiModule != null && !clickGuiModule.isTransparent() ? clickGuiModule.getPanelColor() : themeManager.getWindowBackgroundColor();
        int activeCol = clickGuiModule != null && !clickGuiModule.isTransparent() ? clickGuiModule.getControlOnColor() : themeManager.getPrimaryColor();
        blur.render(ShapeProperties.create(context.method_51448(), menuX, menuY, menuWidth, menuHeight).round(5.0f, 5.0f, 5.0f, 5.0f).color(ColorAssist.reAlphaInt(bgColor, (int)(240.0f * alpha))).build());
        this.rectangle.render(ShapeProperties.create(context.method_51448(), menuX, menuY, menuWidth, menuHeight).round(5.0f, 5.0f, 5.0f, 5.0f).outlineColor(0).color(ColorAssist.reAlphaInt(bgColor, (int)(230.0f * alpha))).build());
        float boxW = 55.0f;
        float boxH = 11.0f;
        float gap = 2.0f;
        float startX = menuX + 4.0f;
        float startY = menuY + (menuHeight - (boxH * 2.0f + gap)) / 2.0f + 1.0f;
        int activeColor = ColorAssist.reAlphaInt(activeCol, (int)(255.0f * alpha));
        int inactiveColor = ColorAssist.reAlphaInt(bgColor, (int)(255.0f * alpha));
        boolean isToggle = this.module.getType() == 1;
        int toggleBoxColor = isToggle ? activeColor : inactiveColor;
        this.rectangle.render(ShapeProperties.create(context.method_51448(), startX, startY, boxW, boxH).round(3.0f).color(toggleBoxColor).outlineColor(isToggle ? new Color(100, 100, 100, (int)(100.0f * alpha)).getRGB() : 0).build());
        float toggleTw = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth("Toggle");
        Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(context.method_51448(), "Toggle", startX + (boxW - toggleTw) / 2.0f, startY + 4.0f, new Color(0, 0, 0, (int)(255.0f * alpha)).getRGB());
        int holdBoxColor = !isToggle ? activeColor : inactiveColor;
        this.rectangle.render(ShapeProperties.create(context.method_51448(), startX, startY + boxH + gap, boxW, boxH).round(3.0f).color(holdBoxColor).outlineColor(!isToggle ? new Color(100, 100, 100, (int)(100.0f * alpha)).getRGB() : 0).build());
        float holdTw = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth("Hold");
        Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(context.method_51448(), "Hold", startX + (boxW - holdTw) / 2.0f, startY + boxH + gap + 4.0f, new Color(0, 0, 0, (int)(255.0f * alpha)).getRGB());
        float bindSize = 22.0f;
        float bindX = startX + boxW + 4.0f;
        float bindY = menuY + (menuHeight - bindSize) / 2.0f;
        String bindName = this.binding ? "..." : StringHelper.getBindName(this.module.getKey());
        this.rectangle.render(ShapeProperties.create(context.method_51448(), bindX, bindY, bindSize, bindSize).round(4.0f).color(clickGuiModule != null && !clickGuiModule.isTransparent() ? ColorAssist.reAlphaInt(clickGuiModule.getControlOffColor(), (int)(255.0f * alpha)) : new Color(40, 41, 45, (int)(255.0f * alpha)).getRGB()).outlineColor(this.binding && clickGuiModule != null && !clickGuiModule.isTransparent() ? ColorAssist.reAlphaInt(clickGuiModule.getAccentColor(), (int)(255.0f * alpha)) : (this.binding ? new Color(255, 255, 255, (int)(255.0f * alpha)).getRGB() : 0)).build());
        float tw = Fonts.getSize(18, Fonts.Type.DEFAULT).getStringWidth(bindName);
        Fonts.getSize(18, Fonts.Type.DEFAULT).drawString(context.method_51448(), bindName, bindX + (bindSize - tw) / 2.0f, bindY + 8.0f, new Color(255, 255, 255, (int)(255.0f * alpha)).getRGB());
        context.method_51448().method_22909();
    }

    private void renderModeRect(class_332 context, float x, float y, float w, float h, String text, boolean active, int activeColor, int inactiveColor, float alpha) {
        int boxColor = active ? activeColor : inactiveColor;
        int textColor = -16777216;
        this.rectangle.render(ShapeProperties.create(context.method_51448(), x, y, w, h).round(3.0f).color(boxColor).outlineColor(active ? new Color(100, 100, 100, (int)(100.0f * alpha)).getRGB() : 0).build());
        float tw = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth(text);
        Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(context.method_51448(), text, x + (w - tw) / 2.0f, y + 4.0f, textColor);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        boolean hovered = Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, 20.0);
        if (selectedModule == this && popupAnimation.getOutput() > 0.5) {
            float menuWidth = 92.0f;
            float menuX = this.x - menuWidth - 3.0f;
            float menuY = this.y;
            float menuHeight = 20.0f;
            if (Calculate.isHovered(mouseX, mouseY, menuX, menuY, menuWidth, menuHeight)) {
                if (button == 0) {
                    float startX = menuX + 4.0f;
                    float startY = menuY + (menuHeight - 24.0f) / 2.0f + 1.0f;
                    if (Calculate.isHovered(mouseX, mouseY, startX, startY, 55.0, 11.0)) {
                        this.module.setType(1);
                        this.binding = false;
                    } else if (Calculate.isHovered(mouseX, mouseY, startX, startY + 13.0f, 55.0, 11.0)) {
                        this.module.setType(2);
                        this.binding = false;
                    } else if (Calculate.isHovered(mouseX, mouseY, startX + 59.0f, menuY + 3.0f, 22.0, 22.0)) {
                        this.binding = !this.binding;
                    }
                }
                return true;
            }
            if (!hovered) {
                this.binding = false;
                ModuleComponent.setSelectedModule(null);
            }
        }
        if (hovered) {
            if (button == 0) {
                if (this.binding) {
                    this.binding = false;
                    return true;
                }
                this.module.switchState();
                return true;
            }
            if (button == 2) {
                boolean opening = selectedModule != this;
                ModuleComponent.setSelectedModule(opening ? this : null);
                this.binding = opening;
                return true;
            }
            if (this.binding && button > 1) {
                this.module.setKey(button);
                this.binding = false;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (AbstractSettingComponent sc : this.settingComponents) {
            sc.mouseReleased(mouseX, mouseY, button);
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.binding) {
            if (keyCode == 256 || keyCode == 261) {
                this.module.setKey(-1);
            } else {
                this.module.setKey(keyCode);
            }
            this.binding = false;
            return true;
        }
        return false;
    }

    @Override
    public void tick() {
        super.tick();
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        ModuleComponent that = (ModuleComponent)o;
        return this.module.equals(that.module);
    }

    public int hashCode() {
        return Objects.hash(this.module);
    }

    public Module getModule() {
        return this.module;
    }

    public Rectangle getRectangle() {
        return this.rectangle;
    }

    public Animation getColorAnimation() {
        return this.colorAnimation;
    }

    public boolean isBinding() {
        return this.binding;
    }

    public long getNoSettingsTime() {
        return this.noSettingsTime;
    }

    public float getSmoothBgProgress() {
        return this.smoothBgProgress;
    }

    public SettingComponentAdder getComponentAdder() {
        return this.componentAdder;
    }

    public float getExpansionProgress() {
        return this.expansionProgress;
    }
}

