/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 */
package fun.bloody.display.screens.clickgui.components.implement.other;

import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.components.implement.category.CategoryComponent;
import fun.bloody.display.screens.clickgui.components.implement.module.ModuleComponent;
import fun.bloody.display.screens.clickgui.components.implement.other.SearchComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.TextComponent;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.interactions.inv.InventoryFlowManager;
import fun.bloody.utils.math.calc.Calculate;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_332;

public class CategoryContainerComponent
extends AbstractComponent {
    private final List<CategoryComponent> categoryComponents = new ArrayList<CategoryComponent>();
    private float dragX;
    private float dragY;
    private boolean dragging;
    private CategoryComponent draggingComponent = null;

    public void initializeCategoryComponents() {
        this.categoryComponents.clear();
        for (ModuleCategory category : ModuleCategory.values()) {
            this.categoryComponents.add(new CategoryComponent(category));
        }
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        float maxHeight = 270.0f;
        float offset = 0.0f;
        int count = 0;
        for (CategoryComponent component : this.categoryComponents) {
            if (count >= 5) break;
            component.x = this.x + offset;
            component.y = this.y;
            component.width = 115.0f;
            component.setFixedBackgroundHeight(maxHeight);
            component.render(context, mouseX, mouseY, delta);
            offset += component.width + 5.0f;
            ++count;
        }
        if (ModuleComponent.selectedModule != null) {
            ModuleComponent.selectedModule.drawContextMenu(context, mouseX, mouseY);
        }
        if (this.dragging && this.draggingComponent != null) {
            this.draggingComponent.x = (float)mouseX - this.dragX;
            this.draggingComponent.y = (float)mouseY - this.dragY;
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (ModuleComponent.selectedModule != null && ModuleComponent.selectedModule.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        for (CategoryComponent category : this.categoryComponents) {
            if (!category.mouseClicked(mouseX, mouseY, button)) continue;
            return true;
        }
        for (CategoryComponent component : this.categoryComponents) {
            if (!Calculate.isHovered(mouseX, mouseY, component.x, component.y, component.width, 28.0)) continue;
            this.dragging = true;
            this.draggingComponent = component;
            this.dragX = (float)(mouseX - (double)component.x);
            this.dragY = (float)(mouseY - (double)component.y);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.dragging = false;
        this.draggingComponent = null;
        this.categoryComponents.forEach(categoryComponent -> categoryComponent.mouseReleased(mouseX, mouseY, button));
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void tick() {
        if (TextComponent.typing || SearchComponent.typing) {
            InventoryFlowManager.unPressMoveKeys();
        } else {
            InventoryFlowManager.updateMoveKeys();
        }
        this.categoryComponents.forEach(AbstractComponent::tick);
        super.tick();
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        this.categoryComponents.forEach(categoryComponent -> categoryComponent.mouseDragged(mouseX, mouseY, button, deltaX, deltaY));
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        for (CategoryComponent category : this.categoryComponents) {
            if (!category.mouseScrolled(mouseX, mouseY, amount)) continue;
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ModuleComponent.selectedModule != null && ModuleComponent.selectedModule.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        for (CategoryComponent category : this.categoryComponents) {
            if (!category.keyPressed(keyCode, scanCode, modifiers)) continue;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        this.categoryComponents.forEach(categoryComponent -> categoryComponent.charTyped(chr, modifiers));
        return super.charTyped(chr, modifiers);
    }

    public CategoryContainerComponent setDragX(float dragX) {
        this.dragX = dragX;
        return this;
    }

    public CategoryContainerComponent setDragY(float dragY) {
        this.dragY = dragY;
        return this;
    }

    public CategoryContainerComponent setDragging(boolean dragging) {
        this.dragging = dragging;
        return this;
    }

    public CategoryContainerComponent setDraggingComponent(CategoryComponent draggingComponent) {
        this.draggingComponent = draggingComponent;
        return this;
    }
}

