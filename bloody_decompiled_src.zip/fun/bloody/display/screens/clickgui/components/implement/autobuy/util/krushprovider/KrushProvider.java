/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1802
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.util.krushprovider;

import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.AutoBuyableItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.defaultsetpricec.Defaultpricec;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list.KrushItems;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.util.krushprovider.KrushItem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1802;

public class KrushProvider {
    public static List<AutoBuyableItem> getKrush() {
        ArrayList<AutoBuyableItem> krush = new ArrayList<AutoBuyableItem>();
        krush.add(new KrushItem("\u0428\u043b\u0435\u043c \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f", class_1802.field_22027, KrushItems.getHelmet(), Defaultpricec.getPrice("\u0428\u043b\u0435\u043c \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f")));
        krush.add(new KrushItem("\u041d\u0430\u0433\u0440\u0443\u0434\u043d\u0438\u043a \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f", class_1802.field_22028, KrushItems.getChestplate(), Defaultpricec.getPrice("\u041d\u0430\u0433\u0440\u0443\u0434\u043d\u0438\u043a \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f")));
        krush.add(new KrushItem("\u041f\u043e\u043d\u043e\u0436\u0438 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f", class_1802.field_22029, KrushItems.getLeggings(), Defaultpricec.getPrice("\u041f\u043e\u043d\u043e\u0436\u0438 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f")));
        krush.add(new KrushItem("\u0411\u043e\u0442\u0438\u043d\u043a\u0438 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f", class_1802.field_22030, KrushItems.getBoots(), Defaultpricec.getPrice("\u0411\u043e\u0442\u0438\u043d\u043a\u0438 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f")));
        krush.add(new KrushItem("\u041c\u0435\u0447 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f", class_1802.field_22022, KrushItems.getSword(), Defaultpricec.getPrice("\u041c\u0435\u0447 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f")));
        krush.add(new KrushItem("\u041a\u0438\u0440\u043a\u0430 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f", class_1802.field_22024, KrushItems.getPickaxe(), Defaultpricec.getPrice("\u041a\u0438\u0440\u043a\u0430 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f")));
        krush.add(new KrushItem("\u0410\u0440\u0431\u0430\u043b\u0435\u0442 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f", class_1802.field_8399, KrushItems.getCrossbow(), Defaultpricec.getPrice("\u0410\u0440\u0431\u0430\u043b\u0435\u0442 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f")));
        krush.add(new KrushItem("\u0422\u0440\u0435\u0437\u0443\u0431\u0435\u0446 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f", class_1802.field_8547, KrushItems.getTrident(), Defaultpricec.getPrice("\u0422\u0440\u0435\u0437\u0443\u0431\u0435\u0446 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f")));
        krush.add(new KrushItem("\u0411\u0443\u043b\u0430\u0432\u0430 \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f", class_1802.field_49814, KrushItems.getMace(), Defaultpricec.getPrice("\u0411\u0443\u043b\u0430\u0432\u0430 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f")));
        return krush;
    }
}

