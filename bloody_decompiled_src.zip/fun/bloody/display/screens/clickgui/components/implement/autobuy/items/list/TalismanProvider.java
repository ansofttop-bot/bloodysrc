/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1802
 *  net.minecraft.class_2561
 *  net.minecraft.class_5250
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list;

import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.AutoBuyableItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.customitem.CustomItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.defaultsetpricec.Defaultpricec;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class TalismanProvider {
    public static List<AutoBuyableItem> getTalismans() {
        ArrayList<AutoBuyableItem> talismans = new ArrayList<AutoBuyableItem>();
        List<class_5250> graniLore = List.of(class_2561.method_43470((String)"\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0413\u0440\u0430\u043d\u0438 - \u044d\u0442\u043e"), class_2561.method_43470((String)"\u0431\u0435\u0437\u0433\u0440\u0430\u043d\u0438\u0447\u043d\u043e\u0441\u0442\u044c \u0441\u0438\u043b\u044b"), class_2561.method_43470((String)"\u0438 \u0434\u0443\u0445\u0430 \u0441\u0432\u043e\u0431\u043e\u0434\u044b"));
        talismans.add(new CustomItem("[\u2605] \u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0413\u0440\u0430\u043d\u0438", null, class_1802.field_8288, Defaultpricec.getPrice("\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0413\u0440\u0430\u043d\u0438"), null, graniLore));
        List<class_5250> dedalLore = List.of(class_2561.method_43470((String)"\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0414\u0435\u0434\u0430\u043b\u0430 - \u044d\u0442\u043e"), class_2561.method_43470((String)"\u0441\u0438\u043b\u0430 \u0438\u043d\u0436\u0435\u043d\u0435\u0440\u043d\u043e\u0433\u043e \u0434\u0443\u0445\u0430,"), class_2561.method_43470((String)"\u0432\u0434\u043e\u0445\u043d\u043e\u0432\u0435\u043d\u0438\u044f \u0438 \u043c\u0430\u0441\u0442\u0435\u0440\u0441\u0442\u0432\u0430"));
        talismans.add(new CustomItem("[\u2605] \u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0414\u0435\u0434\u0430\u043b\u0430", null, class_1802.field_8288, Defaultpricec.getPrice("\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0414\u0435\u0434\u0430\u043b\u0430"), null, dedalLore));
        List<class_5250> tritonLore = List.of(class_2561.method_43470((String)"\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0422\u0440\u0438\u0442\u043e\u043d\u0430 - \u044d\u0442\u043e"), class_2561.method_43470((String)"\u043d\u0435\u0438\u0441\u043a\u043e\u043d\u0447\u0430\u0435\u043c\u0430\u044f \u043c\u043e\u0449\u044c"), class_2561.method_43470((String)"\u043d\u0430\u0434 \u043f\u0440\u0438\u0440\u043e\u0434\u043d\u044b\u043c\u0438 \u0441\u0442\u0438\u0445\u0438\u044f\u043c\u0438"));
        talismans.add(new CustomItem("[\u2605] \u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0422\u0440\u0438\u0442\u043e\u043d\u0430", null, class_1802.field_8288, Defaultpricec.getPrice("\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0422\u0440\u0438\u0442\u043e\u043d\u0430"), null, tritonLore));
        List<class_5250> harmonyLore = List.of(class_2561.method_43470((String)"\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0413\u0430\u0440\u043c\u043e\u043d\u0438\u0438 - \u044d\u0442\u043e"), class_2561.method_43470((String)"\u0441\u0431\u0430\u043b\u0430\u043d\u0441\u0438\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0435 \u0441\u0438\u043b\u044b"), class_2561.method_43470((String)"\u0437\u0430\u0449\u0438\u0442\u044b, \u043c\u043e\u0449\u0438 \u0438 \u0437\u0434\u043e\u0440\u043e\u0432\u044c\u044f"));
        talismans.add(new CustomItem("[\u2605] \u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0413\u0430\u0440\u043c\u043e\u043d\u0438\u0438", null, class_1802.field_8288, Defaultpricec.getPrice("\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0413\u0430\u0440\u043c\u043e\u043d\u0438\u0438"), null, harmonyLore));
        List<class_5250> phoenixLore = List.of(class_2561.method_43470((String)"\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0424\u0435\u043d\u0438\u043a\u0441\u0430 - \u044d\u0442\u043e"), class_2561.method_43470((String)"\u0441\u0442\u0438\u0445\u0438\u0438 \u0441\u0438\u043b\u044b \u0438 \u0432\u043e\u0437\u0440\u043e\u0436\u0434\u0435\u043d\u0438\u044f,"), class_2561.method_43470((String)"\u043a\u043e\u0432\u0430\u043d\u044b\u0435 \u0430\u043d\u0433\u0435\u043b\u044c\u0441\u043a\u0438\u043c \u043f\u043b\u0430\u043c\u0435\u043d\u0435\u043c"));
        talismans.add(new CustomItem("[\u2605] \u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0424\u0435\u043d\u0438\u043a\u0441\u0430", null, class_1802.field_8288, Defaultpricec.getPrice("\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0424\u0435\u043d\u0438\u043a\u0441\u0430"), null, phoenixLore));
        List<class_5250> echidnaLore = List.of(class_2561.method_43470((String)"\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0415\u0445\u0438\u0434\u043d\u044b - \u044d\u0442\u043e"), class_2561.method_43470((String)"\u0441\u043c\u0435\u0440\u0442\u043e\u043d\u043e\u0441\u043d\u044b\u0435 \u0437\u043c\u0435\u0438\u043d\u044b\u0435 \u0440\u044b\u0432\u043a\u0438,"), class_2561.method_43470((String)"\u043e\u0441\u043b\u0430\u0431\u043b\u0435\u043d\u043d\u044b\u0435 \u044f\u0434\u043e\u0432\u0438\u0442\u043e\u0439 \u0430\u0443\u0440\u043e\u0439"));
        talismans.add(new CustomItem("[\u2605] \u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0415\u0445\u0438\u0434\u043d\u044b", null, class_1802.field_8288, Defaultpricec.getPrice("\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u0415\u0445\u0438\u0434\u043d\u044b"), null, echidnaLore));
        List<class_5250> punisherLore = List.of(class_2561.method_43470((String)"\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u041a\u0430\u0440\u0430\u0442\u0435\u043b\u044f - \u044d\u0442\u043e"), class_2561.method_43470((String)"\u043c\u043e\u0449\u044c \u043d\u0435\u0431\u0435\u0441\u043d\u043e\u0433\u043e \u043f\u0430\u043b\u0430\u0447\u0430,"), class_2561.method_43470((String)"\u0441\u043e\u043a\u0440\u0443\u0448\u0430\u044e\u0449\u0435\u0433\u043e \u043d\u0435\u0434\u0440\u0443\u0433\u043e\u0432"));
        talismans.add(new CustomItem("[\u2605] \u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u041a\u0430\u0440\u0430\u0442\u0435\u043b\u044f", null, class_1802.field_8288, Defaultpricec.getPrice("\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u041a\u0430\u0440\u0430\u0442\u0435\u043b\u044f"), null, punisherLore));
        List<class_5250> krushitelLore = List.of(class_2561.method_43470((String)"\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f - \u044d\u0442\u043e"), class_2561.method_43470((String)"\u043b\u0435\u0433\u0435\u043d\u0434\u0430\u0440\u043d\u044b\u0439 \u0442\u0430\u043b\u0438\u0441\u043c\u0430\u043d"), class_2561.method_43470((String)"\u043d\u0435\u0441\u043e\u043a\u0440\u0443\u0448\u0438\u043c\u044b\u0445 \u043a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u0435\u0439"));
        talismans.add(new CustomItem("[\u2605] \u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f", null, class_1802.field_8288, Defaultpricec.getPrice("\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d \u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044f"), null, krushitelLore));
        return talismans;
    }
}

