/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 */
package fun.bloody.display.screens.clickgui.components.implement.other;

import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import net.minecraft.class_332;

public class UserComponent
extends AbstractComponent {
    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return super.mouseClicked(mouseX, mouseY, button);
    }
}

