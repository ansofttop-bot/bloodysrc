/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  org.joml.Matrix4f
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.autobuyui;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.MenuScreen;
import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.AutoBuyableItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.manager.AutoBuyManager;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.originalitems.ItemRegistry;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.window.AutoBuyItemSettingsWindow;
import fun.bloody.display.screens.clickgui.components.implement.other.StatusRender;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

public class AutoBuyGuiComponent
extends AbstractComponent {
    private float scroll = 0.0f;
    private float smoothedScroll = 0.0f;
    private final List<StatusRender> itemStatusRenders = new ArrayList<StatusRender>();
    private final AutoBuyManager autoBuyManager = AutoBuyManager.getInstance();

    public AutoBuyGuiComponent() {
        this.updateItemStatusRenders();
    }

    private void updateItemStatusRenders() {
        this.itemStatusRenders.clear();
        List<AutoBuyableItem> allItems = ItemRegistry.getAllItems();
        for (AutoBuyableItem item : allItems) {
            StatusRender itemStatus = new StatusRender();
            itemStatus.setState(item.isEnabled()).setRunnable(() -> {
                this.autoBuyManager.toggleItem(item);
                this.updateItemStatusRenders();
            });
            this.itemStatusRenders.add(itemStatus);
        }
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (MenuScreen.INSTANCE.getCategory() != ModuleCategory.AUTOBUY) {
            return;
        }
        class_4587 matrix = context.method_51448();
        this.renderAllItems(context, matrix, mouseX, mouseY, delta);
    }

    private void renderAllItems(class_332 context, class_4587 matrix, int mouseX, int mouseY, float delta) {
        List<AutoBuyableItem> potionItems;
        List<AutoBuyableItem> donatorItems;
        List<AutoBuyableItem> miscItems;
        List<AutoBuyableItem> sphereItems;
        List<AutoBuyableItem> talismanItems;
        Matrix4f positionMatrix = matrix.method_23760().method_23761();
        ScissorAssist scissorManager = Bloody.getInstance().getScissorManager();
        float listX = this.x + 55.0f;
        float listY = this.y + 25.0f;
        float listWidth = this.width - 43.0f - 15.0f;
        float listHeight = this.height - 48.0f;
        float contentHeight = this.calculateContentHeight();
        float maxScrollAmount = Math.max(0.0f, contentHeight - listHeight);
        this.scroll = class_3532.method_15363((float)this.scroll, (float)(-maxScrollAmount), (float)0.0f);
        this.smoothedScroll = Calculate.interpolate(this.smoothedScroll, this.scroll, 0.15f);
        scissorManager.push(positionMatrix, listX, listY + 4.0f, listWidth, listHeight - 11.0f);
        float itemY = listY + 10.0f + this.smoothedScroll;
        int globalIndex = 0;
        List<AutoBuyableItem> krushItems = ItemRegistry.getKrush();
        if (!krushItems.isEmpty()) {
            this.renderCategoryHeader(matrix, listX, itemY, listWidth, "\u041a\u0440\u0443\u0448\u0438\u0442\u0435\u043b\u044c");
            itemY += 20.0f;
            for (int i = 0; i < krushItems.size(); ++i) {
                AutoBuyableItem item = krushItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                this.renderItem(context, matrix, item, itemX, itemY, mouseX, mouseY, delta, globalIndex);
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 25.0f;
        }
        if (!(talismanItems = ItemRegistry.getTalismans()).isEmpty()) {
            this.renderCategoryHeader(matrix, listX, itemY, listWidth, "\u0422\u0430\u043b\u0438\u0441\u043c\u0430\u043d\u044b");
            itemY += 20.0f;
            for (int i = 0; i < talismanItems.size(); ++i) {
                AutoBuyableItem item = talismanItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                this.renderItem(context, matrix, item, itemX, itemY, mouseX, mouseY, delta, globalIndex);
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 25.0f;
        }
        if (!(sphereItems = ItemRegistry.getSpheres()).isEmpty()) {
            this.renderCategoryHeader(matrix, listX, itemY, listWidth, "\u0421\u0444\u0435\u0440\u044b");
            itemY += 20.0f;
            for (int i = 0; i < sphereItems.size(); ++i) {
                AutoBuyableItem item = sphereItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                this.renderItem(context, matrix, item, itemX, itemY, mouseX, mouseY, delta, globalIndex);
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 25.0f;
        }
        if (!(miscItems = ItemRegistry.getMisc()).isEmpty()) {
            this.renderCategoryHeader(matrix, listX, itemY, listWidth, "\u0420\u0430\u0437\u043d\u043e\u0435");
            itemY += 20.0f;
            for (int i = 0; i < miscItems.size(); ++i) {
                AutoBuyableItem item = miscItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                this.renderItem(context, matrix, item, itemX, itemY, mouseX, mouseY, delta, globalIndex);
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 25.0f;
        }
        if (!(donatorItems = ItemRegistry.getDonator()).isEmpty()) {
            this.renderCategoryHeader(matrix, listX, itemY, listWidth, "\u0414\u043e\u043d\u0430\u0442\u043e\u0440\u0441\u043a\u0438\u0435");
            itemY += 20.0f;
            for (int i = 0; i < donatorItems.size(); ++i) {
                AutoBuyableItem item = donatorItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                this.renderItem(context, matrix, item, itemX, itemY, mouseX, mouseY, delta, globalIndex);
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 25.0f;
        }
        if (!(potionItems = ItemRegistry.getPotions()).isEmpty()) {
            this.renderCategoryHeader(matrix, listX, itemY, listWidth, "\u0417\u0435\u043b\u044c\u044f");
            itemY += 20.0f;
            for (int i = 0; i < potionItems.size(); ++i) {
                AutoBuyableItem item = potionItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                this.renderItem(context, matrix, item, itemX, itemY, mouseX, mouseY, delta, globalIndex);
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 10.0f;
        }
        scissorManager.pop();
    }

    private float calculateContentHeight() {
        List<AutoBuyableItem> krushItems = ItemRegistry.getKrush();
        List<AutoBuyableItem> talismanItems = ItemRegistry.getTalismans();
        List<AutoBuyableItem> sphereItems = ItemRegistry.getSpheres();
        List<AutoBuyableItem> miscItems = ItemRegistry.getMisc();
        List<AutoBuyableItem> donatorItems = ItemRegistry.getDonator();
        List<AutoBuyableItem> potionItems = ItemRegistry.getPotions();
        float totalHeight = 10.0f;
        if (!krushItems.isEmpty()) {
            totalHeight += 20.0f + (float)((krushItems.size() + 1) / 2) * 50.0f + 25.0f;
        }
        if (!talismanItems.isEmpty()) {
            totalHeight += 20.0f + (float)((talismanItems.size() + 1) / 2) * 50.0f + 25.0f;
        }
        if (!sphereItems.isEmpty()) {
            totalHeight += 20.0f + (float)((sphereItems.size() + 1) / 2) * 50.0f + 25.0f;
        }
        if (!miscItems.isEmpty()) {
            totalHeight += 20.0f + (float)((miscItems.size() + 1) / 2) * 50.0f + 25.0f;
        }
        if (!donatorItems.isEmpty()) {
            totalHeight += 20.0f + (float)((donatorItems.size() + 1) / 2) * 50.0f + 25.0f;
        }
        if (!potionItems.isEmpty()) {
            totalHeight += 20.0f + (float)((potionItems.size() + 1) / 2) * 50.0f + 10.0f;
        }
        return totalHeight;
    }

    private void renderCategoryHeader(class_4587 matrix, float x, float y, float width, String categoryName) {
        float textWidth = Fonts.getSize(14, Fonts.Type.SEMI).getStringWidth(categoryName);
        float lineWidth = (width - textWidth - 20.0f) / 2.0f;
        rectangle.render(ShapeProperties.create(matrix, x, y + 6.0f, lineWidth - 10.0f, 1.0).color(new Color(54, 54, 56, 255).getRGB()).build());
        Fonts.getSize(14, Fonts.Type.SEMI).drawString(matrix, categoryName, x + lineWidth, y + 4.0f, ColorAssist.getText(1.0f));
        rectangle.render(ShapeProperties.create(matrix, x + lineWidth + textWidth + 10.0f, y + 6.0f, lineWidth - 6.0f, 1.0).color(new Color(54, 54, 56, 255).getRGB()).build());
    }

    private void renderItem(class_332 context, class_4587 matrix, AutoBuyableItem item, float itemX, float itemY, int mouseX, int mouseY, float delta, int index) {
        FontRenderer font = Fonts.getSize(16, Fonts.Type.SEMI);
        class_1799 itemStack = item.createItemStack();
        blur.render(ShapeProperties.create(matrix, itemX, itemY, 175.0, 45.0).round(6.0f).quality(64.0f).color(new Color(0, 0, 0, 200).getRGB()).build());
        rectangle.render(ShapeProperties.create(matrix, itemX, itemY, 175.0, 45.0).round(6.0f).softness(2.0f).thickness(0.1f).outlineColor(new Color(18, 19, 20, 225).getRGB()).color(new Color(18, 19, 20, 175).getRGB(), new Color(0, 2, 5, 175).getRGB(), new Color(0, 2, 5, 175).getRGB(), new Color(18, 19, 20, 175).getRGB()).build());
        Render2D.defaultDrawStack(context, itemStack, itemX + 6.0f, itemY + 13.5f, false, false, 1.0f);
        Fonts.getSize(14, Fonts.Type.SEMI).drawGradientString(matrix, item.getDisplayName(), itemX + 30.0f, itemY + 14.0f, ColorAssist.getText(), ColorAssist.getText(0.65f));
        Fonts.getSize(12, Fonts.Type.REGULAR).drawString(matrix, "\u0426\u0435\u043d\u0430 \u043f\u043e\u043a\u0443\u043f\u043a\u0438: $" + item.getSettings().getBuyBelow(), itemX + 30.0f, itemY + 23.0f, ColorAssist.getText(0.65f));
        Fonts.getSize(12, Fonts.Type.REGULAR).drawString(matrix, "\u041a\u0430\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u043f\u043e\u043a\u0443\u043f\u043a\u0438 \u043e\u0442: " + item.getSettings().getMinQuantity(), itemX + 30.0f, itemY + 30.0f, ColorAssist.getText(0.65f));
        if (index < this.itemStatusRenders.size()) {
            this.itemStatusRenders.get(index).position(itemX + 160.0f, itemY + 18.5f).render(context, mouseX, mouseY, delta);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        List<AutoBuyableItem> potionItems;
        List<AutoBuyableItem> donatorItems;
        List<AutoBuyableItem> miscItems;
        List<AutoBuyableItem> sphereItems;
        List<AutoBuyableItem> talismanItems;
        if (MenuScreen.INSTANCE.getCategory() != ModuleCategory.AUTOBUY) {
            return super.mouseClicked(mouseX, mouseY, button);
        }
        float listX = this.x + 55.0f;
        float listY = this.y + 25.0f;
        float itemY = listY + 10.0f + this.smoothedScroll;
        int globalIndex = 0;
        List<AutoBuyableItem> krushItems = ItemRegistry.getKrush();
        if (!krushItems.isEmpty()) {
            itemY += 20.0f;
            for (int i = 0; i < krushItems.size(); ++i) {
                AutoBuyableItem item = krushItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                if (button == 1 && Calculate.isHovered(mouseX, mouseY, itemX, itemY, 175.0, 45.0)) {
                    this.openSettingsWindow(item);
                    return true;
                }
                if (button == 0 && globalIndex < this.itemStatusRenders.size()) {
                    StatusRender status = this.itemStatusRenders.get(globalIndex);
                    status.position(itemX + 160.0f, itemY + 18.5f);
                    if (status.mouseClicked(mouseX, mouseY, button)) {
                        this.autoBuyManager.toggleItem(item);
                        this.updateItemStatusRenders();
                        return true;
                    }
                }
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 25.0f;
        }
        if (!(talismanItems = ItemRegistry.getTalismans()).isEmpty()) {
            itemY += 20.0f;
            for (int i = 0; i < talismanItems.size(); ++i) {
                AutoBuyableItem item = talismanItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                if (button == 1 && Calculate.isHovered(mouseX, mouseY, itemX, itemY, 175.0, 45.0)) {
                    this.openSettingsWindow(item);
                    return true;
                }
                if (button == 0 && globalIndex < this.itemStatusRenders.size()) {
                    StatusRender status = this.itemStatusRenders.get(globalIndex);
                    status.position(itemX + 160.0f, itemY + 18.5f);
                    if (status.mouseClicked(mouseX, mouseY, button)) {
                        this.autoBuyManager.toggleItem(item);
                        this.updateItemStatusRenders();
                        return true;
                    }
                }
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 25.0f;
        }
        if (!(sphereItems = ItemRegistry.getSpheres()).isEmpty()) {
            itemY += 20.0f;
            for (int i = 0; i < sphereItems.size(); ++i) {
                AutoBuyableItem item = sphereItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                if (button == 1 && Calculate.isHovered(mouseX, mouseY, itemX, itemY, 175.0, 45.0)) {
                    this.openSettingsWindow(item);
                    return true;
                }
                if (button == 0 && globalIndex < this.itemStatusRenders.size()) {
                    StatusRender status = this.itemStatusRenders.get(globalIndex);
                    status.position(itemX + 160.0f, itemY + 18.5f);
                    if (status.mouseClicked(mouseX, mouseY, button)) {
                        this.autoBuyManager.toggleItem(item);
                        this.updateItemStatusRenders();
                        return true;
                    }
                }
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 25.0f;
        }
        if (!(miscItems = ItemRegistry.getMisc()).isEmpty()) {
            itemY += 20.0f;
            for (int i = 0; i < miscItems.size(); ++i) {
                AutoBuyableItem item = miscItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                if (button == 1 && Calculate.isHovered(mouseX, mouseY, itemX, itemY, 175.0, 45.0)) {
                    this.openSettingsWindow(item);
                    return true;
                }
                if (button == 0 && globalIndex < this.itemStatusRenders.size()) {
                    StatusRender status = this.itemStatusRenders.get(globalIndex);
                    status.position(itemX + 160.0f, itemY + 18.5f);
                    if (status.mouseClicked(mouseX, mouseY, button)) {
                        this.autoBuyManager.toggleItem(item);
                        this.updateItemStatusRenders();
                        return true;
                    }
                }
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 25.0f;
        }
        if (!(donatorItems = ItemRegistry.getDonator()).isEmpty()) {
            itemY += 20.0f;
            for (int i = 0; i < donatorItems.size(); ++i) {
                AutoBuyableItem item = donatorItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                if (button == 1 && Calculate.isHovered(mouseX, mouseY, itemX, itemY, 175.0, 45.0)) {
                    this.openSettingsWindow(item);
                    return true;
                }
                if (button == 0 && globalIndex < this.itemStatusRenders.size()) {
                    StatusRender status = this.itemStatusRenders.get(globalIndex);
                    status.position(itemX + 160.0f, itemY + 18.5f);
                    if (status.mouseClicked(mouseX, mouseY, button)) {
                        this.autoBuyManager.toggleItem(item);
                        this.updateItemStatusRenders();
                        return true;
                    }
                }
                ++globalIndex;
            }
            itemY += 50.0f;
            itemY += 25.0f;
        }
        if (!(potionItems = ItemRegistry.getPotions()).isEmpty()) {
            itemY += 20.0f;
            for (int i = 0; i < potionItems.size(); ++i) {
                AutoBuyableItem item = potionItems.get(i);
                float itemX = listX + (float)(i % 2 * 190);
                if (i % 2 == 0 && i > 0) {
                    itemY += 50.0f;
                }
                if (button == 1 && Calculate.isHovered(mouseX, mouseY, itemX, itemY, 175.0, 45.0)) {
                    this.openSettingsWindow(item);
                    return true;
                }
                if (button == 0 && globalIndex < this.itemStatusRenders.size()) {
                    StatusRender status = this.itemStatusRenders.get(globalIndex);
                    status.position(itemX + 160.0f, itemY + 18.5f);
                    if (status.mouseClicked(mouseX, mouseY, button)) {
                        this.autoBuyManager.toggleItem(item);
                        this.updateItemStatusRenders();
                        return true;
                    }
                }
                ++globalIndex;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void openSettingsWindow(AutoBuyableItem item) {
        if (MenuScreen.windowManager.getWindows().stream().noneMatch(w -> w instanceof AutoBuyItemSettingsWindow && ((AutoBuyItemSettingsWindow)w).item.equals(item))) {
            AutoBuyItemSettingsWindow settingsWindow = new AutoBuyItemSettingsWindow(item, item.getSettings());
            settingsWindow.position(MenuScreen.INSTANCE.x + MenuScreen.INSTANCE.width + 24, MenuScreen.INSTANCE.y).size(180.0f, settingsWindow.getComponentHeight());
            MenuScreen.windowManager.add(settingsWindow);
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (MenuScreen.INSTANCE.getCategory() == ModuleCategory.AUTOBUY && Calculate.isHovered(mouseX, mouseY, this.x + 55.0f, this.y + 38.0f, this.width - 43.0f - 15.0f, this.height - 48.0f)) {
            this.scroll = (float)((double)this.scroll + amount * 20.0);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    public AutoBuyGuiComponent setScroll(float scroll) {
        this.scroll = scroll;
        return this;
    }

    public AutoBuyGuiComponent setSmoothedScroll(float smoothedScroll) {
        this.smoothedScroll = smoothedScroll;
        return this;
    }
}

