/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1844
 *  net.minecraft.class_2561
 *  net.minecraft.class_5321
 *  net.minecraft.class_6880
 *  net.minecraft.class_9290
 *  net.minecraft.class_9304
 *  net.minecraft.class_9323
 *  net.minecraft.class_9334
 *  org.apache.commons.lang3.StringUtils
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import org.apache.commons.lang3.StringUtils;

public class AuctionUtils {
    public static final Pattern funTimePricePattern = Pattern.compile("\\$(\\d+(?:[\\s,]\\d{3})*(?:\\.\\d{2})?)");

    public static int getPrice(class_1799 stack) {
        Matcher matcher;
        String customName;
        class_9323 tag = stack.method_57353();
        if (tag == null) {
            return -1;
        }
        String priceStr = null;
        String componentString = tag.toString();
        priceStr = StringUtils.substringBetween((String)componentString, (String)"literal{ $", (String)"}[style={color=green}]");
        if ((priceStr == null || priceStr.isEmpty()) && (customName = stack.method_7964().getString()) != null && (matcher = funTimePricePattern.matcher(customName)).find()) {
            priceStr = matcher.group(1);
        }
        if (priceStr == null || priceStr.isEmpty()) {
            return -1;
        }
        try {
            priceStr = priceStr.replaceAll("[\\s,]", "");
            return Integer.parseInt(priceStr);
        }
        catch (NumberFormatException e) {
            return -1;
        }
    }

    private static String cleanString(String str) {
        if (str == null) {
            return "";
        }
        return str.toLowerCase().trim().replaceAll("\u00a7.", "").replaceAll("[^a-z\u0430-\u044f\u04510-9\\s\\[\\]\u2605+]", "").replaceAll("\\s+", " ");
    }

    public static boolean isArmorItem(class_1799 stack) {
        return stack.method_7909() == class_1802.field_22027 || stack.method_7909() == class_1802.field_22028 || stack.method_7909() == class_1802.field_22029 || stack.method_7909() == class_1802.field_22030 || stack.method_7909() == class_1802.field_8805 || stack.method_7909() == class_1802.field_8058 || stack.method_7909() == class_1802.field_8348 || stack.method_7909() == class_1802.field_8285 || stack.method_7909() == class_1802.field_8743 || stack.method_7909() == class_1802.field_8523 || stack.method_7909() == class_1802.field_8396 || stack.method_7909() == class_1802.field_8660 || stack.method_7909() == class_1802.field_8862 || stack.method_7909() == class_1802.field_8678 || stack.method_7909() == class_1802.field_8416 || stack.method_7909() == class_1802.field_8753 || stack.method_7909() == class_1802.field_8283 || stack.method_7909() == class_1802.field_8873 || stack.method_7909() == class_1802.field_8218 || stack.method_7909() == class_1802.field_8313 || stack.method_7909() == class_1802.field_8267 || stack.method_7909() == class_1802.field_8577 || stack.method_7909() == class_1802.field_8570 || stack.method_7909() == class_1802.field_8370 || stack.method_7909() == class_1802.field_8090;
    }

    public static boolean hasThornsEnchantment(class_1799 stack) {
        class_9304 enchants = (class_9304)stack.method_57824(class_9334.field_49633);
        if (enchants == null || enchants.method_57543()) {
            return false;
        }
        for (class_6880 entry : enchants.method_57534()) {
            String lowerEnchantId;
            String enchantId = entry.method_55840();
            if (enchantId == null || !(lowerEnchantId = enchantId.toLowerCase()).contains("thorns") && !lowerEnchantId.contains("\u0448\u0438\u043f")) continue;
            return true;
        }
        class_9290 lore = (class_9290)stack.method_57824(class_9334.field_49632);
        if (lore != null) {
            for (class_2561 line : lore.comp_2400()) {
                String loreStr = line.getString().toLowerCase();
                if (!loreStr.contains("thorns") && !loreStr.contains("\u0448\u0438\u043f")) continue;
                return true;
            }
        }
        return false;
    }

    private static boolean isKillerOriginal(class_1799 stack) {
        if (stack.method_7909() != class_1802.field_8436 && stack.method_7909() != class_1802.field_8574) {
            return false;
        }
        class_1844 potionContents = (class_1844)stack.method_57824(class_9334.field_49651);
        if (potionContents == null) {
            return false;
        }
        List effects = potionContents.comp_2380();
        if (effects.isEmpty()) {
            return false;
        }
        boolean hasStrengthIV = false;
        for (class_1293 effect : effects) {
            int amplifier = effect.method_5578();
            if (!effect.method_5579().method_40225((class_5321)class_1294.field_5910.method_40230().get()) || amplifier < 3) continue;
            hasStrengthIV = true;
        }
        return hasStrengthIV;
    }

    public static boolean compareItem(class_1799 a, class_1799 b) {
        if (a.method_7909() != b.method_7909()) {
            return false;
        }
        if (AuctionUtils.isArmorItem(a) && AuctionUtils.hasThornsEnchantment(a)) {
            return false;
        }
        String aName = a.method_7964().getString();
        aName = funTimePricePattern.matcher(aName).replaceAll("").trim();
        String bName = b.method_7964().getString();
        String aNameClean = AuctionUtils.cleanString(aName);
        String bNameClean = AuctionUtils.cleanString(bName);
        class_9290 aLore = (class_9290)a.method_57824(class_9334.field_49632);
        class_9290 bLoreComp = (class_9290)b.method_57824(class_9334.field_49632);
        boolean hasLore = bLoreComp != null && !bLoreComp.comp_2400().isEmpty();
        boolean isKillerPotionTemplate = false;
        if (hasLore) {
            for (class_2561 expected : bLoreComp.comp_2400()) {
                String expectedStr = expected.getString().toLowerCase();
                if (!expectedStr.contains("\u043a\u0438\u043b\u043b\u0435\u0440") && !expectedStr.contains("killer")) continue;
                isKillerPotionTemplate = true;
                break;
            }
        }
        if (isKillerPotionTemplate && (a.method_7909() == class_1802.field_8436 || a.method_7909() == class_1802.field_8574)) {
            boolean result = AuctionUtils.isKillerOriginal(a);
            return result;
        }
        if (hasLore) {
            double matchRatio;
            List expectedLore = bLoreComp.comp_2400();
            if (aLore == null || aLore.comp_2400().isEmpty()) {
                return false;
            }
            List auctionLoreStrings = aLore.comp_2400().stream().map(text -> AuctionUtils.cleanString(text.getString())).filter(s -> !s.isEmpty()).collect(Collectors.toList());
            String auctionLoreJoined = String.join((CharSequence)" ", auctionLoreStrings);
            boolean hasOriginalMarker = false;
            for (String line : auctionLoreStrings) {
                if (!line.contains("\u043e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442") && !line.contains("\u2605")) continue;
                hasOriginalMarker = true;
            }
            int matchCount = 0;
            int requiredMatches = 0;
            for (class_2561 expected : expectedLore) {
                boolean isOriginalMarker;
                String expectedStr = AuctionUtils.cleanString(expected.getString());
                if (expectedStr.isEmpty()) continue;
                boolean bl = isOriginalMarker = expectedStr.contains("\u043e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442") || expectedStr.contains("\u2605");
                if (isOriginalMarker) {
                    if (!hasOriginalMarker) {
                        return false;
                    }
                    ++matchCount;
                    ++requiredMatches;
                    continue;
                }
                ++requiredMatches;
                boolean found = false;
                for (String auctionLine : auctionLoreStrings) {
                    if (!auctionLine.contains(expectedStr) && !expectedStr.contains(auctionLine)) continue;
                    found = true;
                    break;
                }
                if (!found && auctionLoreJoined.contains(expectedStr)) {
                    found = true;
                }
                if (!found) continue;
                ++matchCount;
            }
            double d = matchRatio = requiredMatches > 0 ? (double)matchCount / (double)requiredMatches : 1.0;
            if (matchRatio < 0.5) {
                return false;
            }
            if (hasOriginalMarker) {
                class_9304 aEnchants = (class_9304)a.method_57824(class_9334.field_49633);
                class_9304 bEnchants = (class_9304)b.method_57824(class_9334.field_49633);
                if (bEnchants != null && !bEnchants.method_57543()) {
                    if (aEnchants == null || aEnchants.method_57543()) {
                        return false;
                    }
                    HashMap<String, Integer> aEnchantMap = new HashMap<String, Integer>();
                    for (Object entry : aEnchants.method_57534()) {
                        String enchantId = entry.method_55840();
                        if (enchantId == null) continue;
                        String string = enchantId.replace("minecraft:", "").toLowerCase();
                        int level = aEnchants.method_57536((class_6880)entry);
                        aEnchantMap.put(string, level);
                    }
                    HashMap<String, Integer> bEnchantMap = new HashMap<String, Integer>();
                    for (Object entry : bEnchants.method_57534()) {
                        String string = entry.method_55840();
                        if (string == null) continue;
                        String enchantName = string.replace("minecraft:", "").toLowerCase();
                        int level = bEnchants.method_57536((class_6880)entry);
                        bEnchantMap.put(enchantName, level);
                    }
                    if (bEnchantMap.isEmpty()) {
                        return true;
                    }
                    int enchantMatchCount = 0;
                    for (Map.Entry entry : bEnchantMap.entrySet()) {
                        String bEnchantName = (String)entry.getKey();
                        Integer aLevel = (Integer)aEnchantMap.get(bEnchantName);
                        if (aLevel == null || aLevel < 1) continue;
                        ++enchantMatchCount;
                    }
                    double enchantMatchRatio = (double)enchantMatchCount / (double)bEnchantMap.size();
                    if (enchantMatchRatio < 1.0) {
                        return false;
                    }
                }
            }
        } else if (!aNameClean.contains(bNameClean) && !bNameClean.contains(aNameClean)) {
            return false;
        }
        return true;
    }
}

