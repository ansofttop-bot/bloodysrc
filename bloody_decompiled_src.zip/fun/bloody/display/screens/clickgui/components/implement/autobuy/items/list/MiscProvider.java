/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1935
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list;

import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.AutoBuyableItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.defaultsetpricec.Defaultpricec;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.util.krushprovider.KrushItem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;

public class MiscProvider {
    public static List<AutoBuyableItem> getMisc() {
        ArrayList<AutoBuyableItem> misc = new ArrayList<AutoBuyableItem>();
        misc.add(new KrushItem("\u0417\u043e\u043b\u043e\u0442\u043e\u0435 \u044f\u0431\u043b\u043e\u043a\u043e", class_1802.field_8463, new class_1799((class_1935)class_1802.field_8463), Defaultpricec.getPrice("\u0417\u043e\u043b\u043e\u0442\u043e\u0435 \u044f\u0431\u043b\u043e\u043a\u043e")));
        misc.add(new KrushItem("\u042f\u0431\u043b\u043e\u043a\u043e", class_1802.field_8279, new class_1799((class_1935)class_1802.field_8279), Defaultpricec.getPrice("\u042f\u0431\u043b\u043e\u043a\u043e")));
        misc.add(new KrushItem("\u0417\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u043d\u043e\u0435 \u0437\u043e\u043b\u043e\u0442\u043e\u0435 \u044f\u0431\u043b\u043e\u043a\u043e", class_1802.field_8367, new class_1799((class_1935)class_1802.field_8367), Defaultpricec.getPrice("\u0417\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u043d\u043e\u0435 \u0437\u043e\u043b\u043e\u0442\u043e\u0435 \u044f\u0431\u043b\u043e\u043a\u043e")));
        misc.add(new KrushItem("\u041f\u043e\u0440\u043e\u0445", class_1802.field_8054, new class_1799((class_1935)class_1802.field_8054), Defaultpricec.getPrice("\u041f\u043e\u0440\u043e\u0445")));
        misc.add(new KrushItem("\u0411\u0438\u0440\u043a\u0430", class_1802.field_8448, new class_1799((class_1935)class_1802.field_8448), Defaultpricec.getPrice("\u0411\u0438\u0440\u043a\u0430")));
        misc.add(new KrushItem("\u0422\u0440\u0435\u0437\u0443\u0431\u0435\u0446", class_1802.field_8547, new class_1799((class_1935)class_1802.field_8547), Defaultpricec.getPrice("\u0422\u0440\u0435\u0437\u0443\u0431\u0435\u0446")));
        misc.add(new KrushItem("\u041d\u0435\u0437\u0435\u0440\u0438\u0442\u043e\u0432\u044b\u0439 \u0441\u043b\u0438\u0442\u043e\u043a", class_1802.field_22020, new class_1799((class_1935)class_1802.field_22020), Defaultpricec.getPrice("\u041d\u0435\u0437\u0435\u0440\u0438\u0442\u043e\u0432\u044b\u0439 \u0441\u043b\u0438\u0442\u043e\u043a")));
        misc.add(new KrushItem("\u041d\u0435\u0437\u0435\u0440\u0438\u0442\u043e\u0432\u043e\u0435 \u0443\u043b\u0443\u0447\u0448\u0435\u043d\u0438\u0435", class_1802.field_41946, new class_1799((class_1935)class_1802.field_41946), Defaultpricec.getPrice("\u041d\u0435\u0437\u0435\u0440\u0438\u0442\u043e\u0432\u043e\u0435 \u0443\u043b\u0443\u0447\u0448\u0435\u043d\u0438\u0435")));
        misc.add(new KrushItem("\u0410\u043b\u043c\u0430\u0437", class_1802.field_8477, new class_1799((class_1935)class_1802.field_8477), Defaultpricec.getPrice("\u0410\u043b\u043c\u0430\u0437")));
        misc.add(new KrushItem("\u0410\u043b\u043c\u0430\u0437\u043d\u044b\u0439 \u0431\u043b\u043e\u043a", class_1802.field_8603, new class_1799((class_1935)class_1802.field_8603), Defaultpricec.getPrice("\u0410\u043b\u043c\u0430\u0437\u043d\u044b\u0439 \u0431\u043b\u043e\u043a")));
        misc.add(new KrushItem("\u0417\u043e\u043b\u043e\u0442\u043e\u0439 \u0441\u043b\u0438\u0442\u043e\u043a", class_1802.field_8695, new class_1799((class_1935)class_1802.field_8695), Defaultpricec.getPrice("\u0417\u043e\u043b\u043e\u0442\u043e\u0439 \u0441\u043b\u0438\u0442\u043e\u043a")));
        misc.add(new KrushItem("\u0411\u043b\u043e\u043a \u0437\u043e\u043b\u043e\u0442\u0430", class_1802.field_8494, new class_1799((class_1935)class_1802.field_8494), Defaultpricec.getPrice("\u0411\u043b\u043e\u043a \u0437\u043e\u043b\u043e\u0442\u0430")));
        misc.add(new KrushItem("\u041c\u0430\u044f\u043a", class_1802.field_8668, new class_1799((class_1935)class_1802.field_8668), Defaultpricec.getPrice("\u041c\u0430\u044f\u043a")));
        misc.add(new KrushItem("\u041f\u0443\u0437\u044b\u0440\u0451\u043a \u043e\u043f\u044b\u0442\u0430", class_1802.field_8287, new class_1799((class_1935)class_1802.field_8287), Defaultpricec.getPrice("\u041f\u0443\u0437\u044b\u0440\u0451\u043a \u043e\u043f\u044b\u0442\u0430")));
        misc.add(new KrushItem("\u0417\u0432\u0435\u0437\u0434\u0430 \u041d\u0435\u0437\u0435\u0440\u0430", class_1802.field_8137, new class_1799((class_1935)class_1802.field_8137), Defaultpricec.getPrice("\u0417\u0432\u0435\u0437\u0434\u0430 \u041d\u0435\u0437\u0435\u0440\u0430")));
        misc.add(new KrushItem("\u0428\u0430\u043b\u043a\u0435\u0440\u043e\u0432\u044b\u0439 \u044f\u0449\u0438\u043a", class_1802.field_8545, new class_1799((class_1935)class_1802.field_8545), Defaultpricec.getPrice("\u0428\u0430\u043b\u043a\u0435\u0440\u043e\u0432\u044b\u0439 \u044f\u0449\u0438\u043a")));
        misc.add(new KrushItem("\u0416\u0435\u043b\u0435\u0437\u043d\u044b\u0439 \u0441\u043b\u0438\u0442\u043e\u043a", class_1802.field_8620, new class_1799((class_1935)class_1802.field_8620), Defaultpricec.getPrice("\u0416\u0435\u043b\u0435\u0437\u043d\u044b\u0439 \u0441\u043b\u0438\u0442\u043e\u043a")));
        misc.add(new KrushItem("\u0416\u0435\u043b\u0435\u0437\u043d\u044b\u0439 \u0431\u043b\u043e\u043a", class_1802.field_8773, new class_1799((class_1935)class_1802.field_8773), Defaultpricec.getPrice("\u0416\u0435\u043b\u0435\u0437\u043d\u044b\u0439 \u0431\u043b\u043e\u043a")));
        misc.add(new KrushItem("\u041d\u0435\u0437\u0435\u0440\u0438\u0442\u043e\u0432\u044b\u0439 \u0431\u043b\u043e\u043a", class_1802.field_22018, new class_1799((class_1935)class_1802.field_22018), Defaultpricec.getPrice("\u041d\u0435\u0437\u0435\u0440\u0438\u0442\u043e\u0432\u044b\u0439 \u0431\u043b\u043e\u043a")));
        misc.add(new KrushItem("\u0421\u043f\u0430\u0432\u043d\u0435\u0440", class_1802.field_8849, new class_1799((class_1935)class_1802.field_8849), Defaultpricec.getPrice("\u0421\u043f\u0430\u0432\u043d\u0435\u0440")));
        misc.add(new KrushItem("\u042d\u043b\u0438\u0442\u0440\u044b", class_1802.field_8833, new class_1799((class_1935)class_1802.field_8833), Defaultpricec.getPrice("\u042d\u043b\u0438\u0442\u0440\u044b")));
        misc.add(new KrushItem("\u042d\u043d\u0434\u0435\u0440 \u0436\u0435\u043c\u0447\u0443\u0433", class_1802.field_8634, new class_1799((class_1935)class_1802.field_8634), Defaultpricec.getPrice("\u042d\u043d\u0434\u0435\u0440 \u0436\u0435\u043c\u0447\u0443\u0433")));
        misc.add(new KrushItem("\u041e\u0431\u0441\u0438\u0434\u0438\u0430\u043d", class_1802.field_8281, new class_1799((class_1935)class_1802.field_8281), Defaultpricec.getPrice("\u041e\u0431\u0441\u0438\u0434\u0438\u0430\u043d")));
        misc.add(new KrushItem("\u0422\u043e\u0442\u0435\u043c \u0431\u0435\u0441\u0441\u043c\u0435\u0440\u0442\u0438\u044f", class_1802.field_8288, new class_1799((class_1935)class_1802.field_8288), Defaultpricec.getPrice("\u0422\u043e\u0442\u0435\u043c \u0431\u0435\u0441\u0441\u043c\u0435\u0440\u0442\u0438\u044f")));
        misc.add(new KrushItem("\u041f\u0430\u043b\u043a\u0430 \u0438\u0444\u0440\u0438\u0442\u0430", class_1802.field_8894, new class_1799((class_1935)class_1802.field_8894), Defaultpricec.getPrice("\u041f\u0430\u043b\u043a\u0430 \u0438\u0444\u0440\u0438\u0442\u0430")));
        misc.add(new KrushItem("\u0414\u0438\u043d\u0430\u043c\u0438\u0442", class_1802.field_8626, new class_1799((class_1935)class_1802.field_8626), Defaultpricec.getPrice("\u0414\u0438\u043d\u0430\u043c\u0438\u0442")));
        misc.add(new KrushItem("\u042f\u0439\u0446\u043e \u0437\u043e\u043c\u0431\u0438-\u0436\u0438\u0442\u0435\u043b\u044f", class_1802.field_8136, new class_1799((class_1935)class_1802.field_8136), Defaultpricec.getPrice("\u042f\u0439\u0446\u043e \u0437\u043e\u043c\u0431\u0438-\u0436\u0438\u0442\u0435\u043b\u044f")));
        misc.add(new KrushItem("\u0413\u043e\u043b\u043e\u0432\u0430 \u0441\u043a\u0435\u043b\u0435\u0442\u0430", class_1802.field_8398, new class_1799((class_1935)class_1802.field_8398), Defaultpricec.getPrice("\u0413\u043e\u043b\u043e\u0432\u0430 \u0441\u043a\u0435\u043b\u0435\u0442\u0430")));
        misc.add(new KrushItem("\u0413\u043e\u043b\u043e\u0432\u0430 \u0437\u043e\u043c\u0431\u0438", class_1802.field_8470, new class_1799((class_1935)class_1802.field_8470), Defaultpricec.getPrice("\u0413\u043e\u043b\u043e\u0432\u0430 \u0437\u043e\u043c\u0431\u0438")));
        misc.add(new KrushItem("\u0413\u043e\u043b\u043e\u0432\u0430 \u043a\u0440\u0438\u043f\u0435\u0440\u0430", class_1802.field_8681, new class_1799((class_1935)class_1802.field_8681), Defaultpricec.getPrice("\u0413\u043e\u043b\u043e\u0432\u0430 \u043a\u0440\u0438\u043f\u0435\u0440\u0430")));
        misc.add(new KrushItem("\u0413\u043e\u043b\u043e\u0432\u0430 \u0432\u0438\u0437\u0435\u0440-\u0441\u043a\u0435\u043b\u0435\u0442\u0430", class_1802.field_8791, new class_1799((class_1935)class_1802.field_8791), Defaultpricec.getPrice("\u0413\u043e\u043b\u043e\u0432\u0430 \u0432\u0438\u0437\u0435\u0440-\u0441\u043a\u0435\u043b\u0435\u0442\u0430")));
        misc.add(new KrushItem("\u0413\u043e\u043b\u043e\u0432\u0430 \u043f\u0438\u0433\u043b\u0438\u043d\u0430", class_1802.field_41304, new class_1799((class_1935)class_1802.field_41304), Defaultpricec.getPrice("\u0413\u043e\u043b\u043e\u0432\u0430 \u043f\u0438\u0433\u043b\u0438\u043d\u0430")));
        misc.add(new KrushItem("\u0413\u043e\u043b\u043e\u0432\u0430 \u0434\u0440\u0430\u043a\u043e\u043d\u0430", class_1802.field_8712, new class_1799((class_1935)class_1802.field_8712), Defaultpricec.getPrice("\u0413\u043e\u043b\u043e\u0432\u0430 \u0434\u0440\u0430\u043a\u043e\u043d\u0430")));
        misc.add(new KrushItem("\u0410\u043b\u043c\u0430\u0437\u043d\u0430\u044f \u0440\u0443\u0434\u0430", class_1802.field_8787, new class_1799((class_1935)class_1802.field_8787), Defaultpricec.getPrice("\u0410\u043b\u043c\u0430\u0437\u043d\u0430\u044f \u0440\u0443\u0434\u0430")));
        misc.add(new KrushItem("\u0418\u0437\u0443\u043c\u0440\u0443\u0434\u043d\u0430\u044f \u0440\u0443\u0434\u0430", class_1802.field_8837, new class_1799((class_1935)class_1802.field_8837), Defaultpricec.getPrice("\u0418\u0437\u0443\u043c\u0440\u0443\u0434\u043d\u0430\u044f \u0440\u0443\u0434\u0430")));
        misc.add(new KrushItem("\u0422\u043e\u0440\u0442", class_1802.field_17534, new class_1799((class_1935)class_1802.field_17534), Defaultpricec.getPrice("\u0422\u043e\u0440\u0442")));
        misc.add(new KrushItem("\u0424\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a", class_1802.field_8639, new class_1799((class_1935)class_1802.field_8639), Defaultpricec.getPrice("\u0424\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a")));
        misc.add(new KrushItem("\u042f\u0439\u0446\u043e \u0436\u0438\u0442\u0435\u043b\u044f", class_1802.field_8086, new class_1799((class_1935)class_1802.field_8086), Defaultpricec.getPrice("\u042f\u0439\u0446\u043e \u0436\u0438\u0442\u0435\u043b\u044f")));
        misc.add(new KrushItem("\u042f\u0439\u0446\u043e \u0432\u0438\u0445\u0440\u044f", class_1802.field_47313, new class_1799((class_1935)class_1802.field_47313), Defaultpricec.getPrice("\u042f\u0439\u0446\u043e \u0432\u0438\u0445\u0440\u044f")));
        misc.add(new KrushItem("\u041c\u0435\u0448\u043e\u043a", class_1802.field_27023, new class_1799((class_1935)class_1802.field_27023), Defaultpricec.getPrice("\u041c\u0435\u0448\u043e\u043a")));
        misc.add(new KrushItem("\u0411\u0443\u043b\u0430\u0432\u0430", class_1802.field_49814, new class_1799((class_1935)class_1802.field_49814), Defaultpricec.getPrice("\u0411\u0443\u043b\u0430\u0432\u0430")));
        misc.add(new KrushItem("\u0417\u043b\u043e\u0432\u0435\u0449\u0438\u0439 \u043a\u043b\u044e\u0447 \u0438\u0441\u043f\u044b\u0442\u0430\u043d\u0438\u0439", class_1802.field_50139, new class_1799((class_1935)class_1802.field_50139), Defaultpricec.getPrice("\u0417\u043b\u043e\u0432\u0435\u0449\u0438\u0439 \u043a\u043b\u044e\u0447 \u0438\u0441\u043f\u044b\u0442\u0430\u043d\u0438\u0439")));
        misc.add(new KrushItem("\u041a\u043b\u044e\u0447 \u0438\u0441\u043f\u044b\u0442\u0430\u043d\u0438\u0439", class_1802.field_47315, new class_1799((class_1935)class_1802.field_47315), Defaultpricec.getPrice("\u041a\u043b\u044e\u0447 \u0438\u0441\u043f\u044b\u0442\u0430\u043d\u0438\u0439")));
        misc.add(new KrushItem("\u0417\u0430\u0440\u044f\u0434 \u0432\u0435\u0442\u0440\u0430", class_1802.field_49098, new class_1799((class_1935)class_1802.field_49098), Defaultpricec.getPrice("\u0417\u0430\u0440\u044f\u0434 \u0432\u0435\u0442\u0440\u0430")));
        misc.add(new KrushItem("\u0421\u0442\u0435\u0440\u0436\u0435\u043d\u044c \u0432\u0438\u0445\u0440\u044f", class_1802.field_49821, new class_1799((class_1935)class_1802.field_49821), Defaultpricec.getPrice("\u0421\u0442\u0435\u0440\u0436\u0435\u043d\u044c \u0432\u0438\u0445\u0440\u044f")));
        return misc;
    }
}

