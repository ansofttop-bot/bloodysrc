/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color.component;

import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class HueComponent
extends AbstractComponent {
    private final ColorSetting setting;
    private boolean hueDragging;

    private float getPickerX() {
        return this.x + 6.0f;
    }

    private float getPickerY() {
        return this.y + 18.5f;
    }

    private float getPickerW() {
        return 88.0f;
    }

    private float getPickerH() {
        return 50.0f;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        class_4587 matrix = context.method_51448();
        float X = this.getPickerX();
        float Y = this.getPickerY();
        float W = this.getPickerW();
        float H = this.getPickerH();
        int[] colors = new int[]{-16777216, -1, -16777216, Color.HSBtoRGB(this.setting.getHue(), 1.0f, 1.0f)};
        rectangle.render(ShapeProperties.create(matrix, X, Y, W, H).round(2.0f).color(colors).build());
        float clampedX = class_3532.method_15363((float)(X + W * this.setting.getSaturation()), (float)X, (float)(X + W - 5.0f));
        float clampedY = class_3532.method_15363((float)(Y + H * (1.0f - this.setting.getBrightness())), (float)Y, (float)(Y + H - 5.0f));
        rectangle.render(ShapeProperties.create(matrix, clampedX, clampedY, 5.0, 5.0).round(2.5f).softness(1.0f).thickness(3.0f).color(0xFFFFFF).outlineColor(-1).build());
        if (this.hueDragging) {
            this.setting.setBrightness(class_3532.method_15363((float)(1.0f - ((float)mouseY - Y) / H), (float)0.0f, (float)1.0f));
            this.setting.setSaturation(class_3532.method_15363((float)(((float)mouseX - X) / W), (float)0.0f, (float)1.0f));
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        this.hueDragging = button == 0 && Calculate.isHovered(mouseX, mouseY, this.getPickerX(), this.getPickerY(), this.getPickerW(), this.getPickerH());
        return this.hueDragging || super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.hueDragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    public HueComponent(ColorSetting setting) {
        this.setting = setting;
    }
}

