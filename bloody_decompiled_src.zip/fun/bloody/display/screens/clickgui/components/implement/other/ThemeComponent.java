/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.other;

import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.components.implement.window.AbstractWindow;
import fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color.ColorWindow;
import fun.bloody.display.screens.clickgui.theme.ClientTheme;
import fun.bloody.display.screens.clickgui.theme.ThemeManager;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class ThemeComponent
extends AbstractComponent {
    private final ThemeManager themeManager = ThemeManager.getInstance();
    private final ColorSetting customColor1Setting = new ColorSetting("Theme Color 1", "Primary custom theme color").setColor(this.themeManager.getCustomColor1());
    private final ColorSetting customColor2Setting = new ColorSetting("Theme Color 2", "Secondary custom theme color").setColor(this.themeManager.getCustomColor2());

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        class_4587 matrix = context.method_51448();
        int currentC1 = this.customColor1Setting.getColor();
        int currentC2 = this.customColor2Setting.getColor();
        if (this.themeManager.getCustomColor1() != currentC1 || this.themeManager.getCustomColor2() != currentC2) {
            this.themeManager.setCustomColor1(currentC1);
            this.themeManager.setCustomColor2(currentC2);
            this.themeManager.updateCustomTheme();
        }
        float circleRadius = 7.0f;
        float circleDiameter = circleRadius * 2.0f;
        float circleGap = 6.0f;
        int totalThemes = this.themeManager.getTotalCount();
        float themesWidth = circleDiameter * (float)totalThemes + circleGap * (float)(totalThemes - 1);
        float panelPadding = 10.0f;
        float panelWidth = themesWidth + panelPadding * 2.0f;
        float panelHeight = 22.0f;
        float startX = this.x + (this.width - panelWidth) / 2.0f;
        float startY = this.y;
        this.height = panelHeight;
        int bgColor = this.themeManager.getWindowBackgroundColor();
        int headColor = this.themeManager.getHeaderColor();
        blur.render(ShapeProperties.create(matrix, startX, startY, panelWidth, panelHeight).round(11.0f).color(ColorAssist.reAlphaInt(bgColor, 180)).build());
        rectangle.render(ShapeProperties.create(matrix, startX, startY, panelWidth, panelHeight).round(11.0f).outlineColor(ColorAssist.reAlphaInt(-1, 10)).color(ColorAssist.reAlphaInt(bgColor, 220)).build());
        float currentX = startX + panelPadding;
        float circleY = startY + (panelHeight - circleDiameter) / 2.0f;
        for (int i = 0; i < totalThemes; ++i) {
            boolean dual;
            int c2;
            int c1;
            boolean selected = this.themeManager.getSelectedIndex() == i;
            boolean isCustom = i >= this.themeManager.getPresets().size();
            float drawDiameter = selected ? circleDiameter + 2.0f : circleDiameter;
            float drawRadius = drawDiameter / 2.0f;
            float drawX = currentX - (drawDiameter - circleDiameter) / 2.0f;
            float drawY = circleY - (drawDiameter - circleDiameter) / 2.0f;
            if (isCustom) {
                c1 = this.themeManager.getCustomColor1();
                c2 = this.themeManager.getCustomColor2();
                dual = this.themeManager.isCustomDualColor();
            } else {
                ClientTheme theme = this.themeManager.getPresets().get(i);
                c1 = theme.getColor1();
                c2 = theme.getColor2();
                dual = theme.isDualColor();
            }
            if (dual) {
                rectangle.render(ShapeProperties.create(matrix, drawX, drawY, drawDiameter, drawDiameter).round(drawRadius).color(c1, c2, c2, c1).build());
            } else {
                rectangle.render(ShapeProperties.create(matrix, drawX, drawY, drawDiameter, drawDiameter).round(drawRadius).color(c1).build());
            }
            rectangle.render(ShapeProperties.create(matrix, drawX, drawY, drawDiameter, drawDiameter).round(drawRadius).thickness(1.0f).softness(0.0f).outlineColor(ColorAssist.reAlphaInt(-1, 15)).color(0).build());
            if (Calculate.isHovered(mouseX, mouseY, drawX, drawY, drawDiameter, drawDiameter)) {
                rectangle.render(ShapeProperties.create(matrix, drawX, drawY, drawDiameter, drawDiameter).round(drawRadius).color(ColorAssist.reAlphaInt(-1, 30)).build());
            }
            if (isCustom) {
                Fonts.getSize(12, Fonts.Type.BOLD).drawString(matrix, "+", drawX + (drawDiameter - Fonts.getSize(12, Fonts.Type.BOLD).getStringWidth("+")) / 2.0f, drawY + (float)(selected ? 5 : 4), ColorAssist.reAlphaInt(-1, 200));
            }
            currentX += circleDiameter + circleGap;
        }
        if (this.themeManager.isCustomSelected()) {
            float settingsW = 145.0f;
            float settingsH = 22.0f;
            float settingsX = startX + panelWidth / 2.0f - settingsW / 2.0f;
            float settingsY = startY - settingsH - 8.0f;
            blur.render(ShapeProperties.create(matrix, settingsX, settingsY, settingsW, settingsH).round(11.0f).color(ColorAssist.reAlphaInt(bgColor, 150)).build());
            rectangle.render(ShapeProperties.create(matrix, settingsX, settingsY, settingsW, settingsH).round(11.0f).outlineColor(ColorAssist.reAlphaInt(-1, 20)).color(ColorAssist.reAlphaInt(bgColor, 250)).build());
            float selectorW = 96.0f;
            float selectorH = 14.0f;
            float selectorX = settingsX + 8.0f;
            float selectorY = settingsY + (settingsH - selectorH) / 2.0f;
            rectangle.render(ShapeProperties.create(matrix, selectorX, selectorY, selectorW, selectorH).round(3.0f).thickness(1.5f).outlineColor(ColorAssist.reAlphaInt(headColor, 155)).color(ColorAssist.reAlphaInt(bgColor, 180)).build());
            float selectionW = (selectorW - 4.0f) / 2.0f;
            float selectionX = this.themeManager.isCustomDualColor() ? selectorX + selectionW + 2.0f : selectorX + 2.0f;
            rectangle.render(ShapeProperties.create(matrix, selectionX, selectorY + 2.0f, selectionW, selectorH - 4.0f).round(3.0f).color(ColorAssist.reAlphaInt(headColor, 255)).build());
            int selectedColor = this.themeManager.getTextColor();
            int unselectedColor = this.themeManager.getInactiveTextColor();
            float label1X = selectorX + 2.0f + (selectionW - Fonts.getSize(14, Fonts.Type.BOLD).getStringWidth("Static")) / 2.0f;
            float label2X = selectorX + selectionW + 2.0f + (selectionW - Fonts.getSize(14, Fonts.Type.BOLD).getStringWidth("Grad")) / 2.0f;
            Fonts.getSize(14, Fonts.Type.BOLD).drawString(matrix, "Static", label1X, selectorY + 7.0f, this.themeManager.isCustomDualColor() ? unselectedColor : selectedColor);
            Fonts.getSize(14, Fonts.Type.BOLD).drawString(matrix, "Grad", label2X, selectorY + 7.0f, this.themeManager.isCustomDualColor() ? selectedColor : unselectedColor);
            float pickerSize = 14.0f;
            float picker1X = settingsX + settingsW - (float)(this.themeManager.isCustomDualColor() ? 38 : 20);
            float pickerY = settingsY + (settingsH - pickerSize) / 2.0f;
            rectangle.render(ShapeProperties.create(matrix, picker1X, pickerY, pickerSize, pickerSize).round(7.0f).color(this.themeManager.getCustomColor1()).build());
            rectangle.render(ShapeProperties.create(matrix, picker1X, pickerY, pickerSize, pickerSize).round(7.0f).thickness(1.0f).softness(0.0f).outlineColor(ColorAssist.reAlphaInt(-1, 100)).color(0).build());
            if (this.themeManager.isCustomDualColor()) {
                float picker2X = picker1X + pickerSize + 4.0f;
                rectangle.render(ShapeProperties.create(matrix, picker2X, pickerY, pickerSize, pickerSize).round(7.0f).color(this.themeManager.getCustomColor2()).build());
                rectangle.render(ShapeProperties.create(matrix, picker2X, pickerY, pickerSize, pickerSize).round(7.0f).thickness(1.0f).softness(0.0f).outlineColor(ColorAssist.reAlphaInt(-1, 100)).color(0).build());
            }
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        float settingsH;
        float settingsY;
        float settingsW;
        float settingsX;
        if (button != 0) {
            return false;
        }
        float circleRadius = 7.0f;
        float circleDiameter = circleRadius * 2.0f;
        float circleGap = 6.0f;
        int totalThemes = this.themeManager.getTotalCount();
        float themesWidth = circleDiameter * (float)totalThemes + circleGap * (float)(totalThemes - 1);
        float panelPadding = 10.0f;
        float panelWidth = themesWidth + panelPadding * 2.0f;
        float startX = this.x + (this.width - panelWidth) / 2.0f;
        float circleY = this.y + (22.0f - circleDiameter) / 2.0f;
        float currentX = startX + panelPadding;
        for (int i = 0; i < totalThemes; ++i) {
            float drawDim;
            boolean selected = this.themeManager.getSelectedIndex() == i;
            float f = drawDim = selected ? circleDiameter + 4.0f : circleDiameter + 2.0f;
            if (Calculate.isHovered(mouseX, mouseY, currentX - 2.0f, circleY - 2.0f, drawDim, drawDim)) {
                this.themeManager.setSelectedIndex(i);
                return true;
            }
            currentX += circleDiameter + circleGap;
        }
        if (this.themeManager.isCustomSelected() && Calculate.isHovered(mouseX, mouseY, settingsX = startX + panelWidth / 2.0f - (settingsW = 145.0f) / 2.0f, settingsY = this.y - (settingsH = 22.0f) - 8.0f, settingsW, settingsH)) {
            float picker2X;
            float pickerY;
            float selectorX = settingsX + 8.0f;
            float selectorY = settingsY + (settingsH - 14.0f) / 2.0f;
            float selectorW = 96.0f;
            if (Calculate.isHovered(mouseX, mouseY, selectorX, selectorY, selectorW, 14.0)) {
                this.themeManager.setCustomDualColor(!this.themeManager.isCustomDualColor());
                return true;
            }
            float pickerSize = 14.0f;
            float picker1X = settingsX + settingsW - (float)(this.themeManager.isCustomDualColor() ? 38 : 20);
            if (Calculate.isHovered(mouseX, mouseY, picker1X, pickerY = settingsY + (settingsH - pickerSize) / 2.0f, pickerSize, pickerSize)) {
                this.openColorPicker(this.customColor1Setting, mouseX, mouseY);
                return true;
            }
            if (this.themeManager.isCustomDualColor() && Calculate.isHovered(mouseX, mouseY, picker2X = picker1X + pickerSize + 4.0f, pickerY, pickerSize, pickerSize)) {
                this.openColorPicker(this.customColor2Setting, mouseX, mouseY);
                return true;
            }
            return true;
        }
        return false;
    }

    private void openColorPicker(ColorSetting setting, double mouseX, double mouseY) {
        windowManager.getWindows().removeIf(w -> w instanceof ColorWindow);
        AbstractWindow colorWindow = new ColorWindow(setting).position((int)(mouseX - 50.0), (int)(mouseY + 20.0)).size(100.0f, 155.0f).draggable(true);
        windowManager.add(colorWindow);
    }
}

