/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.originalitems;

import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.AutoBuyableItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list.DonatorProvider;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list.MiscProvider;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list.PotionProvider;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list.SphereProvider;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list.TalismanProvider;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.settings.AutoBuySettingsManager;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.util.krushprovider.KrushProvider;
import java.util.ArrayList;
import java.util.List;

public class ItemRegistry {
    private static List<AutoBuyableItem> allItems = null;
    private static boolean settingsLoaded = false;

    public static void ensureSettingsLoaded() {
        if (!settingsLoaded) {
            settingsLoaded = true;
        }
    }

    public static List<AutoBuyableItem> getAllItems() {
        if (allItems == null) {
            allItems = new ArrayList<AutoBuyableItem>();
            allItems.addAll(ItemRegistry.getKrush());
            allItems.addAll(ItemRegistry.getTalismans());
            allItems.addAll(ItemRegistry.getSpheres());
            allItems.addAll(ItemRegistry.getMisc());
            allItems.addAll(ItemRegistry.getDonator());
            allItems.addAll(ItemRegistry.getPotions());
            for (AutoBuyableItem item : allItems) {
                AutoBuySettingsManager.getInstance().loadSettings(item.getDisplayName(), item.getSettings());
            }
        }
        return allItems;
    }

    public static void reloadSettings() {
        if (allItems != null) {
            for (AutoBuyableItem item : allItems) {
                AutoBuySettingsManager.getInstance().loadSettings(item.getDisplayName(), item.getSettings());
            }
        }
    }

    public static List<AutoBuyableItem> getKrush() {
        return KrushProvider.getKrush();
    }

    public static List<AutoBuyableItem> getTalismans() {
        return TalismanProvider.getTalismans();
    }

    public static List<AutoBuyableItem> getSpheres() {
        return SphereProvider.getSpheres();
    }

    public static List<AutoBuyableItem> getMisc() {
        return MiscProvider.getMisc();
    }

    public static List<AutoBuyableItem> getDonator() {
        return DonatorProvider.getDonator();
    }

    public static List<AutoBuyableItem> getPotions() {
        return PotionProvider.getPotions();
    }
}

