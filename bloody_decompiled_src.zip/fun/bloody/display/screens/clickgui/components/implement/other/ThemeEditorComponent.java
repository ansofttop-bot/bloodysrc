/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.other;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.components.implement.window.AbstractWindow;
import fun.bloody.display.screens.clickgui.components.implement.window.implement.settings.color.ColorWindow;
import fun.bloody.display.screens.clickgui.theme.ClientTheme;
import fun.bloody.display.screens.clickgui.theme.ThemeManager;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class ThemeEditorComponent
extends AbstractComponent {
    private final ThemeManager themeManager = ThemeManager.getInstance();
    private String themeName = "";
    private final List<EditorEntry> entries = new ArrayList<EditorEntry>();
    private int themePage = 0;
    private final float maxScroll;
    private boolean inputFocused = false;

    public ThemeEditorComponent() {
        this.width = 121.0f;
        this.height = 288.0f;
        this.entries.add(new EditorEntry("\u0410\u043a\u0446\u0435\u043d\u0442", this.themeManager.getPrimarySetting()));
        this.entries.add(new EditorEntry("\u0422\u0435\u043a\u0441\u0442", this.themeManager.getTextSetting()));
        this.entries.add(new EditorEntry("\u0422\u0435\u043a\u0441\u0442 (\u0442\u0443\u0441\u043a\u043b\u044b\u0439)", this.themeManager.getInactiveTextSetting()));
        this.entries.add(new EditorEntry("\u0417\u0430\u0433\u043e\u043b\u043e\u0432\u043a\u0438", this.themeManager.getHeaderSetting()));
        this.entries.add(new EditorEntry("\u0422\u0435\u043a\u0441\u0442 \u0437\u0430\u0433\u043e\u043b\u043e\u0432\u043a\u043e\u0432", this.themeManager.getHeaderTextSetting()));
        this.entries.add(new EditorEntry("\u0424\u043e\u043d \u043e\u043a\u043e\u043d", this.themeManager.getWindowBackgroundSetting()));
        this.entries.add(new EditorEntry("\u0418\u043a\u043e\u043d\u043a\u0438", this.themeManager.getIconColorSetting()));
        this.entries.add(new EditorEntry("\u0410\u043a\u0442\u0438\u0432\u043d\u044b\u0435 \u044d\u043b.", this.themeManager.getActiveSetting()));
        float entryHeight = 16.2f;
        float totalEntriesHeight = (float)this.entries.size() * entryHeight;
        float visibleHeight = 175.0f;
        this.maxScroll = Math.max(0.0f, totalEntriesHeight - visibleHeight + 10.0f);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (this.inputFocused && this.themeName.length() < 16) {
            this.themeName = this.themeName + codePoint;
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.inputFocused) {
            if (keyCode == 259 && !this.themeName.isEmpty()) {
                this.themeName = this.themeName.substring(0, this.themeName.length() - 1);
                return true;
            }
            if (keyCode == 257) {
                this.inputFocused = false;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (Calculate.isHovered(mouseX, mouseY, this.x, this.y + 28.0f, this.width, 180.0)) {
            this.scroll = class_3532.method_15350((double)(this.scroll + amount * 15.0), (double)(-this.maxScroll), (double)0.0);
            return true;
        }
        return false;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        int inputOutline;
        String pageTitle;
        int localStartIdx;
        List<ClientTheme> currentList;
        if (!this.themeManager.isEditorOpen()) {
            return;
        }
        class_4587 matrix = context.method_51448();
        int bgColor = this.themeManager.getWindowBackgroundColor();
        blur.render(ShapeProperties.create(matrix, this.x, this.y, this.width, this.height).round(5.0f).color(ColorAssist.reAlphaInt(bgColor, 200)).build());
        rectangle.render(ShapeProperties.create(matrix, this.x, this.y, this.width, this.height).round(5.0f).outlineColor(0).color(ColorAssist.reAlphaInt(bgColor, 145), ColorAssist.reAlphaInt(bgColor, 255), ColorAssist.reAlphaInt(bgColor, 145), ColorAssist.reAlphaInt(bgColor, 255)).build());
        float headerHeight = 28.0f;
        int headColor = this.themeManager.getHeaderColor();
        rectangle.render(ShapeProperties.create(matrix, this.x, this.y, this.width, headerHeight).round(5.0f).outlineColor(0).color(ColorAssist.reAlphaInt(headColor, 200), ColorAssist.reAlphaInt(headColor, 255), ColorAssist.reAlphaInt(headColor, 200), ColorAssist.reAlphaInt(headColor, 255)).build());
        String title = "Theme Editor";
        Fonts.getSize(18, Fonts.Type.DEFAULT).drawString(matrix, title, this.x + 7.0f, this.y + 10.5f, -1);
        String icon = "I";
        float iconW = Fonts.getSize(24, Fonts.Type.ICONSCATEGORY).getStringWidth(icon);
        Fonts.getSize(24, Fonts.Type.ICONSCATEGORY).drawString(matrix, icon, this.x + this.width - iconW - 10.0f, this.y + 10.5f, -1);
        float listY = this.y + headerHeight + 2.0f;
        float listHeight = 175.0f;
        boolean isLocked = this.themeManager.getSelectedIndex() < this.themeManager.getPresets().size();
        ColorSetting activeSetting = null;
        for (AbstractWindow window : windowManager.getWindows()) {
            if (!(window instanceof ColorWindow)) continue;
            activeSetting = ((ColorWindow)window).getSetting();
            break;
        }
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        scissor.push(matrix.method_23760().method_23761(), (int)this.x, (int)listY, (int)this.width, (int)listHeight);
        float currentY = listY + (float)this.scroll + 2.0f;
        float entryHeight = 16.2f;
        for (EditorEntry entry : this.entries) {
            int textColor = isLocked ? new Color(150, 150, 150, 150).getRGB() : -1;
            Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(matrix, entry.name, this.x + 10.0f, currentY + 3.5f, textColor);
            boolean isActive = activeSetting == entry.setting;
            float dotSize = isActive ? 12.0f : 9.0f;
            float dotX = this.x + this.width - 10.0f - dotSize;
            float dotY = currentY + (entryHeight - dotSize) / 2.0f;
            int dotColor = isLocked ? new Color(entry.setting.getColor()).darker().getRGB() : entry.setting.getColor();
            rectangle.render(ShapeProperties.create(matrix, dotX, dotY, dotSize, dotSize).round(dotSize / 2.0f).color(dotColor).build());
            currentY += entryHeight;
        }
        scissor.pop();
        float circlesAreaY = this.y + this.height - 75.0f;
        int perPage = 6;
        int standardPages = (int)Math.ceil((double)this.themeManager.getPresets().size() / (double)perPage);
        if (this.themePage < standardPages) {
            currentList = this.themeManager.getPresets();
            localStartIdx = this.themePage * perPage;
            pageTitle = "\u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u044b\u0435";
        } else {
            currentList = this.themeManager.getUserThemes();
            localStartIdx = (this.themePage - standardPages) * perPage;
            pageTitle = "\u041c\u043e\u0438 \u0442\u0435\u043c\u044b";
        }
        boolean canLeft = this.themePage > 0;
        int totalUserPages = (int)Math.ceil((double)this.themeManager.getUserThemes().size() / (double)perPage);
        boolean canRight = this.themePage < standardPages - 1 || this.themePage == standardPages - 1 && !this.themeManager.getUserThemes().isEmpty() || this.themePage >= standardPages && this.themePage - standardPages < totalUserPages - 1;
        float arrowY = circlesAreaY + 15.5f;
        float arrowRW = Fonts.getSize(18, Fonts.Type.BOLD).getStringWidth(">");
        Fonts.getSize(18, Fonts.Type.BOLD).drawString(matrix, "<", this.x + 7.0f, arrowY, canLeft ? -1 : new Color(255, 255, 255, 50).getRGB());
        Fonts.getSize(18, Fonts.Type.BOLD).drawString(matrix, ">", this.x + this.width - 7.0f - arrowRW, arrowY, canRight ? -1 : new Color(255, 255, 255, 50).getRGB());
        Fonts.getSize(11, Fonts.Type.DEFAULT).drawString(matrix, pageTitle, this.x + (this.width - Fonts.getSize(11, Fonts.Type.DEFAULT).getStringWidth(pageTitle)) / 2.0f, circlesAreaY - 4.0f, new Color(200, 200, 200).getRGB());
        float defaultRadius = 5.5f;
        float selectedRadius = 7.0f;
        float circleGap = 3.5f;
        int endIdx = Math.min(localStartIdx + perPage, currentList.size());
        int count = endIdx - localStartIdx;
        if (count > 0) {
            float spacingDiameter = defaultRadius * 2.0f;
            float totalW = spacingDiameter * (float)count + circleGap * (float)(count - 1);
            float startCirclesX = this.x + (this.width - totalW) / 2.0f;
            float circlesY_Base = circlesAreaY + 13.0f;
            float curX = startCirclesX;
            for (int i = localStartIdx; i < endIdx; ++i) {
                int c1 = currentList.get(i).getColor1();
                int globalIdx = this.themePage < standardPages ? i : this.themeManager.getPresets().size() + i;
                boolean isSelected = this.themeManager.getSelectedIndex() == globalIdx;
                float radius = isSelected ? selectedRadius : defaultRadius;
                float diameter = radius * 2.0f;
                float drawX = curX - (radius - defaultRadius);
                float drawY = circlesY_Base - (radius - defaultRadius);
                rectangle.render(ShapeProperties.create(matrix, drawX, drawY, diameter, diameter).round(radius).color(c1).build());
                curX += spacingDiameter + circleGap;
            }
        } else if (this.themePage >= standardPages) {
            String emptyMsg = "\u0422\u0435\u043c \u043d\u0435\u0442 :(";
            Fonts.getSize(10, Fonts.Type.DEFAULT).drawString(matrix, emptyMsg, this.x + (this.width - Fonts.getSize(10, Fonts.Type.DEFAULT).getStringWidth(emptyMsg)) / 2.0f, circlesAreaY + 13.0f, new Color(150, 150, 150).getRGB());
        }
        float inputAreaY = circlesAreaY + 34.0f;
        float inputX = this.x + 10.0f;
        float inputW = this.width - 20.0f;
        float inputH = 19.0f;
        int n = inputOutline = this.inputFocused ? new Color(50, 200, 120, 200).getRGB() : new Color(255, 255, 255, 40).getRGB();
        if (this.inputFocused) {
            rectangle.render(ShapeProperties.create(matrix, inputX - 1.5f, inputAreaY - 1.5f, inputW + 3.0f, inputH + 3.0f).round(6.0f).softness(1.2f).color(new Color(50, 200, 120, 60).getRGB()).build());
        }
        rectangle.render(ShapeProperties.create(matrix, inputX, inputAreaY, inputW, inputH).round(4.0f).outlineColor(inputOutline).color(new Color(15, 16, 20, 230).getRGB()).build());
        Fonts.getSize(15, Fonts.Type.DEFAULT).drawString(matrix, (String)(this.themeName.isEmpty() && !this.inputFocused ? "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435" : this.themeName + (this.inputFocused && System.currentTimeMillis() % 1000L < 500L ? "|" : "")), inputX + 6.0f, inputAreaY + 5.5f, new Color(230, 230, 230).getRGB());
        float btnY = inputAreaY + 23.0f;
        float btnH = 18.0f;
        boolean btnHovered = Calculate.isHovered(mouseX, mouseY, inputX, btnY, inputW, btnH);
        int btnColor = btnHovered ? new Color(40, 100, 60, 220).getRGB() : new Color(30, 80, 50, 200).getRGB();
        rectangle.render(ShapeProperties.create(matrix, inputX, btnY, inputW, btnH).round(5.0f).outlineColor(new Color(255, 255, 255, 20).getRGB()).color(btnColor).build());
        float textW = Fonts.getSize(15, Fonts.Type.BOLD).getStringWidth("\u0421\u043e\u0437\u0434\u0430\u0442\u044c \u0442\u0435\u043c\u0443");
        Fonts.getSize(15, Fonts.Type.BOLD).drawString(matrix, "\u0421\u043e\u0437\u0434\u0430\u0442\u044c \u0442\u0435\u043c\u0443", inputX + (inputW - textW) / 2.0f, btnY + 4.5f, -1);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        float inputW;
        float inputAreaY;
        float inputX;
        List<ClientTheme> currentList;
        boolean canRight;
        if (!this.themeManager.isEditorOpen()) {
            return false;
        }
        if (button != 0) {
            return false;
        }
        if (!Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, this.height)) {
            this.inputFocused = false;
            return false;
        }
        float listY = this.y + 28.0f + 2.0f;
        float listHeight = 175.0f;
        if (Calculate.isHovered(mouseX, mouseY, this.x, listY, this.width, listHeight)) {
            if (this.themeManager.getSelectedIndex() < this.themeManager.getPresets().size()) {
                return false;
            }
            float currentY = listY + (float)this.scroll + 2.0f;
            float entryHeight = 16.2f;
            for (EditorEntry entry : this.entries) {
                if (Calculate.isHovered(mouseX, mouseY, this.x, currentY, this.width, entryHeight)) {
                    AbstractWindow existingWindow = null;
                    for (AbstractWindow window : windowManager.getWindows()) {
                        if (!(window instanceof ColorWindow)) continue;
                        existingWindow = window;
                        break;
                    }
                    if (existingWindow != null) {
                        windowManager.delete(existingWindow);
                    } else {
                        AbstractWindow colorWindow = new ColorWindow(entry.setting).position((int)(mouseX - 110.0), (int)(mouseY - 20.0)).size(100.0f, 155.0f).draggable(true);
                        windowManager.add(colorWindow);
                    }
                    return true;
                }
                currentY += entryHeight;
            }
        }
        float circlesAreaY = this.y + this.height - 75.0f;
        int perPage = 6;
        int standardPages = (int)Math.ceil((double)this.themeManager.getPresets().size() / (double)perPage);
        int totalUserPages = (int)Math.ceil((double)this.themeManager.getUserThemes().size() / (double)perPage);
        boolean canLeft = this.themePage > 0;
        boolean bl = canRight = this.themePage < standardPages - 1 || this.themePage == standardPages - 1 && !this.themeManager.getUserThemes().isEmpty() || this.themePage >= standardPages && this.themePage - standardPages < totalUserPages - 1;
        if (Calculate.isHovered(mouseX, mouseY, this.x, circlesAreaY + 10.0f, 25.0, 25.0) && canLeft) {
            --this.themePage;
            return true;
        }
        if (Calculate.isHovered(mouseX, mouseY, this.x + this.width - 25.0f, circlesAreaY + 10.0f, 25.0, 25.0) && canRight) {
            ++this.themePage;
            return true;
        }
        int localStartIdx = this.themePage < standardPages ? this.themePage * perPage : (this.themePage - standardPages) * perPage;
        int endIdx = Math.min(localStartIdx + perPage, (currentList = this.themePage < standardPages ? this.themeManager.getPresets() : this.themeManager.getUserThemes()).size());
        int count = endIdx - localStartIdx;
        if (count > 0) {
            float defaultRadius = 5.5f;
            float spacingDiameter = defaultRadius * 2.0f;
            float circleGap = 3.5f;
            float totalW = spacingDiameter * (float)count + circleGap * (float)(count - 1);
            float startCirclesX = this.x + (this.width - totalW) / 2.0f;
            float circlesY = circlesAreaY + 13.0f;
            float curX = startCirclesX;
            for (int i = localStartIdx; i < endIdx; ++i) {
                if (Calculate.isHovered(mouseX, mouseY, curX, circlesY, spacingDiameter, spacingDiameter)) {
                    int globalIdx = this.themePage < standardPages ? i : this.themeManager.getPresets().size() + i;
                    this.themeManager.setSelectedIndex(globalIdx);
                    return true;
                }
                curX += spacingDiameter + circleGap;
            }
        }
        if (Calculate.isHovered(mouseX, mouseY, inputX = this.x + 10.0f, inputAreaY = circlesAreaY + 25.0f, inputW = this.width - 20.0f, 18.0)) {
            this.inputFocused = true;
            return true;
        }
        this.inputFocused = false;
        float btnY = inputAreaY + 22.0f;
        if (Calculate.isHovered(mouseX, mouseY, inputX, btnY, inputW, 22.0)) {
            if (!this.themeName.isEmpty()) {
                this.themeManager.getUserThemes().add(new ClientTheme(this.themeName, this.themeManager.getPrimaryColor()));
                this.themeName = "";
            }
            return true;
        }
        return true;
    }

    private static class EditorEntry {
        String name;
        ColorSetting setting;

        EditorEntry(String name, ColorSetting setting) {
            this.name = name;
            this.setting = setting;
        }
    }
}

