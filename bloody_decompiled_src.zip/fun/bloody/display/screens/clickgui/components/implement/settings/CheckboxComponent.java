/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_7833
 */
package fun.bloody.display.screens.clickgui.components.implement.settings;

import fun.bloody.Bloody;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.display.screens.clickgui.components.implement.other.CheckComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.display.screens.clickgui.theme.ThemeManager;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public class CheckboxComponent
extends AbstractSettingComponent {
    private final CheckComponent checkComponent = new CheckComponent();
    private final BooleanSetting setting;
    private float currentScroll = 0.0f;
    private float targetScroll = 0.0f;
    private boolean isHovered = false;
    private final Animation toggleAnimation = new Decelerate().setMs(250).setValue(1.0);

    public CheckboxComponent(BooleanSetting setting) {
        super(setting);
        this.setting = setting;
        this.toggleAnimation.setDirection(setting.isValue() ? Direction.FORWARDS : Direction.BACKWARDS);
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        this.height = 18.0f;
        ThemeManager themeManager = ThemeManager.getInstance();
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        int settingTextColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(0, 0, 0, 255).getRGB() : (clickGuiModule != null && clickGuiModule.isBlack() ? new Color(255, 255, 255, 255).getRGB() : themeManager.getTextColor());
        float checkboxWidth = 25.0f;
        float maxWidth = this.width - checkboxWidth - 5.0f;
        if (clickGuiModule != null) {
            settingTextColor = clickGuiModule.getTextColor();
        }
        String settingName = this.setting.getName();
        float textWidth = Fonts.getSize(14, Fonts.Type.DEFAULT).getStringWidth(settingName);
        boolean needsScroll = textWidth > maxWidth;
        boolean currentlyHovered = Calculate.isHovered(mouseX, mouseY, this.x + 5.0f, this.y + 5.0f, maxWidth, 14.0);
        if (currentlyHovered != this.isHovered) {
            this.isHovered = currentlyHovered;
        }
        if (needsScroll) {
            float maxScroll = textWidth - maxWidth;
            this.targetScroll = this.isHovered ? maxScroll : 0.0f;
            float lerpSpeed = 0.05f;
            this.currentScroll += (this.targetScroll - this.currentScroll) * lerpSpeed;
            if (Math.abs(this.targetScroll - this.currentScroll) < 0.1f) {
                this.currentScroll = this.targetScroll;
            }
        } else {
            this.currentScroll = 0.0f;
            this.targetScroll = 0.0f;
        }
        float scrollOffset = this.currentScroll;
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        scissor.push(context.method_51448().method_23760().method_23761(), this.x + 5.0f, this.y, maxWidth, this.height);
        Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(context.method_51448(), settingName, this.x + 5.0f - scrollOffset, this.y + 5.0f, settingTextColor);
        scissor.pop();
        this.toggleAnimation.setDirection(this.setting.isValue() ? Direction.FORWARDS : Direction.BACKWARDS);
        float animProgress = this.toggleAnimation.getOutput().floatValue();
        float boxSize = 12.0f;
        float boxX = this.x + this.width - 19.0f;
        float boxY = this.y + 1.0f;
        int boxBgOff = new Color(82, 84, 157, 31).getRGB();
        int boxBgOn = new Color(70, 100, 200, 180).getRGB();
        if (clickGuiModule != null) {
            boxBgOff = clickGuiModule.getControlOffColor();
            boxBgOn = clickGuiModule.getControlOnColor();
        }
        int r1 = boxBgOff >> 16 & 0xFF;
        int g1 = boxBgOff >> 8 & 0xFF;
        int b1 = boxBgOff & 0xFF;
        int a1 = boxBgOff >> 24 & 0xFF;
        int r2 = boxBgOn >> 16 & 0xFF;
        int g2 = boxBgOn >> 8 & 0xFF;
        int b2 = boxBgOn & 0xFF;
        int a2 = boxBgOn >> 24 & 0xFF;
        int r = (int)((float)r1 + (float)(r2 - r1) * animProgress);
        int g = (int)((float)g1 + (float)(g2 - g1) * animProgress);
        int b = (int)((float)b1 + (float)(b2 - b1) * animProgress);
        int a = (int)((float)a1 + (float)(a2 - a1) * animProgress);
        int boxBg = a << 24 | r << 16 | g << 8 | b;
        rectangle.render(ShapeProperties.create(context.method_51448(), boxX, boxY, boxSize, boxSize).round(3.0f, 1.0f, 1.0f, 3.0f).color(boxBg).build());
        if (animProgress > 0.01f) {
            int checkColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(0, 0, 0, (int)(255.0f * animProgress)).getRGB() : (clickGuiModule != null && clickGuiModule.isBlack() ? new Color(255, 255, 255, (int)(255.0f * animProgress)).getRGB() : new Color(255, 255, 255, (int)(255.0f * animProgress)).getRGB());
            if (clickGuiModule != null) {
                checkColor = clickGuiModule.getCheckColor((int)(255.0f * animProgress));
            }
            int iconSize = 22;
            float iconWidth = Fonts.getSize(iconSize, Fonts.Type.DIVINE).getStringWidth("j");
            float iconHeight = 9.0f;
            float iconX = boxX + (boxSize - iconWidth) / 2.0f;
            float iconY = boxY + (boxSize - iconHeight) / 2.0f + 1.0f;
            class_4587 matrices = context.method_51448();
            matrices.method_22903();
            float centerX = iconX + iconWidth / 2.0f;
            float centerY = iconY + iconHeight / 2.0f;
            matrices.method_46416(centerX, centerY, 0.0f);
            matrices.method_22907(class_7833.field_40718.rotationDegrees(-15.0f));
            matrices.method_46416(-centerX, -centerY, 0.0f);
            Fonts.getSize(iconSize, Fonts.Type.DIVINE).drawString(matrices, "j", iconX, iconY, checkColor);
            matrices.method_22909();
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        float boxX = this.x + this.width - 19.0f;
        float boxY = this.y + 1.0f;
        float boxSize = 12.0f;
        if (Calculate.isHovered(mouseX, mouseY, boxX, boxY, boxSize, boxSize) && button == 0) {
            this.setting.setValue(!this.setting.isValue());
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}

