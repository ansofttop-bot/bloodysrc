/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.settings.multiselect;

import fun.bloody.Bloody;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class MultiSelectedButton
extends AbstractComponent {
    private final MultiSelectSetting setting;
    private final String text;
    private float alpha;
    private final Animation alphaAnimation = new Decelerate().setMs(300).setValue(0.5);

    public MultiSelectedButton(MultiSelectSetting setting, String text) {
        this.setting = setting;
        this.text = text;
        this.alphaAnimation.setDirection(Direction.BACKWARDS);
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        class_4587 matrix = context.method_51448();
        this.alphaAnimation.setDirection(this.setting.getSelected().contains(this.text) ? Direction.FORWARDS : Direction.BACKWARDS);
        float opacity = this.alphaAnimation.getOutput().floatValue();
        int adjustedAlpha = (int)Calculate.clamp(opacity * this.alpha * 255.0f, 0.0f, 255.0f);
        int selectedOpacity = new Color(48, 48, 51, adjustedAlpha).getRGB();
        if (!this.alphaAnimation.isFinished(Direction.BACKWARDS)) {
            rectangle.render(ShapeProperties.create(context.method_51448(), this.x + 1.5f, this.y + 1.5f, this.width - 3.0f, this.height - 3.0f).round(3.0f).color(new Color(58, 58, 60, adjustedAlpha).getRGB(), new Color(58, 58, 60, adjustedAlpha).getRGB(), new Color(58, 58, 60, 0).getRGB(), new Color(58, 58, 60, 0).getRGB()).build());
        }
        float maxTextWidth = this.width - 8.0f;
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        scissor.push(matrix.method_23760().method_23761(), this.x + 2.0f, this.y, maxTextWidth + 4.0f, this.height);
        Fonts.getSize(14, Fonts.Type.BOLD).drawStringWithScroll(matrix, this.text, this.x + 4.0f, this.y + 7.0f, maxTextWidth, ColorAssist.multAlpha(new Color(225, 225, 225, 225).getRGB(), Calculate.clamp(this.alpha, 0.0f, 1.0f)));
        scissor.pop();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, this.height) && button == 0) {
            ArrayList<String> selected = new ArrayList<String>(this.setting.getSelected());
            if (selected.contains(this.text)) {
                selected.remove(this.text);
            } else {
                selected.add(this.text);
                this.sortSelectedAccordingToList(selected, this.setting.getList());
            }
            this.setting.setSelected(selected);
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void sortSelectedAccordingToList(List<String> selected, List<String> list) {
        selected.sort(Comparator.comparingInt(list::indexOf));
    }

    public MultiSelectedButton setAlpha(float alpha) {
        this.alpha = alpha;
        return this;
    }
}

