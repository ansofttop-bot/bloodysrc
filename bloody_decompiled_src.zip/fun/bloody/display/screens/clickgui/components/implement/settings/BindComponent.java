/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.settings;

import fun.bloody.Bloody;
import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.utils.client.chat.StringHelper;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class BindComponent
extends AbstractSettingComponent {
    private final BindSetting setting;
    private boolean binding;
    private float currentScroll = 0.0f;
    private float targetScroll = 0.0f;
    private boolean isHovered = false;

    public BindComponent(BindSetting setting) {
        super(setting);
        this.setting = setting;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        int bindingColor;
        class_4587 matrix = context.method_51448();
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        String bindName = StringHelper.getBindName(this.setting.getKey());
        String name = this.binding ? "..." : bindName;
        float stringWidth = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth(name);
        this.height = 12.0f;
        float buttonWidth = stringWidth + 4.0f;
        float buttonHeight = 12.0f;
        float buttonX = this.x + this.width - buttonWidth - 5.0f;
        float buttonY = this.y + 2.0f;
        Color bgColor = new Color(82, 84, 157, 31);
        boolean isButtonHovered = Calculate.isHovered(mouseX, mouseY, buttonX, buttonY, buttonWidth, buttonHeight);
        if (clickGuiModule != null) {
            bgColor = new Color(clickGuiModule.getControlOffColor(), true);
        }
        rectangle.render(ShapeProperties.create(matrix, buttonX, buttonY, buttonWidth, buttonHeight).round(3.0f, 1.0f, 1.0f, 3.0f).thickness(1.0f).outlineColor(clickGuiModule != null ? clickGuiModule.getControlOutlineColor(isButtonHovered) : (isButtonHovered ? new Color(255, 255, 255, 200).getRGB() : new Color(55, 55, 55, 150).getRGB())).color(bgColor.getRGB()).build());
        float textX = buttonX + (buttonWidth - stringWidth) / 2.0f;
        float textY = buttonY + (buttonHeight - 9.0f) / 2.0f + 2.0f;
        int n = bindingColor = this.binding ? -1 : -2828575;
        if (clickGuiModule != null) {
            bindingColor = this.binding ? clickGuiModule.getTextColor() : clickGuiModule.getInactiveTextColor();
        }
        Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(matrix, name, textX, textY, bindingColor);
        float maxWidth = this.width - buttonWidth - 15.0f;
        String settingName = this.setting.getName();
        float textWidth = Fonts.getSize(14, Fonts.Type.DEFAULT).getStringWidth(settingName);
        boolean needsScroll = textWidth > maxWidth;
        boolean currentlyHovered = Calculate.isHovered(mouseX, mouseY, this.x + 5.0f, this.y, maxWidth, 14.0);
        if (currentlyHovered != this.isHovered) {
            this.isHovered = currentlyHovered;
        }
        if (needsScroll) {
            float maxScroll = textWidth - maxWidth + 10.0f;
            this.targetScroll = this.isHovered ? maxScroll : 0.0f;
            float lerpSpeed = 0.05f;
            this.currentScroll += (this.targetScroll - this.currentScroll) * lerpSpeed;
            if (Math.abs(this.targetScroll - this.currentScroll) < 0.1f) {
                this.currentScroll = this.targetScroll;
            }
        } else {
            this.currentScroll = 0.0f;
            this.targetScroll = 0.0f;
        }
        float scrollOffset = this.currentScroll;
        clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        int nameColor = clickGuiModule != null && clickGuiModule.isWhite() ? new Color(0, 0, 0, 255).getRGB() : -2828575;
        if (clickGuiModule != null) {
            nameColor = clickGuiModule.getTextColor();
        }
        ScissorAssist scissor = Bloody.getInstance().getScissorManager();
        scissor.push(context.method_51448().method_23760().method_23761(), this.x + 5.0f, this.y, maxWidth, 14.0f);
        Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(context.method_51448(), settingName, this.x + 5.0f - scrollOffset, this.y + 5.0f, nameColor);
        scissor.pop();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        String bindName = StringHelper.getBindName(this.setting.getKey());
        String name = this.binding ? "..." : bindName;
        float stringWidth = Fonts.getSize(13, Fonts.Type.DEFAULT).getStringWidth(name);
        float buttonWidth = stringWidth + 4.0f;
        float buttonHeight = 12.0f;
        float buttonX = this.x + this.width - buttonWidth - 5.0f;
        float buttonY = this.y + 2.0f;
        if (button == 0) {
            if (Calculate.isHovered(mouseX, mouseY, buttonX, buttonY, buttonWidth, buttonHeight)) {
                this.binding = !this.binding;
                return true;
            }
            this.binding = false;
        }
        if (this.binding && button > 1) {
            this.setting.setKey(button);
            this.binding = false;
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.binding) {
            if (keyCode == 256 || keyCode == 261) {
                this.setting.setKey(-1);
            } else {
                this.setting.setKey(keyCode);
            }
            this.binding = false;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}

