/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1802
 *  net.minecraft.class_1844
 *  net.minecraft.class_2561
 *  net.minecraft.class_5250
 */
package fun.bloody.display.screens.clickgui.components.implement.autobuy.items.list;

import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.AutoBuyableItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.customitem.CustomItem;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.items.defaultsetpricec.Defaultpricec;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class PotionProvider {
    public static List<AutoBuyableItem> getPotions() {
        ArrayList<AutoBuyableItem> potions = new ArrayList<AutoBuyableItem>();
        List<class_5250> mochaFlashLore = List.of(class_2561.method_43470((String)"\u0418\u0441\u043f\u0435\u0439 \u0441\u043e\u043a \u0424\u043b\u0435\u0448\u0430,"), class_2561.method_43470((String)"\u0434\u0430\u0431\u044b \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u044c \u0435\u0433\u043e"), class_2561.method_43470((String)"\u0441\u0438\u043b\u0443 \u0438 \u0441\u043a\u043e\u0440\u043e\u0441\u0442\u044c"));
        potions.add(new CustomItem("[\u2605] \u041c\u043e\u0447\u0430 \u0424\u043b\u0435\u0448\u0430", null, class_1802.field_8436, Defaultpricec.getPrice("\u041c\u043e\u0447\u0430 \u0424\u043b\u0435\u0448\u0430"), new class_1844(Optional.empty(), Optional.of(6092799), List.of(), Optional.empty()), mochaFlashLore));
        List<class_5250> medicLore = List.of(class_2561.method_43470((String)"\u042d\u043b\u0438\u043a\u0441\u0438\u0440 \u043e\u0442 \u041c\u0435\u0434\u0438\u043a\u0430"), class_2561.method_43470((String)"\u043f\u043e\u043c\u043e\u0433\u0430\u0435\u0442 \u0432\u044b\u0441\u0442\u043e\u044f\u0442\u044c"), class_2561.method_43470((String)"\u0434\u0430\u0436\u0435 \u0432 \u0441\u043c\u0435\u0440\u0442\u0435\u043b\u044c\u043d\u043e\u043c \u0431\u043e\u044e"));
        potions.add(new CustomItem("[\u2605] \u0417\u0435\u043b\u044c\u0435 \u041c\u0435\u0434\u0438\u043a\u0430", null, class_1802.field_8436, Defaultpricec.getPrice("\u0417\u0435\u043b\u044c\u0435 \u041c\u0435\u0434\u0438\u043a\u0430"), new class_1844(Optional.empty(), Optional.of(16711902), List.of(), Optional.empty()), medicLore));
        List<class_5250> agentLore = List.of(class_2561.method_43470((String)"\u041b\u043e\u0432\u043a\u043e\u0441\u0442\u044c \u0438 \u0441\u043a\u0440\u044b\u0442\u043e\u0441\u0442\u044c"), class_2561.method_43470((String)"\u0442\u0430\u0439\u043d\u044b\u0445 \u0410\u0433\u0435\u043d\u0442\u043e\u0432"), class_2561.method_43470((String)"\u0442\u0430\u044f\u0442\u0441\u044f \u0432 \u044d\u0442\u043e\u043c \u043d\u0430\u043f\u0438\u0442\u043a\u0435"));
        potions.add(new CustomItem("[\u2605] \u0417\u0435\u043b\u044c\u0435 \u0410\u0433\u0435\u043d\u0442\u0430", null, class_1802.field_8436, Defaultpricec.getPrice("\u0417\u0435\u043b\u044c\u0435 \u0410\u0433\u0435\u043d\u0442\u0430"), new class_1844(Optional.empty(), Optional.of(0xFFFB00), List.of(), Optional.empty()), agentLore));
        List<class_5250> winnerLore = List.of(class_2561.method_43470((String)"\u0425\u0440\u0430\u0431\u0440\u0430\u044f \u0434\u0443\u0448\u0430 \u041f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f"), class_2561.method_43470((String)"\u0438 \u043d\u0435\u043c\u043d\u043e\u0433\u043e \u043c\u0430\u0433\u0438\u0438"), class_2561.method_43470((String)"\u043e\u0431\u0440\u0430\u0437\u043e\u0432\u0430\u043b\u0438 \u044d\u0442\u043e \u0437\u0435\u043b\u044c\u0435"));
        potions.add(new CustomItem("[\u2605] \u0417\u0435\u043b\u044c\u0435 \u041f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f", null, class_1802.field_8436, Defaultpricec.getPrice("\u0417\u0435\u043b\u044c\u0435 \u041f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f"), new class_1844(Optional.empty(), Optional.of(65280), List.of(), Optional.empty()), winnerLore));
        List<class_5250> killerLore = List.of(class_2561.method_43470((String)"\u041e\u0441\u0442\u043e\u0440\u043e\u0436\u043d\u043e! \u0417\u0435\u043b\u044c\u0435 \u041a\u0438\u043b\u043b\u0435\u0440\u0430"), class_2561.method_43470((String)"\u0432\u044b\u0437\u044b\u0432\u0430\u0435\u0442 \u043a\u0440\u043e\u0432\u043e\u0436\u0430\u0434\u043d\u043e\u0441\u0442\u044c"), class_2561.method_43470((String)"\u0438 \u043f\u043e\u0432\u044b\u0448\u0430\u0435\u0442 \u0432\u044b\u043d\u043e\u0441\u043b\u0438\u0432\u043e\u0441\u0442\u044c!"));
        potions.add(new CustomItem("[\u2605] \u0417\u0435\u043b\u044c\u0435 \u041a\u0438\u043b\u043b\u0435\u0440\u0430", null, class_1802.field_8436, Defaultpricec.getPrice("\u0417\u0435\u043b\u044c\u0435 \u041a\u0438\u043b\u043b\u0435\u0440\u0430"), new class_1844(Optional.empty(), Optional.of(0xFF0000), List.of(), Optional.empty()), killerLore));
        List<class_5250> burpLore = List.of(class_2561.method_43470((String)"\u041e\u043f\u0430\u0441\u043d\u0430\u044f \u0436\u0438\u0434\u043a\u043e\u0441\u0442\u044c \u0432 \u0441\u043e\u0441\u0443\u0434\u0435"), class_2561.method_43470((String)"\u0441\u043e\u0434\u0435\u0440\u0436\u0438\u0442 \u041e\u0442\u0440\u044b\u0436\u043a\u0443 \u0432\u0430\u0441\u0438\u043b\u0438\u0441\u043a\u0430"), class_2561.method_43470((String)"\u0438 \u0434\u0440\u0443\u0433\u0438\u0445 \u043c\u0435\u0440\u0437\u043a\u0438\u0445 \u0442\u0432\u0430\u0440\u0435\u0439"));
        potions.add(new CustomItem("[\u2605] \u0417\u0435\u043b\u044c\u0435 \u041e\u0442\u0440\u044b\u0436\u043a\u0438", null, class_1802.field_8436, Defaultpricec.getPrice("\u0417\u0435\u043b\u044c\u0435 \u041e\u0442\u0440\u044b\u0436\u043a\u0438"), new class_1844(Optional.empty(), Optional.of(16735488), List.of(), Optional.empty()), burpLore));
        List<class_5250> acidLore = List.of(class_2561.method_43470((String)"\u041a\u0443\u0447\u0430 \u0430\u0432\u0430\u043d\u0442\u044e\u0440\u0438\u0441\u0442\u043e\u0432 \u043f\u043e\u043b\u043e\u0436\u0438\u043b\u0438"), class_2561.method_43470((String)"\u0441\u0432\u043e\u0438 \u0436\u0438\u0437\u043d\u0438 \u0432 \u043f\u043e\u043f\u044b\u0442\u043a\u0430\u0445"), class_2561.method_43470((String)"\u0441\u043e\u0431\u0440\u0430\u0442\u044c \u044d\u0442\u0443 \u041a\u0438\u0441\u043b\u043e\u0442\u0443"));
        potions.add(new CustomItem("[\u2605] \u0421\u0435\u0440\u043d\u0430\u044f \u043a\u0438\u0441\u043b\u043e\u0442\u0430", null, class_1802.field_8436, Defaultpricec.getPrice("\u0421\u0435\u0440\u043d\u0430\u044f \u043a\u0438\u0441\u043b\u043e\u0442\u0430"), new class_1844(Optional.empty(), Optional.of(49664), List.of(), Optional.empty()), acidLore));
        List<class_5250> flashLore = List.of(class_2561.method_43470((String)"\u0412\u0441\u0435\u0433\u043e \u043e\u0434\u043d\u0430 \u0431\u0443\u0442\u044b\u043b\u043e\u0447\u043a\u0430"), class_2561.method_43470((String)"\u0412\u0441\u043f\u044b\u0448\u043a\u0438 \u0441\u043f\u043e\u0441\u043e\u0431\u043d\u0430 \u043e\u0441\u043b\u0435\u043f\u0438\u0442\u044c"), class_2561.method_43470((String)"\u0446\u0435\u043b\u0443\u044e \u043e\u0440\u0434\u0443 \u0432\u0440\u0430\u0433\u043e\u0432!"));
        potions.add(new CustomItem("[\u2605] \u0412\u0441\u043f\u044b\u0448\u043a\u0430", null, class_1802.field_8436, Defaultpricec.getPrice("\u0412\u0441\u043f\u044b\u0448\u043a\u0430"), new class_1844(Optional.empty(), Optional.of(0xFFFFFF), List.of(), Optional.empty()), flashLore));
        return potions;
    }
}

