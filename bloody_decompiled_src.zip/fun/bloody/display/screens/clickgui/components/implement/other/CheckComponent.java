/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.screens.clickgui.components.implement.other;

import fun.bloody.Bloody;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.theme.ThemeManager;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class CheckComponent
extends AbstractComponent {
    private boolean state;
    private Runnable runnable;
    private final Animation alphaAnimation = new Decelerate().setMs(400).setValue(100.0);
    private final Animation stencilAnimation = new Decelerate().setMs(200).setValue(8.0);
    private final Animation sliderAnimation = new Decelerate().setMs(225).setValue(8.0);

    @Override
    public CheckComponent position(float x, float y) {
        this.x = x - 7.0f;
        this.y = y + 2.0f;
        return this;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        class_4587 matrix = context.method_51448();
        ThemeManager themeManager = ThemeManager.getInstance();
        ClickGui clickGuiModule = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof ClickGui).findFirst().orElse(null);
        this.alphaAnimation.setDirection(this.state ? Direction.FORWARDS : Direction.BACKWARDS);
        this.stencilAnimation.setDirection(this.state ? Direction.FORWARDS : Direction.BACKWARDS);
        this.sliderAnimation.setDirection(this.state ? Direction.FORWARDS : Direction.BACKWARDS);
        int stateColor = clickGuiModule != null ? clickGuiModule.getControlOnColor() : themeManager.getPrimaryColor();
        int bgColor = clickGuiModule != null ? clickGuiModule.getControlOffColor() : themeManager.getWindowBackgroundColor();
        int opacity = this.alphaAnimation.getOutput().intValue();
        float sliderX = this.x + this.sliderAnimation.getOutput().floatValue();
        rectangle.render(ShapeProperties.create(matrix, this.x, this.y, 16.0, 8.0).round(4.0f).thickness(0.0f).softness(0.0f).color(ColorAssist.reAlphaInt(bgColor, 180)).build());
        rectangle.render(ShapeProperties.create(matrix, this.x, this.y, 16.0, 8.0).round(4.0f).thickness(0.0f).softness(0.0f).color(ColorAssist.reAlphaInt(stateColor, opacity)).build());
        rectangle.render(ShapeProperties.create(matrix, sliderX - 0.5f, this.y - 0.5f, 9.0, 9.0).round(4.5f).thickness(0.0f).softness(1.0f).color(clickGuiModule != null ? clickGuiModule.getCheckColor(255) : new Color(255, 255, 255).getRGB()).build());
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (Calculate.isHovered(mouseX, mouseY, this.x, this.y, 16.0, 8.0) && button == 0) {
            this.runnable.run();
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    public CheckComponent setState(boolean state) {
        this.state = state;
        return this;
    }

    public CheckComponent setRunnable(Runnable runnable) {
        this.runnable = runnable;
        return this;
    }
}

