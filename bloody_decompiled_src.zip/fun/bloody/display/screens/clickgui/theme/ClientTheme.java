/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.display.screens.clickgui.theme;

import fun.bloody.display.screens.clickgui.theme.ThemeManager;
import fun.bloody.utils.display.color.ColorAssist;
import java.awt.Color;

public class ClientTheme {
    private String name;
    private boolean dualColor;
    private int color1;
    private int color2;
    private boolean isWhiteTheme;

    public ClientTheme(String name, boolean dualColor, int color1, int color2) {
        this.name = name;
        this.dualColor = dualColor;
        this.color1 = color1;
        this.color2 = color2;
        this.isWhiteTheme = false;
    }

    public ClientTheme(String name, int singleColor) {
        this(name, false, singleColor, singleColor);
    }

    public ClientTheme(String name, int singleColor, boolean isWhiteTheme) {
        this(name, false, singleColor, singleColor);
        this.isWhiteTheme = isWhiteTheme;
    }

    public int getAnimatedColor(int index, int speed) {
        if (this.dualColor) {
            int angle = (int)((System.currentTimeMillis() / (long)speed + (long)index) % 360L);
            angle = (angle > 180 ? 360 - angle : angle) + 180;
            float progress = Math.clamp((float)angle / 180.0f - 1.0f, 0.0f, 1.0f);
            return ClientTheme.interpolateColor(this.color1, this.color2, progress);
        }
        int angle = (int)((System.currentTimeMillis() / (long)speed + (long)index) % 360L);
        float wave = (float)(Math.sin(Math.toRadians(angle)) * (double)0.15f + (double)0.85f);
        int r = Math.min(255, (int)((float)(this.color1 >> 16 & 0xFF) * wave));
        int g = Math.min(255, (int)((float)(this.color1 >> 8 & 0xFF) * wave));
        int b = Math.min(255, (int)((float)(this.color1 & 0xFF) * wave));
        return 0xFF000000 | r << 16 | g << 8 | b;
    }

    public void applyTo(ThemeManager manager) {
        manager.getPrimarySetting().setColor(this.color1);
        manager.getIconColorSetting().setColor(this.color1);
        int bg = this.getTintedColor(this.color1, 0.08f);
        manager.getWindowBackgroundSetting().setColor(ColorAssist.reAlphaInt(bg, 160));
        int head = this.getTintedColor(this.color1, 0.15f);
        manager.getHeaderSetting().setColor(ColorAssist.reAlphaInt(head, 255));
        manager.getTextSetting().setColor(new Color(255, 255, 255).getRGB());
        manager.getInactiveTextSetting().setColor(new Color(160, 160, 170).getRGB());
        manager.getHeaderTextSetting().setColor(this.color1);
        manager.getActiveSetting().setColor(this.color1);
    }

    private int getTintedColor(int base, float brightness) {
        Color c = new Color(base);
        float[] hsb = Color.RGBtoHSB(c.getRed(), c.getGreen(), c.getBlue(), null);
        return Color.getHSBColor(hsb[0], Math.min(hsb[1], 0.6f), Math.max(brightness, 0.12f)).getRGB();
    }

    private static int interpolateColor(int c1, int c2, float progress) {
        int r1 = c1 >> 16 & 0xFF;
        int g1 = c1 >> 8 & 0xFF;
        int b1 = c1 & 0xFF;
        int r2 = c2 >> 16 & 0xFF;
        int g2 = c2 >> 8 & 0xFF;
        int b2 = c2 & 0xFF;
        int r = (int)((float)r1 + (float)(r2 - r1) * progress);
        int g = (int)((float)g1 + (float)(g2 - g1) * progress);
        int b = (int)((float)b1 + (float)(b2 - b1) * progress);
        return 0xFF000000 | r << 16 | g << 8 | b;
    }

    public String getName() {
        return this.name;
    }

    public boolean isDualColor() {
        return this.dualColor;
    }

    public int getColor1() {
        return this.color1;
    }

    public int getColor2() {
        return this.color2;
    }

    public boolean isWhiteTheme() {
        return this.isWhiteTheme;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDualColor(boolean dualColor) {
        this.dualColor = dualColor;
    }

    public void setColor1(int color1) {
        this.color1 = color1;
    }

    public void setColor2(int color2) {
        this.color2 = color2;
    }

    public void setWhiteTheme(boolean isWhiteTheme) {
        this.isWhiteTheme = isWhiteTheme;
    }
}

