/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.display.screens.clickgui.theme;

import fun.bloody.display.screens.clickgui.theme.ClientTheme;
import fun.bloody.features.module.setting.implement.ColorSetting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ThemeManager {
    private static final ThemeManager INSTANCE = new ThemeManager();
    private boolean editorOpen = false;
    private final ColorSetting primarySetting = new ColorSetting("\u0410\u043a\u0446\u0435\u043d\u0442", "");
    private final ColorSetting textSetting = new ColorSetting("\u0422\u0435\u043a\u0441\u0442", "");
    private final ColorSetting inactiveTextSetting = new ColorSetting("\u0422\u0435\u043a\u0441\u0442 (\u0442\u0443\u0441\u043a\u043b\u044b\u0439)", "");
    private final ColorSetting headerSetting = new ColorSetting("\u0417\u0430\u0433\u043e\u043b\u043e\u0432\u043a\u0438", "");
    private final ColorSetting headerTextSetting = new ColorSetting("\u0422\u0435\u043a\u0441\u0442 \u0437\u0430\u0433\u043e\u043b\u043e\u0432\u043a\u043e\u0432", "");
    private final ColorSetting windowBackgroundSetting = new ColorSetting("\u0424\u043e\u043d \u043e\u043a\u043e\u043d", "");
    private final ColorSetting iconColorSetting = new ColorSetting("\u0418\u043a\u043e\u043d\u043a\u0438", "");
    private final ColorSetting activeSetting = new ColorSetting("\u0410\u043a\u0442\u0438\u0432\u043d\u044b\u0439 \u044d\u043b\u0435\u043c\u0435\u043d\u0442", "");
    private final List<ClientTheme> presets = new ArrayList<ClientTheme>();
    private final List<ClientTheme> userThemes = new ArrayList<ClientTheme>();
    private int selectedIndex = 0;
    private int customColor1 = new Color(50, 200, 120).getRGB();
    private int customColor2 = new Color(50, 150, 255).getRGB();
    private boolean customDualColor = false;

    public static ThemeManager getInstance() {
        return INSTANCE;
    }

    public int getPrimaryColor() {
        return this.primarySetting.getColor();
    }

    public int getTextColor() {
        return this.textSetting.getColor();
    }

    public int getInactiveTextColor() {
        return this.inactiveTextSetting.getColor();
    }

    public int getHeaderColor() {
        return this.headerSetting.getColor();
    }

    public int getHeaderTextColor() {
        return this.headerTextSetting.getColor();
    }

    public int getWindowBackgroundColor() {
        return this.windowBackgroundSetting.getColor();
    }

    public int getIconColor() {
        return this.iconColorSetting.getColor();
    }

    public int getActiveColor() {
        return this.activeSetting.getColor();
    }

    public int getSelectedIndex() {
        return this.selectedIndex;
    }

    public void setSelectedIndex(int index) {
        this.selectedIndex = index;
        if (index >= 0 && index < this.presets.size()) {
            this.presets.get(index).applyTo(this);
        } else if (index == this.presets.size()) {
            this.updateCustomTheme();
        }
    }

    public void updateCustomTheme() {
        if (this.isCustomSelected()) {
            new ClientTheme("Custom", this.customDualColor, this.customColor1, this.customColor2).applyTo(this);
        }
    }

    public void setCustomColor1(int color) {
        if (this.customColor1 != color) {
            this.customColor1 = color;
            if (this.isCustomSelected()) {
                this.updateCustomTheme();
            }
        }
    }

    public void setCustomColor2(int color) {
        if (this.customColor2 != color) {
            this.customColor2 = color;
            if (this.isCustomSelected()) {
                this.updateCustomTheme();
            }
        }
    }

    public void setCustomDualColor(boolean dual) {
        if (this.customDualColor != dual) {
            this.customDualColor = dual;
            if (this.isCustomSelected()) {
                this.updateCustomTheme();
            }
        }
    }

    private ThemeManager() {
        this.primarySetting.setColor(new Color(50, 200, 120).getRGB());
        this.textSetting.setColor(new Color(255, 255, 255).getRGB());
        this.inactiveTextSetting.setColor(new Color(160, 160, 170).getRGB());
        this.headerSetting.setColor(new Color(23, 24, 25).getRGB());
        this.headerTextSetting.setColor(new Color(50, 200, 120).getRGB());
        this.windowBackgroundSetting.setColor(new Color(15, 16, 18).getRGB());
        this.iconColorSetting.setColor(new Color(50, 200, 120).getRGB());
        this.activeSetting.setColor(new Color(50, 200, 120).getRGB());
        this.presets.add(new ClientTheme("Dark", new Color(120, 120, 120).getRGB()));
        this.presets.get(0).setColor1(new Color(60, 60, 65).getRGB());
        this.presets.add(new ClientTheme("White", new Color(255, 255, 255).getRGB(), true));
        this.presets.add(new ClientTheme("Emerald", new Color(50, 200, 120).getRGB()));
        this.presets.add(new ClientTheme("Ocean", new Color(70, 130, 230).getRGB()));
        this.presets.add(new ClientTheme("Amethyst", new Color(160, 100, 230).getRGB()));
        this.presets.add(new ClientTheme("Sunset", true, new Color(255, 120, 50).getRGB(), new Color(220, 50, 130).getRGB()));
        this.presets.add(new ClientTheme("Aurora", true, new Color(50, 220, 100).getRGB(), new Color(50, 160, 255).getRGB()));
        this.setSelectedIndex(0);
    }

    public int getCustomColor1() {
        return this.customColor1;
    }

    public int getCustomColor2() {
        return this.customColor2;
    }

    public boolean isCustomDualColor() {
        return this.customDualColor;
    }

    public ClientTheme getActiveTheme() {
        if (this.selectedIndex >= 0 && this.selectedIndex < this.presets.size()) {
            return this.presets.get(this.selectedIndex);
        }
        return new ClientTheme("Custom", this.customDualColor, this.customColor1, this.customColor2);
    }

    public boolean isCustomSelected() {
        return this.selectedIndex >= this.presets.size();
    }

    public int getTotalCount() {
        return this.presets.size() + 1;
    }

    public int getThemeColor(int index) {
        return this.getActiveTheme().getAnimatedColor(index, 10);
    }

    public int getThemeColor(int index, int speed) {
        return this.getActiveTheme().getAnimatedColor(index, speed);
    }

    public boolean isEditorOpen() {
        return this.editorOpen;
    }

    public void setEditorOpen(boolean editorOpen) {
        this.editorOpen = editorOpen;
    }

    public ColorSetting getPrimarySetting() {
        return this.primarySetting;
    }

    public ColorSetting getTextSetting() {
        return this.textSetting;
    }

    public ColorSetting getInactiveTextSetting() {
        return this.inactiveTextSetting;
    }

    public ColorSetting getHeaderSetting() {
        return this.headerSetting;
    }

    public ColorSetting getHeaderTextSetting() {
        return this.headerTextSetting;
    }

    public ColorSetting getWindowBackgroundSetting() {
        return this.windowBackgroundSetting;
    }

    public ColorSetting getIconColorSetting() {
        return this.iconColorSetting;
    }

    public ColorSetting getActiveSetting() {
        return this.activeSetting;
    }

    public List<ClientTheme> getPresets() {
        return this.presets;
    }

    public List<ClientTheme> getUserThemes() {
        return this.userThemes;
    }
}

