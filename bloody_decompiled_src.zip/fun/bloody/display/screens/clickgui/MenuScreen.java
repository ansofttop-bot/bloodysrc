/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_332
 *  net.minecraft.class_437
 */
package fun.bloody.display.screens.clickgui;

import fun.bloody.common.animation.Easy.Direction;
import fun.bloody.common.animation.Easy.EaseBackIn;
import fun.bloody.display.screens.clickgui.components.AbstractComponent;
import fun.bloody.display.screens.clickgui.components.implement.autobuy.autobuyui.AutoBuyGuiComponent;
import fun.bloody.display.screens.clickgui.components.implement.other.BackgroundComponent;
import fun.bloody.display.screens.clickgui.components.implement.other.CategoryContainerComponent;
import fun.bloody.display.screens.clickgui.components.implement.other.SearchComponent;
import fun.bloody.display.screens.clickgui.components.implement.other.ThemeEditorComponent;
import fun.bloody.display.screens.clickgui.components.implement.other.UserComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.TextComponent;
import fun.bloody.display.screens.clickgui.theme.ThemeManager;
import fun.bloody.features.impl.misc.SelfDestruct;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.sound.SoundManager;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.math.calc.Calculate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class MenuScreen
extends class_437
implements QuickImports {
    public static MenuScreen INSTANCE = new MenuScreen();
    private final List<AbstractComponent> components = new ArrayList<AbstractComponent>();
    private final BackgroundComponent backgroundComponent = new BackgroundComponent();
    private final UserComponent userComponent = new UserComponent();
    private final SearchComponent searchComponent = new SearchComponent();
    private final ThemeEditorComponent themeEditorComponent = new ThemeEditorComponent();
    private final CategoryContainerComponent categoryContainerComponent = new CategoryContainerComponent();
    private final AutoBuyGuiComponent autoBuyGuiComponent = new AutoBuyGuiComponent();
    public final EaseBackIn animation = new EaseBackIn(325, 1.0, 1.5f);
    public ModuleCategory category = ModuleCategory.COMBAT;
    public int x;
    public int y;
    public int width;
    public int height;
    private boolean guiDragging = false;
    private double dragOffsetX;
    private double dragOffsetY;
    private float offsetXPercent = 0.5f;
    private float offsetYPercent = 0.5f;
    private int lastScreenWidth = 0;
    private int lastScreenHeight = 0;
    private double lastTransformedMouseX = 0.0;
    private double lastTransformedMouseY = 0.0;

    public void initialize() {
        this.animation.setDirection(Direction.FORWARDS);
        this.categoryContainerComponent.initializeCategoryComponents();
        this.components.addAll(Arrays.asList(this.backgroundComponent, this.userComponent, this.searchComponent, this.categoryContainerComponent, this.autoBuyGuiComponent));
        this.components.add(this.themeEditorComponent);
    }

    public MenuScreen() {
        super(class_2561.method_30163((String)"MenuScreen"));
        this.initialize();
    }

    public void method_25393() {
        this.method_25419();
        this.components.forEach(AbstractComponent::tick);
        super.method_25393();
    }

    private double[] transformMouseCoords(double mouseX, double mouseY) {
        float scale = this.getScaleAnimation();
        if (scale <= 0.01f) {
            scale = 1.0f;
        }
        float centerX = (float)this.x + (float)this.width / 2.0f;
        float centerY = (float)this.y + (float)this.height / 2.0f;
        double transformedX = (mouseX - (double)centerX) / (double)scale + (double)centerX;
        double transformedY = (mouseY - (double)centerY) / (double)scale + (double)centerY;
        return new double[]{transformedX, transformedY};
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        blur.setup();
        int columnWidth = 115;
        int spacing = 5;
        int totalWidth = 5 * columnWidth + 4 * spacing;
        int totalHeight = 288;
        this.x = window.method_4486() / 2 - totalWidth / 2;
        this.y = window.method_4502() / 2 - totalHeight / 2;
        this.categoryContainerComponent.position(this.x, this.y);
        double[] transformedMouse = this.transformMouseCoords(mouseX, mouseY);
        this.lastTransformedMouseX = transformedMouse[0];
        this.lastTransformedMouseY = transformedMouse[1];
        Calculate.scale(context.method_51448(), (float)window.method_4486() / 2.0f, (float)window.method_4502() / 2.0f, this.getScaleAnimation(), () -> {
            if (ThemeManager.getInstance().isEditorOpen()) {
                this.themeEditorComponent.position((float)this.x - this.themeEditorComponent.width - 10.0f, this.y);
                this.themeEditorComponent.render(context, (int)this.lastTransformedMouseX, (int)this.lastTransformedMouseY, delta);
            }
            this.categoryContainerComponent.render(context, (int)this.lastTransformedMouseX, (int)this.lastTransformedMouseY, delta);
            this.searchComponent.position((float)this.x + (float)totalWidth / 2.0f - this.searchComponent.width / 2.0f, this.y + totalHeight + 15);
            this.searchComponent.render(context, (int)this.lastTransformedMouseX, (int)this.lastTransformedMouseY, delta);
            windowManager.render(context, (int)this.lastTransformedMouseX, (int)this.lastTransformedMouseY, delta);
        });
        super.method_25394(context, mouseX, mouseY, delta);
    }

    public void openGui() {
        if (SelfDestruct.unhooked) {
            return;
        }
        this.animation.setDirection(Direction.FORWARDS);
        this.animation.reset();
        mc.method_1507((class_437)this);
        SoundManager.playSound(SoundManager.OPEN_GUI);
    }

    public float getScaleAnimation() {
        return (float)this.animation.getOutput();
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        boolean windowHandled;
        double[] transformed = this.transformMouseCoords(mouseX, mouseY);
        if (button == 2 && this.isHoveringBackground(transformed[0], transformed[1])) {
            this.guiDragging = true;
            this.dragOffsetX = transformed[0] - (double)this.x;
            this.dragOffsetY = transformed[1] - (double)this.y;
            return true;
        }
        if (!this.guiDragging && !(windowHandled = windowManager.mouseClicked(transformed[0], transformed[1], button))) {
            for (AbstractComponent component : this.components) {
                component.mouseClicked(transformed[0], transformed[1], button);
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    public boolean method_25406(double mouseX, double mouseY, int button) {
        double[] transformed = this.transformMouseCoords(mouseX, mouseY);
        if (button == 2) {
            this.guiDragging = false;
            this.offsetXPercent = ((float)this.x + (float)this.width / 2.0f) / (float)window.method_4486();
            this.offsetYPercent = ((float)this.y + (float)this.height / 2.0f) / (float)window.method_4502();
        }
        for (AbstractComponent component : this.components) {
            component.mouseReleased(transformed[0], transformed[1], button);
        }
        windowManager.mouseReleased(transformed[0], transformed[1], button);
        return super.method_25406(mouseX, mouseY, button);
    }

    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        double[] transformed = this.transformMouseCoords(mouseX, mouseY);
        if (this.guiDragging && button == 2) {
            this.x = (int)(transformed[0] - this.dragOffsetX);
            this.y = (int)(transformed[1] - this.dragOffsetY);
            return true;
        }
        boolean windowHandled = windowManager.mouseDragged(transformed[0], transformed[1], button, deltaX, deltaY);
        if (!windowHandled) {
            for (AbstractComponent component : this.components) {
                component.mouseDragged(transformed[0], transformed[1], button, deltaX, deltaY);
            }
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
        double[] transformed = this.transformMouseCoords(mouseX, mouseY);
        boolean windowHandled = windowManager.mouseScrolled(transformed[0], transformed[1], vertical);
        if (!windowHandled) {
            for (AbstractComponent component : this.components) {
                component.mouseScrolled(transformed[0], transformed[1], vertical);
            }
        }
        return super.method_25401(mouseX, mouseY, horizontal, vertical);
    }

    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (windowManager.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        for (AbstractComponent component : this.components) {
            if (!component.keyPressed(keyCode, scanCode, modifiers)) continue;
            return true;
        }
        if (keyCode == 256 && this.method_25422()) {
            SoundManager.playSound(SoundManager.CLOSE_GUI);
            this.animation.setDirection(Direction.BACKWARDS);
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public boolean method_25400(char chr, int modifiers) {
        if (!windowManager.charTyped(chr, modifiers)) {
            for (AbstractComponent component : this.components) {
                component.charTyped(chr, modifiers);
            }
        }
        return super.method_25400(chr, modifiers);
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25419() {
        if (this.animation.finished(Direction.BACKWARDS)) {
            TextComponent.typing = false;
            SearchComponent.typing = false;
            super.method_25419();
        }
    }

    private boolean isHoveringBackground(double mouseX, double mouseY) {
        return mouseX >= (double)(this.x - 20) && mouseX <= (double)(this.x + this.width + 20) && mouseY >= (double)this.y && mouseY <= (double)(this.y + this.height);
    }

    public void setCategory(ModuleCategory category) {
        this.category = category;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setGuiDragging(boolean guiDragging) {
        this.guiDragging = guiDragging;
    }

    public void setDragOffsetX(double dragOffsetX) {
        this.dragOffsetX = dragOffsetX;
    }

    public void setDragOffsetY(double dragOffsetY) {
        this.dragOffsetY = dragOffsetY;
    }

    public void setOffsetXPercent(float offsetXPercent) {
        this.offsetXPercent = offsetXPercent;
    }

    public void setOffsetYPercent(float offsetYPercent) {
        this.offsetYPercent = offsetYPercent;
    }

    public void setLastScreenWidth(int lastScreenWidth) {
        this.lastScreenWidth = lastScreenWidth;
    }

    public void setLastScreenHeight(int lastScreenHeight) {
        this.lastScreenHeight = lastScreenHeight;
    }

    public void setLastTransformedMouseX(double lastTransformedMouseX) {
        this.lastTransformedMouseX = lastTransformedMouseX;
    }

    public void setLastTransformedMouseY(double lastTransformedMouseY) {
        this.lastTransformedMouseY = lastTransformedMouseY;
    }

    public List<AbstractComponent> getComponents() {
        return this.components;
    }

    public BackgroundComponent getBackgroundComponent() {
        return this.backgroundComponent;
    }

    public UserComponent getUserComponent() {
        return this.userComponent;
    }

    public SearchComponent getSearchComponent() {
        return this.searchComponent;
    }

    public ThemeEditorComponent getThemeEditorComponent() {
        return this.themeEditorComponent;
    }

    public CategoryContainerComponent getCategoryContainerComponent() {
        return this.categoryContainerComponent;
    }

    public AutoBuyGuiComponent getAutoBuyGuiComponent() {
        return this.autoBuyGuiComponent;
    }

    public EaseBackIn getAnimation() {
        return this.animation;
    }

    public ModuleCategory getCategory() {
        return this.category;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public boolean isGuiDragging() {
        return this.guiDragging;
    }

    public double getDragOffsetX() {
        return this.dragOffsetX;
    }

    public double getDragOffsetY() {
        return this.dragOffsetY;
    }

    public float getOffsetXPercent() {
        return this.offsetXPercent;
    }

    public float getOffsetYPercent() {
        return this.offsetYPercent;
    }

    public int getLastScreenWidth() {
        return this.lastScreenWidth;
    }

    public int getLastScreenHeight() {
        return this.lastScreenHeight;
    }

    public double getLastTransformedMouseX() {
        return this.lastTransformedMouseX;
    }

    public double getLastTransformedMouseY() {
        return this.lastTransformedMouseY;
    }
}

