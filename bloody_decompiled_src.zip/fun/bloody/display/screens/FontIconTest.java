/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_332
 *  net.minecraft.class_437
 */
package fun.bloody.display.screens;

import fun.bloody.utils.display.font.Fonts;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class FontIconTest
extends class_437 {
    public FontIconTest() {
        super((class_2561)class_2561.method_43470((String)"Divine Icons Test"));
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_25294(0, 0, this.field_22789, this.field_22790, -16777216);
        int startX = 50;
        int startY = 50;
        int iconSize = 40;
        int spacing = 80;
        int columns = 8;
        context.method_51433(this.field_22793, "Divine Icons Font - Test Screen", startX, 20, -1, true);
        context.method_51433(this.field_22793, "Press ESC to close", startX, this.field_22790 - 30, -256, true);
        try {
            for (int i = 0; i < 26; ++i) {
                char letter = (char)(65 + i);
                int row = i / columns;
                int col = i % columns;
                int x = startX + col * spacing;
                int y = startY + row * spacing;
                Fonts.getSize(iconSize, Fonts.Type.DIVINE_ICONS).drawString(context.method_51448(), String.valueOf(letter), x, y, -1);
                context.method_51433(this.field_22793, String.valueOf(letter), x + 10, y + iconSize + 5, -5592406, false);
            }
            int lowerStartY = startY + 4 * spacing;
            for (int i = 0; i < 26; ++i) {
                char letter = (char)(97 + i);
                int row = i / columns;
                int col = i % columns;
                int x = startX + col * spacing;
                int y = lowerStartY + row * spacing;
                Fonts.getSize(iconSize, Fonts.Type.DIVINE_ICONS).drawString(context.method_51448(), String.valueOf(letter), x, y, -1);
                context.method_51433(this.field_22793, String.valueOf(letter), x + 10, y + iconSize + 5, -5592406, false);
            }
        }
        catch (Exception e) {
            context.method_51433(this.field_22793, "Error loading divine_icons.ttf font!", startX, 100, -65536, true);
            context.method_51433(this.field_22793, "Make sure divine_icons.ttf is in assets/minecraft/fonts/", startX, 120, -65536, false);
        }
    }

    public boolean method_25421() {
        return false;
    }
}

