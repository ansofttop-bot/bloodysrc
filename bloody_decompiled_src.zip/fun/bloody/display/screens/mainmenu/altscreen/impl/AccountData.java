/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.display.screens.mainmenu.altscreen.impl;

import fun.bloody.display.screens.mainmenu.altscreen.impl.Account;
import java.util.List;

public class AccountData {
    public List<Account> accounts;
    public String currentAccount;
}

