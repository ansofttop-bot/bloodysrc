/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.display.screens.mainmenu.altscreen.impl;

import fun.bloody.display.screens.mainmenu.altscreen.impl.Account;
import java.util.ArrayList;
import java.util.List;

public class AccountRepository {
    public List<Account> accountList = new ArrayList<Account>();
    public String currentAccount = "";
}

