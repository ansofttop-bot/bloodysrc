/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 *  net.minecraft.class_429
 *  net.minecraft.class_437
 *  net.minecraft.class_500
 *  net.minecraft.class_526
 */
package fun.bloody.display.screens.mainmenu;

import antidaunleak.api.UserProfile;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.display.screens.mainmenu.altscreen.AltScreen;
import fun.bloody.utils.client.text.TextAnimation;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.gif.GifRender;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.display.shape.ShapeProperties;
import java.awt.Color;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_526;

public class MainMenu
extends class_437
implements QuickImports {
    public static MainMenu INSTANCE = new MainMenu();
    public int x;
    public int y;
    public int width;
    public int height;
    private final TextAnimation textAnimation = new TextAnimation();
    private boolean altVisible = false;
    private final GifRender gifRender = new GifRender("minecraft:gif/backgrounds/mainmenutype1", 1);
    private final Decelerate altFadeAnimation = new Decelerate();
    private final Decelerate mainFadeAnimation = new Decelerate();
    private AltScreen altScreen;
    private long lastToggleTime = 0L;
    private static final long TOGGLE_DELAY = 500L;
    private static final UserProfile userProfile = UserProfile.getInstance();

    public MainMenu() {
        super(class_2561.method_30163((String)"MainMenu"));
        this.altFadeAnimation.setMs(250).setValue(1.0);
        this.mainFadeAnimation.setMs(250).setValue(1.0);
        this.mainFadeAnimation.setDirection(Direction.FORWARDS);
        this.altFadeAnimation.setDirection(Direction.BACKWARDS);
    }

    public void method_25393() {
        super.method_25393();
        this.textAnimation.updateText();
        if (this.altScreen != null) {
            this.altScreen.tick();
        }
        if (this.altFadeAnimation.isFinished(Direction.BACKWARDS)) {
            this.altVisible = false;
        }
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        MainMenu.mc.field_1690.method_42474().method_41748((Object)2);
        this.x = window.method_4486();
        this.y = window.method_4502();
        this.width = window.method_4486() + 2;
        this.height = window.method_4502() + 2;
        float cy = (float)this.height / 2.0f;
        float sy = cy - 25.0f;
        float sx = this.width / 2 - 50;
        float bs = 21.0f;
        this.gifRender.render(context.method_51448(), 0.0f, 0.0f, this.width, this.height);
        image.setTexture("textures/mainmenu/backmenu.png").render(ShapeProperties.create(context.method_51448(), 0.0, 0.0, this.width, this.height).color(-1).build());
        Double mainAlpha = this.mainFadeAnimation.getOutput();
        int mainAlphaInt = (int)(255.0 * mainAlpha);
        if (mainAlpha > (double)0.01f) {
            this.drawButton(context, sx, sy, 102.0f, 18.5f, "Single Player", mainAlphaInt);
            this.drawButton(context, sx, sy + bs, 102.0f, 18.5f, "Multi Player", mainAlphaInt);
            this.drawButton(context, sx, sy + bs * 2.0f, 102.0f, 18.5f, "Alt Screen", mainAlphaInt);
            this.drawButton(context, sx, sy + bs * 3.0f, 50.0f, 18.5f, "", mainAlphaInt);
            this.drawButton(context, sx + 52.0f, sy + bs * 3.0f, 50.0f, 18.5f, "", mainAlphaInt);
            Fonts.getSize(21, Fonts.Type.ICONSTYPENEW).drawCenteredString(context.method_51448(), "i", this.width / 2 - 24, sy + bs + 49.0f, this.applyAlpha(ColorAssist.getText(0.35f), mainAlphaInt));
            Fonts.getSize(22, Fonts.Type.ICONSTYPENEW).drawCenteredString(context.method_51448(), "s", this.width / 2 + 27, sy + bs + 49.0f, this.applyAlpha(ColorAssist.getText(0.35f), mainAlphaInt));
            Fonts.getSize(45, Fonts.Type.ICONS).drawCenteredString(context.method_51448(), "A", this.width / 2, sy - 70.0f, this.applyAlpha(new Color(200, 200, 200).getRGB(), mainAlphaInt));
            Fonts.getSize(18, Fonts.Type.DEFAULT).drawCenteredString(context.method_51448(), "Bloody, you made the right choice.", this.width / 2, sy - 40.0f, this.applyAlpha(new Color(200, 200, 200).getRGB(), mainAlphaInt));
            Fonts.getSize(12, Fonts.Type.DEFAULT).drawCenteredString(context.method_51448(), this.textAnimation.getCurrentText(), this.width / 2, sy - 25.0f, this.applyAlpha(new Color(200, 200, 200).getRGB(), mainAlphaInt));
            Fonts.getSize(12, Fonts.Type.DEFAULT).drawCenteredString(context.method_51448(), "\u00a9 2025 Bloody. All rights reserved.", this.width / 2 + 2, this.height - 7, this.applyAlpha(ColorAssist.getText(0.35f), mainAlphaInt));
            rectangle.render(ShapeProperties.create(context.method_51448(), 8.0, this.height - 27, 20.0, 20.0).thickness(2.0f).round(10.0f).outlineColor(this.applyAlpha(new Color(100, 100, 100, 95).getRGB(), mainAlphaInt)).color(this.applyAlpha(new Color(50, 50, 50, 55).getRGB(), mainAlphaInt), this.applyAlpha(new Color(50, 50, 50, 55).getRGB(), mainAlphaInt), this.applyAlpha(new Color(80, 80, 80, 95).getRGB(), mainAlphaInt), this.applyAlpha(new Color(80, 80, 80, 95).getRGB(), mainAlphaInt)).build());
            Render2D.drawTexture(context, class_2960.method_60655((String)"minecraft", (String)"textures/mainmenu/steve.png"), 9.5f, (float)this.height - 25.5f, 17.0f, 7.0f, 32, 32, 32, this.applyAlpha(new Color(0, 0, 0, 255).getRGB(), mainAlphaInt));
            rectangle.render(ShapeProperties.create(context.method_51448(), 22.0, this.height - 13, 6.0, 6.0).thickness(2.0f).round(3.0f).outlineColor(this.applyAlpha(new Color(100, 100, 100, 95).getRGB(), mainAlphaInt)).color(this.applyAlpha(new Color(50, 50, 50, 55).getRGB(), mainAlphaInt), this.applyAlpha(new Color(50, 50, 50, 55).getRGB(), mainAlphaInt), this.applyAlpha(new Color(80, 80, 80, 95).getRGB(), mainAlphaInt), this.applyAlpha(new Color(80, 80, 80, 95).getRGB(), mainAlphaInt)).build());
            rectangle.render(ShapeProperties.create(context.method_51448(), 23.0, this.height - 12, 4.0, 4.0).round(2.0f).color(this.applyAlpha(new Color(1, 235, 1, 155).getRGB(), mainAlphaInt)).build());
            Fonts.getSize(12, Fonts.Type.DEFAULT).drawString(context.method_51448(), "Username \u25b8 " + userProfile.profile("username"), 35.0, (float)this.height - 21.5f, this.applyAlpha(ColorAssist.getText(0.35f), mainAlphaInt));
            Fonts.getSize(12, Fonts.Type.DEFAULT).drawString(context.method_51448(), "Uid \u25b8 " + userProfile.profile("uid"), 35.0, (float)this.height - 14.5f, this.applyAlpha(ColorAssist.getText(0.35f), mainAlphaInt));
            String text = "Build \u25b8 0.3 alpha";
            float textWidth = Fonts.getSize(12, Fonts.Type.DEFAULT).getStringWidth(text);
            Fonts.getSize(12, Fonts.Type.DEFAULT).drawString(context.method_51448(), text, (float)context.method_51421() - textWidth - 3.0f, (float)context.method_51443() - 5.5f, this.applyAlpha(ColorAssist.getText(0.35f), mainAlphaInt));
        }
        Double altAlpha = this.altFadeAnimation.getOutput();
        if (this.altVisible || altAlpha > (double)0.01f) {
            float centerX = (float)this.width / 2.0f - 80.0f;
            float centerY = (float)this.height / 2.0f - 105.0f;
            if (this.altScreen == null) {
                this.altScreen = new AltScreen(centerX, centerY);
            } else {
                this.altScreen.updatePosition(centerX, centerY);
            }
            int altAlphaInt = (int)(255.0 * altAlpha);
            Color buttonColor = new Color(50, 50, 50, (int)(55.0 * altAlpha));
            Color outlineColor = new Color(100, 100, 100, (int)(95.0 * altAlpha));
            Color gradientColor = new Color(80, 80, 80, (int)(95.0 * altAlpha));
            Color textColor = new Color(200, 200, 200, altAlphaInt);
            Color bgColor = new Color(30, 30, 30, (int)(255.0 * altAlpha));
            this.altScreen.render(context, buttonColor, outlineColor, gradientColor, textColor, bgColor);
        }
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void drawButton(class_332 ctx, float x, float y, float w, float h, String label, int alpha) {
        rectangle.render(ShapeProperties.create(ctx.method_51448(), x, y, w, h).thickness(2.0f).round(4.0f).outlineColor(this.applyAlpha(new Color(100, 100, 100, 95).getRGB(), alpha)).color(this.applyAlpha(new Color(50, 50, 50, 55).getRGB(), alpha), this.applyAlpha(new Color(50, 50, 50, 55).getRGB(), alpha), this.applyAlpha(new Color(80, 80, 80, 95).getRGB(), alpha), this.applyAlpha(new Color(80, 80, 80, 95).getRGB(), alpha)).build());
        rectangle.render(ShapeProperties.create(ctx.method_51448(), x, y, w, 1.0).thickness(2.0f).round(5.0f).outlineColor(this.applyAlpha(new Color(100, 100, 100, 95).getRGB(), alpha)).color(this.applyAlpha(new Color(50, 50, 50, 5).getRGB(), alpha), this.applyAlpha(new Color(50, 50, 50, 255).getRGB(), alpha), this.applyAlpha(new Color(80, 80, 80, 255).getRGB(), alpha), this.applyAlpha(new Color(80, 80, 80, 5).getRGB(), alpha)).build());
        if (!label.isEmpty()) {
            Fonts.getSize(16, Fonts.Type.DEFAULT).drawCenteredString(ctx.method_51448(), label, this.width / 2, y + 7.0f, this.applyAlpha(new Color(200, 200, 200).getRGB(), alpha));
        }
    }

    private int applyAlpha(int color, int alpha) {
        Color c = new Color(color, true);
        int newAlpha = (int)((double)c.getAlpha() / 255.0 * (double)alpha);
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.min(255, newAlpha)).getRGB();
    }

    public boolean method_25402(double mx, double my, int btn) {
        float cy = (float)this.height / 2.0f;
        float sy = cy - 25.0f;
        float sx = this.width / 2 - 50;
        float bs = 21.0f;
        if (this.altVisible && this.altFadeAnimation.getOutput() > 0.5 && this.altScreen != null) {
            return this.altScreen.mouseClicked(mx, my, btn);
        }
        if (this.mainFadeAnimation.getOutput() > 0.5 && btn == 0) {
            if (this.isIn(mx, my, sx, sy, 102.0f, 18.5f)) {
                mc.method_1507((class_437)new class_526((class_437)this));
                return true;
            }
            if (this.isIn(mx, my, sx, sy + bs, 102.0f, 18.5f)) {
                mc.method_1507((class_437)new class_500((class_437)this));
                return true;
            }
            if (this.isIn(mx, my, sx, sy + bs * 2.0f, 102.0f, 18.5f)) {
                this.toggleAlt();
                return true;
            }
            if (this.isIn(mx, my, sx + 52.0f, sy + bs * 3.0f, 50.0f, 18.5f)) {
                mc.method_1507((class_437)new class_429((class_437)this, MainMenu.mc.field_1690));
                return true;
            }
            if (this.isIn(mx, my, sx, sy + bs * 3.0f, 50.0f, 18.5f)) {
                mc.method_1490();
                return true;
            }
        }
        return super.method_25402(mx, my, btn);
    }

    public boolean method_25401(double mx, double my, double h, double v) {
        if (this.altVisible && this.altFadeAnimation.getOutput() > 0.5 && this.altScreen != null) {
            return this.altScreen.mouseScrolled(mx, my, v);
        }
        return super.method_25401(mx, my, h, v);
    }

    public boolean method_25403(double mx, double my, int btn, double dx, double dy) {
        if (this.altVisible && this.altFadeAnimation.getOutput() > 0.5 && this.altScreen != null) {
            return this.altScreen.mouseDragged(mx, my, btn);
        }
        return super.method_25403(mx, my, btn, dx, dy);
    }

    public boolean method_25406(double mx, double my, int btn) {
        if (this.altScreen != null) {
            this.altScreen.mouseReleased();
        }
        return super.method_25406(mx, my, btn);
    }

    public boolean method_25400(char c, int m) {
        if (this.altVisible && this.altFadeAnimation.getOutput() > 0.5 && this.altScreen != null) {
            return this.altScreen.charTyped(c);
        }
        return super.method_25400(c, m);
    }

    public boolean method_25404(int k, int s, int m) {
        if (k == 256) {
            if (this.altVisible) {
                this.toggleAlt();
                return true;
            }
            return false;
        }
        if (this.altVisible && this.altFadeAnimation.getOutput() > 0.5 && this.altScreen != null && this.altScreen.keyPressed(k)) {
            return true;
        }
        return super.method_25404(k, s, m);
    }

    private boolean isIn(double mx, double my, float x, float y, float w, float h) {
        return mx >= (double)x && mx <= (double)(x + w) && my >= (double)y && my <= (double)(y + h);
    }

    private void toggleAlt() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastToggleTime < 500L) {
            return;
        }
        this.lastToggleTime = currentTime;
        if (!this.altVisible) {
            this.altVisible = true;
            this.altFadeAnimation.setDirection(Direction.FORWARDS);
            this.altFadeAnimation.reset();
            this.mainFadeAnimation.setDirection(Direction.BACKWARDS);
            this.mainFadeAnimation.reset();
            if (this.altScreen != null) {
                this.altScreen.reset();
            }
        } else {
            this.altFadeAnimation.setDirection(Direction.BACKWARDS);
            this.altFadeAnimation.reset();
            this.mainFadeAnimation.setDirection(Direction.FORWARDS);
            this.mainFadeAnimation.reset();
            if (this.altScreen != null) {
                this.altScreen.reset();
            }
        }
    }
}

