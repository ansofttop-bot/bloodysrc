/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  net.minecraft.class_1799
 *  net.minecraft.class_332
 */
package fun.bloody.display.hud;

import com.google.common.collect.Lists;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_332;

public class Armor
extends AbstractDraggable {
    private static final int SLOT_SIZE = 18;
    private static final int SLOT_COUNT = 4;

    public Armor() {
        super("Armor", 0, 0, 72, 18, true);
    }

    @Override
    public boolean visible() {
        if (Armor.mc.field_1724 == null) {
            return false;
        }
        if (!Hud.getInstance().interfaceSettings.isSelected("Armor")) {
            return false;
        }
        return Armor.mc.field_1724.method_31548().field_7548.stream().anyMatch(stack -> !stack.method_7960()) || PlayerInteractionHelper.isChat(Armor.mc.field_1755);
    }

    @Override
    public void drawDraggable(class_332 context) {
        if (Armor.mc.field_1724 == null) {
            return;
        }
        List armorList = Lists.reverse((List)Armor.mc.field_1724.method_31548().field_7548);
        for (int i = 0; i < 4; ++i) {
            class_1799 stack;
            float slotX = this.getX() + i * 18;
            float slotY = this.getY();
            if (i >= armorList.size() || (stack = (class_1799)armorList.get(i)).method_7960()) continue;
            Render2D.defaultDrawStack(context, stack, slotX, slotY, false, true, 1.0f);
        }
    }
}

