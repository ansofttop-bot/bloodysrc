/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1844
 *  net.minecraft.class_1935
 *  net.minecraft.class_308
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_9334
 */
package fun.bloody.display.hud;

import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.events.container.SetScreenEvent;
import fun.bloody.features.impl.misc.FuntimeAssist;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.chat.StringHelper;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.interactions.inv.InventoryTask;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1935;
import net.minecraft.class_308;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_9334;

public class Binds
extends AbstractDraggable {
    private final FuntimeAssist FuntimeAssist;
    private final List<BindInfo> binds = new ArrayList<BindInfo>();
    private final Map<class_1792, Long> cooldownStartTimes = new HashMap<class_1792, Long>();
    private final Map<class_1792, Integer> itemCounts = new HashMap<class_1792, Integer>();
    private final Set<class_1792> activeCooldowns = new HashSet<class_1792>();
    private static final int BINDS_PER_ROW = 5;
    private float width;
    private float height;
    private long lastBindChange = 0L;
    private String currentRandomKey1 = "None";
    private String currentRandomKey2 = "None";
    private String currentRandomKey3 = "None";
    private int currentItemIndex1 = 0;
    private int currentItemIndex2 = 1;
    private int currentItemIndex3 = 2;
    private static final class_1792[] EXAMPLE_ITEMS = new class_1792[]{class_1802.field_8449, class_1802.field_8479, class_1802.field_8551, class_1802.field_22021};
    private final Animation animation = new Decelerate().setMs(300).setValue(1.0);

    public Binds() {
        super("Binds", 10, 180, 150, 40, true);
        this.FuntimeAssist = fun.bloody.features.impl.misc.FuntimeAssist.getInstance();
        this.initializeBinds();
    }

    private void initializeBinds() {
        for (FuntimeAssist.KeyBind keyBind : this.FuntimeAssist.getKeyBindings()) {
            String name = keyBind.setting().getName();
            String searchName = this.getSearchNameForBind(name);
            int color = this.getColorForBind(name);
            this.binds.add(new BindInfo(keyBind, name, color, searchName));
        }
    }

    private String getSearchNameForBind(String name) {
        return switch (name) {
            case "\u0417\u0435\u043b\u044c\u0435 \u043e\u0442\u0440\u044b\u0436\u043a\u0438" -> "\u043e\u0442\u0440\u044b\u0436\u043a\u0438";
            case "\u0417\u0435\u043b\u044c\u0435 \u0441\u0435\u0440\u043d\u043e\u0439 \u043a\u0438\u0441\u043b\u043e\u0442\u044b" -> "\u0441\u0435\u0440\u043d\u0430\u044f";
            case "\u0417\u0435\u043b\u044c\u0435 \u0432\u0441\u043f\u044b\u0448\u043a\u0438" -> "\u0432\u0441\u043f\u044b\u0448\u043a\u0430";
            case "\u0417\u0435\u043b\u044c\u0435 \u043c\u043e\u0447\u0438 \u0424\u043b\u0435\u0448\u0430" -> "\u043c\u043e\u0447\u0430 \u0444\u043b\u0435\u0448\u0430";
            case "\u0417\u0435\u043b\u044c\u0435 \u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f" -> "\u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f";
            case "\u0417\u0435\u043b\u044c\u0435 \u0430\u0433\u0435\u043d\u0442\u0430" -> "\u0430\u0433\u0435\u043d\u0442\u0430";
            case "\u0417\u0435\u043b\u044c\u0435 \u043c\u0435\u0434\u0438\u043a\u0430" -> "\u043c\u0435\u0434\u0438\u043a\u0430";
            case "\u0417\u0435\u043b\u044c\u0435 \u043a\u0438\u043b\u043b\u0435\u0440\u0430" -> "\u043a\u0438\u043b\u043b\u0435\u0440\u0430";
            default -> null;
        };
    }

    private int getColorForBind(String name) {
        return switch (name) {
            case "\u0417\u0435\u043b\u044c\u0435 \u043e\u0442\u0440\u044b\u0436\u043a\u0438" -> 16735488;
            case "\u0417\u0435\u043b\u044c\u0435 \u0441\u0435\u0440\u043d\u043e\u0439 \u043a\u0438\u0441\u043b\u043e\u0442\u044b" -> 49664;
            case "\u0417\u0435\u043b\u044c\u0435 \u0432\u0441\u043f\u044b\u0448\u043a\u0438" -> 0xFFFFFF;
            case "\u0417\u0435\u043b\u044c\u0435 \u043c\u043e\u0447\u0438 \u0424\u043b\u0435\u0448\u0430" -> 6092799;
            case "\u0417\u0435\u043b\u044c\u0435 \u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f" -> 65280;
            case "\u0417\u0435\u043b\u044c\u0435 \u0430\u0433\u0435\u043d\u0442\u0430" -> 0xFFFB00;
            case "\u0417\u0435\u043b\u044c\u0435 \u043c\u0435\u0434\u0438\u043a\u0430" -> 16711902;
            case "\u0417\u0435\u043b\u044c\u0435 \u043a\u0438\u043b\u043b\u0435\u0440\u0430" -> 0xFF0000;
            default -> -1;
        };
    }

    private class_1799 createColoredPotion(class_1792 item, int color) {
        class_1799 stack = new class_1799((class_1935)item);
        if (color != -1 && item == class_1802.field_8436) {
            stack.method_57379(class_9334.field_49651, (Object)new class_1844(Optional.empty(), Optional.of(color), List.of(), Optional.empty()));
        }
        return stack;
    }

    private void renderItemStack(class_332 context, class_1799 stack, float x, float y, float scale) {
        class_4587 matrices = context.method_51448();
        matrices.method_22903();
        matrices.method_46416(x, y, 100.0f);
        matrices.method_22905(scale, scale, 1.0f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        class_308.method_24211();
        int hudTextColor = ColorAssist.getHudTextColor();
        float r = (float)(hudTextColor >> 16 & 0xFF) / 255.0f;
        float g = (float)(hudTextColor >> 8 & 0xFF) / 255.0f;
        float b = (float)(hudTextColor & 0xFF) / 255.0f;
        RenderSystem.setShaderColor((float)r, (float)g, (float)b, (float)1.0f);
        context.method_51427(stack, 0, 0);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        class_308.method_24210();
        matrices.method_22909();
    }

    private int countItemInInventory(class_1792 targetItem, String searchName) {
        if (PlayerInteractionHelper.nullCheck()) {
            return 0;
        }
        int count = 0;
        for (int i = 0; i < Binds.mc.field_1724.method_31548().method_5439(); ++i) {
            class_1799 itemStack = Binds.mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7960()) continue;
            if (searchName != null && targetItem == class_1802.field_8436) {
                if (itemStack.method_7909() != targetItem || !InventoryTask.getCleanName(itemStack.method_7964()).contains(searchName.toLowerCase())) continue;
                count += itemStack.method_7947();
                continue;
            }
            if (itemStack.method_7909() != targetItem) continue;
            count += itemStack.method_7947();
        }
        return count;
    }

    private float getCooldownProgress(class_1792 item) {
        if (PlayerInteractionHelper.nullCheck()) {
            return 0.0f;
        }
        class_1799 stack = new class_1799((class_1935)item);
        return Binds.mc.field_1724.method_7357().method_7905(stack, mc.method_61966().method_60637(false));
    }

    private Color getProgressColor(float progress) {
        if (progress <= 0.5f) {
            float t = progress * 2.0f;
            int r = (int)(255.0f * (1.0f - t) + 255.0f * t);
            int g = (int)(0.0f * (1.0f - t) + 165.0f * t);
            int b = 0;
            return new Color(r, g, b);
        }
        float t = (progress - 0.5f) * 2.0f;
        int r = (int)(255.0f * (1.0f - t) + 0.0f * t);
        int g = (int)(165.0f * (1.0f - t) + 255.0f * t);
        int b = 0;
        return new Color(r, g, b);
    }

    @Override
    public boolean visible() {
        if (Binds.mc.field_1724 != null && (Binds.mc.field_1724.method_7325() || Binds.mc.field_1724.method_7337())) {
            return false;
        }
        return Hud.getInstance().interfaceSettings.isSelected("Binds") && Hud.getInstance().state && !this.animation.isFinished(Direction.BACKWARDS);
    }

    @Override
    public void tick() {
        if (PlayerInteractionHelper.nullCheck()) {
            this.animation.setDirection(Direction.BACKWARDS);
            return;
        }
        List<BindInfo> activeBinds = this.binds.stream().filter(this::isBindActive).toList();
        if (!activeBinds.isEmpty()) {
            this.animation.setDirection(Direction.FORWARDS);
        } else if (PlayerInteractionHelper.isChat(Binds.mc.field_1755)) {
            this.animation.setDirection(Direction.FORWARDS);
        } else {
            this.animation.setDirection(Direction.BACKWARDS);
        }
        this.itemCounts.clear();
        for (BindInfo bind : this.binds) {
            int count = this.countItemInInventory(bind.keyBind.item(), bind.searchName);
            this.itemCounts.put(bind.keyBind.item(), count);
        }
        this.activeCooldowns.clear();
        long currentTime = System.currentTimeMillis();
        for (int i = 0; i < Binds.mc.field_1724.method_31548().method_5439(); ++i) {
            class_1799 itemStack = Binds.mc.field_1724.method_31548().method_5438(i);
            if (itemStack.method_7960() || !Binds.mc.field_1724.method_7357().method_7904(itemStack)) continue;
            class_1792 item2 = itemStack.method_7909();
            if (!this.cooldownStartTimes.containsKey(item2)) {
                this.cooldownStartTimes.put(item2, currentTime);
            }
            this.activeCooldowns.add(item2);
        }
        this.cooldownStartTimes.keySet().removeIf(item -> !this.activeCooldowns.contains(item));
        if (activeBinds.isEmpty() && PlayerInteractionHelper.isChat(Binds.mc.field_1755) && currentTime - this.lastBindChange >= 1000L) {
            List<String> availableKeys = List.of("A", "B", "C", "D", "E");
            this.currentRandomKey1 = availableKeys.get(new Random().nextInt(availableKeys.size()));
            this.currentRandomKey2 = availableKeys.get(new Random().nextInt(availableKeys.size()));
            this.currentRandomKey3 = availableKeys.get(new Random().nextInt(availableKeys.size()));
            this.currentItemIndex1 = (this.currentItemIndex1 + 1) % EXAMPLE_ITEMS.length;
            this.currentItemIndex2 = (this.currentItemIndex2 + 1) % EXAMPLE_ITEMS.length;
            this.currentItemIndex3 = (this.currentItemIndex3 + 1) % EXAMPLE_ITEMS.length;
            this.lastBindChange = currentTime;
        }
    }

    private boolean isBindActive(BindInfo bind) {
        return !PlayerInteractionHelper.nullCheck() && bind.keyBind.setting().isVisible() && bind.keyBind.setting().getKey() != -1 && bind.keyBind.setting().getKey() != 0;
    }

    @Override
    public void setScreen(SetScreenEvent e) {
        super.setScreen(e);
        if (PlayerInteractionHelper.nullCheck()) {
            this.animation.setDirection(Direction.BACKWARDS);
            return;
        }
        if (PlayerInteractionHelper.isChat(e.getScreen())) {
            this.animation.setDirection(Direction.FORWARDS);
        } else {
            List<BindInfo> activeBinds = this.binds.stream().filter(this::isBindActive).toList();
            if (!activeBinds.isEmpty()) {
                this.animation.setDirection(Direction.FORWARDS);
            } else {
                this.animation.setDirection(Direction.BACKWARDS);
            }
        }
    }

    @Override
    public void drawDraggable(class_332 context) {
        String[] keys2;
        String name;
        if (!Hud.getInstance().interfaceSettings.isSelected("Binds") || !Hud.getInstance().state || this.animation.isFinished(Direction.BACKWARDS)) {
            return;
        }
        class_4587 matrix = context.method_51448();
        float animationValue = this.animation.getOutput().floatValue();
        if (animationValue <= 0.0f) {
            return;
        }
        List activeBinds = this.binds.stream().filter(this::isBindActive).collect(Collectors.toList());
        float padding = 3.0f;
        float iconSize = 16.0f;
        float spacing = 3.0f;
        float rowHeight = iconSize + 2.0f * padding;
        float posX = this.getX();
        float posY = this.getY();
        int totalBinds = activeBinds.size();
        int rowCount = (int)Math.ceil((double)totalBinds / 5.0);
        ArrayList<Float> rowWidths = new ArrayList<Float>();
        float firstRowWidth = 0.0f;
        FontRenderer font = Fonts.getSize(13, Fonts.Type.DEFAULT);
        if (activeBinds.isEmpty() && PlayerInteractionHelper.isChat(Binds.mc.field_1755)) {
            rowCount = 1;
            name = "Example Bind";
            keys2 = new String[]{this.currentRandomKey1, this.currentRandomKey2, this.currentRandomKey3};
            float textWidth = font.getStringWidth(Arrays.stream(keys2).max((a, b) -> Float.compare(font.getStringWidth((String)a), font.getStringWidth((String)b))).orElse(""));
            float bindWidth = iconSize + padding + textWidth + padding + 4.0f;
            float totalWidth = bindWidth * 3.0f + spacing * 2.0f;
            rowWidths.add(Float.valueOf(totalWidth));
            firstRowWidth = totalWidth;
        } else {
            for (int row = 0; row < rowCount; ++row) {
                float currentX = padding;
                int bindsInThisRow = Math.min(5, totalBinds - row * 5);
                for (int i = 0; i < bindsInThisRow; ++i) {
                    int bindIndex = row * 5 + i;
                    BindInfo bind = (BindInfo)activeBinds.get(bindIndex);
                    String keyName = StringHelper.getBindName(bind.keyBind.setting().getKey());
                    float textWidth = font.getStringWidth(keyName);
                    float bindWidth = iconSize + padding + textWidth + padding + 4.0f;
                    currentX += bindWidth + spacing;
                }
                if (bindsInThisRow > 0) {
                    currentX -= spacing;
                }
                rowWidths.add(Float.valueOf(currentX));
                if (row != 0) continue;
                firstRowWidth = currentX;
            }
        }
        this.width = firstRowWidth + padding;
        this.height = rowHeight * (float)rowCount;
        if (activeBinds.isEmpty() && PlayerInteractionHelper.isChat(Binds.mc.field_1755)) {
            name = "Example Bind";
            keys2 = new String[]{this.currentRandomKey1, this.currentRandomKey2, this.currentRandomKey3};
            class_1799[] stacks = new class_1799[]{new class_1799((class_1935)EXAMPLE_ITEMS[this.currentItemIndex1]), new class_1799((class_1935)EXAMPLE_ITEMS[this.currentItemIndex2]), new class_1799((class_1935)EXAMPLE_ITEMS[this.currentItemIndex3])};
            float offsetX = padding;
            float currentY = posY;
            for (int i = 0; i < 3; ++i) {
                float textWidth = Fonts.getSize(11, Fonts.Type.DEFAULT).getStringWidth(keys2[i]) + 1.5f;
                float backgroundWidth = iconSize + padding + textWidth + padding + 4.0f;
                Hud.getInstance().renderElementBlur(matrix, posX + offsetX - 1.0f, currentY, backgroundWidth, rowHeight - 6.0f, 3.0f);
                rectangle.render(ShapeProperties.create(matrix, posX + offsetX - 1.0f, currentY, backgroundWidth, rowHeight - 6.0f).round(3.0f).thickness(0.1f).outlineColor(new Color(33, 33, 33, 255).getRGB()).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
                Hud.getInstance().renderElementBlur(matrix, posX + offsetX - 1.0f, currentY, 16.0f, rowHeight - 6.0f, 3.0f);
                rectangle.render(ShapeProperties.create(matrix, posX + offsetX - 1.0f, currentY, 16.0, rowHeight - 6.0f).round(0.0f, 0.0f, 3.0f, 3.0f).outlineColor(new Color(33, 33, 33, 255).getRGB()).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
                this.renderItemStack(context, stacks[i], posX + offsetX + 2.0f, currentY + padding + 0.5f, 0.5f);
                float textX = posX + offsetX + iconSize + padding;
                float textY = currentY + padding + (iconSize - Fonts.getSize(11, Fonts.Type.DEFAULT).getStringHeight(keys2[i])) / 2.0f;
                int textAlpha = (int)Math.min(255.0f, Math.max(0.0f, 255.0f * animationValue));
                Fonts.getSize(11, Fonts.Type.DEFAULT).drawString(matrix, keys2[i], textX + 1.0f, textY + 3.0f, ColorAssist.multAlpha(ColorAssist.getHudTextColor(), (float)textAlpha / 255.0f));
                Fonts.getSize(10, Fonts.Type.DEFAULT).drawString(matrix, "64", posX + offsetX + 7.0f, currentY + rowHeight - 12.0f, ColorAssist.multAlpha(ColorAssist.getHudTextColor(), (float)textAlpha / 255.0f));
                offsetX += backgroundWidth + spacing;
            }
        } else {
            for (int row = 0; row < rowCount; ++row) {
                float rowWidth = ((Float)rowWidths.get(row)).floatValue();
                float offsetX = row == 0 ? padding : padding + (firstRowWidth - rowWidth) / 2.0f;
                float currentY = posY + (float)row * rowHeight;
                int bindsInThisRow = Math.min(5, totalBinds - row * 5);
                for (int i = 0; i < bindsInThisRow; ++i) {
                    int bindIndex = row * 5 + i;
                    BindInfo bind = (BindInfo)activeBinds.get(bindIndex);
                    class_1799 stack = this.createColoredPotion(bind.keyBind.item(), bind.color);
                    String keyName = StringHelper.getBindName(bind.keyBind.setting().getKey());
                    float textWidth = Fonts.getSize(11, Fonts.Type.DEFAULT).getStringWidth(keyName) + 1.5f;
                    float backgroundWidth = iconSize + padding + textWidth + padding + 4.0f;
                    int itemCount = this.itemCounts.getOrDefault(bind.keyBind.item(), 0);
                    boolean isEmpty = itemCount == 0;
                    float cooldownProgress = this.getCooldownProgress(bind.keyBind.item());
                    float totalHeight = rowHeight - 6.0f;
                    float cooldownHeight = totalHeight * cooldownProgress;
                    float cooldownStartY = currentY + totalHeight - cooldownHeight;
                    if (isEmpty) {
                        Hud.getInstance().renderElementBlur(matrix, posX + offsetX - 1.0f, currentY, backgroundWidth, rowHeight - 6.0f, 3.0f);
                        rectangle.render(ShapeProperties.create(matrix, posX + offsetX - 1.0f, currentY, backgroundWidth, rowHeight - 6.0f).round(3.0f).outlineColor(new Color(33, 33, 33, 255).getRGB()).color(new Color(150, 0, 0, 255).getRGB()).build());
                        Hud.getInstance().renderElementBlur(matrix, posX + offsetX - 1.0f, currentY, 16.0f, rowHeight - 6.0f, 3.0f);
                        rectangle.render(ShapeProperties.create(matrix, posX + offsetX - 1.0f, currentY, 16.0, rowHeight - 6.0f).round(0.0f, 0.0f, 3.0f, 3.0f).outlineColor(new Color(33, 33, 33, 255).getRGB()).color(new Color(100, 0, 0, 255).getRGB()).build());
                    } else {
                        Hud.getInstance().renderElementBlur(matrix, posX + offsetX - 1.0f, currentY, backgroundWidth, rowHeight - 6.0f, 3.0f);
                        rectangle.render(ShapeProperties.create(matrix, posX + offsetX - 1.0f, currentY, backgroundWidth, rowHeight - 6.0f).round(3.0f).outlineColor(new Color(33, 33, 33, 255).getRGB()).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
                        if (cooldownProgress > 0.0f) {
                            Color progressColor = this.getProgressColor(cooldownProgress);
                            Color progressColorBright = new Color(Math.min(255, (int)((double)progressColor.getRed() * 1.3)), Math.min(255, (int)((double)progressColor.getGreen() * 1.3)), Math.min(255, (int)((double)progressColor.getBlue() * 1.3)), 180);
                            Color color = new Color((int)((double)progressColor.getRed() * 0.6), (int)((double)progressColor.getGreen() * 0.6), (int)((double)progressColor.getBlue() * 0.6), 180);
                        }
                        Hud.getInstance().renderElementBlur(matrix, posX + offsetX - 1.0f, currentY, 16.0f, rowHeight - 6.0f, 3.0f);
                        rectangle.render(ShapeProperties.create(matrix, posX + offsetX - 1.0f, currentY, 16.0, rowHeight - 6.0f).round(0.0f, 0.0f, 3.0f, 3.0f).outlineColor(new Color(33, 33, 33, 255).getRGB()).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
                    }
                    this.renderItemStack(context, stack, posX + offsetX + 2.0f, currentY + padding + 0.5f, 0.5f);
                    float textX = posX + offsetX + iconSize + padding;
                    float textY = currentY + padding + (iconSize - Fonts.getSize(11, Fonts.Type.DEFAULT).getStringHeight(keyName)) / 2.0f;
                    int textAlpha = (int)Math.min(255.0f, Math.max(0.0f, 255.0f * animationValue));
                    Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(matrix, keyName, textX + 1.0f, textY + 3.0f, ColorAssist.multAlpha(ColorAssist.getHudTextColor(), (float)textAlpha / 255.0f));
                    Fonts.getSize(10, Fonts.Type.DEFAULT).drawString(matrix, String.valueOf(itemCount), posX + offsetX + 7.0f, currentY + rowHeight - 12.0f, ColorAssist.multAlpha(ColorAssist.getHudTextColor(), (float)textAlpha / 255.0f));
                    offsetX += backgroundWidth + spacing;
                }
            }
        }
        this.setWidth((int)this.width);
        this.setHeight((int)this.height);
    }

    private static class BindInfo {
        FuntimeAssist.KeyBind keyBind;
        String displayName;
        int color;
        String searchName;

        BindInfo(FuntimeAssist.KeyBind keyBind, String displayName, int color, String searchName) {
            this.keyBind = keyBind;
            this.displayName = displayName;
            this.color = color;
            this.searchName = searchName;
        }
    }
}

