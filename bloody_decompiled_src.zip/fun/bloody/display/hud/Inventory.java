/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.hud;

import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class Inventory
extends AbstractDraggable {
    List<class_1799> stacks = new ArrayList<class_1799>();

    public Inventory() {
        super("Inventory", 385, 40, 123, 60, true);
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("Inventory") && (!this.stacks.stream().filter(stack -> !stack.method_7960()).toList().isEmpty() || PlayerInteractionHelper.isChat(Inventory.mc.field_1755));
    }

    @Override
    public void tick() {
        this.stacks = IntStream.range(9, 36).mapToObj(i -> Inventory.mc.field_1724.field_7514.method_5438(i)).toList();
    }

    @Override
    public void drawDraggable(class_332 context) {
        class_4587 matrix = context.method_51448();
        FontRenderer font = Fonts.getSize(14, Fonts.Type.DEFAULT);
        FontRenderer items = Fonts.getSize(12, Fonts.Type.DEFAULT);
        FontRenderer icon = Fonts.getSize(20, Fonts.Type.ICONS);
        long itemCount = this.stacks.stream().filter(stack -> !stack.method_7960()).mapToInt(class_1799::method_7947).sum();
        String itemCountText = String.valueOf(itemCount);
        float textWidth = items.getStringWidth(itemCountText);
        float boxWidth = textWidth + 6.0f;
        Hud.getInstance().renderElementBlur(matrix, this.getX(), this.getY(), this.getWidth(), 15.5f, 4.0f);
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), 15.5).round(4.0f, 0.0f, 4.0f, 0.0f).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
        Hud.getInstance().renderElementBlur(matrix, this.getX(), (float)this.getY() + 16.4f, this.getWidth(), this.getHeight() - 15, 4.0f);
        rectangle.render(ShapeProperties.create(matrix, this.getX(), (float)this.getY() + 16.4f, this.getWidth(), this.getHeight() - 15).round(0.0f, 4.0f, 0.0f, 4.0f).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
        float iconX = this.getX() + this.getWidth() - 20;
        icon.drawString(matrix, "F", iconX, (float)this.getY() + 5.0f, ColorAssist.getHudTextColor());
        font.drawString(matrix, this.getName(), this.getX() + 4, (float)this.getY() + 6.5f, ColorAssist.getHudTextColor());
        int offsetY = 20;
        int offsetX = 4;
        int itemsPerRow = 9;
        int itemIndex = 0;
        for (class_1799 stack2 : this.stacks) {
            float itemX = this.getX() + offsetX + 1;
            float itemY = (float)(this.getY() + offsetY) + 1.0f;
            if (itemIndex % itemsPerRow != itemsPerRow - 1) {
                rectangle.render(ShapeProperties.create(matrix, itemX + 10.0f, itemY, 0.5, 9.0).color(ColorAssist.getText(0.1f)).round(0.0f).build());
            }
            if (itemIndex < this.stacks.size() - itemsPerRow) {
                rectangle.render(ShapeProperties.create(matrix, itemX - 0.5f, itemY + 10.0f, 9.0, 0.5).color(ColorAssist.getText(0.1f)).round(0.0f).build());
            }
            Render2D.defaultDrawStack(context, stack2, itemX - 1.0f, itemY - 1.0f, false, true, 0.5f);
            offsetX += 13;
            if (++itemIndex % itemsPerRow != 0) continue;
            offsetY += 13;
            offsetX = 4;
        }
    }
}

