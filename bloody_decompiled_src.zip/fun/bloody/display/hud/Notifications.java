/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_1297
 *  net.minecraft.class_1542
 *  net.minecraft.class_1799
 *  net.minecraft.class_2561
 *  net.minecraft.class_2596
 *  net.minecraft.class_2653
 *  net.minecraft.class_2775
 *  net.minecraft.class_332
 *  net.minecraft.class_3414
 *  net.minecraft.class_408
 *  net.minecraft.class_4587
 *  net.minecraft.class_5250
 *  net.minecraft.class_9288
 *  net.minecraft.class_9334
 */
package fun.bloody.display.hud;

import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.events.container.SetScreenEvent;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.features.impl.misc.Unhook;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.client.sound.SoundManager;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.color.HudColorHelper;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.math.calc.Calculate;
import java.lang.runtime.SwitchBootstraps;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2653;
import net.minecraft.class_2775;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_408;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_9288;
import net.minecraft.class_9334;

public class Notifications
extends AbstractDraggable {
    private final List<Notification> list = new ArrayList<Notification>();
    private final List<Stack> stacks = new ArrayList<Stack>();
    private boolean lowHealthWarned = false;
    private static final String TEST_MESSAGE = "\u042d\u0442\u043e \u0442\u0435\u0441\u0442\u043e\u0432\u043e\u0435 \u0441\u043e\u043e\u0431\u0449\u0435\u043d\u0438\u0435";

    public static Notifications getInstance() {
        return Instance.getDraggable(Notifications.class);
    }

    public Notifications() {
        super("Notifications", 0, 50, 100, 15, true);
    }

    @Override
    public void tick() {
        if (Unhook.unhooked) {
            this.list.clear();
            this.stacks.clear();
            return;
        }
        this.list.forEach(notif -> {
            boolean isChatOpen = Notifications.mc.field_1755 instanceof class_408;
            if (!isChatOpen && (System.currentTimeMillis() > notif.removeTime || notif.text.getString().contains("t.me/scamware_su") && !PlayerInteractionHelper.isChat(Notifications.mc.field_1755))) {
                notif.anim.setDirection(Direction.BACKWARDS);
            }
        });
        this.list.removeIf(notif -> notif.anim.isFinished(Direction.BACKWARDS));
        while (!this.stacks.isEmpty()) {
            this.addTextIfNotEmpty(TypePickUp.INVENTORY, "\u041f\u043e\u0434\u043d\u044f\u0442\u044b \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u044b: ");
            this.addTextIfNotEmpty(TypePickUp.SHULKER_INVENTORY, "\u0421\u043b\u043e\u0436\u0435\u043d\u044b \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u044b \u0432 \u0448\u0430\u043b\u043a\u0435\u0440: ");
            this.addTextIfNotEmpty(TypePickUp.SHULKER, "\u041f\u043e\u0434\u043d\u044f\u0442 \u0448\u0430\u043b\u043a\u0435\u0440 \u0441: ");
        }
        if (Notifications.mc.field_1724 != null && Hud.getInstance().interfaceSettings.isSelected("Notifications")) {
            float health = Notifications.mc.field_1724.method_6032();
            if (health <= 6.0f && !this.lowHealthWarned) {
                this.addList(String.valueOf(class_124.field_1061) + "\u0412\u043d\u0438\u043c\u0430\u043d\u0438\u0435! \u0423 \u0432\u0430\u0441 " + String.valueOf(class_124.field_1068) + (int)health + " HP", 5000L);
                this.lowHealthWarned = true;
            } else if (health > 6.0f) {
                this.lowHealthWarned = false;
            }
        }
    }

    @Override
    public void packet(PacketEvent e) {
        if (!PlayerInteractionHelper.nullCheck()) {
            class_2596<?> class_25962 = e.getPacket();
            Objects.requireNonNull(class_25962);
            class_2596<?> class_25963 = class_25962;
            int n = 0;
            block4: while (true) {
                switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{class_2775.class, class_2653.class}, class_25963, n)) {
                    case 0: {
                        class_1297 class_12972;
                        class_2775 item = (class_2775)class_25963;
                        if (!Hud.getInstance().interfaceSettings.isSelected("Notifications") || item.method_11912() != Objects.requireNonNull(Notifications.mc.field_1724).method_5628() || !((class_12972 = Objects.requireNonNull(Notifications.mc.field_1687).method_8469(item.method_11915())) instanceof class_1542)) {
                            n = 1;
                            continue block4;
                        }
                        class_1542 entity = (class_1542)class_12972;
                        class_1799 itemStack = entity.method_6983();
                        class_9288 component = (class_9288)itemStack.method_57824(class_9334.field_49622);
                        if (component == null) {
                            class_2561 itemText = itemStack.method_7964();
                            if (!itemText.method_10851().toString().equals("empty")) break block4;
                            class_5250 text = class_2561.method_43473().method_10852(itemText);
                            if (itemStack.method_7947() > 1) {
                                text.method_27693(String.valueOf(class_124.field_1070) + " [" + String.valueOf(class_124.field_1061) + itemStack.method_7947() + String.valueOf(class_124.field_1080) + "x" + String.valueOf(class_124.field_1070) + "]");
                            }
                            this.stacks.add(new Stack(TypePickUp.INVENTORY, text));
                            break block4;
                        }
                        component.method_57489().filter(s -> s.method_7964().method_10851().toString().equals("empty")).forEach(stack -> {
                            class_5250 text = class_2561.method_43473().method_10852(stack.method_7964());
                            if (stack.method_7947() > 1) {
                                text.method_27693(String.valueOf(class_124.field_1070) + " [" + String.valueOf(class_124.field_1061) + stack.method_7947() + String.valueOf(class_124.field_1080) + "x" + String.valueOf(class_124.field_1070) + "]");
                            }
                            this.stacks.add(new Stack(TypePickUp.SHULKER, text));
                        });
                        break block4;
                    }
                    case 1: {
                        class_9288 currentContainer;
                        class_2653 slot = (class_2653)class_25963;
                        int slotId = slot.method_11450();
                        class_9288 updatedContainer = (class_9288)slot.method_11449().method_57824(class_9334.field_49622);
                        if (updatedContainer == null || slotId >= Objects.requireNonNull(Notifications.mc.field_1724).field_7512.field_7761.size() || slot.method_11452() != 0 || (currentContainer = (class_9288)Notifications.mc.field_1724.field_7512.method_7611(slotId).method_7677().method_57824(class_9334.field_49622)) == null) break block4;
                        updatedContainer.method_57489().filter(stack -> currentContainer.method_57489().noneMatch(s -> Objects.equals(s.method_57353(), stack.method_57353()) && s.toString().equals(stack.toString()))).forEach(stack -> {
                            class_5250 text = class_2561.method_43473().method_10852(stack.method_7964());
                            this.stacks.add(new Stack(TypePickUp.SHULKER_INVENTORY, text));
                        });
                        break block4;
                    }
                }
                break;
            }
        }
    }

    @Override
    public void setScreen(SetScreenEvent e) {
        super.setScreen(e);
        if (e.getScreen() instanceof class_408 && Hud.getInstance().interfaceSettings.isSelected("Notifications")) {
            this.addList(TEST_MESSAGE, 999999999L);
        } else if (e.getScreen() == null || !(e.getScreen() instanceof class_408)) {
            this.list.removeIf(notif -> notif.text.getString().equals(TEST_MESSAGE));
        }
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("Notifications") && !this.list.isEmpty();
    }

    @Override
    public void drawDraggable(class_332 context) {
        boolean isLeft;
        class_4587 matrix = context.method_51448();
        FontRenderer font = Fonts.getSize(12, Fonts.Type.DEFAULT);
        FontRenderer fontIcons = Fonts.getSize(16, Fonts.Type.ICONS);
        int screenWidth = mc.method_22683().method_4486();
        float elementCenterX = this.getX() + this.getWidth() / 2;
        boolean isRight = elementCenterX > (float)screenWidth * 2.0f / 3.0f;
        boolean bl = isLeft = elementCenterX < (float)screenWidth / 3.0f;
        float alignmentOffset = isLeft ? 8.0f : (isRight ? (float)this.getWidth() - 8.0f : (float)this.getWidth() / 2.0f);
        float offsetX = 5.0f;
        if (isRight) {
            float totalHeight = 0.0f;
            for (Notification notification : this.list) {
                float anim = notification.anim.getOutput().floatValue();
                totalHeight += (float)(this.getHeight() + 3) * anim;
            }
            float offsetY = totalHeight;
            for (Notification notification : this.list) {
                float anim = notification.anim.getOutput().floatValue();
                float width = font.getStringWidth(notification.text) + offsetX * 2.0f;
                float startY = (float)(this.getY() + this.getHeight()) - offsetY;
                float startX = (float)this.getX() + alignmentOffset - width;
                Calculate.setAlpha(anim, () -> {
                    Hud.getInstance().renderElementBlur(matrix, startX, startY, width, this.getHeight(), 4.0f);
                    rectangle.render(ShapeProperties.create(matrix, startX, startY, width, this.getHeight()).round(4.0f).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
                    String cleanText = ColorAssist.removeFormatting(notification.text.getString());
                    font.drawString(matrix, cleanText, (int)(startX + offsetX), startY + 6.5f, HudColorHelper.getWatermarkTextColor());
                    float iconX = (float)this.getX() + alignmentOffset - width - 15.2f;
                    Hud.getInstance().renderElementBlur(matrix, iconX - 3.8f, startY, 16.0f, this.getHeight(), 4.0f);
                    rectangle.render(ShapeProperties.create(matrix, iconX - 3.8f, startY, 16.0, this.getHeight()).round(4.0f).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
                    fontIcons.drawString(matrix, "G", iconX, startY + 6.5f, HudColorHelper.getWatermarkTextColor());
                });
                offsetY -= (float)(this.getHeight() + 3) * anim;
            }
        } else {
            float offsetY = 0.0f;
            for (Notification notification : this.list) {
                float anim = notification.anim.getOutput().floatValue();
                float width = font.getStringWidth(notification.text) + offsetX * 2.0f;
                float startY = (float)this.getY() + offsetY;
                float startX = isLeft ? (float)this.getX() + alignmentOffset : (float)this.getX() + alignmentOffset - width / 2.0f + 8.0f;
                Calculate.setAlpha(anim, () -> {
                    Hud.getInstance().renderElementBlur(matrix, startX, startY, width, this.getHeight(), 4.0f);
                    rectangle.render(ShapeProperties.create(matrix, startX, startY, width, this.getHeight()).round(4.0f).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
                    String cleanText = ColorAssist.removeFormatting(notification.text.getString());
                    font.drawString(matrix, cleanText, (int)(startX + offsetX), startY + 6.5f, HudColorHelper.getWatermarkTextColor());
                    float iconX = startX - 15.2f;
                    Hud.getInstance().renderElementBlur(matrix, iconX - 3.8f, startY, 16.0f, this.getHeight(), 4.0f);
                    rectangle.render(ShapeProperties.create(matrix, iconX - 3.8f, startY, 16.0, this.getHeight()).round(4.0f).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
                    fontIcons.drawString(matrix, "G", iconX, startY + 6.5f, HudColorHelper.getWatermarkTextColor());
                });
                offsetY += (float)(this.getHeight() + 3) * anim;
            }
        }
    }

    private void addTextIfNotEmpty(TypePickUp type, String prefix) {
        class_5250 text = class_2561.method_43473();
        List<Stack> list = this.stacks.stream().filter(stack -> stack.type.equals((Object)type)).toList();
        int size = list.size();
        for (int i = 0; i < size; ++i) {
            Stack stack2 = list.get(i);
            if (stack2.type != type) continue;
            text.method_10852((class_2561)stack2.text);
            this.stacks.remove(stack2);
            if (text.getString().length() > 150) break;
            if (i + 1 == size) continue;
            text.method_27693(" ,  ");
        }
        if (!text.equals((Object)class_2561.method_43473())) {
            this.addList((class_2561)class_2561.method_43473().method_27693(prefix).method_10852((class_2561)text), 8000L);
        }
    }

    public void addList(String text, long removeTime) {
        this.addList(text, removeTime, null);
    }

    public void addList(class_2561 text, long removeTime) {
        this.addList(text, removeTime, null);
    }

    public void addList(String text, long removeTime, class_3414 sound) {
        this.addList((class_2561)class_2561.method_43473().method_27693(text), removeTime, sound);
    }

    public void addList(class_2561 text, long removeTime, class_3414 sound) {
        if (Unhook.unhooked) {
            return;
        }
        this.list.add(new Notification(text, new Decelerate().setMs(300).setValue(1.0), System.currentTimeMillis() + removeTime));
        if (this.list.size() > 12) {
            this.list.removeFirst();
        }
        this.list.sort(Comparator.comparingDouble(notif -> -notif.removeTime));
        if (sound != null) {
            SoundManager.playSound(sound);
        }
    }

    public static enum TypePickUp {
        INVENTORY,
        SHULKER,
        SHULKER_INVENTORY;

    }

    public record Stack(TypePickUp type, class_5250 text) {
    }

    public record Notification(class_2561 text, Animation anim, long removeTime) {
    }
}

