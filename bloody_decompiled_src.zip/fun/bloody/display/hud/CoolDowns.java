/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 *  net.minecraft.class_2596
 *  net.minecraft.class_2656
 *  net.minecraft.class_2724
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_7923
 */
package fun.bloody.display.hud;

import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.chat.StringHelper;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.math.calc.Calculate;
import fun.bloody.utils.math.time.StopWatch;
import java.awt.Color;
import java.lang.runtime.SwitchBootstraps;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2656;
import net.minecraft.class_2724;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_7923;

public class CoolDowns
extends AbstractDraggable {
    public final List<CoolDown> list = new ArrayList<CoolDown>();
    private long lastItemChange = 0L;
    private int currentItemIndex = 0;
    private static final class_1792[] EXAMPLE_ITEMS = new class_1792[]{class_1802.field_8449, class_1802.field_8634, class_1802.field_8479, class_1802.field_49814, class_1802.field_8367, class_1802.field_8547, class_1802.field_8399, class_1802.field_8551, class_1802.field_22021};

    public static CoolDowns getInstance() {
        return Instance.getDraggable(CoolDowns.class);
    }

    public CoolDowns() {
        super("Cooldowns", 10, 40, 80, 23, true);
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("Cooldowns") && (!this.list.isEmpty() || PlayerInteractionHelper.isChat(CoolDowns.mc.field_1755));
    }

    @Override
    public void tick() {
        long currentTime;
        this.list.removeIf(c -> c.anim.isFinished(Direction.BACKWARDS));
        this.list.stream().filter(c -> !Objects.requireNonNull(CoolDowns.mc.field_1724).method_7357().method_7904(c.item.method_7854())).forEach(coolDown -> coolDown.anim.setDirection(Direction.BACKWARDS));
        if (this.list.isEmpty() && PlayerInteractionHelper.isChat(CoolDowns.mc.field_1755) && (currentTime = System.currentTimeMillis()) - this.lastItemChange >= 1000L) {
            this.currentItemIndex = (this.currentItemIndex + 1) % EXAMPLE_ITEMS.length;
            this.lastItemChange = currentTime;
        }
    }

    @Override
    public void packet(PacketEvent e) {
        if (PlayerInteractionHelper.nullCheck()) {
            return;
        }
        class_2596<?> class_25962 = e.getPacket();
        Objects.requireNonNull(class_25962);
        class_2596<?> class_25963 = class_25962;
        int n = 0;
        switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{class_2656.class, class_2724.class}, class_25963, n)) {
            case 0: {
                class_2656 c = (class_2656)class_25963;
                class_1792 item = (class_1792)class_7923.field_41178.method_63535(c.comp_3082());
                this.list.stream().filter(coolDown -> coolDown.item.equals(item)).forEach(coolDown -> coolDown.anim.setDirection(Direction.BACKWARDS));
                if (c.comp_2199() == 0) break;
                this.list.add(new CoolDown(item, new StopWatch().setMs((long)(-c.comp_2199()) * 50L), new Decelerate().setMs(150).setValue(1.0)));
                break;
            }
            case 1: {
                class_2724 p = (class_2724)class_25963;
                this.list.clear();
                break;
            }
        }
    }

    @Override
    public void drawDraggable(class_332 context) {
        class_4587 matrix = context.method_51448();
        FontRenderer font = Fonts.getSize(13, Fonts.Type.DEFAULT);
        FontRenderer fontCoolDown = Fonts.getSize(13, Fonts.Type.DEFAULT);
        FontRenderer icon = Fonts.getSize(21, Fonts.Type.ICONRICHREGREG);
        FontRenderer icon2 = Fonts.getSize(14, Fonts.Type.ICONSTYPENEW);
        FontRenderer items = Fonts.getSize(12, Fonts.Type.ICONbloodyREG);
        long activeCooldowns = this.list.stream().filter(c -> !c.anim.isFinished(Direction.BACKWARDS)).count();
        String cooldownCountText = String.valueOf(activeCooldowns);
        float textWidth = items.getStringWidth(cooldownCountText);
        float boxWidth = textWidth + 6.0f;
        Hud.getInstance().renderElementBlur(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight(), 4.0f);
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight()).round(4.0f).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
        float iconX = this.getX() + this.getWidth() - 18;
        icon.drawString(matrix, "D", iconX, (float)this.getY() + 5.0f, ColorAssist.getHudTextColor());
        font.drawString(matrix, this.getName(), this.getX() + 4, (float)this.getY() + 6.5f, ColorAssist.getHudTextColor());
        float centerX = (float)this.getX() + (float)this.getWidth() / 2.0f;
        int offset = 23;
        int maxWidth = 110;
        if (this.list.isEmpty() && PlayerInteractionHelper.isChat(CoolDowns.mc.field_1755)) {
            float centerY = this.getY() + offset;
            class_1792 item = EXAMPLE_ITEMS[this.currentItemIndex];
            String name = "Example CoolDowns";
            String duration = "**:**";
            int hudTextColor = ColorAssist.getHudTextColor();
            int textAlpha = 255;
            int colorWithAlpha = ColorAssist.rgba(hudTextColor >> 16 & 0xFF, hudTextColor >> 8 & 0xFF, hudTextColor & 0xFF, textAlpha);
            Calculate.scale(matrix, centerX, centerY, 1.0f, 1.0f, () -> {
                Render2D.drawStack(matrix, item.method_7854(), (float)this.getX() + 3.5f, centerY - 3.0f, false, 0.5f);
                fontCoolDown.drawString(matrix, name, this.getX() + 18, centerY + 1.0f, colorWithAlpha);
                float timerX = (float)(this.getX() + this.getWidth()) - fontCoolDown.getStringWidth(duration) - 8.0f - 12.0f;
                float timerY = centerY - 2.0f;
                icon2.drawString(matrix, "n", timerX + 2.0f, centerY + 1.0f, hudTextColor);
                fontCoolDown.drawString(matrix, duration, timerX + 12.0f, centerY + 1.0f, hudTextColor);
            });
            int width = (int)fontCoolDown.getStringWidth(name + duration) + 30;
            maxWidth = Math.max(width, maxWidth);
            offset += 11;
        } else {
            for (CoolDown coolDown : this.list) {
                float animation = coolDown.anim.getOutput().floatValue();
                float centerY = this.getY() + offset;
                long elapsedTime = coolDown.time.elapsedTime();
                int time = 0;
                time = elapsedTime >= Integer.MIN_VALUE && elapsedTime <= Integer.MAX_VALUE ? (int)(-elapsedTime / 1000L) : (elapsedTime < 0L ? Integer.MAX_VALUE : Integer.MIN_VALUE);
                String name = coolDown.item.method_7854().method_7964().getString();
                String duration = StringHelper.getDuration(time);
                int textColor = ColorAssist.getText();
                int textAlpha = 255;
                int colorWithAlpha = ColorAssist.rgba(textColor >> 16 & 0xFF, textColor >> 8 & 0xFF, textColor & 0xFF, textAlpha);
                int color = new Color(225, 225, 255, 255).getRGB();
                float durationWidth = fontCoolDown.getStringWidth(duration);
                float durationBoxWidth = durationWidth + 6.0f;
                Calculate.scale(matrix, centerX, centerY, 1.0f, animation, () -> {
                    Render2D.drawStack(matrix, coolDown.item.method_7854(), (float)this.getX() + 3.5f, centerY - 3.0f, false, 0.5f);
                    fontCoolDown.drawString(matrix, name, this.getX() + 18, centerY + 1.0f, colorWithAlpha);
                    float timerX = (float)(this.getX() + this.getWidth()) - durationWidth - 8.0f - 12.0f;
                    float timerY = centerY - 2.0f;
                    float timerWidth = durationWidth + 18.0f;
                    float timerHeight = 10.0f;
                    icon2.drawString(matrix, "n", timerX + 2.0f, centerY + 1.0f, new Color(225, 225, 255, 255).getRGB());
                    fontCoolDown.drawString(matrix, duration, timerX + 12.0f, centerY + 1.0f, color);
                });
                int width = (int)fontCoolDown.getStringWidth(name + duration) + 30;
                maxWidth = Math.max(width, maxWidth);
                offset += (int)(11.0f * animation);
            }
        }
        this.setWidth(maxWidth + 10);
        this.setHeight(offset);
    }

    public record CoolDown(class_1792 item, StopWatch time, Animation anim) {
    }
}

