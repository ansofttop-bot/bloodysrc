/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_2338
 *  net.minecraft.class_332
 */
package fun.bloody.display.hud;

import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.client.packet.network.Network;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.interactions.simulate.Simulations;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_332;

public class PlayerInfo
extends AbstractDraggable {
    public PlayerInfo() {
        super("PlayerInfo", 0, 0, 60, 0, false);
    }

    @Override
    public void drawDraggable(class_332 context) {
        int offset = PlayerInteractionHelper.isChat(PlayerInfo.mc.field_1755) ? -28 : -15;
        this.setY(window.method_4502() + offset);
        FontRenderer font = Fonts.getSize(14, Fonts.Type.DEFAULT);
        class_2338 blockPos = PlayerInfo.mc.field_1724.method_24515();
        String bps = "Bps: " + Calculate.round(Simulations.getSpeedSqrt((class_1297)PlayerInfo.mc.field_1724) * 20.0, 0.25);
        String tps = "Tps: " + Calculate.round(Network.TPS, 0.1f);
        String xyz = "Xyz: " + blockPos.method_10263() + ", " + blockPos.method_10264() + ", " + blockPos.method_10260();
        String text = xyz + " \u2022 " + tps + " \u2022 " + bps;
        float width = font.getStringWidth(text) + 10.0f;
        this.setWidth((int)width);
        this.setHeight(15);
        Hud.getInstance().renderElementBlur(context.method_51448(), this.getX(), this.getY(), this.getWidth(), this.getHeight(), 4.0f);
        font.drawGradientString(context.method_51448(), text, this.getX() + 3, (float)this.getY() + 6.5f, new Color(225, 225, 255, 255).getRGB(), new Color(255, 255, 255, 255).getRGB());
    }
}

