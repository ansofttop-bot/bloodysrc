/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.class_10042
 *  net.minecraft.class_124
 *  net.minecraft.class_1297
 *  net.minecraft.class_2561
 *  net.minecraft.class_268
 *  net.minecraft.class_269
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_5250
 *  net.minecraft.class_640
 *  net.minecraft.class_897
 *  net.minecraft.class_922
 */
package fun.bloody.display.hud;

import com.mojang.authlib.GameProfile;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.common.repository.staff.StaffRepository;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.client.packet.network.Network;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.color.HudColorHelper;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import net.minecraft.class_10042;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import net.minecraft.class_897;
import net.minecraft.class_922;

public class StaffList
extends AbstractDraggable {
    public final Map<class_640, Animation> list = new HashMap<class_640, Animation>();
    private final Set<String> notifiedPlayers = new HashSet<String>();
    private final Pattern namePattern = Pattern.compile("^\\w{3,16}$");
    private long lastColorChange = 0L;
    private int currentColorIndex = 0;
    private static final Map<String, String> CHAR_TO_NAME = new HashMap<String, String>();
    private static final Map<String, Integer> PREFIX_COLORS = new HashMap<String, Integer>();

    public static StaffList getInstance() {
        return Instance.getDraggable(StaffList.class);
    }

    public StaffList() {
        super("Staff", 115, 40, 80, 23, true);
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("Staff") && (!this.list.isEmpty() || PlayerInteractionHelper.isChat(StaffList.mc.field_1755));
    }

    @Override
    public void tick() {
        if (StaffList.mc.field_1687 == null || StaffList.mc.field_1724 == null || mc.method_1562() == null) {
            this.list.clear();
            return;
        }
        Collection playerList = mc.method_1562().method_2880();
        class_269 scoreboard = StaffList.mc.field_1687.method_8428();
        HashSet<String> addedNames = new HashSet<String>();
        if (this.list.isEmpty() && PlayerInteractionHelper.isChat(StaffList.mc.field_1755)) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - this.lastColorChange >= 1000L) {
                this.currentColorIndex = (this.currentColorIndex + 1) % PREFIX_COLORS.size();
                this.lastColorChange = System.currentTimeMillis();
            }
            return;
        }
        for (class_640 entry2 : playerList) {
            String name = entry2.method_2966().getName();
            if (addedNames.contains(name) || this.list.containsKey(entry2)) continue;
            String string = entry2.method_2971() != null ? entry2.method_2971().getString() : name;
        }
        for (StaffRepository.Staff staff : StaffRepository.getStaff()) {
            String staffName = staff.getName();
            if (addedNames.contains(staffName) || this.list.keySet().stream().anyMatch(e -> e.method_2966().getName().equals(staffName))) continue;
            playerList.stream().filter(p -> p.method_2966().getName().equalsIgnoreCase(staffName)).findFirst().ifPresent(entry -> {
                this.list.put((class_640)entry, new Decelerate().setMs(150).setValue(1.0));
                addedNames.add(staffName);
            });
        }
        ArrayList<class_268> teams = new ArrayList<class_268>(scoreboard.method_1159());
        teams.sort(Comparator.comparing(class_268::method_1197));
        Collection online = mc.method_1562().method_2880();
        for (class_268 team : teams) {
            boolean present;
            String name;
            Collection members = team.method_1204();
            if (members.size() != 1 || !this.namePattern.matcher(name = (String)members.iterator().next()).matches() || addedNames.contains(name) || (present = online.stream().anyMatch(e -> e.method_2966() != null && name.equals(e.method_2966().getName()))) || this.list.keySet().stream().anyMatch(e -> e.method_2966().getName().equals(name))) continue;
            String teamPrefix = team.method_1144().getString();
            String prefix = CHAR_TO_NAME.entrySet().stream().filter(e -> teamPrefix.contains((CharSequence)e.getKey())).map(Map.Entry::getValue).findFirst().orElse("");
            class_5250 displayName = class_2561.method_43473();
            if (Network.isReallyWorld()) {
                displayName.method_10852((class_2561)class_2561.method_43470((String)name).method_27692(class_124.field_1080)).method_10852((class_2561)class_2561.method_43470((String)" [").method_27692(class_124.field_1080)).method_10852((class_2561)class_2561.method_43470((String)(prefix.isEmpty() ? "V" : prefix)).method_27692(class_124.field_1070)).method_10852((class_2561)class_2561.method_43470((String)"]").method_27692(class_124.field_1080));
            } else {
                displayName.method_10852((class_2561)class_2561.method_43470((String)"[").method_27692(class_124.field_1080)).method_10852((class_2561)class_2561.method_43470((String)(prefix.isEmpty() ? "V" : prefix)).method_27692(class_124.field_1070)).method_10852((class_2561)class_2561.method_43470((String)"] ").method_27692(class_124.field_1080)).method_10852((class_2561)class_2561.method_43470((String)name).method_27692(class_124.field_1080));
            }
            GameProfile fakeProfile = new GameProfile(UUID.randomUUID(), name);
            class_640 fake = new class_640(fakeProfile, mc.method_1542());
            fake.method_2962((class_2561)displayName);
            fake.method_62153(Integer.MIN_VALUE);
            this.list.put(fake, new Decelerate().setMs(150).setValue(1.0));
            addedNames.add(name);
        }
        this.list.entrySet().removeIf(entry -> {
            String name = ((class_640)entry.getKey()).method_2966().getName();
            boolean isFromRepo = StaffRepository.isStaff(name);
            boolean inPlayerList = playerList.stream().anyMatch(p -> p.method_2966().getName().equals(name));
            boolean inTeam = scoreboard.method_1159().stream().flatMap(t -> t.method_1204().stream()).anyMatch(name::equals);
            boolean shouldRemove = false;
            if (isFromRepo) {
                if (!inPlayerList) {
                    shouldRemove = true;
                }
            } else if (inPlayerList || !inTeam) {
                shouldRemove = true;
            }
            if (shouldRemove) {
                ((Animation)entry.getValue()).setDirection(Direction.BACKWARDS);
            }
            if (((Animation)entry.getValue()).isFinished(Direction.BACKWARDS)) {
                this.notifiedPlayers.remove(name);
                return true;
            }
            return false;
        });
    }

    @Override
    public void drawDraggable(class_332 context) {
        class_4587 matrix = context.method_51448();
        FontRenderer font = Fonts.getSize(13, Fonts.Type.DEFAULT);
        FontRenderer fontPlayer = Fonts.getSize(13, Fonts.Type.DEFAULT);
        FontRenderer icon = Fonts.getSize(19, Fonts.Type.ICONbloodyREG);
        FontRenderer items = Fonts.getSize(12, Fonts.Type.ICONbloodyREG);
        long activeStaff = this.list.entrySet().stream().filter(e -> !((Animation)e.getValue()).isFinished(Direction.BACKWARDS)).count();
        String staffCountText = String.valueOf(activeStaff);
        float textWidth = items.getStringWidth(staffCountText);
        float boxWidth = textWidth + 6.0f;
        Hud.getInstance().renderElementBlur(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight(), 4.0f);
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight()).round(4.0f).color(HudColorHelper.getStaffBackground().getRGB()).build());
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight()).round(4.0f).thickness(0.5f).outlineColor(ColorAssist.setAlpha(ColorAssist.getClientColor(), 80)).color(0).build());
        float iconX = this.getX() + this.getWidth() - 18;
        icon.drawString(matrix, "G", iconX, (float)this.getY() + 5.0f, HudColorHelper.getStaffTextColor());
        font.drawString(matrix, this.getName(), this.getX() + 4, (float)this.getY() + 6.5f, HudColorHelper.getStaffTextColor());
        float centerX = (float)this.getX() + (float)this.getWidth() / 2.0f;
        int offset = 23;
        int maxWidth = 80;
        Collection playerList = Objects.requireNonNull(StaffList.mc.field_1724).field_3944.method_2880();
        for (Map.Entry<class_640, Animation> staff : this.list.entrySet()) {
            class_640 player = staff.getKey();
            if (player == null) continue;
            String name = player.method_2966().getName();
            float centerY = this.getY() + offset;
            float animation = staff.getValue().getOutput().floatValue();
            boolean isVisible = playerList.stream().anyMatch(p -> p.method_2966().getName().equals(name));
            class_640 renderEntry = isVisible ? playerList.stream().filter(p -> p.method_2966().getName().equals(name)).findFirst().orElse(player) : player;
            String displayName = renderEntry.method_2971() != null ? renderEntry.method_2971().getString() : name;
            String prefix = CHAR_TO_NAME.entrySet().stream().filter(e -> displayName.contains((CharSequence)e.getKey())).map(Map.Entry::getValue).findFirst().orElse("Vanish");
            int prefixColor = PREFIX_COLORS.getOrDefault(prefix, new Color(255, 0, 0, 255).getRGB());
            class_2960 skinTexture = renderEntry.method_52810().comp_1626();
            int textColor = HudColorHelper.getStaffTextColor();
            int textAlpha = 255;
            int colorWithAlpha = ColorAssist.rgba(textColor >> 16 & 0xFF, textColor >> 8 & 0xFF, textColor & 0xFF, textAlpha);
            float prefixWidth = fontPlayer.getStringWidth(prefix);
            float prefixBoxWidth = prefixWidth + 6.0f;
            Calculate.scale(matrix, centerX, centerY, 1.0f, animation, () -> {
                Render2D.drawTexture(context, skinTexture, (float)this.getX() + 4.5f, centerY - 1.5f, 8.0f, 3.5f, 8, 8, 64, ColorAssist.getRect(1.0f));
                fontPlayer.drawString(matrix, name, this.getX() + 19, centerY + 1.0f, colorWithAlpha);
                fontPlayer.drawString(matrix, prefix, (float)(this.getX() + this.getWidth()) - prefixWidth - 8.0f, centerY + 1.0f, prefixColor);
            });
            float width = fontPlayer.getStringWidth(name) + 25.0f + 10.0f;
            maxWidth = (int)Math.max(width, (float)maxWidth);
            offset += (int)(11.0f * animation);
        }
        if (this.list.isEmpty() && PlayerInteractionHelper.isChat(StaffList.mc.field_1755)) {
            float centerY = this.getY() + offset;
            String name = "Example Staff";
            String prefix = "Vanish";
            int textColor = HudColorHelper.getStaffTextColor();
            int textAlpha = 255;
            int colorWithAlpha = ColorAssist.rgba(textColor >> 16 & 0xFF, textColor >> 8 & 0xFF, textColor & 0xFF, textAlpha);
            int prefixColor = PREFIX_COLORS.getOrDefault("Vanish", new Color(225, 225, 255, 255).getRGB());
            float prefixWidth = fontPlayer.getStringWidth("Vanish");
            float prefixBoxWidth = prefixWidth + 6.0f;
            Calculate.scale(matrix, centerX, centerY, 1.0f, 1.0f, () -> {
                class_897 baseRenderer = mc.method_1561().method_3953((class_1297)StaffList.mc.field_1724);
                if (baseRenderer instanceof class_922) {
                    class_922 renderer = (class_922)baseRenderer;
                    class_10042 state = (class_10042)renderer.method_62425((class_1297)StaffList.mc.field_1724, tickCounter.method_60637(false));
                    class_2960 textureLocation = renderer.method_3885(state);
                    Render2D.drawTexture(context, textureLocation, (float)this.getX() + 4.5f, centerY - 1.5f, 8.0f, 3.0f, 8, 8, 64, ColorAssist.getRect(1.0f), ColorAssist.multRed(-1, 1.0f));
                }
                fontPlayer.drawString(matrix, name, this.getX() + 19, centerY + 1.0f, colorWithAlpha);
                fontPlayer.drawString(matrix, "Vanish", (float)(this.getX() + this.getWidth()) - prefixWidth - 8.0f, centerY + 1.0f, prefixColor);
            });
            int width = (int)fontPlayer.getStringWidth(name) + 25 + 10;
            maxWidth = Math.max(width, maxWidth);
            offset += 11;
        }
        this.setWidth(maxWidth + 20);
        this.setHeight(offset);
    }

    static {
        CHAR_TO_NAME.put("\ua500", "player");
        CHAR_TO_NAME.put("\ua504", "hero");
        CHAR_TO_NAME.put("\ua508", "titan");
        CHAR_TO_NAME.put("\ua512", "avenger");
        CHAR_TO_NAME.put("\ua516", "overlord");
        CHAR_TO_NAME.put("\ua520", "magister");
        CHAR_TO_NAME.put("\ua524", "imperator");
        CHAR_TO_NAME.put("\ua528", "dragon");
        CHAR_TO_NAME.put("\ua532", "bull");
        CHAR_TO_NAME.put("\ua552", "rabbit");
        CHAR_TO_NAME.put("\ua536", "tiger");
        CHAR_TO_NAME.put("\ua544", "dracula");
        CHAR_TO_NAME.put("\ua556", "bunny");
        CHAR_TO_NAME.put("\ua540", "hydra");
        CHAR_TO_NAME.put("\ua548", "cobra");
        CHAR_TO_NAME.put("\ua501", "media");
        CHAR_TO_NAME.put("\ua505", "yt");
        CHAR_TO_NAME.put("\ua560", "d.helper");
        CHAR_TO_NAME.put("\ua509", "helper");
        CHAR_TO_NAME.put("\ua513", "ml.moder");
        CHAR_TO_NAME.put("\ua517", "moder");
        CHAR_TO_NAME.put("\ua521", "moder+");
        CHAR_TO_NAME.put("\ua525", "st.moder");
        CHAR_TO_NAME.put("\ua529", "gl.moder");
        CHAR_TO_NAME.put("\ua533", "ml.admin");
        CHAR_TO_NAME.put("\ua537", "admin");
        PREFIX_COLORS.put("media", new Color(255, 0, 0, 255).getRGB());
        PREFIX_COLORS.put("yt", new Color(255, 0, 0, 255).getRGB());
        PREFIX_COLORS.put("d.helper", new Color(255, 255, 0, 255).getRGB());
        PREFIX_COLORS.put("helper", new Color(255, 255, 0, 255).getRGB());
        PREFIX_COLORS.put("ml.moder", new Color(0, 255, 255, 255).getRGB());
        PREFIX_COLORS.put("moder", new Color(0, 0, 255, 255).getRGB());
        PREFIX_COLORS.put("moder+", new Color(0, 0, 255, 255).getRGB());
        PREFIX_COLORS.put("st.moder", new Color(128, 0, 128, 255).getRGB());
        PREFIX_COLORS.put("gl.moder", new Color(128, 0, 128, 255).getRGB());
        PREFIX_COLORS.put("ml.admin", new Color(0, 255, 255, 255).getRGB());
        PREFIX_COLORS.put("admin", new Color(255, 0, 0, 255).getRGB());
        PREFIX_COLORS.put("Vanish", new Color(255, 0, 0, 255).getRGB());
    }
}

