/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1291
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1309
 *  net.minecraft.class_2596
 *  net.minecraft.class_2678
 *  net.minecraft.class_2718
 *  net.minecraft.class_2724
 *  net.minecraft.class_2783
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_6880
 *  net.minecraft.class_7923
 */
package fun.bloody.display.hud;

import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.color.HudColorHelper;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.math.calc.Calculate;
import java.lang.runtime.SwitchBootstraps;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_2596;
import net.minecraft.class_2678;
import net.minecraft.class_2718;
import net.minecraft.class_2724;
import net.minecraft.class_2783;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class Potions
extends AbstractDraggable {
    private final List<Potion> list = new ArrayList<Potion>();
    private static final class_6880<class_1291>[] NEGATIVE_EFFECTS = new class_6880[]{class_1294.field_5899, class_1294.field_5920, class_1294.field_5916, class_1294.field_5919, class_1294.field_5903, class_1294.field_5909, class_1294.field_5901, class_1294.field_5921, class_1294.field_5911, class_1294.field_5902, class_1294.field_5908, class_1294.field_16595};
    private long lastEffectChange = 0L;
    private class_6880<class_1291> currentRandomEffect = class_1294.field_5904;

    public Potions() {
        super("Potions", 200, 40, 80, 23, true);
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("Potions") && (!this.list.isEmpty() || PlayerInteractionHelper.isChat(Potions.mc.field_1755));
    }

    @Override
    public void tick() {
        long currentTime;
        this.list.removeIf(p -> p.anim.isFinished(Direction.BACKWARDS));
        this.list.forEach(p -> p.effect.method_5585((class_1309)Potions.mc.field_1724, null));
        if (this.list.isEmpty() && PlayerInteractionHelper.isChat(Potions.mc.field_1755) && (currentTime = System.currentTimeMillis()) - this.lastEffectChange >= 1000L) {
            ArrayList effects = new ArrayList();
            for (class_2960 id : class_7923.field_41174.method_10235()) {
                class_7923.field_41174.method_10223(id).ifPresent(effects::add);
            }
            if (!effects.isEmpty()) {
                this.currentRandomEffect = (class_6880)effects.get(new Random().nextInt(effects.size()));
                this.lastEffectChange = currentTime;
            }
        }
    }

    @Override
    public void packet(PacketEvent e) {
        class_2596<?> class_25962 = e.getPacket();
        Objects.requireNonNull(class_25962);
        class_2596<?> class_25963 = class_25962;
        int n = 0;
        switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{class_2783.class, class_2718.class, class_2724.class, class_2678.class}, class_25963, n)) {
            case 0: {
                class_2783 effect = (class_2783)class_25963;
                if (PlayerInteractionHelper.nullCheck() || effect.method_11943() != Objects.requireNonNull(Potions.mc.field_1724).method_5628()) break;
                class_6880 effectId = effect.method_11946();
                this.list.stream().filter(p -> p.effect.method_5579().method_55840().equals(effectId.method_55840())).forEach(s -> s.anim.setDirection(Direction.BACKWARDS));
                this.list.add(new Potion(new class_1293(effectId, effect.method_11944(), effect.method_11945(), effect.method_11950(), effect.method_11949(), effect.method_11942()), new Decelerate().setMs(150).setValue(1.0)));
                break;
            }
            case 1: {
                class_2718 effect = (class_2718)class_25963;
                this.list.stream().filter(s -> s.effect.method_5579().method_55840().equals(effect.comp_2176().method_55840())).forEach(s -> s.anim.setDirection(Direction.BACKWARDS));
                break;
            }
            case 2: {
                class_2724 p2 = (class_2724)class_25963;
                this.list.clear();
                break;
            }
            case 3: {
                class_2678 p3 = (class_2678)class_25963;
                this.list.clear();
                break;
            }
        }
    }

    @Override
    public void drawDraggable(class_332 context) {
        class_4587 matrix = context.method_51448();
        FontRenderer font = Fonts.getSize(13, Fonts.Type.DEFAULT);
        FontRenderer fontPotion = Fonts.getSize(13, Fonts.Type.DEFAULT);
        FontRenderer icon = Fonts.getSize(17, Fonts.Type.ICONbloodyREG);
        FontRenderer icon2 = Fonts.getSize(14, Fonts.Type.ICONSTYPENEW);
        FontRenderer items = Fonts.getSize(12, Fonts.Type.ICONbloodyREG);
        Hud.getInstance().renderElementBlur(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight(), 4.0f);
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight()).round(4.0f).color(HudColorHelper.getPotionsBackground().getRGB()).build());
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight()).round(4.0f).thickness(0.5f).outlineColor(ColorAssist.setAlpha(ColorAssist.getClientColor(), 80)).color(0).build());
        float iconX = this.getX() + this.getWidth() - 18;
        icon.drawString(matrix, "C", iconX, (float)this.getY() + 7.0f, HudColorHelper.getPotionsTextColor());
        font.drawString(matrix, this.getName(), this.getX() + 4, (float)this.getY() + 6.5f, HudColorHelper.getPotionsTextColor());
        float centerX = (float)this.getX() + (float)this.getWidth() / 2.0f;
        int offset = 23;
        int maxWidth = 100;
        float fixedTimerIconX = this.getX() + this.getWidth() - 32;
        float maxNameWidth = this.getWidth() - 52;
        if (this.list.isEmpty() && PlayerInteractionHelper.isChat(Potions.mc.field_1755)) {
            float centerY = this.getY() + offset;
            String originalName = "Example effect";
            String duration = "**:**";
            Object name = originalName;
            float nameWidth = fontPotion.getStringWidth((String)name);
            if (nameWidth > maxNameWidth) {
                while (fontPotion.getStringWidth((String)name + "...") > maxNameWidth && ((String)name).length() > 1) {
                    name = ((String)name).substring(0, ((String)name).length() - 1);
                }
                name = (String)name + "...";
            }
            String finalName = name;
            int textColor = HudColorHelper.getPotionsTextColor();
            int textAlpha = 255;
            int colorWithAlpha = ColorAssist.rgba(textColor >> 16 & 0xFF, textColor >> 8 & 0xFF, textColor & 0xFF, textAlpha);
            int color = HudColorHelper.getPotionsTextColor();
            int colorWithAlphaRectangle = ColorAssist.rgba(textColor >> 16 & 0xCD, textColor >> 8 & 0xCD, textColor & 0xCD, textAlpha - 125);
            float durationWidth = fontPotion.getStringWidth(duration);
            float durationBoxWidth = durationWidth + 6.0f;
            Calculate.scale(matrix, centerX, centerY, 1.0f, 1.0f, () -> {
                Render2D.drawSprite(matrix, mc.method_18505().method_18663(this.currentRandomEffect), (float)this.getX() + 3.5f, (int)centerY - 2, 8.0f, 8, colorWithAlpha);
                fontPotion.drawString(matrix, finalName, this.getX() + 18, centerY + 1.0f, colorWithAlpha);
                icon2.drawString(matrix, "n", fixedTimerIconX, centerY + 1.0f, HudColorHelper.getPotionsTextColor());
                fontPotion.drawString(matrix, duration, fixedTimerIconX + 10.0f, centerY + 1.0f, color);
            });
            int width = (int)fontPotion.getStringWidth(finalName + duration) + 30;
            maxWidth = Math.max(width, maxWidth);
            offset += 11;
        } else {
            for (Potion potion : this.list) {
                class_1293 effect = potion.effect;
                float animation = potion.anim.getOutput().floatValue();
                float centerY = this.getY() + offset;
                int amplifier = effect.method_5578();
                String originalName = ((class_1291)effect.method_5579().comp_349()).method_5560().getString();
                String duration = this.getDuration(effect);
                Object name = originalName;
                Object lvl = amplifier > 0 ? " " + (amplifier + 1) : "";
                float nameWithLevelWidth = fontPotion.getStringWidth((String)name + (String)lvl);
                if (nameWithLevelWidth > maxNameWidth) {
                    while (fontPotion.getStringWidth((String)name + (String)lvl + "...") > maxNameWidth && ((String)name).length() > 1) {
                        name = ((String)name).substring(0, ((String)name).length() - 1);
                    }
                    name = (String)name + "...";
                }
                String finalName = name;
                boolean isBadEffect = this.isBadEffect((class_6880<class_1291>)effect.method_5579());
                int textColor = isBadEffect ? ColorAssist.rgba(255, 85, 75, 255) : HudColorHelper.getPotionsTextColor();
                int textAlpha = 255;
                if (effect.method_5584() <= 200 && effect.method_5584() > 0) {
                    double output = 0.5 + 0.5 * Math.cos(Math.PI * 2 * (double)(System.currentTimeMillis() % 700L) / 700.0);
                    textAlpha = (int)(100.0 + 155.0 * output);
                } else if (effect.method_5584() == 0) {
                    textAlpha = 0;
                }
                int colorWithAlpha = isBadEffect ? ColorAssist.rgba(255, 85, 75, textAlpha) : ColorAssist.rgba(textColor >> 16 & 0xFF, textColor >> 8 & 0xFF, textColor & 0xFF, textAlpha);
                int color = HudColorHelper.getPotionsTextColor();
                int colorWithAlphaRectangle = isBadEffect ? ColorAssist.rgba(255, 85, 75, textAlpha - 125) : ColorAssist.rgba(textColor >> 16 & 0xCD, textColor >> 8 & 0xCD, textColor & 0xCD, textAlpha - 125);
                float durationWidth = fontPotion.getStringWidth(duration);
                float durationBoxWidth = durationWidth + 6.0f;
                Calculate.scale(matrix, centerX, centerY, 1.0f, animation, () -> {
                    Render2D.drawSprite(matrix, mc.method_18505().method_18663(effect.method_5579()), (float)this.getX() + 3.5f, (int)centerY - 2, 8.0f, 8, colorWithAlpha);
                    fontPotion.drawString(matrix, finalName, this.getX() + 18, centerY + 1.0f, colorWithAlpha);
                    if (amplifier > 0) {
                        String level = " " + (amplifier + 1);
                        fontPotion.drawString(matrix, level, (float)(this.getX() + 18) + fontPotion.getStringWidth(finalName), centerY + 1.0f, colorWithAlpha);
                    }
                    icon2.drawString(matrix, "n", fixedTimerIconX, centerY + 1.0f, HudColorHelper.getPotionsTextColor());
                    fontPotion.drawString(matrix, duration, fixedTimerIconX + 10.0f, centerY + 1.0f, color);
                });
                int width = (int)fontPotion.getStringWidth(finalName + (String)lvl + duration) + 30;
                maxWidth = Math.max(width, maxWidth);
                offset += (int)(11.0f * animation);
            }
        }
        this.setWidth(maxWidth);
        this.setHeight(offset);
    }

    private String getDuration(class_1293 pe) {
        int var1 = pe.method_5584();
        int mins = var1 / 1200;
        return pe.method_48559() || mins > 60 ? "**:**" : mins + ":" + String.format("%02d", var1 % 1200 / 20);
    }

    private boolean isBadEffect(class_6880<class_1291> effect) {
        for (class_6880<class_1291> negativeEffect : NEGATIVE_EFFECTS) {
            if (effect != negativeEffect) continue;
            return true;
        }
        return false;
    }

    private record Potion(class_1293 effect, Animation anim) {
    }
}

