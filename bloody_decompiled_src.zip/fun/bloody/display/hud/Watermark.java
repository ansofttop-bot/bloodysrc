/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_640
 *  net.minecraft.class_746
 */
package fun.bloody.display.hud;

import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.color.HudColorHelper;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.shape.ShapeProperties;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_640;
import net.minecraft.class_746;

public class Watermark
extends AbstractDraggable {
    private int fpsCount;
    private int ping;
    private final String[] textCycle = new String[]{"Bloody", "blood.client", "best", "", "build by: 1.0"};
    private int currentTextIndex = 0;
    private long lastSwitchTime = 0L;
    private float smoothedAnimatedTextWidth = 0.0f;
    private float textAnimationProgress = 0.0f;

    public Watermark() {
        super("Watermark", 10, 10, 150, 40, true);
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("Watermark");
    }

    @Override
    public void tick() {
        if (Watermark.mc.field_1724 == null) {
            return;
        }
        this.fpsCount = mc.method_47599();
        this.ping = this.getPing();
        if (Hud.getInstance().watermarkAnimation.isValue()) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - this.lastSwitchTime >= 5000L) {
                this.lastSwitchTime = currentTime;
                this.currentTextIndex = (this.currentTextIndex + 1) % this.textCycle.length;
                this.textAnimationProgress = 0.0f;
            }
            if (this.textAnimationProgress < 1.0f) {
                this.textAnimationProgress += 0.02f;
                if (this.textAnimationProgress > 1.0f) {
                    this.textAnimationProgress = 1.0f;
                }
            }
        } else {
            this.textAnimationProgress = 0.0f;
        }
        if (Hud.getInstance().interfaceSettings.isSelected("Watermark")) {
            this.startAnimation();
        } else {
            this.stopAnimation();
        }
    }

    @Override
    public void drawDraggable(class_332 ctx) {
        if (!Hud.getInstance().interfaceSettings.isSelected("Watermark")) {
            return;
        }
        class_4587 matrix = ctx.method_51448();
        class_746 player = Watermark.mc.field_1724;
        if (player == null) {
            return;
        }
        float x = this.getX();
        float y = this.getY();
        this.drawSecondStyle(ctx, matrix, x, y);
    }

    private void drawSecondStyle(class_332 ctx, class_4587 matrix, float x, float y) {
        boolean hasAnyElement;
        String displayText;
        String separator = " | ";
        FontRenderer font = Fonts.getSize(14, Fonts.Type.SEMI);
        float padding = 6.0f;
        float separatorWidth = font.getStringWidth(separator);
        float textHeight = font.getStringHeight("A");
        float logoSize = textHeight + 2.0f;
        float logoMargin = 4.0f;
        boolean hasLogo = false;
        try {
            class_2960 logoId = class_2960.method_60654((String)"textures/logo/bloody_logo.png");
            hasLogo = mc.method_1478().method_14486(logoId).isPresent();
        }
        catch (Exception e) {
            hasLogo = false;
        }
        String nick = mc.method_1548().method_1676();
        String serverIp = mc.method_1542() ? "Singleplayer" : (mc.method_1558() != null ? Watermark.mc.method_1558().field_3761 : "None");
        String fpsLabel = this.fpsCount + " FPS";
        String coordsText = String.format("XYZ: %d / %d / %d", (int)Watermark.mc.field_1724.method_23317(), (int)Watermark.mc.field_1724.method_23318(), (int)Watermark.mc.field_1724.method_23321());
        boolean showNick = Hud.getInstance().watermarkElements.isSelected("Nickname");
        boolean showServer = Hud.getInstance().watermarkElements.isSelected("Server");
        boolean showFPS = Hud.getInstance().watermarkElements.isSelected("FPS");
        boolean showCoords = Hud.getInstance().watermarkElements.isSelected("Coordinates");
        boolean animationEnabled = Hud.getInstance().watermarkAnimation.isValue();
        if (!animationEnabled) {
            float currentAnimatedTextWidth;
            displayText = "BloodyGhost";
            this.smoothedAnimatedTextWidth = currentAnimatedTextWidth = font.getStringWidth(displayText);
        } else {
            int displayChars;
            String fullText = this.textCycle[this.currentTextIndex];
            float animValue = this.textAnimationProgress;
            int totalChars = fullText.length();
            float printEnd = 0.3f;
            float eraseStart = 0.7f;
            if (animValue < printEnd) {
                displayChars = (int)((float)totalChars * (animValue / printEnd));
            } else if (animValue < eraseStart) {
                displayChars = totalChars;
            } else {
                float eraseProgress = (animValue - eraseStart) / (1.0f - eraseStart);
                displayChars = (int)((float)totalChars * (1.0f - eraseProgress));
            }
            displayChars = Math.max(0, Math.min(totalChars, displayChars));
            displayText = fullText.substring(0, displayChars);
            float currentAnimatedTextWidth = font.getStringWidth(displayText);
            float smoothingAlpha = 0.15f;
            this.smoothedAnimatedTextWidth += (currentAnimatedTextWidth - this.smoothedAnimatedTextWidth) * smoothingAlpha;
        }
        float nickW = showNick ? font.getStringWidth(nick) : 0.0f;
        float ipW = showServer ? font.getStringWidth(serverIp) : 0.0f;
        float fpsW = showFPS ? font.getStringWidth(fpsLabel) : 0.0f;
        float coordsW = showCoords ? font.getStringWidth(coordsText) : 0.0f;
        float totalWidth = padding;
        if (hasLogo) {
            totalWidth += logoSize + logoMargin;
        }
        totalWidth += this.smoothedAnimatedTextWidth + 3.0f;
        boolean bl = hasAnyElement = showNick || showServer || showFPS || showCoords;
        if (hasAnyElement) {
            totalWidth += separatorWidth;
        }
        boolean needSeparator = false;
        if (showNick) {
            if (needSeparator) {
                totalWidth += separatorWidth;
            }
            totalWidth += nickW + 1.0f;
            needSeparator = true;
        }
        if (showServer) {
            if (needSeparator) {
                totalWidth += separatorWidth;
            }
            totalWidth += ipW + 2.0f;
            needSeparator = true;
        }
        if (showFPS) {
            if (needSeparator) {
                totalWidth += separatorWidth;
            }
            totalWidth += fpsW + 1.0f;
            needSeparator = true;
        }
        if (showCoords) {
            if (needSeparator) {
                totalWidth += separatorWidth;
            }
            totalWidth += coordsW;
        }
        float bgHeight = 16.0f;
        Hud.getInstance().renderElementBlur(matrix, x, y, totalWidth += padding, bgHeight, 4.0f);
        rectangle.render(ShapeProperties.create(matrix, x, y, totalWidth, bgHeight).round(4.0f).color(HudColorHelper.getWatermarkBackground().getRGB()).build());
        if (Hud.getInstance().watermarkGlow.isValue()) {
            rectangle.render(ShapeProperties.create(matrix, x, y, totalWidth, bgHeight).round(4.0f).softness(8.0f).thickness(1.0f).quality(40.0f).outlineColor(ColorAssist.getClientColor()).color(0).build());
        }
        int hudTextColor = ColorAssist.getHudTextColor();
        float baselineY = y + bgHeight / 2.0f - 2.0f;
        float currentX = x + padding;
        if (hasLogo) {
            float logoY = y + (bgHeight - logoSize) / 2.0f;
            image.setTexture("textures/logo/bloody_logo.png").render(ShapeProperties.create(matrix, currentX, logoY, logoSize, logoSize).color(-1).build());
            currentX += logoSize + logoMargin;
        }
        if (animationEnabled) {
            float textAlpha = 1.0f;
            float animValue = this.textAnimationProgress;
            float printEnd = 0.3f;
            float eraseStart = 0.7f;
            if (animValue < printEnd) {
                textAlpha = animValue / printEnd;
            } else if (animValue >= eraseStart) {
                float eraseProgress = (animValue - eraseStart) / (1.0f - eraseStart);
                textAlpha = 1.0f - eraseProgress;
            }
            textAlpha = Math.max(0.0f, Math.min(1.0f, textAlpha));
            font.drawString(matrix, displayText, currentX, baselineY, HudColorHelper.getWatermarkTextColor());
        } else {
            font.drawString(matrix, displayText, currentX, baselineY, HudColorHelper.getWatermarkTextColor());
        }
        currentX += this.smoothedAnimatedTextWidth + 3.0f;
        if (hasAnyElement) {
            font.drawString(matrix, separator, currentX, baselineY, hudTextColor);
            currentX += separatorWidth;
        }
        boolean firstElement = true;
        if (showNick) {
            if (!firstElement) {
                font.drawString(matrix, separator, currentX, baselineY, hudTextColor);
                currentX += separatorWidth;
            } else {
                firstElement = false;
            }
            font.drawString(matrix, nick, currentX, baselineY, HudColorHelper.getWatermarkTextColor());
            currentX += nickW + 1.0f;
        }
        if (showServer) {
            if (!firstElement) {
                font.drawString(matrix, separator, currentX, baselineY, hudTextColor);
                currentX += separatorWidth;
            } else {
                firstElement = false;
            }
            font.drawString(matrix, serverIp, currentX, baselineY, HudColorHelper.getWatermarkTextColor());
            currentX += ipW + 2.0f;
        }
        if (showFPS) {
            if (!firstElement) {
                font.drawString(matrix, separator, currentX, baselineY, hudTextColor);
                currentX += separatorWidth;
            } else {
                firstElement = false;
            }
            font.drawString(matrix, fpsLabel, currentX, baselineY, HudColorHelper.getWatermarkTextColor());
            currentX += fpsW + 1.0f;
        }
        if (showCoords) {
            if (!firstElement) {
                font.drawString(matrix, separator, currentX, baselineY, hudTextColor);
                currentX += separatorWidth;
            }
            font.drawString(matrix, coordsText, currentX, baselineY, HudColorHelper.getWatermarkTextColor());
        }
        this.setHeight((int)bgHeight);
        this.setWidth((int)totalWidth);
    }

    private int getPing() {
        class_640 entry;
        if (mc.method_1562() != null && Watermark.mc.field_1724 != null && (entry = mc.method_1562().method_2871(Watermark.mc.field_1724.method_5667())) != null) {
            return entry.method_2959();
        }
        return 0;
    }
}

