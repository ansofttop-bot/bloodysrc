/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.hud;

import fun.bloody.Bloody;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.features.module.Module;
import fun.bloody.utils.client.chat.StringHelper;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.color.HudColorHelper;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.math.calc.Calculate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class HotKeys
extends AbstractDraggable {
    private List<Module> keysList = new ArrayList<Module>();
    private long lastKeyChange = 0L;
    private String currentRandomKey = "NONE";

    public HotKeys() {
        super("KeyBinds", 300, 40, 80, 23, true);
    }

    @Override
    public boolean visible() {
        return !this.keysList.isEmpty();
    }

    @Override
    public void tick() {
        long currentTime;
        this.keysList = Bloody.getInstance().getModuleProvider().getModules().stream().filter(module -> module.getAnimation().getOutput().floatValue() != 0.0f && module.getKey() != -1).toList();
        if (this.keysList.isEmpty() && PlayerInteractionHelper.isChat(HotKeys.mc.field_1755) && (currentTime = System.currentTimeMillis()) - this.lastKeyChange >= 1000L) {
            List<String> availableKeys = List.of("A", "B", "C", "D", "E");
            this.currentRandomKey = availableKeys.get(new Random().nextInt(availableKeys.size()));
            this.lastKeyChange = currentTime;
        }
    }

    @Override
    public void drawDraggable(class_332 context) {
        class_4587 matrix = context.method_51448();
        FontRenderer font = Fonts.getSize(13, Fonts.Type.DEFAULT);
        FontRenderer fontModule = Fonts.getSize(13, Fonts.Type.DEFAULT);
        FontRenderer categoryIcon = Fonts.getSize(16, Fonts.Type.ICONSCATEGORY);
        Hud.getInstance().renderElementBlur(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight(), 4.0f);
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight()).round(4.0f).color(HudColorHelper.getKeyBindsBackground().getRGB()).build());
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight()).round(4.0f).thickness(0.5f).outlineColor(ColorAssist.setAlpha(ColorAssist.getClientColor(), 80)).color(0).build());
        font.drawString(matrix, this.getName(), this.getX() + 5, (float)this.getY() + 6.5f, HudColorHelper.getKeyBindsTextColor());
        float centerX = (float)this.getX() + (float)this.getWidth() / 2.0f;
        int offset = 23;
        int maxWidth = 80;
        if (this.keysList.isEmpty() && PlayerInteractionHelper.isChat(HotKeys.mc.field_1755)) {
            float centerY = this.getY() + offset;
            String name = "\u041f\u0440\u0438\u043c\u0435\u0440 \u043c\u043e\u0434\u0443\u043b\u0435\u0439";
            String bind = "[" + this.currentRandomKey + "]";
            String iconChar = "A";
            int textColor = HudColorHelper.getKeyBindsTextColor();
            int textAlpha = 255;
            int colorWithAlpha = ColorAssist.rgba(textColor >> 16 & 0xFF, textColor >> 8 & 0xFF, textColor & 0xFF, textAlpha);
            int color = HudColorHelper.getKeyBindsTextColor();
            float bindWidth = fontModule.getStringWidth(bind);
            float bindBoxWidth = bindWidth + 6.0f;
            Calculate.scale(matrix, centerX, centerY, 1.0f, 1.0f, () -> {
                categoryIcon.drawString(matrix, iconChar, (float)this.getX() + 4.5f, centerY + 1.5f, color);
                fontModule.drawString(matrix, name, this.getX() + 19, centerY + 1.0f, colorWithAlpha);
                fontModule.drawString(matrix, bind, (float)(this.getX() + this.getWidth()) - bindWidth - 8.0f, centerY + 1.0f, color);
            });
            int width = (int)fontModule.getStringWidth(name + bind) + 25;
            maxWidth = Math.max(width, maxWidth);
            offset += 11;
        } else {
            for (Module module : this.keysList) {
                String bind = "[" + StringHelper.getBindName(module.getKey()) + "]";
                float centerY = this.getY() + offset;
                float animation = module.getAnimation().getOutput().floatValue();
                int textColor = HudColorHelper.getKeyBindsTextColor();
                int textAlpha = 255;
                int colorWithAlpha = ColorAssist.rgba(textColor >> 16 & 0xFF, textColor >> 8 & 0xFF, textColor & 0xFF, textAlpha);
                int color = HudColorHelper.getKeyBindsTextColor();
                float bindWidth = fontModule.getStringWidth(bind);
                float bindBoxWidth = bindWidth + 6.0f;
                Calculate.scale(matrix, centerX, centerY, 1.0f, animation, () -> {
                    fontModule.drawString(matrix, module.getName(), this.getX() + 5, centerY + 1.0f, colorWithAlpha);
                    fontModule.drawString(matrix, bind, (float)(this.getX() + this.getWidth()) - bindWidth - 8.0f, centerY + 1.0f, color);
                });
                float width = fontModule.getStringWidth(module.getName() + bind) + 15.0f;
                maxWidth = (int)Math.max(width, (float)maxWidth);
                offset += (int)(animation * 11.0f);
            }
        }
        this.setWidth(maxWidth + 10);
        this.setHeight(offset);
    }
}

