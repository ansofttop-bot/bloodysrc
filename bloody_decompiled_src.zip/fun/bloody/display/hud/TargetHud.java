/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10042
 *  net.minecraft.class_1297
 *  net.minecraft.class_1304
 *  net.minecraft.class_1309
 *  net.minecraft.class_1429
 *  net.minecraft.class_1569
 *  net.minecraft.class_1657
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_897
 *  net.minecraft.class_922
 */
package fun.bloody.display.hud;

import fun.bloody.Bloody;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.Easy.EaseBackIn;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.client.packet.network.Network;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.color.HudColorHelper;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.scissor.ScissorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.math.calc.Calculate;
import fun.bloody.utils.math.time.StopWatch;
import java.awt.Color;
import java.util.Optional;
import net.minecraft.class_10042;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_897;
import net.minecraft.class_922;

public class TargetHud
extends AbstractDraggable {
    private final Animation animation = new Decelerate().setMs(650).setValue(1.0);
    private final Animation faceAlphaAnimation = new Decelerate().setMs(125).setValue(1.0);
    private final EaseBackIn hoverAnimation = new EaseBackIn(100, 1.0, 1.5f);
    private final StopWatch stopWatch = new StopWatch();
    private final StopWatch healthUpdateTimer = new StopWatch();
    private final StopWatch distanceUpdateTimer = new StopWatch();
    private class_1309 lastTarget;
    private class_1792 lastItem = class_1802.field_8162;
    private float displayedHealth;
    private float displayedAbsorption;
    private float displayedDistance;
    private float lastKnownMaxHealth;

    public TargetHud() {
        super("TargetHud", 10, 80, 100, 36, true);
    }

    @Override
    public boolean visible() {
        Hud hudModule = Hud.getInstance();
        boolean isHoverMode = hudModule.targetHudMode.isSelected("\u041f\u0440\u0438 \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u0438");
        if (isHoverMode) {
            return this.hoverAnimation.getDirection() == fun.bloody.common.animation.Easy.Direction.FORWARDS;
        }
        return this.scaleAnimation.isDirection(Direction.FORWARDS);
    }

    @Override
    public void tick() {
        class_1309 foundTarget;
        Hud hudModule = Hud.getInstance();
        boolean isHoverMode = hudModule.targetHudMode.isSelected("\u041f\u0440\u0438 \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u0438");
        class_1309 class_13092 = foundTarget = isHoverMode ? this.findTargetByLooking() : this.findTarget();
        if (foundTarget != null) {
            if (this.lastTarget != foundTarget) {
                this.displayedHealth = PlayerInteractionHelper.getHealth(foundTarget);
                this.displayedAbsorption = foundTarget.method_6067();
                this.lastKnownMaxHealth = foundTarget.method_6063();
            }
            this.lastTarget = foundTarget;
            if (isHoverMode) {
                this.hoverAnimation.setDirection(fun.bloody.common.animation.Easy.Direction.FORWARDS);
            } else {
                this.startAnimation();
            }
            this.faceAlphaAnimation.setDirection(Direction.FORWARDS);
            this.stopWatch.reset();
        } else if (!isHoverMode && PlayerInteractionHelper.isChat(TargetHud.mc.field_1755)) {
            if (this.lastTarget != TargetHud.mc.field_1724) {
                this.displayedHealth = PlayerInteractionHelper.getHealth((class_1309)TargetHud.mc.field_1724);
                this.displayedAbsorption = TargetHud.mc.field_1724.method_6067();
                this.lastKnownMaxHealth = TargetHud.mc.field_1724.method_6063();
            }
            this.lastTarget = TargetHud.mc.field_1724;
            if (isHoverMode) {
                this.hoverAnimation.setDirection(fun.bloody.common.animation.Easy.Direction.FORWARDS);
            } else {
                this.startAnimation();
            }
            this.faceAlphaAnimation.setDirection(Direction.FORWARDS);
            this.stopWatch.reset();
        } else if (this.stopWatch.finished(isHoverMode ? 50.0 : 500.0)) {
            if (isHoverMode) {
                this.hoverAnimation.setDirection(fun.bloody.common.animation.Easy.Direction.BACKWARDS);
            } else {
                this.stopAnimation();
            }
            this.faceAlphaAnimation.setDirection(Direction.BACKWARDS);
        }
        if (this.lastTarget != null) {
            float currentHealth = PlayerInteractionHelper.getHealth(this.lastTarget);
            float currentAbsorption = this.lastTarget.method_6067();
            float maxHealth = this.lastTarget.method_6063();
            if (this.healthUpdateTimer.finished(16.0)) {
                if (Math.abs(currentHealth - this.displayedHealth) > 0.1f || Math.abs(currentAbsorption - this.displayedAbsorption) > 0.1f) {
                    float healthDiff = currentHealth - this.displayedHealth;
                    float absorptionDiff = currentAbsorption - this.displayedAbsorption;
                    float healthStep = Math.signum(healthDiff) * Math.min(Math.abs(healthDiff) * 0.3f, 0.8f);
                    float absorptionStep = Math.signum(absorptionDiff) * Math.min(Math.abs(absorptionDiff) * 0.3f, 0.4f);
                    this.displayedHealth = class_3532.method_15363((float)(this.displayedHealth + healthStep), (float)0.0f, (float)maxHealth);
                    this.displayedAbsorption = Math.max(0.0f, this.displayedAbsorption + absorptionStep);
                }
                this.lastKnownMaxHealth = maxHealth;
                this.healthUpdateTimer.reset();
            }
        }
    }

    @Override
    public void drawDraggable(class_332 context) {
        if (Hud.getInstance().interfaceSettings.isSelected("TargetHud") && Hud.getInstance().state && this.lastTarget != null) {
            class_4587 matrix = context.method_51448();
            this.drawFace(context);
        }
    }

    private void drawMain(class_332 context, class_4587 matrix) {
        FontRenderer font = Fonts.getSize(17, Fonts.Type.REGULAR);
        FontRenderer distancefont = Fonts.getSize(13, Fonts.Type.SEMI);
        if (this.distanceUpdateTimer.finished(10.0)) {
            float actualDistance = TargetHud.mc.field_1724.method_5739((class_1297)this.lastTarget);
            float roundedDistance = (float)Math.round(actualDistance * 2.0f) / 2.0f;
            this.displayedDistance = class_3532.method_15363((float)Calculate.interpolateSmooth(0.5, this.displayedDistance, roundedDistance), (float)0.0f, (float)100.0f);
            this.distanceUpdateTimer.reset();
        }
        String distanceText = String.format("%.1f", Float.valueOf(this.displayedDistance));
        float nameWidth = font.getStringWidth(this.lastTarget.method_5477().getString());
        float baseWidth = Math.max(80, 100);
        this.setWidth((int)baseWidth + 10);
        this.setHeight(40);
        Hud.getInstance().renderElementBlur(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight() - 10, 6.0f);
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight() - 10).round(6.0f).color(HudColorHelper.getTargetHudBackground().getRGB()).build());
        float healthBarX = this.getX() + 29;
        float healthBarY = this.getY() + 18;
        float healthBarWidth = this.getWidth() - 33;
        float healthBarHeight = 4.0f;
        blur.render(ShapeProperties.create(matrix, healthBarX, healthBarY, healthBarWidth, healthBarHeight).round(2.0f).quality(12.0f).color(new Color(0, 0, 0, 150).getRGB()).build());
        float healthPercentage = this.displayedHealth / Math.max(0.1f, this.lastKnownMaxHealth);
        float healthFillWidth = class_3532.method_15363((float)(healthBarWidth * healthPercentage), (float)0.0f, (float)healthBarWidth);
        rectangle.render(ShapeProperties.create(matrix, healthBarX, healthBarY, healthFillWidth, healthBarHeight).round(2.0f).color(ColorAssist.getClientColor(0.8f)).build());
        if (this.displayedAbsorption > 0.0f && !Network.isFunTime()) {
            float absorptionPercentage = Math.min(this.displayedAbsorption / 20.0f, 1.0f);
            float absorptionFillWidth = healthBarWidth * absorptionPercentage;
            float absorptionFillX = healthBarX + healthBarWidth - absorptionFillWidth;
            rectangle.render(ShapeProperties.create(matrix, absorptionFillX, healthBarY, absorptionFillWidth, healthBarHeight).round(2.0f).color(new Color(255, 215, 0, 180).getRGB(), new Color(255, 128, 0, 180).getRGB(), new Color(255, 215, 0, 180).getRGB(), new Color(255, 128, 0, 180).getRGB()).build());
        }
        if (nameWidth > 50.0f) {
            ScissorAssist scissorManager = Bloody.getInstance().getScissorManager();
            scissorManager.push(matrix.method_23760().method_23761(), this.getX(), this.getY(), this.getWidth() - 29, this.getHeight());
            font.drawGradientString(matrix, this.lastTarget.method_5477().getString(), this.getX() + 29, (float)this.getY() + 6.0f, HudColorHelper.getTargetHudTextColor(), ColorAssist.multAlpha(HudColorHelper.getTargetHudTextColor(), 0.15f));
            scissorManager.pop();
        } else {
            font.drawString(matrix, this.lastTarget.method_5477().getString(), this.getX() + 29, (float)this.getY() + 6.0f, HudColorHelper.getTargetHudTextColor());
        }
        float actualTotalHealth = this.displayedHealth + this.displayedAbsorption;
        String healthText = this.lastTarget.method_5767() && !Network.isSpookyTime() && !Network.isCopyTime() ? " ??" : String.format("%.0f", Float.valueOf(actualTotalHealth));
        Color healthColor = this.displayedAbsorption > 0.0f && !Network.isFunTime() ? new Color(255, 215, 0, 225) : new Color(255, 255, 255, 225);
        float healthTextX = (float)(this.getX() + this.getWidth()) - distancefont.getStringWidth(healthText) - 4.0f;
        float healthTextY = this.getY() + 11;
        distancefont.drawString(matrix, healthText, healthTextX, healthTextY, healthColor.getRGB());
    }

    private void drawFace(class_332 context) {
        this.drawFaceClient(context);
    }

    private void drawFaceStyle1(class_332 context) {
        class_897 baseRenderer = mc.method_1561().method_3953((class_1297)this.lastTarget);
        if (!(baseRenderer instanceof class_922)) {
            return;
        }
        class_922 renderer = (class_922)baseRenderer;
        class_10042 state = (class_10042)renderer.method_62425((class_1297)this.lastTarget, tickCounter.method_60637(false));
        class_2960 textureLocation = renderer.method_3885(state);
        float alpha = this.faceAlphaAnimation.getOutput().floatValue();
        Calculate.setAlpha(alpha, () -> Render2D.drawTexture(context, textureLocation, this.getX() + 5, (float)this.getY() + 5.5f, 20.0f, 4.0f, 8, 8, 64, ColorAssist.getRect(1.0f), ColorAssist.multRed(-1, 1.0f + (float)this.lastTarget.field_6235 / 4.0f)));
    }

    private void drawFaceStyle2(class_332 context) {
        class_4587 matrix = context.method_51448();
        FontRenderer font = Fonts.getSize(18, Fonts.Type.REGULAR);
        FontRenderer distancefont = Fonts.getSize(12, Fonts.Type.SEMI);
        float hp = PlayerInteractionHelper.getHealth(this.lastTarget);
        String stringHp = this.lastTarget.method_5767() && !Network.isSpookyTime() && !Network.isCopyTime() ? " ??" : PlayerInteractionHelper.getHealthString(hp);
        float currentHealthAngle = class_3532.method_15363((float)(hp / this.lastTarget.method_6063() * 360.0f), (float)0.0f, (float)360.0f);
        float absorptionAmount = this.lastTarget.method_6067();
        float currentAbsorptionAngle = class_3532.method_15363((float)(absorptionAmount / 20.0f * 360.0f), (float)0.0f, (float)360.0f);
        float actualDistance = TargetHud.mc.field_1724.method_5739((class_1297)this.lastTarget);
        float roundedDistance = (float)Math.round(actualDistance * 2.0f) / 2.0f;
        if (this.distanceUpdateTimer.finished(10.0)) {
            this.displayedDistance = class_3532.method_15363((float)Calculate.interpolateSmooth(0.5, this.displayedDistance, roundedDistance), (float)0.0f, (float)100.0f);
            this.distanceUpdateTimer.reset();
        }
        String distanceText = String.format("%.1f", Float.valueOf(this.displayedDistance));
        float nameWidth = font.getStringWidth(this.lastTarget.method_5477().getString());
        float baseWidth = Math.max(80, 100);
        this.setWidth((int)baseWidth + 10);
        this.setHeight(41);
        Hud.getInstance().renderElementBlur(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight() - 10, 6.0f);
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight() - 10).round(6.0f).color(HudColorHelper.getTargetHudBackground().getRGB()).build());
        class_897 baseRenderer = mc.method_1561().method_3953((class_1297)this.lastTarget);
        if (baseRenderer instanceof class_922) {
            class_922 renderer = (class_922)baseRenderer;
            class_10042 state = (class_10042)renderer.method_62425((class_1297)this.lastTarget, tickCounter.method_60637(false));
            class_2960 textureLocation = renderer.method_3885(state);
            float alpha = this.faceAlphaAnimation.getOutput().floatValue();
            Calculate.setAlpha(alpha, () -> Render2D.drawTexture(context, textureLocation, this.getX() + 5, (float)this.getY() + 5.5f, 20.0f, 4.0f, 8, 8, 64, ColorAssist.getRect(1.0f), ColorAssist.multRed(-1, 1.0f + (float)this.lastTarget.field_6235 / 4.0f)));
        }
        arc.render(ShapeProperties.create(matrix, (float)(this.getX() + this.getWidth()) - 28.5f, (float)this.getY() + 2.5f, 26.0, 26.0).round(0.26f).thickness(0.3f).end(361.0f).color(new Color(255, 255, 255, 25).getRGB()).build());
        arc.render(ShapeProperties.create(matrix, (float)(this.getX() + this.getWidth()) - 28.5f, (float)this.getY() + 2.5f, 26.0, 26.0).round(0.26f).thickness(0.3f).end(currentHealthAngle).color(ColorAssist.fade(0), ColorAssist.fade(200), ColorAssist.fade(0), ColorAssist.fade(200)).build());
        if (currentAbsorptionAngle > 0.0f && !Network.isFunTime()) {
            arc.render(ShapeProperties.create(matrix, (float)(this.getX() + this.getWidth()) - 28.5f, (float)this.getY() + 2.5f, 26.0, 26.0).round(0.26f).thickness(0.3f).end(currentAbsorptionAngle - 2.5f).color(new Color(255, 215, 0, 255).getRGB(), new Color(255, 128, 0, 255).getRGB(), new Color(255, 215, 0, 255).getRGB(), new Color(255, 128, 0, 255).getRGB()).build());
        }
        if (nameWidth > 50.0f) {
            ScissorAssist scissorManager = Bloody.getInstance().getScissorManager();
            scissorManager.push(matrix.method_23760().method_23761(), this.getX(), this.getY(), this.getWidth() - 29, this.getHeight());
            font.drawGradientString(matrix, this.lastTarget.method_5477().getString(), this.getX() + 29, (float)this.getY() + 9.0f, HudColorHelper.getTargetHudTextColor(), ColorAssist.multAlpha(HudColorHelper.getTargetHudTextColor(), 0.15f));
            distancefont.drawString(matrix, "Distance: " + distanceText, this.getX() + 29, (float)this.getY() + 19.0f, new Color(225, 225, 255, 255).getRGB());
            scissorManager.pop();
        } else {
            font.drawString(matrix, this.lastTarget.method_5477().getString(), this.getX() + 29, (float)this.getY() + 9.0f, HudColorHelper.getTargetHudTextColor());
            distancefont.drawString(matrix, "Distance: " + distanceText, this.getX() + 29, (float)this.getY() + 19.0f, new Color(225, 225, 255, 255).getRGB());
        }
        float arcCenterX = (float)(this.getX() + this.getWidth()) - 15.25f;
        float arcCenterY = (float)this.getY() + 15.0f;
        Fonts.getSize(11, Fonts.Type.BOLD).drawCenteredString(matrix, stringHp, arcCenterX, arcCenterY, ColorAssist.multAlpha(HudColorHelper.getTargetHudTextColor(), 0.88f));
        this.drawArmor(context, matrix);
    }

    private void drawFaceStyle3(class_332 context) {
        float currentWidth;
        String name;
        float nameWidth;
        float targetWidth;
        float widthDiff;
        class_4587 matrix = context.method_51448();
        FontRenderer font = Fonts.getSize(18, Fonts.Type.REGULAR);
        FontRenderer smallFont = Fonts.getSize(13, Fonts.Type.SEMI);
        if (this.distanceUpdateTimer.finished(10.0)) {
            float actualDistance = TargetHud.mc.field_1724.method_5739((class_1297)this.lastTarget);
            float roundedDistance = (float)Math.round(actualDistance * 2.0f) / 2.0f;
            this.displayedDistance = class_3532.method_15363((float)Calculate.interpolateSmooth(0.5, this.displayedDistance, roundedDistance), (float)0.0f, (float)100.0f);
            this.distanceUpdateTimer.reset();
        }
        if (Math.abs(widthDiff = (targetWidth = Math.max(120.0f, (nameWidth = font.getStringWidth(name = this.lastTarget.method_5477().getString())) + 80.0f)) - (currentWidth = (float)this.getWidth())) > 0.5f) {
            this.setWidth((int)(currentWidth += widthDiff * 0.15f));
        }
        this.setHeight(50);
        Hud.getInstance().renderElementBlur(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight(), 8.0f);
        rectangle.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), this.getHeight()).round(8.0f).color(HudColorHelper.getTargetHudBackground().getRGB()).build());
        class_897 baseRenderer = mc.method_1561().method_3953((class_1297)this.lastTarget);
        if (baseRenderer instanceof class_922) {
            class_922 renderer = (class_922)baseRenderer;
            class_10042 state = (class_10042)renderer.method_62425((class_1297)this.lastTarget, tickCounter.method_60637(false));
            class_2960 textureLocation = renderer.method_3885(state);
            float alpha = this.faceAlphaAnimation.getOutput().floatValue();
            float hurtEffect = 1.0f + (float)this.lastTarget.field_6235 / 4.0f;
            Calculate.setAlpha(alpha, () -> {
                rectangle.render(ShapeProperties.create(matrix, this.getX() + 5, this.getY() + 5, 30.0, 30.0).round(6.0f).color(new Color(30, 30, 30, 150).getRGB()).build());
                Render2D.drawTexture(context, textureLocation, this.getX() + 10, this.getY() + 10, 20.0f, 4.0f, 8, 8, 64, ColorAssist.getRect(1.0f), ColorAssist.multRed(-1, hurtEffect));
            });
        }
        font.drawString(matrix, name, this.getX() + 42, this.getY() + 8, HudColorHelper.getTargetHudTextColor());
        String distanceText = String.format("%.1fm", Float.valueOf(this.displayedDistance));
        smallFont.drawString(matrix, distanceText, this.getX() + 42, this.getY() + 20, new Color(180, 180, 180, 200).getRGB());
        float hpBarX = this.getX() + 42;
        float hpBarY = this.getY() + 32;
        float hpBarWidth = this.getWidth() - 47;
        float hpBarHeight = 6.0f;
        rectangle.render(ShapeProperties.create(matrix, hpBarX, hpBarY, hpBarWidth, hpBarHeight).round(3.0f).color(new Color(40, 40, 40, 200).getRGB()).build());
        float healthPercentage = this.displayedHealth / Math.max(0.1f, this.lastKnownMaxHealth);
        float healthFillWidth = class_3532.method_15363((float)(hpBarWidth * healthPercentage), (float)0.0f, (float)hpBarWidth);
        rectangle.render(ShapeProperties.create(matrix, hpBarX, hpBarY, healthFillWidth, hpBarHeight).round(3.0f).color(ColorAssist.getClientColor(0.9f), ColorAssist.getClientColor(0.7f), ColorAssist.getClientColor(0.9f), ColorAssist.getClientColor(0.7f)).build());
        if (this.displayedAbsorption > 0.0f && !Network.isFunTime()) {
            float absorptionPercentage = Math.min(this.displayedAbsorption / 20.0f, 1.0f);
            float absorptionFillWidth = hpBarWidth * absorptionPercentage;
            float absorptionFillX = hpBarX + hpBarWidth - absorptionFillWidth;
            rectangle.render(ShapeProperties.create(matrix, absorptionFillX, hpBarY, absorptionFillWidth, hpBarHeight).round(3.0f).color(new Color(255, 215, 0, 200).getRGB(), new Color(255, 165, 0, 200).getRGB(), new Color(255, 215, 0, 200).getRGB(), new Color(255, 165, 0, 200).getRGB()).build());
        }
        float actualTotalHealth = this.displayedHealth + this.displayedAbsorption;
        String healthText = this.lastTarget.method_5767() && !Network.isSpookyTime() && !Network.isCopyTime() ? "??" : String.format("%.1f", Float.valueOf(actualTotalHealth));
        Color healthColor = this.displayedAbsorption > 0.0f && !Network.isFunTime() ? new Color(255, 215, 0, 255) : new Color(255, 255, 255, 255);
        float healthTextX = (float)(this.getX() + this.getWidth()) - smallFont.getStringWidth(healthText) - 5.0f;
        smallFont.drawString(matrix, healthText, healthTextX, this.getY() + 8, healthColor.getRGB());
    }

    private void drawArmorStyle3(class_332 context, class_4587 matrix) {
        class_1799[] slots = new class_1799[]{this.lastTarget.method_6047(), this.lastTarget.method_6079(), this.lastTarget.method_6118(class_1304.field_6169), this.lastTarget.method_6118(class_1304.field_6174), this.lastTarget.method_6118(class_1304.field_6172), this.lastTarget.method_6118(class_1304.field_6166)};
        float startX = this.getX() + 42;
        float startY = this.getY() + 40;
        float slotSize = 12.0f;
        float spacing = 14.0f;
        matrix.method_22903();
        for (int i = 0; i < 6; ++i) {
            float currentX = startX + (float)i * spacing;
            rectangle.render(ShapeProperties.create(matrix, currentX, startY, slotSize, slotSize).round(3.0f).color(new Color(30, 30, 30, 150).getRGB()).build());
            if (slots[i].method_7960()) continue;
            Render2D.drawStack(matrix, slots[i], currentX + 1.0f, startY + 1.0f, false, 0.6f);
        }
        matrix.method_22909();
    }

    private void drawArmor(class_332 context, class_4587 matrix) {
        class_1799[] slots = new class_1799[]{this.lastTarget.method_6047(), this.lastTarget.method_6079(), this.lastTarget.method_6118(class_1304.field_6169), this.lastTarget.method_6118(class_1304.field_6174), this.lastTarget.method_6118(class_1304.field_6172), this.lastTarget.method_6118(class_1304.field_6166)};
        float x = (float)this.getX() + 21.0f;
        float y = this.getY() + 17;
        float slotSize = 10.0f;
        matrix.method_22903();
        matrix.method_46416(x, y, 0.0f);
        for (int i = 0; i < 6; ++i) {
            float currentX = (float)i * 11.5f;
            Hud.getInstance().renderElementBlur(matrix, currentX - 0.5f, 15.0f, slotSize + 1.0f, slotSize + 1.0f, 3.0f);
            rectangle.render(ShapeProperties.create(matrix, currentX - 0.5f, 15.0, slotSize + 1.0f, slotSize + 1.0f).round(3.0f).color(HudColorHelper.getTargetHudBackground().getRGB()).build());
            if (slots[i].method_7960()) continue;
            Render2D.drawStack(matrix, slots[i], currentX, 15.5f, false, 0.5f);
        }
        matrix.method_22909();
    }

    private void drawFaceCelestial(class_332 context) {
        class_4587 matrix = context.method_51448();
        float width = 96.333336f;
        float height = 32.3f;
        float headSize = 27.2f;
        float spacing = 4.0f;
        this.setWidth((int)width);
        this.setHeight((int)height);
        float alphaAnimationValue = this.scaleAnimation.getOutput().floatValue();
        int alpha = (int)(255.0f * alphaAnimationValue);
        int shadowAlpha = (int)(255.0f * alphaAnimationValue);
        float posX = this.getX();
        float posY = this.getY();
        Hud.getInstance().renderElementBlur(matrix, posX, posY, width, height, 5.0f);
        rectangle.render(ShapeProperties.create(matrix, posX, posY, width, height).round(5.0f).color(HudColorHelper.getTargetHudBackground().getRGB()).build());
        float headCenterX = posX + 4.0f + headSize / 2.0f;
        float headCenterY = posY + height / 2.0f;
        class_897 baseRenderer = mc.method_1561().method_3953((class_1297)this.lastTarget);
        if (baseRenderer instanceof class_922) {
            class_922 renderer = (class_922)baseRenderer;
            class_10042 state = (class_10042)renderer.method_62425((class_1297)this.lastTarget, tickCounter.method_60637(false));
            class_2960 textureLocation = renderer.method_3885(state);
            float faceAlpha = this.faceAlphaAnimation.getOutput().floatValue() * alphaAnimationValue;
            float hurtEffect = 1.0f + (float)this.lastTarget.field_6235 / 4.0f;
            Calculate.setAlpha(faceAlpha, () -> Render2D.drawTexture(context, textureLocation, headCenterX - headSize / 2.0f, headCenterY - headSize / 2.0f, headSize, 4.0f, 8, 8, 64, ColorAssist.getRect(1.0f), ColorAssist.multRed(-1, hurtEffect)));
        }
        float lineX = posX + headSize + spacing + 2.0f;
        Fonts.getSize(17, Fonts.Type.REGULAR).drawString(matrix, this.lastTarget.method_5477().getString(), lineX, posY + spacing + 1.5f, ColorAssist.setAlpha(HudColorHelper.getTargetHudTextColor(), alpha));
        float healthY = posY + height - spacing - 13.0f;
        float healthTextAnimation = this.displayedHealth;
        String healthText = this.lastTarget.method_5767() && !Network.isSpookyTime() && !Network.isCopyTime() ? "HP: \u041d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u043e" : String.format("HP: %.1f", Float.valueOf(healthTextAnimation)).replace(',', '.');
        Fonts.getSize(13, Fonts.Type.SEMI).drawString(matrix, healthText, lineX, healthY, ColorAssist.setAlpha(HudColorHelper.getTargetHudTextColor(), alpha));
        float barWidth = width - (headSize + spacing * 2.0f);
        float barY = posY + height - spacing * 2.0f - 2.5f;
        rectangle.render(ShapeProperties.create(matrix, lineX - 1.0f, barY, barWidth, 8.0).round(2.0f).color(ColorAssist.setAlpha(new Color(35, 35, 35).getRGB(), alpha)).build());
        float healthBarAnimation = this.displayedHealth / Math.max(0.1f, this.lastKnownMaxHealth);
        rectangle.render(ShapeProperties.create(matrix, lineX - 1.0f, barY, barWidth * healthBarAnimation, 7.5).round(2.0f).color(ColorAssist.setAlpha(ColorAssist.getClientColor(), (int)(200.0f * alphaAnimationValue))).build());
    }

    private void drawFaceClient(class_332 context) {
        String healthText;
        float maxNameWidth;
        class_4587 matrix = context.method_51448();
        float width = 96.333336f;
        float height = 29.64f;
        float headSize = 20.672f;
        float spacing = 4.0f;
        this.setWidth((int)width);
        this.setHeight((int)height);
        Hud hudModule = Hud.getInstance();
        boolean isHoverMode = hudModule.targetHudMode.isSelected("\u041f\u0440\u0438 \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u0438");
        float alphaAnimationValue = isHoverMode ? (float)this.hoverAnimation.getOutput() : this.scaleAnimation.getOutput().floatValue();
        alphaAnimationValue = class_3532.method_15363((float)alphaAnimationValue, (float)0.0f, (float)1.0f);
        int backgroundAlpha = (int)(84.0f * alphaAnimationValue);
        int outlineAlpha = (int)(80.0f * alphaAnimationValue);
        int textAlpha = (int)(255.0f * alphaAnimationValue);
        float posX = this.getX();
        float posY = this.getY();
        Hud.getInstance().renderElementBlur(matrix, posX, posY, width, height, 4.5f);
        rectangle.render(ShapeProperties.create(matrix, posX, posY, width, height).round(4.5f).color(HudColorHelper.getTargetHudBackground().getRGB()).build());
        float headCenterX = posX + 4.0f + headSize / 2.0f;
        float headCenterY = posY + height / 2.0f;
        class_897 baseRenderer = mc.method_1561().method_3953((class_1297)this.lastTarget);
        if (baseRenderer instanceof class_922) {
            class_922 renderer = (class_922)baseRenderer;
            class_10042 state = (class_10042)renderer.method_62425((class_1297)this.lastTarget, tickCounter.method_60637(false));
            class_2960 textureLocation = renderer.method_3885(state);
            float faceAlpha = this.faceAlphaAnimation.getOutput().floatValue() * alphaAnimationValue;
            float hurtEffect = 1.0f + (float)this.lastTarget.field_6235 / 4.0f;
            Calculate.setAlpha(faceAlpha, () -> Render2D.drawTexture(context, textureLocation, headCenterX - headSize / 2.0f, headCenterY - headSize / 2.0f, headSize, 4.0f, 8, 8, 64, ColorAssist.getRect(1.0f), ColorAssist.multRed(-1, hurtEffect)));
        }
        float lineX = posX + headSize + spacing + 2.0f;
        float barWidth = (width - (headSize + spacing * 2.0f)) * 0.95f;
        String playerName = this.lastTarget.method_5477().getString();
        FontRenderer nameFont = Fonts.getSize(17, Fonts.Type.REGULAR);
        float nameWidth = nameFont.getStringWidth(playerName);
        if (nameWidth > (maxNameWidth = barWidth)) {
            String trimmedName = playerName;
            while (nameFont.getStringWidth(trimmedName) > maxNameWidth && trimmedName.length() > 0) {
                trimmedName = trimmedName.substring(0, trimmedName.length() - 1);
            }
            ScissorAssist scissorManager = Bloody.getInstance().getScissorManager();
            scissorManager.push(matrix.method_23760().method_23761(), lineX, posY, maxNameWidth, height);
            nameFont.drawGradientString(matrix, trimmedName, lineX, posY + spacing + 0.5f, ColorAssist.setAlpha(HudColorHelper.getTargetHudTextColor(), textAlpha), ColorAssist.setAlpha(HudColorHelper.getTargetHudTextColor(), (int)((float)textAlpha * 0.15f)));
            scissorManager.pop();
        } else {
            nameFont.drawString(matrix, playerName, lineX, posY + spacing + 0.5f, ColorAssist.setAlpha(HudColorHelper.getTargetHudTextColor(), textAlpha));
        }
        float healthY = posY + height - spacing - 11.0f;
        float healthTextAnimation = this.displayedHealth;
        float absorptionAmount = this.displayedAbsorption;
        String winLossText = "";
        if (this.lastTarget.method_5767() && !Network.isSpookyTime() && !Network.isCopyTime()) {
            healthText = "HP: \u041d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u043e";
        } else {
            healthText = absorptionAmount > 0.0f && !Network.isFunTime() ? String.format("HP: %.1f+%.1f", Float.valueOf(healthTextAnimation), Float.valueOf(absorptionAmount)).replace(',', '.') : String.format("HP: %.1f", Float.valueOf(healthTextAnimation)).replace(',', '.');
            if (TargetHud.mc.field_1724 != null) {
                float targetHealth;
                float myHealth = TargetHud.mc.field_1724.method_6032() + TargetHud.mc.field_1724.method_6067();
                winLossText = myHealth > (targetHealth = healthTextAnimation + absorptionAmount) ? " | WIN" : (myHealth < targetHealth ? " | LOSS" : " | DRAW");
            }
        }
        Fonts.getSize(13, Fonts.Type.SEMI).drawString(matrix, healthText, lineX, healthY, ColorAssist.setAlpha(HudColorHelper.getTargetHudTextColor(), textAlpha));
        if (!winLossText.isEmpty()) {
            float healthTextWidth = Fonts.getSize(13, Fonts.Type.SEMI).getStringWidth(healthText);
            int statusColor = winLossText.contains("WIN") ? new Color(255, 215, 0, textAlpha).getRGB() : (winLossText.contains("DRAW") ? new Color(50, 255, 50, textAlpha).getRGB() : new Color(255, 50, 50, textAlpha).getRGB());
            Fonts.getSize(13, Fonts.Type.SEMI).drawString(matrix, winLossText, lineX + healthTextWidth, healthY, statusColor);
        }
        float barHeight = 5.5f;
        float barY = posY + height - spacing * 1.5f - 2.5f;
        rectangle.render(ShapeProperties.create(matrix, lineX - 1.0f, barY, barWidth, barHeight).round(2.0f).color(ColorAssist.setAlpha(new Color(35, 35, 35).getRGB(), textAlpha)).build());
        float healthPercentage = this.displayedHealth / Math.max(0.1f, this.lastKnownMaxHealth);
        float healthFillWidth = class_3532.method_15363((float)(barWidth * healthPercentage), (float)0.0f, (float)barWidth);
        rectangle.render(ShapeProperties.create(matrix, lineX - 1.0f, barY, healthFillWidth, barHeight - 0.5f).round(2.0f).color(ColorAssist.setAlpha(ColorAssist.getClientColor(), (int)(200.0f * alphaAnimationValue))).build());
        if (absorptionAmount > 0.0f && !Network.isFunTime()) {
            float absorptionPercentage = Math.min(absorptionAmount / 20.0f, 1.0f);
            float absorptionFillWidth = barWidth * absorptionPercentage;
            float absorptionFillX = lineX - 1.0f + barWidth - absorptionFillWidth;
            rectangle.render(ShapeProperties.create(matrix, absorptionFillX, barY, absorptionFillWidth, barHeight - 0.5f).round(2.0f).color(new Color(255, 215, 0, (int)(200.0f * alphaAnimationValue)).getRGB(), new Color(255, 165, 0, (int)(200.0f * alphaAnimationValue)).getRGB(), new Color(255, 215, 0, (int)(200.0f * alphaAnimationValue)).getRGB(), new Color(255, 165, 0, (int)(200.0f * alphaAnimationValue)).getRGB()).build());
        }
    }

    private class_1309 findTarget() {
        if (TargetHud.mc.field_1687 == null || TargetHud.mc.field_1724 == null) {
            return null;
        }
        class_1309 closestTarget = null;
        double closestDistance = 20.0;
        for (class_1297 entity : TargetHud.mc.field_1687.method_18112()) {
            double distance;
            if (!(entity instanceof class_1309)) continue;
            class_1309 livingEntity = (class_1309)entity;
            if (entity == TargetHud.mc.field_1724 || !livingEntity.method_5805() || !((distance = (double)TargetHud.mc.field_1724.method_5739((class_1297)livingEntity)) < closestDistance) || !(livingEntity instanceof class_1657) && !(livingEntity instanceof class_1569) && !(livingEntity instanceof class_1429)) continue;
            closestDistance = distance;
            closestTarget = livingEntity;
        }
        return closestTarget;
    }

    private class_1309 findTargetByLooking() {
        if (TargetHud.mc.field_1687 == null || TargetHud.mc.field_1724 == null) {
            return null;
        }
        class_243 eyePos = TargetHud.mc.field_1724.method_33571();
        class_243 lookVec = TargetHud.mc.field_1724.method_5828(1.0f);
        double maxRange = 20.0;
        class_243 lookEnd = eyePos.method_1019(lookVec.method_1021(maxRange));
        class_1309 closestTarget = null;
        double closestDistance = maxRange;
        for (class_1297 entity : TargetHud.mc.field_1687.method_18112()) {
            double distance;
            class_238 targetBox;
            Optional hitResult;
            if (!(entity instanceof class_1309)) continue;
            class_1309 livingEntity = (class_1309)entity;
            if (entity == TargetHud.mc.field_1724 || !livingEntity.method_5805() || !(hitResult = (targetBox = livingEntity.method_5829()).method_992(eyePos, lookEnd)).isPresent() || !((distance = eyePos.method_1022((class_243)hitResult.get())) < closestDistance)) continue;
            closestDistance = distance;
            closestTarget = livingEntity;
        }
        return closestTarget;
    }
}

