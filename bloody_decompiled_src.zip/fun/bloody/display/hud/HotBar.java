/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1306
 *  net.minecraft.class_1661
 *  net.minecraft.class_1799
 *  net.minecraft.class_2561
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.hud;

import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.math.calc.Calculate;
import java.util.Objects;
import java.util.stream.IntStream;
import net.minecraft.class_1306;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class HotBar
extends AbstractDraggable {
    private float selectItemX;

    public HotBar() {
        super("HotBar", 0, 50, 182, 22, true);
    }

    @Override
    public boolean visible() {
        if (HotBar.mc.field_1724 != null && HotBar.mc.field_1724.method_7325()) {
            return false;
        }
        return Hud.getInstance().interfaceSettings.isSelected("HotBar");
    }

    @Override
    public void drawDraggable(class_332 context) {
        if (HotBar.mc.field_1724 == null) {
            return;
        }
        class_4587 matrix = context.method_51448();
        class_1661 inventory = Objects.requireNonNull(HotBar.mc.field_1724).method_31548();
        class_1799 offHand = HotBar.mc.field_1724.method_6079();
        this.selectItemX = Calculate.interpolate(this.selectItemX, inventory.field_7545 * 20, 0.15f);
        this.setX((mc.method_22683().method_4486() - this.getWidth()) / 2);
        this.setY(mc.method_22683().method_4502() - 27);
        Hud.getInstance().renderElementBlur(matrix, (float)this.getX() - 0.5f, (float)this.getY() - 0.5f, this.getWidth() + 1, 23.0f, 3.0f);
        rectangle.render(ShapeProperties.create(matrix, (float)this.getX() - 0.5f, (float)this.getY() - 0.5f, this.getWidth() + 1, 23.0).round(3.0f).thickness(2.0f).softness(1.0f).outlineColor(ColorAssist.multAlpha(ColorAssist.getOutline(), 0.7f)).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
        Hud.getInstance().renderElementBlur(matrix, (float)this.getX() + this.selectItemX + 1.0f, this.getY() + 1, 20.0f, 20.0f, 2.25f);
        rectangle.render(ShapeProperties.create(matrix, (float)this.getX() + this.selectItemX + 1.0f, this.getY() + 1, 20.0, 20.0).round(2.25f).thickness(3.0f).outlineColor(ColorAssist.getClientColor()).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
        IntStream.range(0, 9).forEach(i -> this.drawStack(context, (class_1799)inventory.field_7547.get(i), this.getX() + i * 20 + 2, this.getY() + 2, false));
        if (!offHand.method_7960()) {
            float offhandX = this.getX() + (Objects.requireNonNull(HotBar.mc.field_1724).method_6068().equals((Object)class_1306.field_6183) ? -28 : 198);
            this.drawStack(context, offHand, offhandX, this.getY() + 2, true);
        }
        if (!HotBar.mc.field_1724.method_7325() && !HotBar.mc.field_1724.method_7337()) {
            this.drawExperienceBar(matrix);
        }
        this.drawOverlayInfo(matrix);
    }

    public void drawExperienceBar(class_4587 matrix) {
        if (HotBar.mc.field_1724 == null) {
            return;
        }
        FontRenderer font = Fonts.getSize(16, Fonts.Type.DEFAULT);
        font.drawCenteredString(matrix, "" + HotBar.mc.field_1724.field_7520, (float)mc.method_22683().method_4486() / 2.0f, (float)this.getY() - 9.5f, ColorAssist.GREEN);
    }

    public void drawOverlayInfo(class_4587 matrix) {
        int x;
        float width;
        class_2561 text;
        float alpha;
        float scaledWidth = (float)mc.method_22683().method_4486() / 2.0f;
        float heightStart = mc.method_22683().method_4502() - 75;
        float paddingX = 4.0f;
        float paddingY = 3.0f;
        FontRenderer font = Fonts.getSize(14, Fonts.Type.DEFAULT);
        if (HotBar.mc.field_1705.field_2040 > 0 && HotBar.mc.field_1705.field_2031 != null) {
            alpha = (float)HotBar.mc.field_1705.field_2040 * 256.0f / 10.0f / 255.0f;
            alpha = Math.min(alpha, 1.0f);
            text = HotBar.mc.field_1705.field_2031.method_7964();
            width = font.getStringWidth(text);
            x = (int)(scaledWidth - width / 2.0f);
            Calculate.setAlpha(alpha, () -> {
                Hud.getInstance().renderElementBlur(matrix, (float)x - paddingX, heightStart - paddingY, width + paddingX * 2.0f, font.getStringHeight(text) / 2.15f + paddingY * 2.0f, 2.5f);
                rectangle.render(ShapeProperties.create(matrix, (float)x - paddingX, heightStart - paddingY, width + paddingX * 2.0f, font.getStringHeight(text) / 2.15f + paddingY * 2.0f).round(2.5f).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
                font.drawText(matrix, text, x, heightStart + 2.5f);
            });
        }
        if (HotBar.mc.field_1705.field_2041 > 0 && HotBar.mc.field_1705.field_2018 != null && !HotBar.mc.field_1705.field_2018.getString().isEmpty()) {
            alpha = (float)HotBar.mc.field_1705.field_2041 * 256.0f / 10.0f / 255.0f;
            alpha = Math.min(alpha, 1.0f);
            text = HotBar.mc.field_1705.field_2018;
            width = font.getStringWidth(text);
            x = (int)(scaledWidth - width / 2.0f);
            Calculate.setAlpha(alpha, () -> {
                Hud.getInstance().renderElementBlur(matrix, (float)x - paddingX, heightStart - paddingY - 17.0f, width + paddingX * 2.0f, font.getStringHeight(text) / 2.15f + paddingY * 2.0f, 2.5f);
                rectangle.render(ShapeProperties.create(matrix, (float)x - paddingX, heightStart - paddingY - 17.0f, width + paddingX * 2.0f, font.getStringHeight(text) / 2.15f + paddingY * 2.0f).round(2.5f).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
                font.drawText(matrix, text, x, heightStart - 14.5f);
            });
        }
    }

    public void drawStack(class_332 context, class_1799 stack, float x, float y, boolean offHand) {
        if (offHand) {
            Hud.getInstance().renderElementBlur(context.method_51448(), x - 2.5f, y - 2.5f, 23.0f, 23.0f, 3.0f);
            rectangle.render(ShapeProperties.create(context.method_51448(), x - 2.5f, y - 2.5f, 23.0, 23.0).round(3.0f).thickness(2.0f).softness(1.0f).outlineColor(ColorAssist.multAlpha(ColorAssist.getOutline(), 0.7f)).color(Hud.getInstance().getBackgroundColor().getRGB()).build());
        }
        Render2D.defaultDrawStack(context, stack, x, y, false, true, 1.0f);
    }
}

