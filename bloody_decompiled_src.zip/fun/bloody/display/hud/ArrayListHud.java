/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 */
package fun.bloody.display.hud;

import fun.bloody.Bloody;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.color.HudColorHelper;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.shape.ShapeProperties;
import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class ArrayListHud
extends AbstractDraggable {
    private float listAlpha = 0.0f;

    public ArrayListHud() {
        super("ArrayList", 6, 28, 150, 200, true);
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("ArrayList");
    }

    @Override
    public void tick() {
        if (ArrayListHud.mc.field_1724 == null) {
            return;
        }
        if (Hud.getInstance().interfaceSettings.isSelected("ArrayList")) {
            this.startAnimation();
        } else {
            this.stopAnimation();
        }
    }

    @Override
    public void drawDraggable(class_332 ctx) {
        float textSize;
        float initialY;
        if (!Hud.getInstance().interfaceSettings.isSelected("ArrayList")) {
            return;
        }
        if (mc.method_22683() == null) {
            return;
        }
        class_4587 matrix = ctx.method_51448();
        if (ArrayListHud.mc.field_1724 == null) {
            return;
        }
        float scale = 1.0f;
        this.listAlpha += (1.0f - this.listAlpha) * 0.12f;
        float x = this.getX();
        float y = initialY = (float)this.getY();
        float moduleSpacing = 12.0f * scale;
        float rectangleHeight = 14.0f * scale;
        float bindSize = textSize = 14.0f;
        float textPaddingLeft = 4.0f * scale;
        float textPaddingRight = 4.0f * scale;
        FontRenderer font = Fonts.getSize((int)textSize, Fonts.Type.REGULAR);
        List activeFunctions = Bloody.getInstance().getModuleRepository().modules().stream().filter(Module::isState).sorted(Comparator.comparing(f -> Float.valueOf(-this.getEntryWidth((Module)f, font, textSize, bindSize))).thenComparing(f -> -this.getEntryText((Module)f).length())).collect(Collectors.toList());
        if (activeFunctions.isEmpty()) {
            return;
        }
        if (Hud.getInstance().arrayListBackground.isValue()) {
            y = initialY;
            for (int i = 0; i < activeFunctions.size(); ++i) {
                Module function = (Module)activeFunctions.get(i);
                float entryWidth = this.getEntryWidth(function, font, textSize, bindSize);
                float rectWidth = textPaddingLeft + entryWidth + textPaddingRight;
                float rectY = y - 0.8f * scale;
                Hud.getInstance().renderElementBlur(matrix, x, rectY, rectWidth, rectangleHeight, 4.0f);
                rectangle.render(ShapeProperties.create(matrix, x, rectY, rectWidth, rectangleHeight).round(4.0f).color(HudColorHelper.getArrayListBackground().getRGB()).build());
                y += moduleSpacing;
            }
        }
        y = initialY;
        int moduleIndex = 0;
        for (int i = 0; i < activeFunctions.size(); ++i) {
            int textColor;
            String bindText;
            Module function = (Module)activeFunctions.get(i);
            String text = function.getVisibleName();
            if (text == null || text.isEmpty()) {
                text = function.getName();
            }
            boolean hasBind = !(bindText = this.getBindText(function)).isEmpty();
            float textWidth = font.getStringWidth(text);
            float textY = y + 3.0f;
            if (Hud.getInstance().arrayListColors.isValue()) {
                float hue = (float)moduleIndex * 360.0f / (float)activeFunctions.size() / 360.0f;
                textColor = Color.HSBtoRGB(hue, 0.8f, 1.0f);
                ++moduleIndex;
            } else {
                textColor = HudColorHelper.getArrayListTextColor();
            }
            font.drawString(matrix, text, x + textPaddingLeft, textY, textColor);
            if (hasBind) {
                float bindX = x + textPaddingLeft + textWidth;
                font.drawString(matrix, " - " + bindText, bindX, textY, textColor);
            }
            y += moduleSpacing;
        }
        if (!activeFunctions.isEmpty()) {
            float maxWidth = activeFunctions.stream().map(f -> Float.valueOf(textPaddingLeft + this.getEntryWidth((Module)f, font, textSize, bindSize) + textPaddingRight)).max(Float::compare).orElse(Float.valueOf(150.0f)).floatValue();
            float totalHeight = (float)activeFunctions.size() * moduleSpacing;
            this.setWidth((int)maxWidth);
            this.setHeight((int)totalHeight);
        }
    }

    private int getCategoryColor(ModuleCategory category) {
        return switch (category) {
            case ModuleCategory.COMBAT -> new Color(255, 85, 85).getRGB();
            case ModuleCategory.MOVEMENT -> new Color(85, 255, 85).getRGB();
            case ModuleCategory.PLAYER -> new Color(85, 170, 255).getRGB();
            case ModuleCategory.RENDER -> new Color(255, 170, 255).getRGB();
            case ModuleCategory.MISC -> new Color(255, 255, 85).getRGB();
            default -> new Color(255, 255, 255).getRGB();
        };
    }

    private void renderSteppedRectangle(class_332 ctx, List<Module> functions, float x, float y, float rowStep, float rowHeight, float paddingLeft, float paddingRight, FontRenderer font, float textSize, float bindSize) {
        Color backgroundColor = HudColorHelper.getArrayListBackground();
        float bgAlpha = Hud.getInstance().getBackgroundAlpha();
        int finalAlpha = (int)((float)backgroundColor.getAlpha() * bgAlpha * this.listAlpha);
        if (finalAlpha <= 0) {
            return;
        }
        Color bgWithAlpha = new Color(backgroundColor.getRed(), backgroundColor.getGreen(), backgroundColor.getBlue(), finalAlpha);
        for (int i = 0; i < functions.size(); ++i) {
            Module function = functions.get(i);
            float entryWidth = this.getEntryWidth(function, font, textSize, bindSize);
            float rectWidth = paddingLeft + entryWidth + paddingRight;
            float rectY = y + (float)i * rowStep;
            ctx.method_25294((int)x, (int)rectY, (int)(x + rectWidth), (int)(rectY + rowHeight), bgWithAlpha.getRGB());
        }
    }

    private float getEntryWidth(Module function, FontRenderer font, float textSize, float bindSize) {
        String text = function.getVisibleName();
        String bindText = this.getBindText(function);
        float width = font.getStringWidth(text);
        if (!bindText.isEmpty()) {
            width += font.getStringWidth(" - ");
            width += font.getStringWidth(bindText);
        }
        return width;
    }

    private String getEntryText(Module function) {
        String bindText = this.getBindText(function);
        return bindText.isEmpty() ? function.getVisibleName() : function.getVisibleName() + " - " + bindText;
    }

    private String getBindText(Module function) {
        int bind = function.getKey();
        if (bind == -1 || bind == 0) {
            return "";
        }
        if (bind >= 0 && bind <= 7) {
            return "M" + (bind + 1);
        }
        if (bind >= 65 && bind <= 90) {
            return String.valueOf((char)(65 + bind - 65));
        }
        if (bind >= 48 && bind <= 57) {
            return String.valueOf((char)(48 + bind - 48));
        }
        return switch (bind) {
            case 340, 344 -> "SHIFT";
            case 341, 345 -> "CTRL";
            case 342, 346 -> "ALT";
            case 32 -> "SPACE";
            case 258 -> "TAB";
            case 257 -> "ENTER";
            case 259 -> "BACKSPACE";
            case 261 -> "DELETE";
            case 260 -> "INSERT";
            case 268 -> "HOME";
            case 269 -> "END";
            case 266 -> "PGUP";
            case 267 -> "PGDN";
            case 265 -> "UP";
            case 264 -> "DOWN";
            case 263 -> "LEFT";
            case 262 -> "RIGHT";
            default -> "";
        };
    }
}

