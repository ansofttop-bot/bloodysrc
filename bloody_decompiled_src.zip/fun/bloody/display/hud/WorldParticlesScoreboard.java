/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_266
 *  net.minecraft.class_268
 *  net.minecraft.class_270
 *  net.minecraft.class_332
 *  net.minecraft.class_4587
 *  net.minecraft.class_5250
 *  net.minecraft.class_8646
 *  net.minecraft.class_9011
 */
package fun.bloody.display.hud;

import fun.bloody.features.impl.render.Hud;
import fun.bloody.utils.client.managers.api.draggable.AbstractDraggable;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.shape.ShapeProperties;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_270;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_8646;
import net.minecraft.class_9011;

public class WorldParticlesScoreboard
extends AbstractDraggable {
    private List<class_9011> scoreboardEntries = new ArrayList<class_9011>();
    private class_266 objective;

    public WorldParticlesScoreboard() {
        super("WP Scoreboard", 10, 100, 100, 120, true);
    }

    @Override
    public boolean visible() {
        if (!Hud.getInstance().interfaceSettings.isSelected("Scoreboard")) {
            return false;
        }
        return !this.scoreboardEntries.isEmpty();
    }

    @Override
    public void tick() {
        if (WorldParticlesScoreboard.mc.field_1687 == null) {
            return;
        }
        this.objective = Objects.requireNonNull(WorldParticlesScoreboard.mc.field_1687).method_8428().method_1189(class_8646.field_45157);
        if (this.objective == null) {
            this.scoreboardEntries = new ArrayList<class_9011>();
            return;
        }
        this.scoreboardEntries = WorldParticlesScoreboard.mc.field_1687.method_8428().method_1184(this.objective).stream().sorted(Comparator.comparing(class_9011::comp_2128).reversed().thenComparing(class_9011::comp_2127, String.CASE_INSENSITIVE_ORDER)).toList();
    }

    @Override
    public void drawDraggable(class_332 context) {
        if (WorldParticlesScoreboard.mc.field_1687 == null || this.objective == null) {
            return;
        }
        class_4587 matrix = context.method_51448();
        FontRenderer font = Fonts.getSize(16, Fonts.Type.DEFAULT);
        class_5250 text = class_2561.method_43473();
        class_5250 mainText = this.objective != null ? this.objective.method_1114() : class_2561.method_43473();
        this.scoreboardEntries.forEach(entry -> text.method_10852((class_2561)class_268.method_1142((class_270)Objects.requireNonNull(WorldParticlesScoreboard.mc.field_1687).method_8428().method_1164(entry.comp_2127()), (class_2561)entry.method_55387())).method_27693("\n"));
        int padding = 3;
        int offsetText = 14;
        int width = (int)Math.max(font.getStringWidth((class_2561)text) + (float)(padding * 2) + 1.0f, 100.0f);
        int mainBlurColor = ColorAssist.multAlpha(ColorAssist.getClientColor(), 0.07f);
        blur.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), offsetText).round(4.0f, 0.0f, 4.0f, 0.0f).softness(1.0f).thickness(2.0f).quality(40.0f).outlineColor(ColorAssist.getOutline(0.15f)).color(ColorAssist.multAlpha(ColorAssist.BLACK, 0.65f)).build());
        blur.render(ShapeProperties.create(matrix, this.getX(), this.getY(), this.getWidth(), offsetText).round(4.0f, 0.0f, 4.0f, 0.0f).softness(1.0f).thickness(2.0f).quality(40.0f).outlineColor(ColorAssist.getOutline(0.8f)).color(mainBlurColor).build());
        blur.render(ShapeProperties.create(matrix, this.getX(), (float)(this.getY() + offsetText) - 0.5f, this.getWidth(), this.getHeight() - offsetText).quality(40.0f).round(0.0f, 4.0f, 0.0f, 4.0f).softness(1.0f).thickness(2.0f).outlineColor(ColorAssist.getOutline(0.15f)).color(ColorAssist.multAlpha(ColorAssist.BLACK, 0.65f)).build());
        blur.render(ShapeProperties.create(matrix, this.getX(), (float)(this.getY() + offsetText) - 0.5f, this.getWidth(), this.getHeight() - offsetText).quality(40.0f).round(0.0f, 4.0f, 0.0f, 4.0f).thickness(2.0f).softness(1.0f).outlineColor(ColorAssist.multAlpha(ColorAssist.multAlpha(ColorAssist.getClientColor(), 0.8f), 0.5f)).color(ColorAssist.multAlpha(ColorAssist.getClientColor(), 0.1f)).build());
        font.drawText(matrix, (class_2561)mainText, (int)((float)this.getX() + ((float)this.getWidth() - font.getStringWidth((class_2561)mainText)) / 2.0f), (float)(this.getY() + padding) + 1.5f);
        font.drawText(matrix, (class_2561)text, this.getX() + padding, this.getY() + offsetText + padding);
        if (this.getX() > mc.method_22683().method_4486() / 2) {
            this.setX(this.getX() + this.getWidth() - width);
        }
        this.setWidth(width);
        this.setHeight((int)((double)font.getStringHeight((class_2561)text) / 2.16 + (double)offsetText + (double)padding));
    }
}

