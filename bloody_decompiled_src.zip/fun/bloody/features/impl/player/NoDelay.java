/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.player;

import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;

public class NoDelay
extends Module {
    public final MultiSelectSetting ignoreSetting = new MultiSelectSetting("\u0422\u0438\u043f", "\u0420\u0430\u0437\u0440\u0435\u0448\u0430\u0435\u0442 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0435 \u0432\u0430\u043c\u0438 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044f").value("Jump", "Right Click", "Break CoolDown");

    public static NoDelay getInstance() {
        return Instance.get(NoDelay.class);
    }

    public NoDelay() {
        super("NoDelay", "No Delay", ModuleCategory.PLAYER);
        this.setup(this.ignoreSetting);
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (this.ignoreSetting.isSelected("Break CoolDown")) {
            NoDelay.mc.field_1761.field_3716 = 0;
        }
        if (this.ignoreSetting.isSelected("Jump")) {
            NoDelay.mc.field_1724.field_6228 = 0;
        }
        if (this.ignoreSetting.isSelected("Right Click")) {
            NoDelay.mc.field_1752 = 0;
        }
    }
}

