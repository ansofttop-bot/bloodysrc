/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 */
package fun.bloody.features.impl.player;

import fun.bloody.events.block.PushEvent;
import fun.bloody.events.player.PlayerCollisionEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.utils.client.managers.event.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

public class NoPush
extends Module {
    private final MultiSelectSetting ignoreSetting = new MultiSelectSetting("\u0418\u0433\u043d\u043e\u0440\u0438\u0440\u043e\u0432\u0430\u0442\u044c", "\u0420\u0430\u0437\u0440\u0435\u0448\u0430\u0435\u0442 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0435 \u0432\u0430\u043c\u0438 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044f").value("Water", "Block", "Entity Collision", "Powder Snow", "Berry");

    public NoPush() {
        super("NoPush", "No Push", ModuleCategory.PLAYER);
        this.setup(this.ignoreSetting);
    }

    @EventHandler
    public void onPush(PushEvent e) {
        switch (e.getType()) {
            case COLLISION: {
                e.setCancelled(this.ignoreSetting.isSelected("Entity Collision"));
                break;
            }
            case WATER: {
                e.setCancelled(this.ignoreSetting.isSelected("Water"));
                break;
            }
            case BLOCK: {
                e.setCancelled(this.ignoreSetting.isSelected("Block"));
            }
        }
    }

    @EventHandler
    public void onPlayerCollision(PlayerCollisionEvent e) {
        class_2248 block = e.getBlock();
        if (block.equals(class_2246.field_27879)) {
            e.setCancelled(this.ignoreSetting.isSelected("Powder Snow"));
        } else if (block.equals(class_2246.field_16999)) {
            e.setCancelled(this.ignoreSetting.isSelected("Berry"));
        }
    }
}

