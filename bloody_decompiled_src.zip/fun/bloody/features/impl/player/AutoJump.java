/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 */
package fun.bloody.features.impl.player;

import fun.bloody.events.player.MotionEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.managers.event.EventHandler;
import net.minecraft.class_2338;

public class AutoJump
extends Module {
    public AutoJump() {
        super("AutoJump", ModuleCategory.PLAYER);
    }

    @EventHandler
    public void onMotion(MotionEvent event) {
        if (AutoJump.mc.field_1724 == null || AutoJump.mc.field_1687 == null) {
            return;
        }
        if (!AutoJump.mc.field_1724.method_24828()) {
            return;
        }
        if (AutoJump.mc.field_1724.field_3913.field_3905 <= 0.0f) {
            return;
        }
        class_2338 playerPos = AutoJump.mc.field_1724.method_24515();
        float yaw = AutoJump.mc.field_1724.method_36454();
        int offsetX = 0;
        int offsetZ = 0;
        float normalizedYaw = (yaw % 360.0f + 360.0f) % 360.0f;
        if (normalizedYaw >= 315.0f || normalizedYaw < 45.0f) {
            offsetZ = 1;
        } else if (normalizedYaw >= 45.0f && normalizedYaw < 135.0f) {
            offsetX = -1;
        } else if (normalizedYaw >= 135.0f && normalizedYaw < 225.0f) {
            offsetZ = -1;
        } else {
            offsetX = 1;
        }
        class_2338 frontPos = playerPos.method_10069(offsetX, 0, offsetZ);
        class_2338 belowFrontPos = frontPos.method_10074();
        if (AutoJump.mc.field_1687.method_8320(belowFrontPos).method_26215() && AutoJump.mc.field_1724.method_24828()) {
            AutoJump.mc.field_1724.method_6043();
        }
    }

    @Override
    public void deactivate() {
    }
}

