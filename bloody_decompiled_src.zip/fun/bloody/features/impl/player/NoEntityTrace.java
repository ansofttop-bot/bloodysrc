/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1829
 */
package fun.bloody.features.impl.player;

import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.utils.client.Instance;
import net.minecraft.class_1829;

public class NoEntityTrace
extends Module {
    private final BooleanSetting noSword = new BooleanSetting("\u0411\u0435\u0437 \u043c\u0435\u0447\u0430", "\u041d\u0435 \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u0441 \u043c\u0435\u0447\u043e\u043c \u0432 \u0440\u0443\u043a\u0435").setValue(true);

    public NoEntityTrace() {
        super("NoEntityTrace", "No Entity Trace", ModuleCategory.PLAYER);
        this.setup(this.noSword);
    }

    public static NoEntityTrace getInstance() {
        return Instance.get(NoEntityTrace.class);
    }

    public boolean shouldIgnoreEntityTrace() {
        return this.isState() && (!(NoEntityTrace.mc.field_1724.method_6047().method_7909() instanceof class_1829) || !this.noSword.isValue());
    }
}

