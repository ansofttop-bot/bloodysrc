/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.player;

import fun.bloody.common.repository.friend.FriendUtils;
import fun.bloody.events.render.TextFactoryEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.TextSetting;
import fun.bloody.utils.client.managers.event.EventHandler;

public class NameProtect
extends Module {
    private final TextSetting nameSetting = new TextSetting("\u0418\u043c\u044f", "\u041d\u0438\u043a\u043d\u0435\u0439\u043c, \u043a\u043e\u0442\u043e\u0440\u044b\u0439 \u0431\u0443\u0434\u0435\u0442 \u0437\u0430\u043c\u0435\u043d\u0435\u043d \u043d\u0430 \u0432\u0430\u0448").setText("Protected").setMax(32);
    private final BooleanSetting friendsSetting = new BooleanSetting("\u0414\u0440\u0443\u0437\u044c\u044f", "\u0421\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043d\u0438\u043a\u043d\u0435\u0439\u043c\u044b \u0434\u0440\u0443\u0437\u0435\u0439").setValue(true);

    public NameProtect() {
        super("NameProtect", "Name Protect", ModuleCategory.PLAYER);
        this.setup(this.friendsSetting);
    }

    @EventHandler
    public void onTextFactory(TextFactoryEvent e) {
        e.replaceText(mc.method_1548().method_1676(), this.nameSetting.getText());
        if (this.friendsSetting.isValue()) {
            FriendUtils.getFriends().forEach(friend -> e.replaceText(friend.getName(), this.nameSetting.getText()));
        }
    }
}

