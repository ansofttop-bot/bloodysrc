/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_243
 *  net.minecraft.class_2680
 */
package fun.bloody.features.impl.player;

import fun.bloody.events.player.RotationUpdateEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.math.time.StopWatch;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public class AntiAFK
extends Module {
    StopWatch timer = new StopWatch();
    MultiSelectSetting multiSetting = new MultiSelectSetting("\u0420\u0435\u0436\u0438\u043c", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435, \u0447\u0442\u043e \u0431\u0443\u0434\u0435\u0442 \u043f\u0440\u043e\u0438\u0441\u0445\u043e\u0434\u0438\u0442\u044c").value("Walk", "Jump", "Spin", "Rotation change");
    SliderSettings time = new SliderSettings("\u0412\u044b\u043f\u043e\u043b\u043d\u044f\u0442\u044c \u043a\u0430\u0436\u0434\u044b\u0435 (\u0432 \u043c\u0438\u043d\u0443\u0442\u0430\u0445)", "\u043f\u0438\u0444").setValue(10.0f).range(1.0f, 25.0f);
    private double yawTarget = 0.0;
    private boolean rotating = false;
    private class_243 walkStartPos = null;
    private boolean walking = false;
    private class_2338 breakingBlockPos = null;

    public AntiAFK() {
        super("AntiAFK", "Anti AFK", ModuleCategory.PLAYER);
        this.setup(this.multiSetting, this.time);
    }

    @Override
    public void activate() {
        this.timer.reset();
    }

    @Override
    public void deactivate() {
        this.rotating = false;
    }

    @EventHandler
    public void rotate(RotationUpdateEvent e) {
        if (this.rotating) {
            double diff = this.yawTarget - (double)AntiAFK.mc.field_1724.method_36454();
            double diff2 = this.yawTarget - (double)AntiAFK.mc.field_1724.method_36455();
            if (Math.abs(diff) > 1.0) {
                AntiAFK.mc.field_1724.method_36456((float)((double)AntiAFK.mc.field_1724.method_36454() + diff * 0.1));
                AntiAFK.mc.field_1724.method_36457((float)((double)AntiAFK.mc.field_1724.method_36455() + diff * 0.1));
            } else {
                this.rotating = false;
            }
        }
    }

    @EventHandler
    public void tick(TickEvent e) {
        if (PlayerInteractionHelper.nullCheck()) {
            return;
        }
        long intervalMs = (long)(this.time.getValue() * 60.0f * 100.0f);
        if (this.timer.every(intervalMs)) {
            List<String> modes = this.multiSetting.getSelected();
            Iterator<String> iterator2 = modes.iterator();
            while (iterator2.hasNext()) {
                String mode;
                switch (mode = iterator2.next()) {
                    case "Walk": {
                        this.walkForward();
                        break;
                    }
                    case "Jump": {
                        if (!AntiAFK.mc.field_1724.method_24828()) break;
                        AntiAFK.mc.field_1690.field_1903.method_23481(true);
                        break;
                    }
                    case "Spin": {
                        this.spin();
                        break;
                    }
                    case "Rotation change": {
                        this.randomRotation();
                        break;
                    }
                    case "Break Block": {
                        this.breakBlockUnder();
                    }
                }
            }
        }
    }

    private void walkForward() {
        if (!this.walking) {
            this.walkStartPos = AntiAFK.mc.field_1724.method_19538();
            this.walking = true;
        }
        AntiAFK.mc.field_1690.field_1881.method_23481(false);
        AntiAFK.mc.field_1690.field_1913.method_23481(false);
        AntiAFK.mc.field_1690.field_1849.method_23481(false);
        class_243 look = AntiAFK.mc.field_1724.method_5720();
        class_2338 target = AntiAFK.mc.field_1724.method_24515().method_10069((int)look.field_1352 * 5, 0, (int)look.field_1350 * 5);
        double distance = AntiAFK.mc.field_1724.method_19538().method_1022(this.walkStartPos);
        if (distance >= 5.0) {
            AntiAFK.mc.field_1690.field_1894.method_23481(false);
            AntiAFK.mc.field_1690.field_1881.method_23481(false);
            AntiAFK.mc.field_1690.field_1913.method_23481(false);
            AntiAFK.mc.field_1690.field_1849.method_23481(false);
            this.walking = false;
            this.walkStartPos = null;
            return;
        }
        if (!AntiAFK.mc.field_1687.method_8320(target).method_26215()) {
            AntiAFK.mc.field_1690.field_1881.method_23481(true);
        } else {
            AntiAFK.mc.field_1690.field_1894.method_23481(true);
        }
    }

    private void spin() {
        this.yawTarget = AntiAFK.mc.field_1724.method_36454() + 360.0f;
        this.rotating = true;
    }

    private void randomRotation() {
        this.yawTarget = (double)AntiAFK.mc.field_1724.method_36454() + (Math.random() * 360.0 - 180.0);
        this.rotating = true;
    }

    private void breakBlockUnder() {
        class_2338 pos = AntiAFK.mc.field_1724.method_24515().method_10074();
        class_2680 block = AntiAFK.mc.field_1687.method_8320(pos);
        if (block.method_26215()) {
            AntiAFK.mc.field_1690.field_1886.method_23481(false);
            this.breakingBlockPos = null;
            return;
        }
        if (!pos.equals((Object)this.breakingBlockPos)) {
            this.breakingBlockPos = pos;
        }
        AntiAFK.mc.field_1690.field_1886.method_23481(true);
    }
}

