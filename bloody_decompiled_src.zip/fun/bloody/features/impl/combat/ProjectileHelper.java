/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1308
 *  net.minecraft.class_1309
 *  net.minecraft.class_1429
 *  net.minecraft.class_1531
 *  net.minecraft.class_1657
 *  net.minecraft.class_1753
 *  net.minecraft.class_1764
 *  net.minecraft.class_1799
 *  net.minecraft.class_1835
 *  net.minecraft.class_1937
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 */
package fun.bloody.features.impl.combat;

import fun.bloody.common.repository.friend.FriendUtils;
import fun.bloody.events.player.RotationUpdateEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.features.aura.target.TargetFinder;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.features.aura.warp.TurnsConfig;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import fun.bloody.utils.math.task.TaskPriority;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1835;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class ProjectileHelper
extends Module {
    private final SliderSettings searchDistance = new SliderSettings("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u043f\u043e\u0438\u0441\u043a\u0430", "\u0420\u0430\u0434\u0438\u0443\u0441 \u043f\u043e\u0438\u0441\u043a\u0430 \u0446\u0435\u043b\u0438 \u0432\u043e\u043a\u0440\u0443\u0433 \u0438\u0433\u0440\u043e\u043a\u0430").setValue(16.0f).range(5.0f, 64.0f);
    private final MultiSelectSetting targetType = new MultiSelectSetting("\u0422\u0438\u043f \u0442\u0430\u0440\u0433\u0435\u0442\u0430", "\u0424\u0438\u043b\u044c\u0442\u0440\u0443\u0435\u0442 \u0446\u0435\u043b\u0438 \u043f\u043e \u0442\u0438\u043f\u0443").value("Players", "Mobs", "Animals", "Armor Stand").selected("Players", "Mobs", "Animals");
    private final MultiSelectSetting settings = new MultiSelectSetting("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438", "\u0414\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u044b\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438").value("\u0422\u043e\u043b\u044c\u043a\u043e \u0432\u043e \u0432\u0440\u0435\u043c\u044f \u0437\u0430\u0440\u044f\u0434\u0430", "\u041d\u0430\u0432\u043e\u0434\u0438\u0442\u0441\u044f \u0437\u0430 \u0441\u0442\u0435\u043d\u043e\u0439").selected("\u0422\u043e\u043b\u044c\u043a\u043e \u0432\u043e \u0432\u0440\u0435\u043c\u044f \u0437\u0430\u0440\u044f\u0434\u0430");
    private final TargetFinder targetFinder = new TargetFinder();
    private class_1309 currentTarget;

    public ProjectileHelper() {
        super("ProjectileHelper", "Projectile Helper", ModuleCategory.COMBAT);
        this.setup(this.searchDistance, this.targetType, this.settings);
    }

    public class_1309 getTarget(class_1937 world, Iterable<class_1297> entities) {
        List entityList = StreamSupport.stream(entities.spliterator(), false).collect(Collectors.toList());
        List validTargets = entityList.stream().filter(e -> e instanceof class_1309).map(e -> (class_1309)e).filter(this::isValidTarget).collect(Collectors.toList());
        class_1309 nearestTarget = null;
        double nearestDistance = Double.MAX_VALUE;
        class_243 playerPos = ProjectileHelper.mc.field_1724.method_33571();
        for (class_1309 target : validTargets) {
            class_243 targetCenter;
            class_3965 hit;
            double distance = target.method_19538().method_1022(ProjectileHelper.mc.field_1724.method_19538());
            if (!(distance < nearestDistance) || !(distance <= (double)this.searchDistance.getValue()) || !this.settings.isSelected("\u041d\u0430\u0432\u043e\u0434\u0438\u0442\u0441\u044f \u0437\u0430 \u0441\u0442\u0435\u043d\u043e\u0439") && (hit = ProjectileHelper.mc.field_1687.method_17742(new class_3959(playerPos, targetCenter = target.method_19538().method_1031(0.0, (double)target.method_17682() * 0.5, 0.0), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)ProjectileHelper.mc.field_1724))).method_17783() == class_239.class_240.field_1332) continue;
            nearestDistance = distance;
            nearestTarget = target;
        }
        this.currentTarget = nearestTarget;
        return this.currentTarget;
    }

    private boolean isValidTarget(class_1309 entity) {
        if (entity == null) {
            return false;
        }
        if (entity == ProjectileHelper.mc.field_1724) {
            return false;
        }
        if (!entity.method_5805()) {
            return false;
        }
        if (!this.targetType.isSelected("Players") && entity instanceof class_1657) {
            return false;
        }
        if (!this.targetType.isSelected("Mobs") && entity instanceof class_1308) {
            return false;
        }
        if (!this.targetType.isSelected("Animals") && entity instanceof class_1429) {
            return false;
        }
        return this.targetType.isSelected("Armor Stand") || !(entity instanceof class_1531);
    }

    public class_243 getPredictedPosition(class_1309 target, class_243 shooterPos, float projectileSpeed, float gravity) {
        class_3965 headHit;
        double playerY = shooterPos.field_1351;
        double targetFeetY = target.method_19538().field_1351;
        double targetHeadY = target.method_19538().field_1351 + (double)target.method_17682();
        double targetCenterY = target.method_19538().field_1351 + (double)target.method_17682() * 0.5;
        class_243 headPos = target.method_19538().method_1031(0.0, (double)target.method_17682() * 0.9, 0.0);
        class_243 centerPos = target.method_19538().method_1031(0.0, (double)target.method_17682() * 0.5, 0.0);
        class_243 targetPos = playerY < targetCenterY - 0.5 ? ((headHit = ProjectileHelper.mc.field_1687.method_17742(new class_3959(shooterPos, headPos, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)ProjectileHelper.mc.field_1724))).method_17783() == class_239.class_240.field_1333 ? headPos : centerPos) : centerPos;
        class_243 targetVelocity = target.method_18798();
        class_243 predicted = targetPos;
        for (int i = 0; i < 10; ++i) {
            class_243 delta = predicted.method_1020(shooterPos);
            double distance = delta.method_1033();
            double t = distance / (double)projectileSpeed;
            predicted = targetPos.method_1019(targetVelocity.method_1021(t));
            double gravityDrop = 0.5 * (double)gravity * t * t;
            predicted = predicted.method_1023(0.0, gravityDrop, 0.0);
        }
        return predicted;
    }

    private boolean isHoldingProjectile() {
        class_1799 main = ProjectileHelper.mc.field_1724.method_6047();
        return main.method_7909() instanceof class_1753 || main.method_7909() instanceof class_1764 || main.method_7909() instanceof class_1835;
    }

    /*
     * Unable to fully structure code
     */
    @EventHandler
    public void onRotationUpdate(RotationUpdateEvent e) {
        if (e.getType() != 0) {
            return;
        }
        stack = ProjectileHelper.mc.field_1724.method_6047();
        holdingBow = stack.method_7909() instanceof class_1753;
        if (!(stack.method_7909() instanceof class_1764)) ** GOTO lbl-1000
        (class_1764)stack.method_7909();
        if (class_1764.method_7781((class_1799)stack)) {
            v0 = true;
        } else lbl-1000:
        // 2 sources

        {
            v0 = false;
        }
        holdingCrossbow = v0;
        holdingTrident = stack.method_7909() instanceof class_1835;
        if (!(holdingBow || holdingCrossbow || holdingTrident)) {
            this.currentTarget = null;
            return;
        }
        if (this.settings.isSelected("\u0422\u043e\u043b\u044c\u043a\u043e \u0432\u043e \u0432\u0440\u0435\u043c\u044f \u0437\u0430\u0440\u044f\u0434\u0430")) {
            if (holdingBow) {
                if (ProjectileHelper.mc.field_1724.method_6030() != stack || ProjectileHelper.mc.field_1724.method_6048() < 3) {
                    this.currentTarget = null;
                    return;
                }
            } else if (holdingTrident && ProjectileHelper.mc.field_1724.method_6030() != stack) {
                this.currentTarget = null;
                return;
            }
        }
        if (this.currentTarget != null && !this.currentTarget.method_5805()) {
            this.currentTarget = null;
        }
        if (this.currentTarget == null) {
            this.currentTarget = this.getTarget((class_1937)ProjectileHelper.mc.field_1687, ProjectileHelper.mc.field_1687.method_18112());
            if (this.currentTarget == ProjectileHelper.mc.field_1724) {
                this.currentTarget = null;
            }
        }
        if (FriendUtils.isFriend((class_1297)this.currentTarget)) {
            this.currentTarget = null;
        }
        if (this.currentTarget != null) {
            shooterPos = ProjectileHelper.mc.field_1724.method_19538().method_1031(0.0, (double)ProjectileHelper.mc.field_1724.method_18381(ProjectileHelper.mc.field_1724.method_18376()), 0.0).method_1019(ProjectileHelper.mc.field_1724.method_18798());
            projectileSpeed = 3.0f;
            if (holdingBow) {
                useTicks = ProjectileHelper.mc.field_1724.method_6048();
                charge = class_1753.method_7722((int)useTicks);
                projectileSpeed = charge * 3.0f;
            } else if (holdingCrossbow) {
                projectileSpeed = 3.15f;
            } else if (holdingTrident) {
                projectileSpeed = 2.5f;
            }
            gravity = 0.03f;
            predictedPos = this.getPredictedPosition(this.currentTarget, shooterPos, projectileSpeed, gravity);
            dx = predictedPos.field_1352 - shooterPos.field_1352;
            dy = predictedPos.field_1351 - shooterPos.field_1351;
            dz = predictedPos.field_1350 - shooterPos.field_1350;
            distanceXZ = Math.sqrt(dx * dx + dz * dz);
            yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
            pitch = (float)(-Math.toDegrees(Math.atan2(dy, distanceXZ)));
            distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (distance > 5.0) {
                gravityCompensation = (float)((double)gravity * distance * distance * 0.05);
                pitch -= gravityCompensation;
            }
            TurnsConnection.INSTANCE.rotateTo(new Turns(yaw, pitch), TurnsConfig.DEFAULT, TaskPriority.HIGH_IMPORTANCE_1, this);
        }
    }
}

