/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_3532
 *  net.minecraft.class_3675
 *  net.minecraft.class_437
 *  net.minecraft.class_490
 *  net.minecraft.class_7923
 *  net.minecraft.class_9801
 */
package fun.bloody.features.impl.combat;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.events.keyboard.KeyEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.events.render.DrawEvent;
import fun.bloody.features.impl.movement.InventoryMove;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.features.module.setting.implement.TextSetting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.math.time.StopWatch;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_7923;
import net.minecraft.class_9801;

public class AutoSwap
extends Module {
    private final SelectSetting mode = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "\u0412\u044b\u0431\u043e\u0440 \u0440\u0435\u0436\u0438\u043c\u0430 \u0441\u0432\u0430\u043f\u0430").value("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b", "\u041a\u043e\u043b\u0435\u0441\u043e").selected("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b");
    private final SelectSetting firstItem = new SelectSetting("\u041f\u0435\u0440\u0432\u044b\u0439", "\u0412\u044b\u0431\u043e\u0440 \u043f\u0435\u0440\u0432\u043e\u0433\u043e \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u0430").value("\u0422\u043e\u0442\u0435\u043c", "\u0428\u0430\u0440", "\u0429\u0438\u0442").selected("\u0422\u043e\u0442\u0435\u043c").visible(() -> this.mode.isSelected("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b"));
    private final SelectSetting secondItem = new SelectSetting("\u0412\u0442\u043e\u0440\u043e\u0439", "\u0412\u044b\u0431\u043e\u0440 \u0432\u0442\u043e\u0440\u043e\u0433\u043e \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u0430").value("\u0422\u043e\u0442\u0435\u043c", "\u0428\u0430\u0440", "\u0429\u0438\u0442").selected("\u0429\u0438\u0442").visible(() -> this.mode.isSelected("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b"));
    private final BindSetting bind = new BindSetting("\u041a\u043d\u043e\u043f\u043a\u0430 \u0441\u0432\u0430\u043f\u0430", "\u041a\u043d\u043e\u043f\u043a\u0430 \u0434\u043b\u044f \u0440\u0435\u0436\u0438\u043c\u0430 \u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b").visible(() -> this.mode.isSelected("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b"));
    private final BindSetting wheelBind = new BindSetting("\u0411\u0438\u043d\u0434 \u043a\u043e\u043b\u0435\u0441\u0430", "\u041a\u043d\u043e\u043f\u043a\u0430 \u0434\u043b\u044f \u0440\u0435\u0436\u0438\u043c\u0430 \u041a\u043e\u043b\u0435\u0441\u043e").visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e"));
    private final SliderSettings wheelSlots = new SliderSettings("\u042f\u0447\u0435\u0439\u043a\u0438", "\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u044f\u0447\u0435\u0435\u043a \u0432 \u043a\u043e\u043b\u0435\u0441\u0435").setValue(3.0f).range(2.0f, 8.0f).visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e"));
    private final BooleanSetting customSlots = new BooleanSetting("Custom Slots", "\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c \u043a\u0430\u0441\u0442\u043e\u043c\u043d\u044b\u0435 \u0441\u043b\u043e\u0442\u044b").setValue(false).visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e"));
    private final TextSetting slot1 = new TextSetting("\u0421\u043b\u043e\u0442 1", "\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u0432 \u0441\u043b\u043e\u0442\u0435 1").visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e") && this.customSlots.isValue());
    private final TextSetting slot2 = new TextSetting("\u0421\u043b\u043e\u0442 2", "\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u0432 \u0441\u043b\u043e\u0442\u0435 2").visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e") && this.customSlots.isValue());
    private final TextSetting slot3 = new TextSetting("\u0421\u043b\u043e\u0442 3", "\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u0432 \u0441\u043b\u043e\u0442\u0435 3").visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e") && this.customSlots.isValue());
    private final TextSetting slot4 = new TextSetting("\u0421\u043b\u043e\u0442 4", "\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u0432 \u0441\u043b\u043e\u0442\u0435 4").visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e") && this.customSlots.isValue());
    private final TextSetting slot5 = new TextSetting("\u0421\u043b\u043e\u0442 5", "\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u0432 \u0441\u043b\u043e\u0442\u0435 5").visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e") && this.customSlots.isValue());
    private final TextSetting slot6 = new TextSetting("\u0421\u043b\u043e\u0442 6", "\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u0432 \u0441\u043b\u043e\u0442\u0435 6").visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e") && this.customSlots.isValue());
    private final TextSetting slot7 = new TextSetting("\u0421\u043b\u043e\u0442 7", "\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u0432 \u0441\u043b\u043e\u0442\u0435 7").visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e") && this.customSlots.isValue());
    private final TextSetting slot8 = new TextSetting("\u0421\u043b\u043e\u0442 8", "\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u0432 \u0441\u043b\u043e\u0442\u0435 8").visible(() -> this.mode.isSelected("\u041a\u043e\u043b\u0435\u0441\u043e") && this.customSlots.isValue());
    private boolean wheelOpen = false;
    private int pendingPickSlot = -1;
    private boolean cursorUnlocked = false;
    private class_1792 pendingSwapItem = null;
    private boolean isWaitingForStop = false;
    private class_1792 lastMainHandItem = null;
    private long swapBlockTime = 0L;
    private static final long SWAP_BLOCK_DURATION = 100L;
    private final StopWatch swapWatch = new StopWatch();
    private final StopWatch swapWatchK = new StopWatch();

    public static AutoSwap getInstance() {
        return Instance.get(AutoSwap.class);
    }

    public AutoSwap() {
        super("AutoSwap", "Auto Swap", ModuleCategory.COMBAT);
        this.setup(this.mode, this.firstItem, this.secondItem, this.bind, this.wheelBind, this.wheelSlots, this.customSlots, this.slot1, this.slot2, this.slot3, this.slot4, this.slot5, this.slot6, this.slot7, this.slot8);
        this.slot1.setText("minecraft:totem_of_undying");
        this.slot2.setText("minecraft:player_head");
        this.slot3.setText("minecraft:shield");
        this.slot4.setText("minecraft:air");
        this.slot5.setText("minecraft:air");
        this.slot6.setText("minecraft:air");
        this.slot7.setText("minecraft:air");
        this.slot8.setText("minecraft:air");
    }

    public boolean isWheelOpen() {
        return this.wheelOpen;
    }

    @Override
    public void deactivate() {
        super.deactivate();
        this.wheelOpen = false;
        this.pendingPickSlot = -1;
        this.updateWheelCursorState(false);
        this.isWaitingForStop = false;
        this.pendingSwapItem = null;
    }

    @EventHandler
    public void onKey(KeyEvent event) {
        if (AutoSwap.mc.field_1755 != null && !this.wheelOpen) {
            return;
        }
        if ("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b".equals(this.mode.getSelected())) {
            this.handleItemsMode(event);
        } else {
            this.handleWheelMode(event);
        }
    }

    private void handleItemsMode(KeyEvent event) {
        if (this.swapWatchK.finished(300.0) && event.isKeyDown(this.bind.getKey())) {
            class_1792 first = this.getItemByType(this.firstItem.getSelected());
            class_1792 second = this.getItemByType(this.secondItem.getSelected());
            class_1799 offhand = AutoSwap.mc.field_1724.method_6079();
            if (offhand.method_7909() != first && first != class_1802.field_8162) {
                this.swapToItem(first);
            } else if (second != class_1802.field_8162) {
                this.swapToItem(second);
            }
            this.swapWatchK.reset();
        }
    }

    private void handleWheelMode(KeyEvent event) {
        if (this.swapWatchK.finished(300.0) && event.isKeyDown(this.wheelBind.getKey())) {
            boolean bl = this.wheelOpen = !this.wheelOpen;
            if (!this.wheelOpen) {
                this.pendingPickSlot = -1;
                this.updateWheelCursorState(false);
            } else {
                this.updateWheelCursorState(true);
            }
            this.swapWatchK.reset();
        }
        if (this.wheelOpen) {
            if (event.key() == 0 && event.action() == 1) {
                this.handleWheelClick();
            }
            if (event.key() == 256 && event.action() == 1) {
                this.wheelOpen = false;
                this.pendingPickSlot = -1;
                this.updateWheelCursorState(false);
            }
        }
    }

    private void handleWheelClick() {
        float mouseY;
        int count = this.getWheelSlotCount();
        float cx = (float)mc.method_22683().method_4486() / 2.0f;
        float cy = (float)mc.method_22683().method_4502() / 2.0f;
        float outerR = 92.0f;
        float innerR = 54.0f;
        float mouseX = (float)(AutoSwap.mc.field_1729.method_1603() * (double)mc.method_22683().method_4486() / (double)mc.method_22683().method_4480());
        int hover = this.getHoverIndex(mouseX, mouseY = (float)(AutoSwap.mc.field_1729.method_1604() * (double)mc.method_22683().method_4502() / (double)mc.method_22683().method_4507()), cx, cy, innerR, outerR, count);
        if (hover == -1) {
            return;
        }
        class_1799 stack = this.getStackForIndex(hover);
        if (stack.method_7960() || stack.method_7909() == class_1802.field_8162) {
            this.pendingPickSlot = hover;
            mc.method_1507((class_437)new class_490((class_1657)AutoSwap.mc.field_1724));
            return;
        }
        this.swapToItem(stack.method_7909());
        this.wheelOpen = false;
        this.updateWheelCursorState(false);
    }

    @EventHandler
    public void onTick(TickEvent event) {
        if (AutoSwap.mc.field_1724 == null) {
            return;
        }
        if (this.isWaitingForStop && this.pendingSwapItem != null) {
            InventoryMove.stopMovementTemporarily(2);
            AutoSwap.mc.field_1690.field_1894.method_23481(false);
            AutoSwap.mc.field_1690.field_1881.method_23481(false);
            AutoSwap.mc.field_1690.field_1913.method_23481(false);
            AutoSwap.mc.field_1690.field_1849.method_23481(false);
            AutoSwap.mc.field_1690.field_1903.method_23481(false);
            AutoSwap.mc.field_1690.field_1867.method_23481(false);
            if (AutoSwap.mc.field_1724.field_3913.field_3905 == 0.0f && AutoSwap.mc.field_1724.field_3913.field_3907 == 0.0f) {
                this.performSwap(this.pendingSwapItem);
                this.isWaitingForStop = false;
                this.pendingSwapItem = null;
                boolean wPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)AutoSwap.mc.field_1690.field_1894.method_1429().method_1444());
                boolean sPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)AutoSwap.mc.field_1690.field_1881.method_1429().method_1444());
                boolean aPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)AutoSwap.mc.field_1690.field_1913.method_1429().method_1444());
                boolean dPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)AutoSwap.mc.field_1690.field_1849.method_1429().method_1444());
                boolean spacePressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)AutoSwap.mc.field_1690.field_1903.method_1429().method_1444());
                boolean shiftPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)AutoSwap.mc.field_1690.field_1867.method_1429().method_1444());
                AutoSwap.mc.field_1690.field_1894.method_23481(wPressed);
                AutoSwap.mc.field_1690.field_1881.method_23481(sPressed);
                AutoSwap.mc.field_1690.field_1913.method_23481(aPressed);
                AutoSwap.mc.field_1690.field_1849.method_23481(dPressed);
                AutoSwap.mc.field_1690.field_1903.method_23481(spacePressed);
                AutoSwap.mc.field_1690.field_1867.method_23481(shiftPressed);
            }
            return;
        }
    }

    @EventHandler
    public void onDraw(DrawEvent event) {
        int i;
        if (!this.wheelOpen || !"\u041a\u043e\u043b\u0435\u0441\u043e".equals(this.mode.getSelected())) {
            return;
        }
        if (AutoSwap.mc.field_1755 != null) {
            return;
        }
        int count = this.getWheelSlotCount();
        float cx = (float)mc.method_22683().method_4486() / 2.0f;
        float cy = (float)mc.method_22683().method_4502() / 2.0f;
        float outerR = 92.0f;
        float innerR = 54.0f;
        float mouseX = (float)(AutoSwap.mc.field_1729.method_1603() * (double)mc.method_22683().method_4486() / (double)mc.method_22683().method_4480());
        float mouseY = (float)(AutoSwap.mc.field_1729.method_1604() * (double)mc.method_22683().method_4502() / (double)mc.method_22683().method_4507());
        int hover = this.getHoverIndex(mouseX, mouseY, cx, cy, innerR, outerR, count);
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27379, class_290.field_1576);
        for (i = 0; i < count; ++i) {
            boolean isHover = i == hover;
            int r = 0;
            int g = 0;
            int b = 0;
            int a = 38;
            if (isHover) {
                r = 50;
                g = 255;
                b = 50;
                a = 38;
            }
            float start = (float)(-1.5707963267948966 + Math.PI * 2 * ((double)i / (double)count));
            float end = (float)(-1.5707963267948966 + Math.PI * 2 * (((double)i + 1.0) / (double)count));
            this.drawRingSegment(buffer, cx, cy, innerR, outerR, start, end, r, g, b, a);
        }
        class_286.method_43433((class_9801)buffer.method_60800());
        for (i = 0; i < count; ++i) {
            class_1799 stack = this.getStackForIndex(i);
            if (stack.method_7960() || stack.method_7909() == class_1802.field_8162) continue;
            float start = (float)(-1.5707963267948966 + Math.PI * 2 * ((double)i / (double)count));
            float end = (float)(-1.5707963267948966 + Math.PI * 2 * (((double)i + 1.0) / (double)count));
            float mid = (start + end) / 2.0f;
            float iconR = (innerR + outerR) / 2.0f;
            float ix = cx + (float)Math.cos(mid) * iconR;
            float iy = cy + (float)Math.sin(mid) * iconR;
            event.getDrawContext().method_51427(stack, (int)(ix - 8.0f), (int)(iy - 8.0f));
        }
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private void swapToItem(class_1792 item) {
        this.isWaitingForStop = true;
        this.pendingSwapItem = item;
    }

    private void performSwap(class_1792 item) {
        int slot = this.findItemSlot(item);
        if (slot != -1) {
            int syncSlot = slot < 9 ? slot + 36 : slot;
            AutoSwap.mc.field_1761.method_2906(0, syncSlot, 0, class_1713.field_7790, (class_1657)AutoSwap.mc.field_1724);
            AutoSwap.mc.field_1761.method_2906(0, 45, 0, class_1713.field_7790, (class_1657)AutoSwap.mc.field_1724);
            AutoSwap.mc.field_1761.method_2906(0, syncSlot, 0, class_1713.field_7790, (class_1657)AutoSwap.mc.field_1724);
        }
    }

    private void updateWheelCursorState(boolean shouldBeUnlocked) {
        if (mc == null || AutoSwap.mc.field_1729 == null) {
            return;
        }
        if (shouldBeUnlocked) {
            AutoSwap.mc.field_1729.method_1610();
            this.cursorUnlocked = true;
            return;
        }
        if (this.cursorUnlocked) {
            AutoSwap.mc.field_1729.method_1612();
            this.cursorUnlocked = false;
        }
    }

    private int findItemSlot(class_1792 item) {
        for (int i = 0; i < 36; ++i) {
            class_1799 stack = AutoSwap.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() != item) continue;
            return i;
        }
        return -1;
    }

    private class_1792 getItemByType(String itemType) {
        return switch (itemType) {
            case "\u0422\u043e\u0442\u0435\u043c" -> class_1802.field_8288;
            case "\u0428\u0430\u0440" -> class_1802.field_8575;
            case "\u0429\u0438\u0442" -> class_1802.field_8255;
            default -> class_1802.field_8162;
        };
    }

    private int getWheelSlotCount() {
        int count = Math.round(this.wheelSlots.getValue());
        return class_3532.method_15340((int)count, (int)2, (int)8);
    }

    private List<TextSetting> getWheelSettings() {
        ArrayList<TextSetting> list = new ArrayList<TextSetting>();
        list.add(this.slot1);
        list.add(this.slot2);
        list.add(this.slot3);
        list.add(this.slot4);
        list.add(this.slot5);
        list.add(this.slot6);
        list.add(this.slot7);
        list.add(this.slot8);
        return list;
    }

    private void setSlotString(int index, String value) {
        List<TextSetting> settings = this.getWheelSettings();
        if (index < 0 || index >= settings.size()) {
            return;
        }
        settings.get(index).setText(value);
    }

    private class_1799 getStackForIndex(int index) {
        if (index < 0 || index >= 8) {
            return class_1799.field_8037;
        }
        if (!this.customSlots.isValue()) {
            return switch (index) {
                case 0 -> class_1802.field_8288.method_7854();
                case 1 -> class_1802.field_8575.method_7854();
                default -> class_1799.field_8037;
            };
        }
        List<TextSetting> settings = this.getWheelSettings();
        if (index >= settings.size()) {
            return class_1799.field_8037;
        }
        String raw = settings.get(index).getText();
        if (raw == null || raw.isBlank()) {
            return class_1799.field_8037;
        }
        class_2960 id = class_2960.method_12829((String)raw);
        if (id == null) {
            return class_1799.field_8037;
        }
        class_1792 item = (class_1792)class_7923.field_41178.method_63535(id);
        if (item == null) {
            return class_1799.field_8037;
        }
        return item.method_7854();
    }

    private int getHoverIndex(float mouseX, float mouseY, float cx, float cy, float innerR, float outerR, int count) {
        int idx;
        float dx = mouseX - cx;
        float dy = mouseY - cy;
        float dist = (float)Math.sqrt(dx * dx + dy * dy);
        if (dist < innerR || dist > outerR) {
            return -1;
        }
        double ang = Math.atan2(dy, dx);
        if ((ang += 1.5707963267948966) < 0.0) {
            ang += Math.PI * 2;
        }
        if ((idx = (int)Math.floor(ang / (Math.PI * 2) * (double)count)) < 0 || idx >= count) {
            return -1;
        }
        return idx;
    }

    private void drawRingSegment(class_287 buffer, float cx, float cy, float innerR, float outerR, float start, float end, int r, int g, int b, int a) {
        int steps = Math.max(32, (int)(96.0 * ((double)Math.abs(end - start) / (Math.PI * 2))));
        float step = (end - start) / (float)steps;
        for (int i = 0; i < steps; ++i) {
            float a0 = start + step * (float)i;
            float a1 = start + step * (float)(i + 1);
            float x0o = cx + (float)Math.cos(a0) * outerR;
            float y0o = cy + (float)Math.sin(a0) * outerR;
            float x1o = cx + (float)Math.cos(a1) * outerR;
            float y1o = cy + (float)Math.sin(a1) * outerR;
            float x0i = cx + (float)Math.cos(a0) * innerR;
            float y0i = cy + (float)Math.sin(a0) * innerR;
            float x1i = cx + (float)Math.cos(a1) * innerR;
            float y1i = cy + (float)Math.sin(a1) * innerR;
            buffer.method_22912(x0i, y0i, 0.0f).method_1336(r, g, b, a);
            buffer.method_22912(x0o, y0o, 0.0f).method_1336(r, g, b, a);
            buffer.method_22912(x1o, y1o, 0.0f).method_1336(r, g, b, a);
            buffer.method_22912(x0i, y0i, 0.0f).method_1336(r, g, b, a);
            buffer.method_22912(x1o, y1o, 0.0f).method_1336(r, g, b, a);
            buffer.method_22912(x1i, y1i, 0.0f).method_1336(r, g, b, a);
        }
    }
}

