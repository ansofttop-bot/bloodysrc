/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1792
 *  net.minecraft.class_1829
 *  net.minecraft.class_1937
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_2596
 *  net.minecraft.class_2663
 *  net.minecraft.class_2678
 *  net.minecraft.class_2724
 *  net.minecraft.class_2799
 *  net.minecraft.class_2799$class_2800
 *  net.minecraft.class_3532
 *  net.minecraft.class_3545
 *  net.minecraft.class_4587
 */
package fun.bloody.features.impl.combat;

import antidaunleak.api.annotation.Native;
import fun.bloody.Bloody;
import fun.bloody.display.hud.Notifications;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.events.player.MotionEvent;
import fun.bloody.events.player.RotationUpdateEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.events.render.DrawEvent;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.geometry.Render3D;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.features.aura.point.MultiPoint;
import fun.bloody.utils.features.aura.rotations.constructor.LinearConstructor;
import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.rotations.impl.FakeAngle;
import fun.bloody.utils.features.aura.rotations.impl.LegitAngle;
import fun.bloody.utils.features.aura.rotations.impl.OtherAngle;
import fun.bloody.utils.features.aura.rotations.impl.TestAngle;
import fun.bloody.utils.features.aura.striking.StrikeManager;
import fun.bloody.utils.features.aura.striking.StrikerConstructor;
import fun.bloody.utils.features.aura.target.TargetFinder;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.features.aura.warp.TurnsConfig;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.math.calc.Calculate;
import fun.bloody.utils.math.task.TaskPriority;
import java.lang.runtime.SwitchBootstraps;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1829;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2663;
import net.minecraft.class_2678;
import net.minecraft.class_2724;
import net.minecraft.class_2799;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import net.minecraft.class_4587;

public class Aura
extends Module {
    private static final float RANGE_MARGIN = 0.253f;
    private static final Map<String, Integer> LEGIT_SPRINT_MAP = Map.of("FunTime", 1, "Matrix", 1, "Snap", 1, "HolyWorld", 2);
    private TargetFinder targetSelector = new TargetFinder();
    private MultiPoint pointFinder = new MultiPoint();
    public class_1309 target;
    public class_1309 lastTarget;
    private long shiftTapEndTime = 0L;
    public static boolean fakeRotate;
    public static float legitSprintNeed;
    private FovCircleRenderer fovCircleRenderer;
    private SelectSetting aimMode = new SelectSetting("\u041d\u0430\u0432\u043e\u0434\u043a\u0430", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0442\u0438\u043f \u043d\u0430\u0432\u043e\u0434\u043a\u0438").value("Legit Snap", "Other", "FunTime").selected("FunTime");
    private MultiSelectSetting targetType = new MultiSelectSetting("\u0422\u0438\u043f \u0442\u0430\u0440\u0433\u0435\u0442\u0430", "\u0424\u0438\u043b\u044c\u0442\u0440\u0443\u0435\u0442 \u0432\u0435\u0441\u044c \u0441\u043f\u0438\u0441\u043e\u043a \u0446\u0435\u043b\u0435\u0439 \u043f\u043e \u0442\u0438\u043f\u0443").value("Players", "Mobs", "Animals", "Friends", "Armor Stand").selected("Players", "Mobs", "Animals");
    private SliderSettings attackRange = new SliderSettings("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u0443\u0434\u0430\u0440\u0430", "\u0414\u0430\u043b\u044c\u043d\u043e\u0441\u0442\u044c \u0430\u0442\u0430\u043a\u0438 \u0434\u043e \u0446\u0435\u043b\u0438").setValue(3.0f).range(1.0f, 6.0f);
    private SliderSettings lookRange = new SliderSettings("\u0414\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u0430\u044f \u0434\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u043f\u043e\u0438\u0441\u043a\u0430", "\u0414\u0438\u0430\u043f\u0430\u0437\u043e\u043d \u043f\u043e\u0438\u0441\u043a\u0430 \u0434\u043e \u0446\u0435\u043b\u0438").setValue(1.5f).range(0.0f, 2.0f);
    private MultiSelectSetting attackSetting = new MultiSelectSetting("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438", "\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u043d\u0430\u0441\u0442\u0440\u043e\u0438\u0442\u044c \u0440\u0430\u0431\u043e\u0442\u0443 \u0444\u0443\u043d\u043a\u0446\u0438\u0438").value("Only Critical", "Break Shield", "UnPress Shield", "No Attack When Eat", "Ignore The Walls", "Fake Lag", "Hit Chance", "\u0422\u043e\u043b\u044c\u043a\u043e \u0441 \u043e\u0440\u0443\u0436\u0438\u0435\u043c").selected("Only Critical", "Break Shield");
    private SliderSettings hitChance = new SliderSettings("\u0428\u0430\u043d\u0441 \u0443\u0434\u0430\u0440\u0430 \u0432 %", "\u0428\u0430\u043d\u0441 \u0443\u0434\u0430\u0440\u0430 \u043f\u043e \u0446\u0435\u043b\u0438").setValue(100.0f).range(1.0f, 100.0f).visible(() -> this.attackSetting.isSelected("Hit Chance"));
    private SelectSetting correctionType = new SelectSetting("\u041a\u043e\u0440\u0440\u0435\u043a\u0446\u0438\u0438 \u0434\u0432\u0438\u0436\u0435\u043d\u0438\u044f", "\u0412\u044b\u0431\u043e\u0440 \u043a\u043e\u0440\u0440\u0435\u043a\u0446\u0438\u0438 \u0434\u0432\u0438\u0436\u0435\u043d\u0438\u044f \u0438\u0433\u0440\u043e\u043a\u0430").value("Free", "Focused", "Not visible").selected("Free");
    private SelectSetting sprintReset = new SelectSetting("\u0421\u0431\u0440\u043e\u0441 \u0441\u043f\u0440\u0438\u043d\u0442\u0430", "\u0412\u044b\u0431\u043e\u0440 \u0441\u0431\u0440\u043e\u0441\u0430 \u0441\u043f\u0440\u0438\u043d\u0442\u0430 \u043f\u0435\u0440\u0435\u0434 \u0443\u0434\u0430\u0440\u043e\u043c").value("Legit", "Packet", "\u041d\u0435\u0442").selected("Legit");
    private BooleanSetting smartCrits = new BooleanSetting("\u0423\u0434\u0430\u0440\u044b \u043d\u0430 \u0437\u0435\u043c\u043b\u0435", "\u041a\u0440\u0438\u0442\u044b \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u0440\u0438 \u043d\u0430\u0436\u0430\u0442\u0438\u0438 \u043f\u0440\u043e\u0431\u0435\u043b\u0430").setValue(true).visible(() -> this.attackSetting.isSelected("Only Critical"));
    private final List<class_2596<?>> packets = new CopyOnWriteArrayList();
    private class_238 box;
    public static int tickStop;
    public static boolean shouldRotate;
    public boolean elytraStateForward = false;
    private boolean wasForwardPressed = false;

    public static Aura getInstance() {
        return Instance.get(Aura.class);
    }

    public Aura() {
        super("Aura", ModuleCategory.COMBAT);
        this.setup(this.aimMode, this.correctionType, this.sprintReset, this.targetType, this.attackRange, this.lookRange, this.hitChance, this.attackSetting, this.smartCrits);
        this.fovCircleRenderer = new FovCircleRenderer();
        Bloody.getInstance().getEventManager().register(this.fovCircleRenderer);
    }

    @Override
    public void deactivate() {
        this.targetSelector.releaseTarget();
        this.target = null;
        this.lastTarget = null;
        this.packets.forEach(PlayerInteractionHelper::sendPacketWithOutEvent);
        this.packets.clear();
        TurnsConnection rotationController = TurnsConnection.INSTANCE;
        rotationController.setRotation(null);
        rotationController.clear();
        rotationController.resetRotationPlan();
        super.deactivate();
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        class_1297 entity;
        class_2663 status;
        class_2596<?> class_25962 = e.getPacket();
        if (class_25962 instanceof class_2663 && (status = (class_2663)class_25962).method_11470() == 30 && (entity = status.method_11469((class_1937)Aura.mc.field_1687)) != null && entity.equals((Object)this.target) && Hud.getInstance().notificationSettings.isSelected("Break Shield")) {
            Notifications.getInstance().addList((class_2561)class_2561.method_43470((String)"\u0421\u043b\u043e\u043c\u0430\u043b\u0438 \u0449\u0438\u0442 \u0438\u0433\u0440\u043e\u043a\u0443 - ").method_10852(entity.method_5476()), 5000L);
        }
        if (this.attackSetting.isSelected("Fake Lag") && this.target != null) {
            if (PlayerInteractionHelper.nullCheck()) {
                return;
            }
            class_2596<?> class_25963 = e.getPacket();
            Objects.requireNonNull(class_25963);
            class_2596<?> class_25964 = class_25963;
            int n = 0;
            block5: while (true) {
                switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{class_2724.class, class_2678.class, class_2799.class}, class_25964, n)) {
                    case 0: {
                        class_2724 respawn = (class_2724)class_25964;
                        this.setState(false);
                        break block5;
                    }
                    case 1: {
                        class_2678 join = (class_2678)class_25964;
                        this.setState(false);
                        break block5;
                    }
                    case 2: {
                        class_2799 status2 = (class_2799)class_25964;
                        if (!status2.method_12119().equals((Object)class_2799.class_2800.field_12774)) {
                            n = 3;
                            continue block5;
                        }
                        this.setState(false);
                        break block5;
                    }
                    default: {
                        if (!e.isSend() || tickStop >= 0) break block5;
                        this.packets.add(e.getPacket());
                        e.cancel();
                        break block5;
                    }
                }
                break;
            }
        }
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        if (this.box != null && this.attackSetting.isSelected("Fake Lag") && this.target != null) {
            Render3D.drawBox(this.box, ColorAssist.getClientColor(), 1.0f);
        }
    }

    @EventHandler
    public void tick(TickEvent e) {
        if (PlayerInteractionHelper.nullCheck()) {
            return;
        }
        if (this.target == null) {
            return;
        }
        if (--tickStop >= 0 && !this.packets.isEmpty() && this.attackSetting.isSelected("Fake Lag")) {
            this.box = Aura.mc.field_1724.method_5829();
            this.packets.forEach(PlayerInteractionHelper::sendPacketWithOutEvent);
            this.packets.clear();
        }
        if (Aura.mc.field_1724.method_5739((class_1297)this.target) > this.attackRange.getValue() && this.attackSetting.isSelected("Fake Lag")) {
            this.packets.forEach(PlayerInteractionHelper::sendPacketWithOutEvent);
            this.packets.clear();
        }
    }

    @EventHandler
    public void onRotationUpdate(RotationUpdateEvent e) {
        try {
            if (this.aimMode.isSelected("FunTime") && Bloody.getInstance().getFtCheckClient() != null) {
                Bloody.getInstance().getFtCheckClient().checkAndWarnFunTime();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (this.attackSetting.isSelected("\u0422\u043e\u043b\u044c\u043a\u043e \u0441 \u043e\u0440\u0443\u0436\u0438\u0435\u043c") && !this.isHoldingSword()) {
            return;
        }
        switch (e.getType()) {
            case 0: {
                this.target = this.updateTarget();
                if (this.target != null) {
                    this.rotateToTarget(this.getConfig());
                    this.lastTarget = this.target;
                    break;
                }
                if (this.lastTarget == null) break;
                TurnsConnection rotationController = TurnsConnection.INSTANCE;
                rotationController.setRotation(null);
                rotationController.clear();
                rotationController.resetRotationPlan();
                this.lastTarget = null;
                break;
            }
            case 2: {
                if (this.target == null) break;
                Bloody.getInstance().getAttackPerpetrator().performAttack(this.getConfig());
            }
        }
    }

    private boolean isHoldingSword() {
        if (Aura.mc.field_1724 == null) {
            return false;
        }
        class_1792 item = Aura.mc.field_1724.method_6047().method_7909();
        return item instanceof class_1829;
    }

    private class_1309 updateTarget() {
        TargetFinder.EntityFilter filter = new TargetFinder.EntityFilter(this.targetType.getSelected());
        float range = this.attackRange.getValue() + 0.253f + this.lookRange.getValue();
        float dynamicFov = 360.0f;
        if (this.aimMode.isSelected("Legit Snap") && this.fovCircleRenderer != null) {
            dynamicFov = this.fovCircleRenderer.getCachedDynamicFov();
        }
        this.targetSelector.searchTargets(Aura.mc.field_1687.method_18112(), range, dynamicFov, this.attackSetting.isSelected("Ignore The Walls"));
        this.targetSelector.validateTarget(filter::isValid);
        return this.targetSelector.getCurrentTarget();
    }

    @Native(type=Native.Type.VMProtectBeginMutation)
    private void rotateToTarget(StrikerConstructor.AttackPerpetratorConfigurable config) {
        boolean elytraMode;
        StrikeManager attackHandler = Bloody.getInstance().getAttackPerpetrator().getAttackHandler();
        TurnsConnection controller = TurnsConnection.INSTANCE;
        Turns.VecRotation rotation = new Turns.VecRotation(config.getAngle(), config.getAngle().toVector());
        TurnsConfig rotationConfig = this.getRotationConfig();
        boolean bl = elytraMode = Aura.mc.field_1724.method_6128() && this.attackSetting.isSelected("Elytra possibilities");
        if (fakeRotate && this.target != null) {
            FakeAngle fake = new FakeAngle();
            Turns fakeRot = fake.limitAngleChange(controller.getRotation(), rotation.getAngle(), rotation.getVec(), (class_1297)this.target);
            controller.setFakeRotation(fakeRot);
        }
        fakeRotate = false;
        switch (this.aimMode.getSelected()) {
            case "Legit Snap": {
                if (!attackHandler.canAttack(config, 1) && attackHandler.getAttackTimer().finished(40.0)) break;
                controller.rotateTo(rotation, this.target, 1, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
                break;
            }
            case "SpookyAnarhy": {
                controller.rotateTo(rotation, this.target, 1, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
                break;
            }
            case "FunTime": {
                controller.rotateTo(rotation, this.target, 1, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
                break;
            }
            case "Other": {
                controller.rotateTo(rotation, this.target, 1, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
                break;
            }
            default: {
                controller.rotateTo(rotation, this.target, 1, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
            }
        }
        if (shouldRotate && !this.aimMode.isSelected("TriggerBot")) {
            controller.rotateTo(rotation, this.target, 1, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
        }
        if (elytraMode && !this.aimMode.isSelected("TriggerBot")) {
            controller.rotateTo(rotation, this.target, 1, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
        }
    }

    public StrikerConstructor.AttackPerpetratorConfigurable getConfig() {
        float baseRange = this.attackRange.getValue() + 0.253f;
        class_3545<class_243, class_238> pointData = this.pointFinder.computeVector(this.target, baseRange, TurnsConnection.INSTANCE.getRotation(), this.getSmoothMode().randomValue(), this.attackSetting.isSelected("Ignore The Walls"));
        class_243 computedPoint = (class_243)pointData.method_15442();
        class_238 hitbox = (class_238)pointData.method_15441();
        if (Aura.mc.field_1724.method_6128() && this.target.method_6128()) {
            class_243 targetVelocity = this.target.method_18798();
            double targetSpeed = targetVelocity.method_37267();
            float leadTicks = 0.0f;
            if (targetSpeed > 0.35) {
                class_243 predictedPos = this.target.method_19538().method_1019(targetVelocity.method_1021((double)leadTicks));
                computedPoint = predictedPos.method_1031(0.0, (double)(this.target.method_17682() / 2.0f), 0.0);
                hitbox = new class_238(predictedPos.field_1352 - (double)(this.target.method_17681() / 2.0f), predictedPos.field_1351, predictedPos.field_1350 - (double)(this.target.method_17681() / 2.0f), predictedPos.field_1352 + (double)(this.target.method_17681() / 2.0f), predictedPos.field_1351 + (double)this.target.method_17682(), predictedPos.field_1350 + (double)(this.target.method_17681() / 2.0f));
            }
        }
        Turns angle = MathAngle.fromVec3d(computedPoint.method_1020(Objects.requireNonNull(Aura.mc.field_1724).method_33571()));
        return new StrikerConstructor.AttackPerpetratorConfigurable(this.target, angle, baseRange, this.attackSetting.getSelected(), this.aimMode, hitbox);
    }

    @Native(type=Native.Type.VMProtectBeginMutation)
    public TurnsConfig getRotationConfig() {
        boolean visibleCorrection = !this.correctionType.isSelected("Not visible");
        boolean freeCorrection = !this.aimMode.isSelected("Legit") && this.correctionType.isSelected("Free");
        return new TurnsConfig(this.getSmoothMode(), visibleCorrection, freeCorrection);
    }

    @EventHandler
    public void onmotion(MotionEvent event) {
    }

    public RotateConstructor getSmoothMode() {
        if (Aura.mc.field_1724.method_6128() && this.attackSetting.isSelected("Elytra possibilities") && !this.aimMode.isSelected("Trigger Bot")) {
            return new LinearConstructor();
        }
        return switch (this.aimMode.getSelected()) {
            case "Legit Snap" -> new LegitAngle();
            case "Other" -> new OtherAngle();
            case "FunTime" -> new TestAngle();
            default -> new LinearConstructor();
        };
    }

    public void setTargetSelector(TargetFinder targetSelector) {
        this.targetSelector = targetSelector;
    }

    public void setPointFinder(MultiPoint pointFinder) {
        this.pointFinder = pointFinder;
    }

    public void setTarget(class_1309 target) {
        this.target = target;
    }

    public void setLastTarget(class_1309 lastTarget) {
        this.lastTarget = lastTarget;
    }

    public void setShiftTapEndTime(long shiftTapEndTime) {
        this.shiftTapEndTime = shiftTapEndTime;
    }

    public void setFovCircleRenderer(FovCircleRenderer fovCircleRenderer) {
        this.fovCircleRenderer = fovCircleRenderer;
    }

    public void setAimMode(SelectSetting aimMode) {
        this.aimMode = aimMode;
    }

    public void setTargetType(MultiSelectSetting targetType) {
        this.targetType = targetType;
    }

    public void setAttackRange(SliderSettings attackRange) {
        this.attackRange = attackRange;
    }

    public void setLookRange(SliderSettings lookRange) {
        this.lookRange = lookRange;
    }

    public void setAttackSetting(MultiSelectSetting attackSetting) {
        this.attackSetting = attackSetting;
    }

    public void setHitChance(SliderSettings hitChance) {
        this.hitChance = hitChance;
    }

    public void setCorrectionType(SelectSetting correctionType) {
        this.correctionType = correctionType;
    }

    public void setSprintReset(SelectSetting sprintReset) {
        this.sprintReset = sprintReset;
    }

    public void setSmartCrits(BooleanSetting smartCrits) {
        this.smartCrits = smartCrits;
    }

    public void setBox(class_238 box) {
        this.box = box;
    }

    public void setElytraStateForward(boolean elytraStateForward) {
        this.elytraStateForward = elytraStateForward;
    }

    public void setWasForwardPressed(boolean wasForwardPressed) {
        this.wasForwardPressed = wasForwardPressed;
    }

    public TargetFinder getTargetSelector() {
        return this.targetSelector;
    }

    public MultiPoint getPointFinder() {
        return this.pointFinder;
    }

    public class_1309 getTarget() {
        return this.target;
    }

    public class_1309 getLastTarget() {
        return this.lastTarget;
    }

    public long getShiftTapEndTime() {
        return this.shiftTapEndTime;
    }

    public FovCircleRenderer getFovCircleRenderer() {
        return this.fovCircleRenderer;
    }

    public SelectSetting getAimMode() {
        return this.aimMode;
    }

    public MultiSelectSetting getTargetType() {
        return this.targetType;
    }

    public SliderSettings getAttackRange() {
        return this.attackRange;
    }

    public SliderSettings getLookRange() {
        return this.lookRange;
    }

    public MultiSelectSetting getAttackSetting() {
        return this.attackSetting;
    }

    public SliderSettings getHitChance() {
        return this.hitChance;
    }

    public SelectSetting getCorrectionType() {
        return this.correctionType;
    }

    public SelectSetting getSprintReset() {
        return this.sprintReset;
    }

    public BooleanSetting getSmartCrits() {
        return this.smartCrits;
    }

    public List<class_2596<?>> getPackets() {
        return this.packets;
    }

    public class_238 getBox() {
        return this.box;
    }

    public boolean isElytraStateForward() {
        return this.elytraStateForward;
    }

    public boolean isWasForwardPressed() {
        return this.wasForwardPressed;
    }

    public static float getLegitSprintNeed() {
        return legitSprintNeed;
    }

    static {
        tickStop = -1;
    }

    public class FovCircleRenderer
    implements QuickImports {
        private float currentScale = 1.0f;
        private float targetScale = 1.0f;
        private float cachedDynamicFov = 33.0f;
        private float lastFinalRadius = 0.0f;

        @EventHandler
        public void drawEvent(DrawEvent e) {
            if (FovCircleRenderer.mc.field_1724 == null || !Aura.this.aimMode.isSelected("Legit Snap") || !Aura.this.isState()) {
                return;
            }
            if (FovCircleRenderer.mc.field_1690.method_31044().method_31034()) {
                float finalRadius;
                class_4587 matrix = e.getDrawContext().method_51448();
                float middleW = (float)mc.method_22683().method_4486() / 2.0f;
                float middleH = (float)mc.method_22683().method_4502() / 2.0f;
                double fov = ((Integer)FovCircleRenderer.mc.field_1690.method_41808().method_41753()).intValue();
                fov = class_3532.method_15350((double)fov, (double)30.0, (double)110.0);
                float baseRadius = (float)class_3532.method_16436((double)((fov - 30.0) / 80.0), (double)106.5, (double)65.0);
                float fovScale = (float)(450.0 / fov);
                float dynamicRadius = baseRadius * fovScale;
                this.targetScale = FovCircleRenderer.mc.field_1724.method_5624() ? 0.9f : 1.0f;
                this.currentScale = Calculate.interpolateSmooth(2.5, this.currentScale, this.targetScale);
                this.lastFinalRadius = finalRadius = dynamicRadius * this.currentScale;
                float baseThickness = (float)class_3532.method_16436((double)((fov - 30.0) / 80.0), (double)0.003, (double)0.015);
                arc.render(ShapeProperties.create(matrix, middleW - finalRadius / 2.0f, middleH - finalRadius / 2.0f, finalRadius, finalRadius).round(0.3f).thickness(baseThickness).end(360.0f).color(ColorAssist.getColor(255, 255, 255, 255)).build());
                this.cachedDynamicFov = this.calculateDynamicFov();
            }
        }

        private float calculateDynamicFov() {
            if (FovCircleRenderer.mc.field_1724 == null || mc.method_22683() == null) {
                return 33.0f;
            }
            double fov = ((Integer)FovCircleRenderer.mc.field_1690.method_41808().method_41753()).intValue();
            fov = class_3532.method_15350((double)fov, (double)30.0, (double)110.0);
            float screenWidth = mc.method_22683().method_4486();
            float screenHeight = mc.method_22683().method_4502();
            float circleRadiusInPixels = this.lastFinalRadius / 2.0f;
            double horizontalFovRadians = Math.toRadians(fov);
            double pixelsPerRadian = (double)screenWidth / horizontalFovRadians;
            double circleFovRadians = (double)circleRadiusInPixels / pixelsPerRadian;
            float circleFovDegrees = (float)Math.toDegrees(circleFovRadians);
            return class_3532.method_15363((float)(circleFovDegrees *= 2.0f), (float)36.0f, (float)360.0f);
        }

        public float getCachedDynamicFov() {
            return this.cachedDynamicFov;
        }
    }
}

