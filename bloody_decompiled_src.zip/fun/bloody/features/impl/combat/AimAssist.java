/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1308
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1829
 *  net.minecraft.class_238
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 */
package fun.bloody.features.impl.combat;

import fun.bloody.common.repository.friend.FriendUtils;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AimAssist
extends Module {
    public SelectSetting mode = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "\u0420\u0435\u0436\u0438\u043c \u0440\u0430\u0431\u043e\u0442\u044b \u043c\u043e\u0434\u0443\u043b\u044f").value("Default", "Custom").selected("Default");
    public SliderSettings speed = new SliderSettings("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u043f\u043e\u0432\u043e\u0440\u043e\u0442\u0430 \u0433\u043e\u043b\u043e\u0432\u044b").range(0.35f, 1.8f).setValue(1.0f).visible(() -> this.mode.isSelected("Default"));
    public SliderSettings range = new SliderSettings("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f", "\u041c\u0430\u043a\u0441\u0438\u043c\u0430\u043b\u044c\u043d\u0430\u044f \u0434\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u0430\u0442\u0430\u043a\u0438").range(3.0f, 6.0f).setValue(4.0f).visible(() -> this.mode.isSelected("Default"));
    public BooleanSetting rageSpeed = new BooleanSetting("Rage Speed", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0431\u043e\u043b\u044c\u0448\u0435 1.15 \u0431\u0443\u0434\u0435\u0442 \u0432 1.5 \u0440\u0430\u0437\u0430 \u0431\u044b\u0441\u0442\u0440\u0435\u0435").setValue(false).visible(() -> this.mode.isSelected("Default"));
    public SelectSetting aimPoint = new SelectSetting("\u0422\u043e\u0447\u043a\u0430 \u043f\u0440\u0438\u0446\u0435\u043b\u0438\u0432\u0430\u043d\u0438\u044f", "\u0412\u044b\u0431\u043e\u0440 \u0447\u0430\u0441\u0442\u0438 \u0442\u0435\u043b\u0430 \u0434\u043b\u044f \u043f\u0440\u0438\u0446\u0435\u043b\u0438\u0432\u0430\u043d\u0438\u044f").value("\u0413\u043e\u043b\u043e\u0432\u0430", "\u0416\u0438\u0432\u043e\u0442", "\u041d\u043e\u0433\u0438", "\u0420\u0443\u043a\u0438", "\u0420\u0443\u0447\u043d\u0430\u044f").selected("\u0413\u043e\u043b\u043e\u0432\u0430").visible(() -> this.mode.isSelected("Default"));
    public SelectSetting priority = new SelectSetting("\u041f\u0440\u0438\u043e\u0440\u0438\u0442\u0435\u0442", "\u0412\u044b\u0431\u043e\u0440 \u043f\u0440\u0438\u043e\u0440\u0438\u0442\u0435\u0442\u0430 \u0446\u0435\u043b\u0438").value("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f", "\u0417\u0434\u043e\u0440\u043e\u0432\u044c\u0435", "\u0411\u0440\u043e\u043d\u044f", "Lock").selected("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f").visible(() -> this.mode.isSelected("Default"));
    public BooleanSetting customVerticalEnabled = new BooleanSetting("\u0412\u0435\u0440\u0442\u0438\u043a\u0430\u043b\u044c", "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u0435 \u043f\u043e \u0432\u0435\u0440\u0442\u0438\u043a\u0430\u043b\u0438").setValue(true).visible(() -> this.mode.isSelected("Custom"));
    public BooleanSetting customFovEnabled = new BooleanSetting("FOV", "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u043e\u0433\u0440\u0430\u043d\u0438\u0447\u0435\u043d\u0438\u0435 FOV").setValue(false).visible(() -> this.mode.isSelected("Custom"));
    public BooleanSetting windAimCustom = new BooleanSetting("\u041d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u0435 \u043f\u0440\u0438 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0438 \u0432\u0435\u0442\u0440\u0430", "\u041d\u0430\u0432\u043e\u0434\u0438\u0442\u044c\u0441\u044f \u043f\u0440\u0438 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0438 \u0437\u0430\u0440\u044f\u0434\u0430 \u0432\u0435\u0442\u0440\u0430").setValue(false).visible(() -> this.mode.isSelected("Custom"));
    public SliderSettings customYawSpeed = new SliderSettings("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c Yaw", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u043f\u043e\u0432\u043e\u0440\u043e\u0442\u0430 \u043f\u043e \u0433\u043e\u0440\u0438\u0437\u043e\u043d\u0442\u0430\u043b\u0438").range(0.1f, 5.0f).setValue(1.5f).visible(() -> this.mode.isSelected("Custom"));
    public SliderSettings customPitchSpeed = new SliderSettings("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c Pitch", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u043f\u043e\u0432\u043e\u0440\u043e\u0442\u0430 \u043f\u043e \u0432\u0435\u0440\u0442\u0438\u043a\u0430\u043b\u0438").range(0.1f, 5.0f).setValue(1.5f).visible(() -> this.mode.isSelected("Custom"));
    public SliderSettings customVerticalSpeed = new SliderSettings("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c Vertical", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0432\u0435\u0440\u0442\u0438\u043a\u0430\u043b\u044c\u043d\u043e\u0433\u043e \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u044f").range(0.1f, 5.0f).setValue(1.5f).visible(() -> this.mode.isSelected("Custom") && this.customVerticalEnabled.isValue());
    public SliderSettings customElytraRange = new SliderSettings("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u043d\u0430 \u044d\u043b\u0438\u0442\u0440\u0430\u0445", "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u044f \u043d\u0430 \u044d\u043b\u0438\u0442\u0440\u0430\u0445").range(3.0f, 10.0f).setValue(6.0f).visible(() -> this.mode.isSelected("Custom"));
    public SliderSettings customRange = new SliderSettings("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u044f", "\u041c\u0430\u043a\u0441\u0438\u043c\u0430\u043b\u044c\u043d\u0430\u044f \u0434\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u044f").range(3.0f, 10.0f).setValue(5.0f).visible(() -> this.mode.isSelected("Custom"));
    public SliderSettings customFov = new SliderSettings("FOV \u0443\u0433\u043e\u043b", "\u0423\u0433\u043e\u043b \u043e\u0431\u0437\u043e\u0440\u0430 \u0434\u043b\u044f \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u044f").range(30.0f, 180.0f).setValue(90.0f).visible(() -> this.mode.isSelected("Custom") && this.customFovEnabled.isValue());
    public BooleanSetting customSyncTps = new BooleanSetting("\u0421\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0441 TPS", "\u0421\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u044f \u0441 TPS \u0441\u0435\u0440\u0432\u0435\u0440\u0430").setValue(false).visible(() -> this.mode.isSelected("Custom"));
    public MultiSelectSetting targetSettings = new MultiSelectSetting("\u041d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u0435 \u043d\u0430", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0446\u0435\u043b\u0435\u0439 \u0434\u043b\u044f \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u044f").value("\u0418\u0433\u0440\u043e\u043a\u043e\u0432", "\u041c\u043e\u0431\u043e\u0432", "\u0418\u0433\u0440\u043e\u043a\u043e\u0432 \u0431\u0435\u0437 \u0431\u0440\u043e\u043d\u0438", "\u041d\u0435\u0432\u0438\u0434\u0438\u043c\u044b\u0445", "\u0413\u043e\u043b\u044b\u0445").selected("\u0418\u0433\u0440\u043e\u043a\u043e\u0432");
    public BooleanSetting disableIgnoreWalls = new BooleanSetting("\u0418\u0433\u043d\u043e\u0440\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0441\u0442\u0435\u043d\u044b", "\u041d\u0435 \u043d\u0430\u0432\u043e\u0434\u0438\u0442\u044c\u0441\u044f \u0447\u0435\u0440\u0435\u0437 \u0441\u0442\u0435\u043d\u044b").setValue(false);
    public BooleanSetting disableInInventory = new BooleanSetting("\u0418\u0433\u043d\u043e\u0440\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u0435 \u0432 \u044f\u0449\u0438\u043a\u0430\u0445", "\u041d\u0435 \u043d\u0430\u0432\u043e\u0434\u0438\u0442\u044c\u0441\u044f \u043a\u043e\u0433\u0434\u0430 \u043e\u0442\u043a\u0440\u044b\u0442 \u0438\u043d\u0432\u0435\u043d\u0442\u0430\u0440\u044c").setValue(true);
    public BooleanSetting disableBlock360 = new BooleanSetting("\u0418\u0433\u043d\u043e\u0440\u0438\u0440\u043e\u0432\u0430\u0442\u044c 360", "\u041d\u0430\u0432\u043e\u0434\u0438\u0442\u044c\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u0432 \u043f\u0440\u0435\u0434\u0435\u043b\u0430\u0445 160 \u0433\u0440\u0430\u0434\u0443\u0441\u043e\u0432").setValue(false);
    public BooleanSetting onlyWithWeapon = new BooleanSetting("\u0422\u043e\u043b\u044c\u043a\u043e \u0441 \u043e\u0440\u0443\u0436\u0438\u0435\u043c", "\u0420\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u0442\u043e\u043b\u044c\u043a\u043e \u043a\u043e\u0433\u0434\u0430 \u0432 \u0440\u0443\u043a\u0435 \u043c\u0435\u0447").setValue(false);
    public SelectSetting workMode = new SelectSetting("\u0420\u0435\u0436\u0438\u043c \u0440\u0430\u0431\u043e\u0442\u044b", "\u0420\u0435\u0436\u0438\u043c \u0440\u0430\u0431\u043e\u0442\u044b \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u044f").value("\u041f\u043e\u043b\u043d\u043e\u0446\u0435\u043d\u043d\u044b\u0439", "\u041b\u0435\u0433\u0438\u0442\u043d\u044b\u0439").selected("\u041f\u043e\u043b\u043d\u043e\u0446\u0435\u043d\u043d\u044b\u0439");
    private class_1297 FD;
    private long Dp;
    private double aeX;
    private double nX;
    private double RM;
    private double ayG;
    private double SL;
    private double Rt;
    private double alh;
    private double yY;
    private double akx;
    private double Nk;
    private long aho;
    private int adW;
    private double lastTargetY;
    private float lastPlayerYaw = 0.0f;
    private float lastPlayerPitch = 0.0f;
    private long lastPlayerMoveTime = 0L;
    private double lastPlayerY = 0.0;
    private double lastPlayerMotionY = 0.0;
    private long lastMotionUpdate = 0L;
    private long lastTargetSearch = 0L;
    private static final long TARGET_SEARCH_INTERVAL = 50L;
    private final Map<class_1297, Float> lastKnownHealth = new HashMap<class_1297, Float>();
    private class_1297 lockedTarget = null;
    private boolean wasHealthUnknown = false;
    private final Map<class_1297, Long> targetFirstSeen = new HashMap<class_1297, Long>();
    public static boolean isActive = false;

    public static AimAssist getInstance() {
        return Instance.get(AimAssist.class);
    }

    public AimAssist() {
        super("AimAssist", "AimAssist", ModuleCategory.COMBAT);
        this.setup(this.mode, this.speed, this.range, this.rageSpeed, this.aimPoint, this.priority, this.customYawSpeed, this.customPitchSpeed, this.customVerticalSpeed, this.customElytraRange, this.customRange, this.customFov, this.targetSettings, this.customVerticalEnabled, this.customFovEnabled, this.customSyncTps, this.disableIgnoreWalls, this.disableInInventory, this.disableBlock360, this.onlyWithWeapon, this.workMode);
    }

    private double getEffectiveSpeed() {
        double baseSpeed = this.speed.getValue();
        if (this.rageSpeed.isValue() && baseSpeed > (double)1.15f) {
            return baseSpeed * 2.0;
        }
        return baseSpeed;
    }

    @Override
    public void deactivate() {
        isActive = false;
        this.FD = null;
    }

    private void a() {
        this.FD = null;
        this.Dp = 0L;
        this.aeX = 0.0;
        this.nX = 0.0;
        this.lastTargetSearch = 0L;
        this.lastTargetY = 0.0;
        this.lastKnownHealth.clear();
        this.lockedTarget = null;
        this.wasHealthUnknown = false;
        this.lastPlayerYaw = 0.0f;
        this.lastPlayerY = 0.0;
        this.lastPlayerMotionY = 0.0;
        this.lastMotionUpdate = 0L;
        this.lastPlayerPitch = 0.0f;
        this.lastPlayerMoveTime = 0L;
        this.b();
    }

    private void b() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        this.RM = r.nextDouble(Math.PI * 2);
        this.ayG = r.nextDouble(Math.PI * 2);
        this.SL = r.nextDouble(0.15, 0.35);
        this.Rt = r.nextDouble(0.12, 0.3);
        this.alh = r.nextDouble(1.8, 3.5);
        this.yY = r.nextDouble(0.85, 1.15);
        this.akx = r.nextDouble(-0.05, 0.15);
        this.adW = r.nextInt(3);
        this.Nk = r.nextDouble(-0.08, 0.05);
        this.aho = System.currentTimeMillis();
    }

    @EventHandler
    public void onRender(WorldRenderEvent event) {
        if (AimAssist.mc.field_1724 == null || AimAssist.mc.field_1687 == null) {
            return;
        }
        if (this.onlyWithWeapon.isValue() && !this.isHoldingSword()) {
            return;
        }
        if (this.disableInInventory.isValue() && AimAssist.mc.field_1755 != null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.lastTargetSearch > 50L || this.FD == null) {
            class_1297 target;
            class_1297 class_12972 = target = this.mode.isSelected("Custom") ? this.getCustomTarget() : this.g();
            if (target == null) {
                if (this.FD != null) {
                    this.a();
                }
                return;
            }
            if (target != this.FD) {
                this.FD = target;
                this.Dp = now;
                this.lastTargetY = target.method_23318();
                this.b();
            }
            this.lastTargetSearch = now;
        }
        if (this.FD == null) {
            return;
        }
        if (this.workMode.isSelected("\u041b\u0435\u0433\u0438\u0442\u043d\u044b\u0439") && this.isLookingAtTargetHitbox(this.FD)) {
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (now - this.aho > r.nextLong(400L, 800L)) {
            this.Nk += r.nextDouble(-0.04, 0.04);
            this.Nk = class_3532.method_15350((double)this.Nk, (double)-0.1, (double)0.08);
            this.aho = now;
        }
        double[] angles = this.i(this.FD);
        if (this.mode.isSelected("Custom")) {
            this.customAim(angles[0], angles[1], now);
            return;
        }
        if (this.aimPoint.isSelected("\u0420\u0443\u0447\u043d\u0430\u044f")) {
            this.mManual(angles[0], angles[1], r, now);
        } else {
            this.m(angles[0], angles[1], r, now);
        }
    }

    private void mManual(double targetYaw, double targetPitch, ThreadLocalRandom r, long now) {
        double yawDelta;
        if (this.isLookingAtTargetBody(this.FD)) {
            this.lastPlayerYaw = AimAssist.mc.field_1724.method_36454();
            this.lastPlayerPitch = AimAssist.mc.field_1724.method_36455();
            this.lastPlayerMoveTime = now;
            return;
        }
        float currentYaw = AimAssist.mc.field_1724.method_36454();
        float currentPitch = AimAssist.mc.field_1724.method_36455();
        if (this.disableBlock360.isValue()) {
            for (yawDelta = targetYaw - (double)currentYaw; yawDelta > 180.0; yawDelta -= 360.0) {
            }
            while (yawDelta < -180.0) {
                yawDelta += 360.0;
            }
            if (Math.abs(yawDelta) > 80.0) {
                this.lastPlayerYaw = currentYaw;
                this.lastPlayerPitch = currentPitch;
                return;
            }
        }
        for (yawDelta = targetYaw - (double)currentYaw; yawDelta > 180.0; yawDelta -= 360.0) {
        }
        while (yawDelta < -180.0) {
            yawDelta += 360.0;
        }
        double pitchDelta = targetPitch - (double)currentPitch;
        double distance = Math.sqrt(yawDelta * yawDelta + pitchDelta * pitchDelta);
        if (distance < 0.1) {
            this.lastPlayerYaw = currentYaw;
            this.lastPlayerPitch = currentPitch;
            return;
        }
        double timeSinceAcquire = class_3532.method_15350((double)((double)(now - this.Dp) / 500.0), (double)0.0, (double)1.0);
        double easedProgress = 1.0 - Math.pow(1.0 - timeSinceAcquire, 2.0);
        double baseSpeed = this.getEffectiveSpeed() * this.yY;
        double distMult = distance < 5.0 ? 0.3 : (distance < 15.0 ? 0.5 : (distance < 30.0 ? 0.7 : 0.9));
        double speedFactor = class_3532.method_15350((double)(baseSpeed * easedProgress * distMult * 0.02), (double)0.003, (double)0.5);
        double finalYawDelta = yawDelta * speedFactor;
        double finalPitchDelta = pitchDelta * speedFactor;
        if (distance < 2.5 && this.akx > 0.01) {
            double overshoot = this.akx * 0.3;
            finalYawDelta *= 1.0 + overshoot;
            finalPitchDelta *= 1.0 + overshoot * 0.5;
            this.akx *= 0.95;
        }
        double maxChange = 1.5;
        double yawChange = finalYawDelta - this.aeX;
        double pitchChange = finalPitchDelta - this.nX;
        if (Math.abs(yawChange) > maxChange) {
            finalYawDelta = this.aeX + Math.signum(yawChange) * maxChange;
        }
        if (Math.abs(pitchChange) > maxChange) {
            finalPitchDelta = this.nX + Math.signum(pitchChange) * maxChange;
        }
        this.aeX = finalYawDelta;
        this.nX = finalPitchDelta;
        double gcdFix = Math.pow((Double)AimAssist.mc.field_1690.method_42495().method_41753() * 0.6 + 0.2, 3.0) * 1.2;
        finalYawDelta -= finalYawDelta % gcdFix;
        finalPitchDelta -= finalPitchDelta % gcdFix;
        if (Math.abs(finalYawDelta) >= 0.003 || Math.abs(finalPitchDelta) >= 0.003) {
            AimAssist.mc.field_1724.method_36456((float)((double)currentYaw + finalYawDelta));
            AimAssist.mc.field_1724.method_36457(class_3532.method_15363((float)((float)((double)currentPitch + finalPitchDelta)), (float)-90.0f, (float)90.0f));
        }
        this.lastPlayerYaw = AimAssist.mc.field_1724.method_36454();
        this.lastPlayerPitch = AimAssist.mc.field_1724.method_36455();
    }

    private boolean isLookingAtTargetBody(class_1297 target) {
        if (AimAssist.mc.field_1724 == null || target == null) {
            return false;
        }
        class_243 eyePos = AimAssist.mc.field_1724.method_33571();
        class_243 lookVec = AimAssist.mc.field_1724.method_5828(1.0f);
        class_243 lookEnd = eyePos.method_1019(lookVec.method_1021((double)this.range.getValue() + 2.0));
        class_238 targetBox = target.method_5829();
        double height = targetBox.field_1325 - targetBox.field_1322;
        double width = targetBox.field_1320 - targetBox.field_1323;
        double depth = targetBox.field_1324 - targetBox.field_1321;
        double expandX = width * 0.1;
        double expandZ = depth * 0.1;
        class_238 headBox = new class_238(targetBox.field_1323 - expandX, targetBox.field_1322 + height * 0.75, targetBox.field_1321 - expandZ, targetBox.field_1320 + expandX, targetBox.field_1325, targetBox.field_1324 + expandZ);
        class_238 neckBox = new class_238(targetBox.field_1323 - expandX, targetBox.field_1322 + height * 0.6, targetBox.field_1321 - expandZ, targetBox.field_1320 + expandX, targetBox.field_1322 + height * 0.75, targetBox.field_1324 + expandZ);
        class_238 bodyBox = new class_238(targetBox.field_1323 - expandX, targetBox.field_1322 + height * 0.35, targetBox.field_1321 - expandZ, targetBox.field_1320 + expandX, targetBox.field_1322 + height * 0.6, targetBox.field_1324 + expandZ);
        class_238 armsBox = new class_238(targetBox.field_1323 - width * 0.3, targetBox.field_1322 + height * 0.4, targetBox.field_1321 - expandZ, targetBox.field_1320 + width * 0.3, targetBox.field_1322 + height * 0.7, targetBox.field_1324 + expandZ);
        class_238 legsBox = new class_238(targetBox.field_1323 - expandX, targetBox.field_1322, targetBox.field_1321 - expandZ, targetBox.field_1320 + expandX, targetBox.field_1322 + height * 0.35, targetBox.field_1324 + expandZ);
        if (headBox.method_992(eyePos, lookEnd).isPresent()) {
            return true;
        }
        if (neckBox.method_992(eyePos, lookEnd).isPresent()) {
            return true;
        }
        if (bodyBox.method_992(eyePos, lookEnd).isPresent()) {
            return true;
        }
        if (armsBox.method_992(eyePos, lookEnd).isPresent()) {
            return true;
        }
        return legsBox.method_992(eyePos, lookEnd).isPresent();
    }

    private boolean isLookingAtTargetHitbox(class_1297 target) {
        if (AimAssist.mc.field_1724 == null || target == null) {
            return false;
        }
        class_243 eyePos = AimAssist.mc.field_1724.method_33571();
        class_243 lookVec = AimAssist.mc.field_1724.method_5828(1.0f);
        double maxRange = this.mode.isSelected("Custom") ? (double)(AimAssist.mc.field_1724.method_6128() ? this.customElytraRange.getValue() : this.customRange.getValue()) : (double)this.range.getValue();
        class_243 lookEnd = eyePos.method_1019(lookVec.method_1021(maxRange + 2.0));
        class_238 targetBox = target.method_5829();
        return targetBox.method_992(eyePos, lookEnd).isPresent();
    }

    /*
     * WARNING - void declaration
     */
    private class_1297 g() {
        class_1309 currentLiving;
        if (AimAssist.mc.field_1687 == null || AimAssist.mc.field_1724 == null) {
            return null;
        }
        ArrayList<class_1309> validTargets = new ArrayList<class_1309>();
        boolean anyHealthKnown = false;
        for (class_1297 entity : AimAssist.mc.field_1687.method_18112()) {
            double maxRange;
            double d;
            if (!(entity instanceof class_1309)) continue;
            class_1309 living = (class_1309)entity;
            if (entity == AimAssist.mc.field_1724) continue;
            boolean isValidTarget = false;
            if (living instanceof class_1657) {
                class_1657 class_16572 = (class_1657)living;
                if (class_16572.method_7337() || class_16572.method_7325() || FriendUtils.isFriend((class_1297)class_16572)) continue;
                if (this.targetSettings.isSelected("\u0418\u0433\u0440\u043e\u043a\u043e\u0432")) {
                    isValidTarget = true;
                }
                if (this.targetSettings.isSelected("\u0418\u0433\u0440\u043e\u043a\u043e\u0432 \u0431\u0435\u0437 \u0431\u0440\u043e\u043d\u0438") && class_16572.method_6096() == 0) {
                    isValidTarget = true;
                }
                if (this.targetSettings.isSelected("\u0413\u043e\u043b\u044b\u0445")) {
                    boolean hasAnyItem = false;
                    for (class_1799 slot : class_16572.method_31548().field_7548) {
                        if (slot.method_7960()) continue;
                        hasAnyItem = true;
                        break;
                    }
                    if (!class_16572.method_6047().method_7960() || !class_16572.method_6079().method_7960()) {
                        hasAnyItem = true;
                    }
                    if (!hasAnyItem) {
                        isValidTarget = true;
                    }
                }
            } else if (living instanceof class_1308 && this.targetSettings.isSelected("\u041c\u043e\u0431\u043e\u0432")) {
                isValidTarget = true;
            }
            if (!isValidTarget || living.method_5767() && !this.targetSettings.isSelected("\u041d\u0435\u0432\u0438\u0434\u0438\u043c\u044b\u0445") || !living.method_5805() || living.method_6032() <= 0.0f || (d = AimAssist.mc.field_1724.method_5858((class_1297)living)) > (maxRange = (double)this.range.getValue()) * maxRange || this.disableIgnoreWalls.isValue() && !this.canSeeEntity((class_1297)living)) continue;
            if (this.disableBlock360.isValue()) {
                double yawDelta;
                double yawToTarget = this.getYawToEntity((class_1297)living);
                for (yawDelta = yawToTarget - (double)AimAssist.mc.field_1724.method_36454(); yawDelta > 180.0; yawDelta -= 360.0) {
                }
                while (yawDelta < -180.0) {
                    yawDelta += 360.0;
                }
                if (Math.abs(yawDelta) > 80.0) continue;
            }
            validTargets.add(living);
            float currentHealth = living.method_6032();
            if (!(currentHealth > 0.0f)) continue;
            this.lastKnownHealth.put((class_1297)living, Float.valueOf(currentHealth));
            anyHealthKnown = true;
        }
        if (validTargets.isEmpty()) {
            this.lockedTarget = null;
            this.wasHealthUnknown = false;
            return null;
        }
        if (this.priority.isSelected("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f")) {
            if (this.FD != null && validTargets.contains(this.FD)) {
                double currentDistance = AimAssist.mc.field_1724.method_5858(this.FD);
                double minDistance = Double.MAX_VALUE;
                Object var7_23 = null;
                for (class_1309 target : validTargets) {
                    double distance = AimAssist.mc.field_1724.method_5858((class_1297)target);
                    if (!(distance < minDistance)) continue;
                    minDistance = distance;
                    class_1309 class_13092 = target;
                }
                if (minDistance < currentDistance - 2.25) {
                    void var7_24;
                    return var7_24;
                }
                return this.FD;
            }
            class_1309 closest = null;
            double minDistance = Double.MAX_VALUE;
            for (class_1309 class_13093 : validTargets) {
                double distance = AimAssist.mc.field_1724.method_5858((class_1297)class_13093);
                if (!(distance < minDistance)) continue;
                minDistance = distance;
                closest = class_13093;
            }
            return closest;
        }
        if (this.priority.isSelected("\u0411\u0440\u043e\u043d\u044f")) {
            class_1297 minDistance;
            if (this.FD != null && validTargets.contains(this.FD) && (minDistance = this.FD) instanceof class_1309) {
                currentLiving = (class_1309)minDistance;
                float currentArmor = currentLiving.method_6096();
                float maxArmor = Float.MIN_VALUE;
                class_1309 bestArmor = null;
                for (class_1309 target : validTargets) {
                    float armor = target.method_6096();
                    if (!(armor > maxArmor)) continue;
                    maxArmor = armor;
                    bestArmor = target;
                }
                if (maxArmor > currentArmor + 2.0f) {
                    return bestArmor;
                }
                return this.FD;
            }
            class_1309 bestArmor = null;
            float maxArmor = Float.MIN_VALUE;
            for (class_1309 target : validTargets) {
                float f = target.method_6096();
                if (!(f > maxArmor)) continue;
                maxArmor = f;
                bestArmor = target;
            }
            return bestArmor;
        }
        if (this.priority.isSelected("\u0417\u0434\u043e\u0440\u043e\u0432\u044c\u0435")) {
            class_1297 maxArmor;
            if (!anyHealthKnown) {
                if (this.lockedTarget != null && validTargets.contains(this.lockedTarget)) {
                    this.wasHealthUnknown = true;
                    return this.lockedTarget;
                }
                this.lockedTarget = (class_1297)validTargets.get(0);
                this.wasHealthUnknown = true;
                return this.lockedTarget;
            }
            if (this.wasHealthUnknown && anyHealthKnown) {
                this.lockedTarget = null;
                this.wasHealthUnknown = false;
            }
            if (this.FD != null && validTargets.contains(this.FD) && (maxArmor = this.FD) instanceof class_1309) {
                currentLiving = (class_1309)maxArmor;
                float currentHealth = currentLiving.method_6032();
                if (currentHealth <= 0.0f) {
                    Float cached = this.lastKnownHealth.get(this.FD);
                    currentHealth = cached != null && cached.floatValue() > 0.0f ? cached.floatValue() : Float.MAX_VALUE;
                }
                class_1309 betterTarget = null;
                float betterHealth = Float.MAX_VALUE;
                for (class_1309 target : validTargets) {
                    if (target == this.FD) continue;
                    float health = target.method_6032();
                    if (health <= 0.0f) {
                        Float cached = this.lastKnownHealth.get(target);
                        if (cached == null || !(cached.floatValue() > 0.0f)) continue;
                        health = cached.floatValue();
                    }
                    if (!(health < betterHealth)) continue;
                    betterHealth = health;
                    betterTarget = target;
                }
                if (betterTarget != null && betterHealth < currentHealth - 2.5f) {
                    this.lastKnownHealth.entrySet().removeIf(entry -> !((class_1297)entry.getKey()).method_5805() || ((class_1297)entry.getKey()).method_31481());
                    return betterTarget;
                }
                this.lastKnownHealth.entrySet().removeIf(entry -> !((class_1297)entry.getKey()).method_5805() || ((class_1297)entry.getKey()).method_31481());
                return this.FD;
            }
            class_1309 lowestHealthTarget = null;
            float minHealth = Float.MAX_VALUE;
            for (class_1309 target : validTargets) {
                float f = target.method_6032();
                if (f <= 0.0f) {
                    Float cached = this.lastKnownHealth.get(target);
                    if (cached == null || !(cached.floatValue() > 0.0f)) continue;
                    f = cached.floatValue();
                }
                if (!(f < minHealth)) continue;
                minHealth = f;
                lowestHealthTarget = target;
            }
            this.lastKnownHealth.entrySet().removeIf(entry -> !((class_1297)entry.getKey()).method_5805() || ((class_1297)entry.getKey()).method_31481());
            return lowestHealthTarget;
        }
        if (this.priority.isSelected("Lock")) {
            if (this.lockedTarget != null && validTargets.contains(this.lockedTarget)) {
                return this.lockedTarget;
            }
            if (!validTargets.isEmpty()) {
                this.lockedTarget = (class_1297)validTargets.get(ThreadLocalRandom.current().nextInt(validTargets.size()));
                return this.lockedTarget;
            }
            this.lockedTarget = null;
            return null;
        }
        return null;
    }

    private boolean canSeeEntity(class_1297 entity) {
        class_243 targetPos;
        if (AimAssist.mc.field_1687 == null || AimAssist.mc.field_1724 == null) {
            return false;
        }
        class_243 eyePos = AimAssist.mc.field_1724.method_33571();
        class_3959 context = new class_3959(eyePos, targetPos = entity.method_19538().method_1031(0.0, (double)entity.method_17682() * 0.5, 0.0), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)AimAssist.mc.field_1724);
        class_3965 result = AimAssist.mc.field_1687.method_17742(context);
        return result.method_17783() == class_239.class_240.field_1333;
    }

    private double[] i(class_1297 entity) {
        class_243 eyePos = AimAssist.mc.field_1724.method_33571();
        double jumpAdjustment = 0.0;
        if (!AimAssist.mc.field_1724.method_24828()) {
            if (System.currentTimeMillis() - this.lastMotionUpdate > 5L) {
                double motionY;
                double currentY = AimAssist.mc.field_1724.method_23318();
                this.lastPlayerMotionY = motionY = currentY - this.lastPlayerY;
                this.lastPlayerY = currentY;
                this.lastMotionUpdate = System.currentTimeMillis();
            }
            if (this.lastPlayerMotionY > 0.05) {
                jumpAdjustment = Math.min(this.lastPlayerMotionY * 15.0, 25.0);
            }
        }
        double aimHeight = this.aimPoint.isSelected("\u0413\u043e\u043b\u043e\u0432\u0430") ? 0.85 : (this.aimPoint.isSelected("\u0416\u0438\u0432\u043e\u0442") ? 0.5 : (this.aimPoint.isSelected("\u041d\u043e\u0433\u0438") ? 0.15 : 0.65));
        double currentTargetY = entity.method_23318();
        double yDiff = currentTargetY - this.lastTargetY;
        this.lastTargetY = Math.abs(yDiff) > 0.1 ? (this.lastTargetY += yDiff * 0.3) : currentTargetY;
        double offsetX = 0.0;
        double offsetY = 0.0;
        double offsetZ = 0.0;
        double finalHeight = class_3532.method_15350((double)((aimHeight += this.Nk) + offsetY), (double)0.05, (double)0.95);
        class_243 targetPos = new class_243(entity.method_23317() + offsetX, this.lastTargetY + (double)entity.method_17682() * finalHeight, entity.method_23321() + offsetZ);
        double deltaX = targetPos.field_1352 - eyePos.field_1352;
        double deltaY = targetPos.field_1351 - eyePos.field_1351;
        double deltaZ = targetPos.field_1350 - eyePos.field_1350;
        double horizontalDist = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        double yaw = horizontalDist < 0.001 ? (double)AimAssist.mc.field_1724.method_36454() : Math.toDegrees(Math.atan2(-deltaX, deltaZ));
        double totalDist = Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
        double pitch = totalDist < 0.001 ? (double)AimAssist.mc.field_1724.method_36455() : -Math.toDegrees(Math.asin(class_3532.method_15350((double)(deltaY / totalDist), (double)-1.0, (double)1.0)));
        return new double[]{yaw, pitch -= jumpAdjustment};
    }

    private class_1297 getCustomTarget() {
        if (AimAssist.mc.field_1687 == null || AimAssist.mc.field_1724 == null) {
            return null;
        }
        ArrayList<class_1309> validTargets = new ArrayList<class_1309>();
        boolean isElytra = AimAssist.mc.field_1724.method_6128();
        double maxRange = isElytra ? (double)this.customElytraRange.getValue() : (double)this.customRange.getValue();
        for (class_1297 entity : AimAssist.mc.field_1687.method_18112()) {
            double distance;
            if (!(entity instanceof class_1309)) continue;
            class_1309 living = (class_1309)entity;
            if (entity == AimAssist.mc.field_1724) continue;
            boolean isValidTarget = false;
            if (living instanceof class_1657) {
                class_1657 player = (class_1657)living;
                if (player.method_7337() || player.method_7325() || FriendUtils.isFriend((class_1297)player)) continue;
                if (this.targetSettings.isSelected("\u0418\u0433\u0440\u043e\u043a\u043e\u0432")) {
                    isValidTarget = true;
                }
                if (this.targetSettings.isSelected("\u0418\u0433\u0440\u043e\u043a\u043e\u0432 \u0431\u0435\u0437 \u0431\u0440\u043e\u043d\u0438") && player.method_6096() == 0) {
                    isValidTarget = true;
                }
                if (this.targetSettings.isSelected("\u0413\u043e\u043b\u044b\u0445")) {
                    boolean hasAnyItem = false;
                    for (class_1799 slot : player.method_31548().field_7548) {
                        if (slot.method_7960()) continue;
                        hasAnyItem = true;
                        break;
                    }
                    if (!player.method_6047().method_7960() || !player.method_6079().method_7960()) {
                        hasAnyItem = true;
                    }
                    if (!hasAnyItem) {
                        isValidTarget = true;
                    }
                }
            } else if (living instanceof class_1308 && this.targetSettings.isSelected("\u041c\u043e\u0431\u043e\u0432")) {
                isValidTarget = true;
            }
            if (!isValidTarget || living.method_5767() && !this.targetSettings.isSelected("\u041d\u0435\u0432\u0438\u0434\u0438\u043c\u044b\u0445") || !living.method_5805() || living.method_6032() <= 0.0f || (distance = AimAssist.mc.field_1724.method_5858((class_1297)living)) > maxRange * maxRange || this.disableIgnoreWalls.isValue() && !this.canSeeEntity((class_1297)living)) continue;
            if (this.disableBlock360.isValue()) {
                double yawDelta;
                double yawToTarget = this.getYawToEntity((class_1297)living);
                for (yawDelta = yawToTarget - (double)AimAssist.mc.field_1724.method_36454(); yawDelta > 180.0; yawDelta -= 360.0) {
                }
                while (yawDelta < -180.0) {
                    yawDelta += 360.0;
                }
                if (Math.abs(yawDelta) > 80.0) continue;
            }
            if (this.customFovEnabled.isValue() && !this.isInFov((class_1297)living, this.customFov.getValue())) continue;
            validTargets.add(living);
        }
        if (validTargets.isEmpty()) {
            return null;
        }
        class_1309 closest = null;
        double minDistance = Double.MAX_VALUE;
        for (class_1309 target : validTargets) {
            double distance = AimAssist.mc.field_1724.method_5858((class_1297)target);
            if (!(distance < minDistance)) continue;
            minDistance = distance;
            closest = target;
        }
        return closest;
    }

    private double getYawToEntity(class_1297 entity) {
        class_243 eyePos = AimAssist.mc.field_1724.method_33571();
        class_243 targetPos = entity.method_19538().method_1031(0.0, (double)entity.method_17682() * 0.5, 0.0);
        double deltaX = targetPos.field_1352 - eyePos.field_1352;
        double deltaZ = targetPos.field_1350 - eyePos.field_1350;
        return Math.toDegrees(Math.atan2(-deltaX, deltaZ));
    }

    private boolean isInFov(class_1297 entity, double fov) {
        class_243 eyePos = AimAssist.mc.field_1724.method_33571();
        class_243 targetPos = entity.method_19538().method_1031(0.0, (double)entity.method_17682() * 0.5, 0.0);
        class_243 toTarget = targetPos.method_1020(eyePos).method_1029();
        class_243 lookVec = AimAssist.mc.field_1724.method_5828(1.0f);
        double dot = lookVec.method_1026(toTarget);
        double angle = Math.toDegrees(Math.acos(class_3532.method_15350((double)dot, (double)-1.0, (double)1.0)));
        return angle <= fov / 2.0;
    }

    private void customAim(double targetYaw, double targetPitch, long now) {
        double yawDelta;
        float currentYaw = AimAssist.mc.field_1724.method_36454();
        float currentPitch = AimAssist.mc.field_1724.method_36455();
        for (yawDelta = targetYaw - (double)currentYaw; yawDelta > 180.0; yawDelta -= 360.0) {
        }
        while (yawDelta < -180.0) {
            yawDelta += 360.0;
        }
        double pitchDelta = targetPitch - (double)currentPitch;
        double tpsMultiplier = 1.0;
        if (this.customSyncTps.isValue()) {
            float tps = AimAssist.mc.field_1687 != null ? Math.min(20.0f, AimAssist.mc.field_1687.method_54719().method_54748()) : 20.0f;
            tpsMultiplier = (double)tps / 20.0;
        }
        double yawSpeed = (double)this.customYawSpeed.getValue() * tpsMultiplier * 0.05;
        double pitchSpeed = (double)this.customPitchSpeed.getValue() * tpsMultiplier * 0.05;
        double verticalSpeed = (double)this.customVerticalSpeed.getValue() * tpsMultiplier * 0.05;
        double finalYawDelta = yawDelta * yawSpeed;
        double finalPitchDelta = 0.0;
        if (this.customVerticalEnabled.isValue()) {
            finalPitchDelta = pitchDelta * verticalSpeed;
        }
        double gcdFix = Math.pow((Double)AimAssist.mc.field_1690.method_42495().method_41753() * 0.6 + 0.2, 3.0) * 1.2;
        finalYawDelta -= finalYawDelta % gcdFix;
        if (this.customVerticalEnabled.isValue()) {
            finalPitchDelta -= finalPitchDelta % gcdFix;
        }
        if (Math.abs(finalYawDelta) >= 0.003) {
            AimAssist.mc.field_1724.method_36456((float)((double)currentYaw + finalYawDelta));
        }
        if (this.customVerticalEnabled.isValue() && Math.abs(finalPitchDelta) >= 0.003) {
            AimAssist.mc.field_1724.method_36457(class_3532.method_15363((float)((float)((double)currentPitch + finalPitchDelta)), (float)-90.0f, (float)90.0f));
        }
    }

    /*
     * Exception decompiling
     */
    private void m(double targetYaw, double targetPitch, ThreadLocalRandom r, long now) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.ClassCastException: class org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement cannot be cast to class org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement (org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement and org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement are in unnamed module of loader 'app')
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchExpressionRewriter$LValueSingleUsageCheckingRewriter.rewriteExpression(SwitchExpressionRewriter.java:96)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression.applyExpressionRewriter(LValueExpression.java:84)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter.rewriteExpression(AbstractExpressionRewriter.java:14)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticOperation.applyExpressionRewriter(ArithmeticOperation.java:171)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter.rewriteExpression(AbstractExpressionRewriter.java:14)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple.rewriteExpressions(AssignmentSimple.java:167)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredFor.rewriteExpressions(StructuredFor.java:194)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer.transform(ExpressionRewriterTransformer.java:24)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:680)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:421)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer.transform(ExpressionRewriterTransformer.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:680)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredIf.transformStructuredChildren(StructuredIf.java:96)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer.transform(ExpressionRewriterTransformer.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:680)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:421)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer.transform(ExpressionRewriterTransformer.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:680)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchExpressionRewriter.rewriteBlockSwitches(SwitchExpressionRewriter.java:140)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchExpressionRewriter.transform(SwitchExpressionRewriter.java:71)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.switchExpression(Op04StructuredStatement.java:101)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:909)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private boolean isHoldingSword() {
        if (AimAssist.mc.field_1724 == null) {
            return false;
        }
        class_1792 item = AimAssist.mc.field_1724.method_6047().method_7909();
        return item instanceof class_1829;
    }
}

