/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 *  net.minecraft.class_1829
 *  net.minecraft.class_238
 *  net.minecraft.class_239
 *  net.minecraft.class_243
 *  net.minecraft.class_3545
 *  net.minecraft.class_3966
 */
package fun.bloody.features.impl.combat;

import antidaunleak.api.annotation.Native;
import fun.bloody.Bloody;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.events.player.RotationUpdateEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.impl.misc.MaceHelper;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.features.aura.point.MultiPoint;
import fun.bloody.utils.features.aura.rotations.constructor.LinearConstructor;
import fun.bloody.utils.features.aura.rotations.constructor.RotateConstructor;
import fun.bloody.utils.features.aura.striking.StrikerConstructor;
import fun.bloody.utils.features.aura.target.TargetFinder;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3545;
import net.minecraft.class_3966;

public class TriggerBot
extends Module {
    private static final float RANGE_MARGIN = 0.253f;
    private final TargetFinder targetSelector = new TargetFinder();
    private final MultiPoint pointFinder = new MultiPoint();
    public class_1309 target;
    public SliderSettings attackRange = new SliderSettings("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u0443\u0434\u0430\u0440\u0430", "\u0414\u0430\u043b\u044c\u043d\u043e\u0441\u0442\u044c \u0430\u0442\u0430\u043a\u0438 \u0434\u043e \u0446\u0435\u043b\u0438").setValue(3.0f).range(1.0f, 6.0f);
    MultiSelectSetting targetType = new MultiSelectSetting("\u0422\u0438\u043f \u0442\u0430\u0440\u0433\u0435\u0442\u0430", "\u0424\u0438\u043b\u044c\u0442\u0440\u0443\u0435\u0442 \u0441\u043f\u0438\u0441\u043e\u043a \u0446\u0435\u043b\u0435\u0439 \u043f\u043e \u0442\u0438\u043f\u0443").value("Players", "Mobs", "Animals", "Friends", "Armor Stand").selected("Players", "Mobs", "Animals");
    public MultiSelectSetting attackSetting = new MultiSelectSetting("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438", "\u041f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b \u0430\u0442\u0430\u043a\u0438").value("Only Critical", "Break Shield", "UnPress Shield", "No Attack When Eat", "Ignore The Walls", "Hit Chance", "\u0422\u043e\u043b\u044c\u043a\u043e \u0441 \u043e\u0440\u0443\u0436\u0438\u0435\u043c").selected("Only Critical", "Break Shield");
    public SliderSettings hitChance = new SliderSettings("\u0428\u0430\u043d\u0441 \u0443\u0434\u0430\u0440\u0430 \u0432 %", "\u0428\u0430\u043d\u0441 \u0443\u0434\u0430\u0440\u0430 \u043f\u043e \u0446\u0435\u043b\u0438").setValue(100.0f).range(1.0f, 100.0f).visible(() -> this.attackSetting.isSelected("Hit Chance"));
    public SelectSetting sprintReset = new SelectSetting("\u0421\u0431\u0440\u043e\u0441 \u0441\u043f\u0440\u0438\u043d\u0442\u0430", "\u0412\u044b\u0431\u043e\u0440 \u0441\u0431\u0440\u043e\u0441\u0430 \u0441\u043f\u0440\u0438\u043d\u0442\u0430 \u043f\u0435\u0440\u0435\u0434 \u0443\u0434\u0430\u0440\u043e\u043c").value("Legit", "Packet", "\u041d\u0435\u0442").selected("Legit");
    public BooleanSetting smartCrits = new BooleanSetting("\u0423\u043c\u043d\u044b\u0435 \u043a\u0440\u0438\u0442\u044b", "\u041a\u0440\u0438\u0442\u044b \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u0440\u0438 \u043d\u0430\u0436\u0430\u0442\u0438\u0438 \u043f\u0440\u043e\u0431\u0435\u043b\u0430").setValue(true).visible(() -> this.attackSetting.isSelected("Only Critical"));

    public TriggerBot() {
        super("TriggerBot", "Trigger Bot", ModuleCategory.COMBAT);
        this.setup(this.attackRange, this.targetType, this.attackSetting, this.hitChance, this.sprintReset, this.smartCrits);
    }

    public static TriggerBot getInstance() {
        return Instance.get(TriggerBot.class);
    }

    private class_1309 updateTarget() {
        TargetFinder.EntityFilter filter = new TargetFinder.EntityFilter(this.targetType.getSelected());
        float range = this.attackRange.getValue() + 0.253f;
        this.targetSelector.searchTargets(TriggerBot.mc.field_1687.method_18112(), range, 360.0f, this.attackSetting.isSelected("Ignore The Walls"));
        this.targetSelector.validateTarget(filter::isValid);
        return this.targetSelector.getCurrentTarget();
    }

    @EventHandler
    @Native(type=Native.Type.VMProtectBeginMutation)
    public void onRotationUpdate(RotationUpdateEvent e) {
        if (PlayerInteractionHelper.nullCheck()) {
            return;
        }
        if (this.attackSetting.isSelected("\u0422\u043e\u043b\u044c\u043a\u043e \u0441 \u043e\u0440\u0443\u0436\u0438\u0435\u043c") && !this.isHoldingSword()) {
            return;
        }
        switch (e.getType()) {
            case 0: {
                class_3966 entityHit;
                class_1297 class_12972;
                class_239 class_2392;
                this.target = this.updateTarget();
                if (TriggerBot.mc.field_1765 == null || !((class_2392 = TriggerBot.mc.field_1765) instanceof class_3966) || !((class_12972 = (entityHit = (class_3966)class_2392).method_17782()) instanceof class_1309)) break;
                class_1309 hoveredEntity = (class_1309)class_12972;
                TargetFinder.EntityFilter filter = new TargetFinder.EntityFilter(this.targetType.getSelected());
                if (!filter.isValid(hoveredEntity)) break;
                this.target = hoveredEntity;
                break;
            }
            case 2: {
                if (this.target == null) break;
                Bloody.getInstance().getAttackPerpetrator().performAttack(this.getConfig());
            }
        }
    }

    private boolean isHoldingSword() {
        if (TriggerBot.mc.field_1724 == null) {
            return false;
        }
        class_1792 item = TriggerBot.mc.field_1724.method_6047().method_7909();
        return item instanceof class_1829;
    }

    private boolean shouldAttackWithWind() {
        if (!MaceHelper.isUsingWindCharge()) {
            return false;
        }
        if (TriggerBot.mc.field_1724.method_6047().method_7909() != class_1802.field_49814) {
            return false;
        }
        if (TriggerBot.mc.field_1724.method_24828()) {
            return false;
        }
        if (TriggerBot.mc.field_1724.field_6017 < 1.5f) {
            return false;
        }
        float cooldownProgress = TriggerBot.mc.field_1724.method_7261(0.5f);
        return !(cooldownProgress < 0.9f);
    }

    public StrikerConstructor.AttackPerpetratorConfigurable getConfig() {
        float baseRange = this.attackRange.getValue() + 0.253f;
        class_3545<class_243, class_238> pointData = this.pointFinder.computeVector(this.target, baseRange, TurnsConnection.INSTANCE.getRotation(), this.getSmoothMode().randomValue(), this.attackSetting.isSelected("Ignore The Walls"));
        class_243 computedPoint = (class_243)pointData.method_15442();
        class_238 hitbox = (class_238)pointData.method_15441();
        Turns angle = MathAngle.fromVec3d(computedPoint.method_1020(Objects.requireNonNull(TriggerBot.mc.field_1724).method_33571()));
        return new StrikerConstructor.AttackPerpetratorConfigurable(this.target, angle, baseRange, this.attackSetting.getSelected(), null, hitbox);
    }

    public RotateConstructor getSmoothMode() {
        return new LinearConstructor();
    }

    @EventHandler
    public void tick(TickEvent e) {
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
    }
}

