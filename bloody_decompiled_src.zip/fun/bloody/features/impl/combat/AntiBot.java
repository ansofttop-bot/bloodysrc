/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_1661
 *  net.minecraft.class_1738
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2596
 *  net.minecraft.class_2703
 *  net.minecraft.class_2703$class_2705
 *  net.minecraft.class_7828
 */
package fun.bloody.features.impl.combat;

import antidaunleak.api.annotation.Native;
import com.mojang.authlib.GameProfile;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import java.lang.runtime.SwitchBootstraps;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.IntStream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2703;
import net.minecraft.class_7828;

public class AntiBot
extends Module {
    private final Set<UUID> suspectSet = new HashSet<UUID>();
    static Set<UUID> botSet = new HashSet<UUID>();
    private final SelectSetting mode = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0435\u0436\u0438\u043c \u043e\u0431\u043d\u0430\u0440\u0443\u0436\u0435\u043d\u0438\u044f \u0431\u043e\u0442\u043e\u0432").value("Matrix", "ReallyWorld").selected("ReallyWorld");

    public static AntiBot getInstance() {
        return Instance.get(AntiBot.class);
    }

    public AntiBot() {
        super("AntiBot", "Anti Bot", ModuleCategory.COMBAT);
        this.setup(this.mode);
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        class_2596<?> class_25962 = e.getPacket();
        Objects.requireNonNull(class_25962);
        class_2596<?> class_25963 = class_25962;
        int n = 0;
        switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{class_2703.class, class_7828.class}, class_25963, n)) {
            case 0: {
                class_2703 list = (class_2703)class_25963;
                this.checkPlayerAfterSpawn(list);
                break;
            }
            case 1: {
                class_7828 remove = (class_7828)class_25963;
                this.removePlayerBecauseLeftServer(remove);
                break;
            }
        }
    }

    @EventHandler
    @Native(type=Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (!this.suspectSet.isEmpty()) {
            AntiBot.mc.field_1687.method_18456().stream().filter(p -> this.suspectSet.contains(p.method_5667())).forEach(this::evaluateSuspectPlayer);
        }
        if (this.mode.isSelected("Matrix")) {
            this.matrixMode();
        } else if (this.mode.isSelected("ReallyWorld")) {
            this.ReallyWorldMode();
        }
    }

    private void checkPlayerAfterSpawn(class_2703 listS2CPacket) {
        listS2CPacket.method_46330().forEach(entry -> {
            GameProfile profile = entry.comp_1107();
            if (profile == null || this.isRealPlayer((class_2703.class_2705)entry, profile)) {
                return;
            }
            if (this.isDuplicateProfile(profile)) {
                botSet.add(profile.getId());
            } else {
                this.suspectSet.add(profile.getId());
            }
        });
    }

    private void removePlayerBecauseLeftServer(class_7828 removeS2CPacket) {
        removeS2CPacket.comp_1105().forEach(uuid -> {
            this.suspectSet.remove(uuid);
            botSet.remove(uuid);
        });
    }

    private boolean isRealPlayer(class_2703.class_2705 entry, GameProfile profile) {
        return entry.comp_1109() < 2 || profile.getProperties() != null && !profile.getProperties().isEmpty();
    }

    private void evaluateSuspectPlayer(class_1657 player) {
        Iterable armor = null;
        if (!this.isFullyEquipped(player)) {
            armor = player.method_5661();
        }
        if (this.isFullyEquipped(player) || this.hasArmorChanged(player, armor)) {
            botSet.add(player.method_5667());
        }
        this.suspectSet.remove(player.method_5667());
    }

    private void matrixMode() {
        Iterator<UUID> iterator2 = this.suspectSet.iterator();
        while (iterator2.hasNext()) {
            UUID susPlayer = iterator2.next();
            class_1657 entity = AntiBot.mc.field_1687.method_18470(susPlayer);
            if (entity != null) {
                boolean isFakeUUID;
                String playerName = entity.method_5477().getString();
                boolean isNameBot = playerName.startsWith("CIT-") && !playerName.contains("NPC") && !playerName.contains("[ZNPC]");
                int armorCount = 0;
                for (class_1799 item : entity.method_5661()) {
                    if (item.method_7960()) continue;
                    ++armorCount;
                }
                boolean isFullArmor = armorCount == 4;
                boolean bl = isFakeUUID = !entity.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + playerName).getBytes()));
                if (isFullArmor || isNameBot || isFakeUUID) {
                    botSet.add(susPlayer);
                }
            }
            iterator2.remove();
        }
        if (AntiBot.mc.field_1724.field_6012 % 100 == 0) {
            botSet.removeIf(uuid -> AntiBot.mc.field_1687.method_18470(uuid) == null);
        }
    }

    private void ReallyWorldMode() {
        for (class_1657 entity : AntiBot.mc.field_1687.method_18456()) {
            if (entity.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + entity.method_5477().getString()).getBytes())) || botSet.contains(entity.method_5667()) || entity.method_5477().getString().contains("NPC") || entity.method_5477().getString().startsWith("[ZNPC]")) continue;
            botSet.add(entity.method_5667());
        }
    }

    private void newMatrixMode() {
        for (class_1657 entity : AntiBot.mc.field_1687.method_18456()) {
            if (entity == AntiBot.mc.field_1724) continue;
            List armorItems = StreamSupport.stream(entity.method_5661().spliterator(), false).toList();
            boolean allArmorValid = true;
            for (class_1799 item : armorItems) {
                if (!item.method_7960() && item.method_7923() && item.method_7919() <= 0) continue;
                allArmorValid = false;
                break;
            }
            boolean hasSpecificArmor = false;
            for (class_1799 item : armorItems) {
                if (item.method_7909() != class_1802.field_8370 && item.method_7909() != class_1802.field_8570 && item.method_7909() != class_1802.field_8577 && item.method_7909() != class_1802.field_8267 && item.method_7909() != class_1802.field_8660 && item.method_7909() != class_1802.field_8396 && item.method_7909() != class_1802.field_8523 && item.method_7909() != class_1802.field_8743) continue;
                hasSpecificArmor = true;
                break;
            }
            if (allArmorValid && hasSpecificArmor && entity.method_5998(class_1268.field_5810).method_7909() == class_1802.field_8162 && entity.method_5998(class_1268.field_5808).method_7909() != class_1802.field_8162 && entity.method_7344().method_7586() == 20 && !entity.method_5477().getString().contains("NPC") && !entity.method_5477().getString().startsWith("[ZNPC]")) {
                botSet.add(entity.method_5667());
                continue;
            }
            botSet.remove(entity.method_5667());
        }
    }

    public boolean isDuplicateProfile(GameProfile profile) {
        return Objects.requireNonNull(mc.method_1562()).method_2880().stream().filter(player -> player.method_2966().getName().equals(profile.getName()) && !player.method_2966().getId().equals(profile.getId())).count() == 1L;
    }

    public boolean isFullyEquipped(class_1657 entity) {
        return IntStream.rangeClosed(0, 3).mapToObj(arg_0 -> ((class_1661)entity.method_31548()).method_7372(arg_0)).allMatch(stack -> stack.method_7909() instanceof class_1738 && !stack.method_7942());
    }

    public boolean hasArmorChanged(class_1657 entity, Iterable<class_1799> prevArmor) {
        if (prevArmor == null) {
            return true;
        }
        List currentArmorList = StreamSupport.stream(entity.method_5661().spliterator(), false).toList();
        List<class_1799> prevArmorList = StreamSupport.stream(prevArmor.spliterator(), false).toList();
        return !IntStream.range(0, Math.min(currentArmorList.size(), prevArmorList.size())).allMatch(i -> ((class_1799)currentArmorList.get(i)).equals(prevArmorList.get(i))) || currentArmorList.size() != prevArmorList.size();
    }

    public boolean isBot(class_1657 entity) {
        String playerName = entity.method_5477().getString();
        boolean isNameBot = playerName.startsWith("CIT-") && !playerName.contains("NPC") && !playerName.startsWith("[ZNPC]");
        boolean isMarkedBot = botSet.contains(entity.method_5667());
        this.isBotU((class_1297)entity);
        return isNameBot || isMarkedBot;
    }

    public boolean isBot(UUID uuid) {
        return botSet.contains(uuid);
    }

    public boolean isBotU(class_1297 entity) {
        return !entity.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + entity.method_5477().getString()).getBytes())) && entity.method_5767() && !entity.method_5477().getString().contains("NPC") && !entity.method_5477().getString().startsWith("[ZNPC]");
    }

    public void reset() {
        this.suspectSet.clear();
        botSet.clear();
    }

    @Override
    public void deactivate() {
        this.reset();
        super.deactivate();
    }
}

