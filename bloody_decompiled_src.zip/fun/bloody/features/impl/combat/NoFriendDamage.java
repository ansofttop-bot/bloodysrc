/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.combat;

import fun.bloody.common.repository.friend.FriendUtils;
import fun.bloody.events.player.AttackEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.managers.event.EventHandler;

public class NoFriendDamage
extends Module {
    public NoFriendDamage() {
        super("NoFriendDamage", "No Friend Damage", ModuleCategory.COMBAT);
    }

    @EventHandler
    public void onAttack(AttackEvent e) {
        e.setCancelled(FriendUtils.isFriend(e.getEntity()));
    }
}

