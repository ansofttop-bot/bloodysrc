/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1511
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_238
 *  net.minecraft.class_310
 *  net.minecraft.class_3675
 */
package fun.bloody.features.impl.combat;

import antidaunleak.api.annotation.Native;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.interactions.inv.InventoryResult;
import fun.bloody.utils.interactions.inv.InventoryToolkit;
import java.util.List;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class AutoTotem
extends Module {
    private static final class_310 MC = class_310.method_1551();
    private final SelectSetting modeSetting = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "\u0421\u043f\u043e\u0441\u043e\u0431 \u0441\u0432\u043e\u043f\u0430").value("Default", "Legit").selected("Default");
    private final SelectSetting selectionMode = new SelectSetting("\u0420\u0435\u0436\u0438\u043c \u0432\u044b\u0431\u043e\u0440\u0430", "\u041a\u0430\u043a\u043e\u0439 \u0442\u043e\u0442\u0435\u043c \u0432\u044b\u0431\u0438\u0440\u0430\u0442\u044c").value("\u041e\u0431\u044b\u0447\u043d\u044b\u0439", "\u0425\u0443\u0434\u0448\u0438\u0439").selected("\u041e\u0431\u044b\u0447\u043d\u044b\u0439");
    private final SliderSettings healthThreshold = new SliderSettings("\u041f\u043e\u0440\u043e\u0433 \u0437\u0434\u043e\u0440\u043e\u0432\u044c\u044f", "\u041c\u0438\u043d\u0438\u043c\u0430\u043b\u044c\u043d\u043e\u0435 \u0437\u0434\u043e\u0440\u043e\u0432\u044c\u0435 \u0434\u043b\u044f \u044d\u043a\u0438\u043f\u0438\u0440\u043e\u0432\u043a\u0438 \u0442\u043e\u0442\u0435\u043c\u0430").setValue(4.5f).range(1.0f, 20.0f);
    private final SliderSettings elytraHealth = new SliderSettings("\u0417\u0434\u043e\u0440\u043e\u0432\u044c\u0435 \u043d\u0430 \u044d\u043b\u0438\u0442\u0440\u0435", "\u041c\u0438\u043d\u0438\u043c\u0430\u043b\u044c\u043d\u043e\u0435 \u0437\u0434\u043e\u0440\u043e\u0432\u044c\u0435 \u043f\u0440\u0438 \u043f\u043e\u043b\u0435\u0442\u0435").setValue(8.5f).range(1.0f, 20.0f);
    private final SliderSettings crystalDistance = new SliderSettings("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u0434\u043e \u043a\u0440\u0438\u0441\u0442\u0430\u043b\u043b\u0430", "\u041c\u0430\u043a\u0441 \u0434\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u0434\u043e \u043a\u0440\u0438\u0441\u0442\u0430\u043b\u043b\u0430").setValue(4.0f).range(1.0f, 6.0f);
    private final BooleanSetting fallCheck = new BooleanSetting("\u041f\u0430\u0434\u0435\u043d\u0438\u0435", "\u042d\u043a\u0438\u043f\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0442\u043e\u0442\u0435\u043c \u043f\u0440\u0438 \u043f\u0430\u0434\u0435\u043d\u0438\u0438").setValue(true);
    private final BooleanSetting saveTaliks = new BooleanSetting("\u0421\u0435\u0439\u0432 \u0442\u0430\u043b\u0438\u043a\u043e\u0432", "\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c \u043e\u0431\u044b\u0447\u043d\u044b\u0435 \u0442\u043e\u0442\u0435\u043c\u044b \u0431\u0435\u0437 \u0447\u0430\u0440").setValue(true);
    private final BooleanSetting returnItem = new BooleanSetting("\u0412\u043e\u0437\u0432\u0440\u0430\u0449\u0430\u0442\u044c \u043f\u0440\u0435\u0434\u043c\u0435\u0442", "\u0412\u0435\u0440\u043d\u0443\u0442\u044c \u043f\u0440\u0435\u0434\u044b\u0434\u0443\u0449\u0438\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442 \u0432 \u0440\u0443\u043a\u0443/\u0445\u043e\u0442\u0431\u0430\u0440 \u043f\u043e\u0441\u043b\u0435 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u044f \u0442\u043e\u0442\u0435\u043c\u0430").setValue(true);
    private int savedSlot = -1;
    private int totemSlot = -1;
    private long actionStartTime = 0L;
    private boolean keysOverridden = false;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private boolean wasJumpPressed;
    private boolean playerFullyStopped = false;
    private Phase phase = Phase.READY;
    private class_1799 previousMainHandStack = class_1799.field_8037;
    private int previousMainHandSlot = -1;
    private boolean needsReturn = false;

    public AutoTotem() {
        super("AutoTotem", "Auto Totem", ModuleCategory.COMBAT);
        this.setup(this.modeSetting, this.selectionMode, this.healthThreshold, this.elytraHealth, this.crystalDistance, this.fallCheck, this.saveTaliks, this.returnItem);
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (AutoTotem.MC.field_1724 == null || AutoTotem.MC.field_1687 == null) {
            this.resetState();
            return;
        }
        if (this.phase != Phase.READY) {
            this.execute();
            return;
        }
        float health = AutoTotem.MC.field_1724.method_6032();
        boolean shouldEquip = false;
        if (AutoTotem.MC.field_1724.method_6128() && health <= this.elytraHealth.getValue()) {
            shouldEquip = true;
        } else if (health <= this.healthThreshold.getValue()) {
            shouldEquip = true;
        } else if (this.fallCheck.isValue() && AutoTotem.MC.field_1724.field_6017 > 10.0f) {
            shouldEquip = true;
        } else if (this.getClosestCrystalDistance() <= (double)this.crystalDistance.getValue()) {
            shouldEquip = true;
        }
        if (shouldEquip) {
            this.tryEquipTotem();
        }
        if (this.phase == Phase.READY && this.needsReturn && this.returnItem.isValue() && this.previousMainHandSlot >= 0 && !this.previousMainHandStack.method_7960() && AutoTotem.MC.field_1724.method_6079().method_7909() != class_1802.field_8288) {
            this.attemptReturnPreviousItem();
            this.previousMainHandStack = class_1799.field_8037;
            this.previousMainHandSlot = -1;
            this.needsReturn = false;
        }
    }

    @Native(type=Native.Type.VMProtectBeginUltra)
    private void tryEquipTotem() {
        if (this.phase != Phase.READY) {
            return;
        }
        if (this.isTotemInOffhand()) {
            return;
        }
        if (AutoTotem.MC.field_1755 != null) {
            return;
        }
        this.savedSlot = AutoTotem.MC.field_1724.method_31548().field_7545;
        InventoryResult hotbar = InventoryToolkit.findItemInHotBar(class_1802.field_8288);
        if (hotbar.found()) {
            this.totemSlot = hotbar.slot();
            if (this.modeSetting.getSelected().equals("Default")) {
                this.executeDefaultSwap();
            } else {
                this.startLegitEquip();
            }
            return;
        }
        InventoryResult inv = this.saveTaliks.isValue() ? this.findTotemWithSaveTalics() : InventoryToolkit.findItemInInventory(class_1802.field_8288);
        if (inv.found()) {
            this.totemSlot = inv.slot();
            this.previousMainHandSlot = AutoTotem.MC.field_1724.method_31548().field_7545;
            this.previousMainHandStack = AutoTotem.MC.field_1724.method_6047().method_7972();
            this.needsReturn = true;
            if (this.modeSetting.getSelected().equals("Legit")) {
                this.startLegitEquip();
            } else {
                this.executeDefaultSwap();
            }
        }
    }

    private void executeDefaultSwap() {
        if (this.totemSlot < 0) {
            this.resetState();
            return;
        }
        int slotIndex = this.totemSlot;
        if (slotIndex >= 0 && slotIndex <= 8) {
            slotIndex += 36;
        }
        if (AutoTotem.MC.field_1761 != null && AutoTotem.MC.field_1724.field_7498 != null) {
            AutoTotem.MC.field_1761.method_2906(AutoTotem.MC.field_1724.field_7498.field_7763, slotIndex, 40, class_1713.field_7791, (class_1657)AutoTotem.MC.field_1724);
        }
        if (this.returnItem.isValue() && this.needsReturn && this.previousMainHandSlot >= 0) {
            AutoTotem.MC.field_1724.method_31548().field_7545 = this.previousMainHandSlot;
        } else if (this.savedSlot >= 0) {
            AutoTotem.MC.field_1724.method_31548().field_7545 = this.savedSlot;
        }
        this.resetState();
    }

    @Native(type=Native.Type.VMProtectBeginMutation)
    private void startLegitEquip() {
        this.wasForwardPressed = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1894.method_1429().method_1444());
        this.wasBackPressed = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1881.method_1429().method_1444());
        this.wasLeftPressed = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1913.method_1429().method_1444());
        this.wasRightPressed = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1849.method_1429().method_1444());
        this.wasJumpPressed = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1903.method_1429().method_1444());
        this.phase = Phase.SLOWING_DOWN;
        this.actionStartTime = System.currentTimeMillis();
        this.playerFullyStopped = false;
        this.keysOverridden = false;
    }

    private void execute() {
        if (AutoTotem.MC.field_1724 == null || AutoTotem.MC.field_1755 != null) {
            this.resetState();
            return;
        }
        long elapsed = System.currentTimeMillis() - this.actionStartTime;
        switch (this.phase.ordinal()) {
            case 1: {
                AutoTotem.MC.field_1724.field_3913.field_3905 = 0.0f;
                AutoTotem.MC.field_1724.field_3913.field_3907 = 0.0f;
                if (AutoTotem.MC.field_1724.method_5624()) {
                    AutoTotem.MC.field_1724.method_5728(false);
                }
                if (!this.keysOverridden) {
                    AutoTotem.MC.field_1690.field_1894.method_23481(false);
                    AutoTotem.MC.field_1690.field_1881.method_23481(false);
                    AutoTotem.MC.field_1690.field_1913.method_23481(false);
                    AutoTotem.MC.field_1690.field_1849.method_23481(false);
                    AutoTotem.MC.field_1690.field_1903.method_23481(false);
                    this.keysOverridden = true;
                }
                if (elapsed <= 1L) break;
                this.phase = Phase.SWAP_TOTEM;
                this.actionStartTime = System.currentTimeMillis();
                break;
            }
            case 2: {
                if (elapsed <= 25L) break;
                if (this.totemSlot < 0) {
                    this.resetState();
                    return;
                }
                int slotIndex = this.totemSlot;
                if (slotIndex >= 0 && slotIndex <= 8) {
                    slotIndex += 36;
                }
                if (AutoTotem.MC.field_1761 != null && AutoTotem.MC.field_1724.field_7498 != null) {
                    AutoTotem.MC.field_1761.method_2906(AutoTotem.MC.field_1724.field_7498.field_7763, slotIndex, 40, class_1713.field_7791, (class_1657)AutoTotem.MC.field_1724);
                }
                this.phase = Phase.AWAIT_SWITCH;
                this.actionStartTime = System.currentTimeMillis();
                break;
            }
            case 3: {
                if (!this.isTotemInOffhand() && elapsed <= 50L) break;
                this.phase = Phase.RESTORE_SLOT;
                this.actionStartTime = System.currentTimeMillis();
                break;
            }
            case 4: {
                if (elapsed <= 25L) break;
                InventoryToolkit.switchTo(this.savedSlot);
                if (this.modeSetting.getSelected().equals("Legit")) {
                    if (this.keysOverridden) {
                        this.restoreKeyStates();
                    }
                    this.actionStartTime = System.currentTimeMillis();
                    this.phase = Phase.SPEEDING_UP;
                    break;
                }
                this.phase = Phase.FINISH;
                break;
            }
            case 5: {
                long speedupElapsed = System.currentTimeMillis() - this.actionStartTime;
                float speedupProgress = Math.min(1.0f, (float)speedupElapsed / 20.0f);
                if (AutoTotem.MC.field_1724.field_3913 != null) {
                    boolean forward = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1894.method_1429().method_1444());
                    float targetForward = forward ? 1.0f : 0.0f;
                    AutoTotem.MC.field_1724.field_3913.field_3905 = this.lerp(AutoTotem.MC.field_1724.field_3913.field_3905, targetForward * speedupProgress, 0.4f);
                    if (speedupProgress > 0.4f && forward && !AutoTotem.MC.field_1724.method_5624()) {
                        AutoTotem.MC.field_1724.method_5728(true);
                    }
                }
                if (speedupElapsed <= 25L) break;
                this.phase = Phase.FINISH;
                break;
            }
            case 6: {
                this.resetState();
            }
        }
    }

    private float lerp(float start, float end, float delta) {
        return start + (end - start) * delta;
    }

    private InventoryResult findTotemWithSaveTalics() {
        InventoryResult nonEnchanted = InventoryToolkit.findInInventory(i -> i.method_7909() == class_1802.field_8288 && !i.method_7942());
        if (nonEnchanted.found()) {
            return nonEnchanted;
        }
        return InventoryToolkit.findItemInInventory(class_1802.field_8288);
    }

    private double getClosestCrystalDistance() {
        double minDist = Double.MAX_VALUE;
        if (AutoTotem.MC.field_1724 == null || AutoTotem.MC.field_1687 == null) {
            return minDist;
        }
        class_238 box = AutoTotem.MC.field_1724.method_5829().method_1014((double)this.crystalDistance.getValue());
        List crystals = AutoTotem.MC.field_1687.method_8390(class_1511.class, box, e -> true);
        for (class_1511 crystal : crystals) {
            double dist = AutoTotem.MC.field_1724.method_19538().method_1022(crystal.method_19538());
            if (!(dist < minDist)) continue;
            minDist = dist;
        }
        return minDist;
    }

    private boolean isTotemInOffhand() {
        class_1799 stack = AutoTotem.MC.field_1724.method_6079();
        return stack.method_7909() == class_1802.field_8288;
    }

    private void restoreKeyStates() {
        boolean currentForward = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1894.method_1429().method_1444());
        boolean currentBack = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1881.method_1429().method_1444());
        boolean currentLeft = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1913.method_1429().method_1444());
        boolean currentRight = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1849.method_1429().method_1444());
        boolean currentJump = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)AutoTotem.MC.field_1690.field_1903.method_1429().method_1444());
        AutoTotem.MC.field_1690.field_1894.method_23481(this.wasForwardPressed && currentForward);
        AutoTotem.MC.field_1690.field_1881.method_23481(this.wasBackPressed && currentBack);
        AutoTotem.MC.field_1690.field_1913.method_23481(this.wasLeftPressed && currentLeft);
        AutoTotem.MC.field_1690.field_1849.method_23481(this.wasRightPressed && currentRight);
        AutoTotem.MC.field_1690.field_1903.method_23481(this.wasJumpPressed && currentJump);
        this.keysOverridden = false;
    }

    private void attemptReturnPreviousItem() {
        int toIndex;
        if (!this.returnItem.isValue()) {
            return;
        }
        if (this.previousMainHandStack == null || this.previousMainHandStack.method_7960()) {
            return;
        }
        if (AutoTotem.MC.field_1724 == null || AutoTotem.MC.field_1724.field_7498 == null || AutoTotem.MC.field_1761 == null) {
            return;
        }
        int targetHotbar = this.previousMainHandSlot;
        if (targetHotbar < 0 || targetHotbar > 8) {
            int n = targetHotbar = this.savedSlot >= 0 ? this.savedSlot : -1;
        }
        if (targetHotbar < 0) {
            return;
        }
        class_1799 currentStackInTarget = AutoTotem.MC.field_1724.method_31548().method_5438(targetHotbar);
        if (!currentStackInTarget.method_7960() && currentStackInTarget.method_7909() == this.previousMainHandStack.method_7909()) {
            InventoryToolkit.switchTo(targetHotbar);
            return;
        }
        InventoryResult found = InventoryToolkit.findInInventory(i -> i.method_7909() == this.previousMainHandStack.method_7909());
        if (!found.found()) {
            InventoryToolkit.switchTo(targetHotbar);
            return;
        }
        int fromSlot = found.slot();
        int fromIndex = fromSlot;
        if (fromIndex >= 0 && fromIndex <= 8) {
            fromIndex += 36;
        }
        if ((toIndex = targetHotbar) >= 0 && toIndex <= 8) {
            toIndex += 36;
        }
        AutoTotem.MC.field_1761.method_2906(AutoTotem.MC.field_1724.field_7498.field_7763, fromIndex, toIndex, class_1713.field_7791, (class_1657)AutoTotem.MC.field_1724);
        InventoryToolkit.switchTo(targetHotbar);
    }

    private void resetState() {
        if (this.keysOverridden) {
            this.restoreKeyStates();
        }
        this.totemSlot = -1;
        this.savedSlot = -1;
        this.actionStartTime = 0L;
        this.phase = Phase.READY;
        this.playerFullyStopped = false;
    }

    @Override
    public void deactivate() {
        this.resetState();
        this.previousMainHandStack = class_1799.field_8037;
        this.previousMainHandSlot = -1;
        this.needsReturn = false;
        super.deactivate();
    }

    private static enum Phase {
        READY,
        SLOWING_DOWN,
        SWAP_TOTEM,
        AWAIT_SWITCH,
        RESTORE_SLOT,
        SPEEDING_UP,
        FINISH;

    }
}

