/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 *  net.minecraft.class_2960
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_7833
 *  org.joml.Vector4i
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.geometry.Render3D;
import fun.bloody.utils.display.interfaces.QuickImports;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Vector4i;

public class LineGlyphs
extends Module {
    private BooleanSetting glowing = new BooleanSetting("\u0421\u0432\u0435\u0447\u0435\u043d\u0438\u0435", "\u0414\u043e\u0431\u0430\u0432\u043b\u044f\u0435\u0442 \u0441\u0432\u0435\u0447\u0435\u043d\u0438\u0435 \u043b\u0438\u043d\u0438\u044f\u043c").setValue(true);
    private BooleanSetting dashed = new BooleanSetting("\u041f\u0443\u043d\u043a\u0442\u0438\u0440", "\u0414\u0435\u043b\u0430\u0435\u0442 \u043b\u0438\u043d\u0438\u0438 \u043f\u0443\u043d\u043a\u0442\u0438\u0440\u043d\u044b\u043c\u0438").setValue(false);
    private SelectSetting colorMode = new SelectSetting("\u0420\u0435\u0436\u0438\u043c \u0446\u0432\u0435\u0442\u0430", "\u0412\u044b\u0431\u043e\u0440 \u0440\u0435\u0436\u0438\u043c\u0430 \u0446\u0432\u0435\u0442\u0430").value("Client", "Picker", "DoublePicker").selected("Client");
    private ColorSetting pickColor1 = new ColorSetting("\u0426\u0432\u0435\u0442 1", "\u041f\u0435\u0440\u0432\u044b\u0439 \u0446\u0432\u0435\u0442").value(ColorAssist.getColor(100, 200, 255)).visible(() -> this.colorMode.getSelected().contains("Picker"));
    private ColorSetting pickColor2 = new ColorSetting("\u0426\u0432\u0435\u0442 2", "\u0412\u0442\u043e\u0440\u043e\u0439 \u0446\u0432\u0435\u0442").value(ColorAssist.getColor(255, 100, 200)).visible(() -> this.colorMode.getSelected().equals("DoublePicker"));
    private final List<FallingLine> lines = new ArrayList<FallingLine>();
    private final Random random = new Random();
    private static final int LINE_COUNT = 120;
    private static final float FALL_SPEED = 0.07f;
    private static final float LINE_LENGTH = 17.0f;
    private static final float SEGMENT_LENGTH = 2.0f;
    private static final float ZIGZAG_WIDTH = 5.0f;

    public static LineGlyphs getInstance() {
        return Instance.get(LineGlyphs.class);
    }

    public LineGlyphs() {
        super("LineGlyphs", "Line Glyphs", ModuleCategory.RENDER);
        this.setup(this.glowing, this.dashed, this.colorMode, this.pickColor1, this.pickColor2);
    }

    @Override
    public void activate() {
        super.activate();
        this.generateLines();
    }

    @Override
    public void deactivate() {
        super.deactivate();
        this.lines.clear();
    }

    private void generateLines() {
        this.lines.clear();
        if (LineGlyphs.mc.field_1724 == null) {
            return;
        }
        for (int i = 0; i < 120; ++i) {
            this.lines.add(new FallingLine(this.random, LineGlyphs.mc.field_1724.method_19538()));
        }
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        if (LineGlyphs.mc.field_1724 == null) {
            return;
        }
        int linesToSpawn = 120 - this.lines.size();
        Iterator<FallingLine> iterator2 = this.lines.iterator();
        while (iterator2.hasNext()) {
            FallingLine line = iterator2.next();
            line.update(LineGlyphs.mc.field_1724.method_19538(), 0.07f, 2.0f, 5.0f, 17.0f);
            if (!line.shouldRespawn(LineGlyphs.mc.field_1724.method_19538())) continue;
            iterator2.remove();
            ++linesToSpawn;
        }
        for (int i = 0; i < linesToSpawn; ++i) {
            this.lines.add(new FallingLine(this.random, LineGlyphs.mc.field_1724.method_19538()));
        }
        this.renderLines(e.getStack());
    }

    private void renderLines(class_4587 stack) {
        if (this.lines.isEmpty() || LineGlyphs.mc.field_1773 == null) {
            return;
        }
        class_4184 camera = LineGlyphs.mc.field_1773.method_19418();
        class_243 camPos = camera.method_19326();
        for (int lineIndex = 0; lineIndex < this.lines.size(); ++lineIndex) {
            FallingLine line = this.lines.get(lineIndex);
            if (line.points.size() < 2) continue;
            int color = this.getColor(lineIndex);
            for (int i = 0; i < line.points.size() - 1; ++i) {
                int glowColor;
                float width;
                class_243 start = line.points.get(i);
                class_243 end = line.points.get(i + 1);
                if (start.method_1022(camPos) > 60.0 || end.method_1022(camPos) > 60.0) continue;
                float segmentAlpha = (float)(i + 1) / (float)line.points.size();
                int segmentColor = ColorAssist.setAlpha(color, (int)(segmentAlpha * 255.0f));
                float f = width = this.glowing.isValue() ? 2.5f : 1.5f;
                if (this.dashed.isValue()) {
                    this.drawDashedLine(start, end, segmentColor, width);
                    if (!this.glowing.isValue()) continue;
                    glowColor = ColorAssist.setAlpha(color, (int)(segmentAlpha * 100.0f));
                    this.drawDashedLine(start, end, glowColor, 4.0f);
                    continue;
                }
                Render3D.drawLine(start, end, segmentColor, width, true);
                if (!this.glowing.isValue()) continue;
                glowColor = ColorAssist.setAlpha(color, (int)(segmentAlpha * 100.0f));
                Render3D.drawLine(start, end, glowColor, 4.0f, true);
            }
            this.renderTurnCircles(stack, line, color, camPos);
        }
    }

    private void drawDashedLine(class_243 start, class_243 end, int color, float width) {
        double dashLength = 0.15;
        double gapLength = 0.1;
        double totalPattern = dashLength + gapLength;
        class_243 direction = end.method_1020(start);
        double lineLength = direction.method_1033();
        class_243 normalizedDir = direction.method_1029();
        for (double currentDistance = 0.0; currentDistance < lineLength; currentDistance += totalPattern) {
            double dashEnd = Math.min(currentDistance + dashLength, lineLength);
            class_243 dashStart = start.method_1019(normalizedDir.method_1021(currentDistance));
            class_243 dashEndPos = start.method_1019(normalizedDir.method_1021(dashEnd));
            Render3D.drawLine(dashStart, dashEndPos, color, width, true);
        }
    }

    private void renderTurnCircles(class_4587 stack, FallingLine line, int color, class_243 camPos) {
        if (line.turnPoints.isEmpty() || LineGlyphs.mc.field_1773 == null) {
            return;
        }
        class_4184 camera = LineGlyphs.mc.field_1773.method_19418();
        float pitch = camera.method_19329();
        float yaw = camera.method_19330();
        for (class_243 turnPoint : line.turnPoints) {
            if (turnPoint.method_1022(camPos) > 60.0) continue;
            float alpha = 1.0f;
            if (!line.points.isEmpty()) {
                class_243 lastPoint = line.points.get(line.points.size() - 1);
                double distanceFromEnd = turnPoint.method_1022(lastPoint);
                alpha = Math.max(0.3f, 1.0f - (float)(distanceFromEnd / 17.0));
            }
            int particleColor = ColorAssist.setAlpha(color, (int)(alpha * 255.0f));
            float size = 0.2f;
            double posX = turnPoint.field_1352 - camPos.field_1352;
            double posY = turnPoint.field_1351 - camPos.field_1351;
            double posZ = turnPoint.field_1350 - camPos.field_1350;
            class_4587 matrices = new class_4587();
            matrices.method_22903();
            matrices.method_22907(class_7833.field_40714.rotationDegrees(pitch));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(yaw + 180.0f));
            matrices.method_22904(posX, posY, posZ);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(pitch));
            Render3D.drawTexture(matrices.method_23760(), class_2960.method_60654((String)"textures/features/particles/bloom.png"), -size / 2.0f, -size / 2.0f, size, size, new Vector4i(particleColor, particleColor, particleColor, particleColor), true);
            matrices.method_22909();
        }
    }

    private int getColor(int index) {
        return switch (this.colorMode.getSelected()) {
            case "Client" -> ColorAssist.getClientColor();
            case "Picker" -> this.pickColor1.getColor();
            case "DoublePicker" -> ColorAssist.gradient(this.pickColor1.getColor(), this.pickColor2.getColor(), index, 10);
            default -> ColorAssist.getClientColor();
        };
    }

    private static class FallingLine {
        List<class_243> points = new ArrayList<class_243>();
        List<class_243> turnPoints = new ArrayList<class_243>();
        class_243 currentDirection;
        double distanceTraveled = 0.0;
        double currentSegmentLength;
        Random random = new Random();

        public FallingLine(Random random, class_243 playerPos) {
            if (QuickImports.mc.field_1773 == null || QuickImports.mc.field_1724 == null) {
                double range = 15.0;
                double x = playerPos.field_1352 + (random.nextDouble() - 0.5) * range;
                double y = playerPos.field_1351 + random.nextDouble() * 14.0;
                double z = playerPos.field_1350 + (random.nextDouble() - 0.5) * range;
                this.points.add(new class_243(x, y, z));
            } else {
                float yaw = QuickImports.mc.field_1724.method_36454();
                float pitch = QuickImports.mc.field_1724.method_36455();
                double yawRad = Math.toRadians(yaw);
                double pitchRad = Math.toRadians(pitch);
                double distance = 2.0 + random.nextDouble() * 6.0;
                double dirX = -Math.sin(yawRad) * Math.cos(pitchRad);
                double dirY = -Math.sin(pitchRad);
                double dirZ = Math.cos(yawRad) * Math.cos(pitchRad);
                class_243 lookDir = new class_243(dirX, dirY, dirZ);
                class_243 worldUp = new class_243(0.0, 1.0, 0.0);
                class_243 right = lookDir.method_1036(worldUp).method_1029();
                class_243 up = right.method_1036(lookDir).method_1029();
                double horizontalSpread = (random.nextDouble() - 0.5) * 24.0;
                double verticalSpread = (random.nextDouble() - 0.5) * 18.0;
                double x = playerPos.field_1352 + dirX * distance;
                double y = playerPos.field_1351 + dirY * distance;
                double z = playerPos.field_1350 + dirZ * distance;
                this.points.add(new class_243(x += right.field_1352 * horizontalSpread + up.field_1352 * verticalSpread, y += right.field_1351 * horizontalSpread + up.field_1351 * verticalSpread, z += right.field_1350 * horizontalSpread + up.field_1350 * verticalSpread));
            }
            this.currentDirection = this.getRandomDirection();
            this.currentSegmentLength = 0.5 + random.nextDouble() * 1.5;
        }

        public void update(class_243 playerPos, float fallSpeed, float segmentLengthSetting, float zigzagWidth, float maxLineLength) {
            if (this.points.isEmpty()) {
                return;
            }
            class_243 lastPoint = this.points.get(this.points.size() - 1);
            class_243 movement = this.currentDirection.method_1021((double)fallSpeed);
            class_243 newPoint = lastPoint.method_1019(movement);
            this.points.add(newPoint);
            this.distanceTraveled += (double)fallSpeed;
            if (this.distanceTraveled >= this.currentSegmentLength) {
                this.turnPoints.add(newPoint);
                this.makeRandomTurn(zigzagWidth);
                this.distanceTraveled = 0.0;
                this.currentSegmentLength = 0.5 + this.random.nextDouble() * 1.5;
            }
            double totalLength = this.calculateTotalLength();
            while (totalLength > (double)maxLineLength && this.points.size() > 2) {
                class_243 removedPoint = this.points.remove(0);
                this.turnPoints.removeIf(turnPoint -> turnPoint.equals((Object)removedPoint));
                totalLength = this.calculateTotalLength();
            }
            if (!this.points.isEmpty()) {
                class_243 firstPoint = this.points.get(0);
                this.turnPoints.removeIf(turnPoint -> {
                    boolean isInPoints = this.points.stream().anyMatch(p -> p.method_1022(turnPoint) < 0.1);
                    return !isInPoints && turnPoint.method_1022(firstPoint) > (double)maxLineLength;
                });
            }
        }

        private double calculateTotalLength() {
            double length = 0.0;
            for (int i = 0; i < this.points.size() - 1; ++i) {
                length += this.points.get(i).method_1022(this.points.get(i + 1));
            }
            return length;
        }

        private void makeRandomTurn(float zigzagWidth) {
            this.currentDirection = this.getRandomDirection();
        }

        private class_243 getRandomDirection() {
            int directionType = this.random.nextInt(6);
            return switch (directionType) {
                case 0 -> new class_243(1.0, 0.0, 0.0);
                case 1 -> new class_243(-1.0, 0.0, 0.0);
                case 2 -> new class_243(0.0, 1.0, 0.0);
                case 3 -> new class_243(0.0, -1.0, 0.0);
                case 4 -> new class_243(0.0, 0.0, 1.0);
                case 5 -> new class_243(0.0, 0.0, -1.0);
                default -> new class_243(0.0, -1.0, 0.0);
            };
        }

        public boolean shouldRespawn(class_243 playerPos) {
            if (this.points.isEmpty()) {
                return true;
            }
            class_243 lastPoint = this.points.get(this.points.size() - 1);
            double distance = lastPoint.method_1022(playerPos);
            if (distance > 18.0) {
                return true;
            }
            if (QuickImports.mc.field_1773 != null) {
                class_243 toLine;
                class_4184 camera = QuickImports.mc.field_1773.method_19418();
                class_243 cameraPos = camera.method_19326();
                class_243 cameraDir = class_243.method_1030((float)camera.method_19329(), (float)camera.method_19330());
                double dotProduct = cameraDir.method_1026(toLine = lastPoint.method_1020(cameraPos).method_1029());
                if (dotProduct < 0.5) {
                    return true;
                }
            }
            return false;
        }
    }
}

