/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.managers.event.EventHandler;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

public class FullBright
extends Module {
    public FullBright() {
        super("FullBright", "Full Bright", ModuleCategory.RENDER);
    }

    @EventHandler
    private void onTick(TickEvent event) {
        if (FullBright.mc.field_1724 == null || FullBright.mc.field_1687 == null) {
            return;
        }
        if (!FullBright.mc.field_1724.method_6059(class_1294.field_5925)) {
            FullBright.mc.field_1724.method_6092(new class_1293(class_1294.field_5925, -1, 3));
        }
    }

    @Override
    public void deactivate() {
        if (FullBright.mc.field_1724 != null) {
            FullBright.mc.field_1724.method_6016(class_1294.field_5925);
        }
        super.deactivate();
    }
}

