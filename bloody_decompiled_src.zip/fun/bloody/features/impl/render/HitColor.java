/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.player.AttackEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.events.render.EntityColorEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1309;

public class HitColor
extends Module {
    private final ColorSetting hitColorSetting = new ColorSetting("\u0426\u0432\u0435\u0442 \u0443\u0434\u0430\u0440\u0430", "\u0426\u0432\u0435\u0442 \u043f\u0440\u0438 \u043e\u0431\u044b\u0447\u043d\u043e\u043c \u0443\u0434\u0430\u0440\u0435").setColor(-65536);
    private final ColorSetting critColorSetting = new ColorSetting("\u0426\u0432\u0435\u0442 \u043a\u0440\u0438\u0442\u0430", "\u0426\u0432\u0435\u0442 \u043f\u0440\u0438 \u043a\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043a\u043e\u043c \u0443\u0434\u0430\u0440\u0435").setColor(-65536);
    private final SliderSettings durationSetting = new SliderSettings("\u0414\u043b\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u044c", "\u0414\u043b\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u044c \u044d\u0444\u0444\u0435\u043a\u0442\u0430 \u0432 \u0442\u0438\u043a\u0430\u0445").setValue(10.0f).range(1, 40);
    private final BooleanSetting onlyCrit = new BooleanSetting("\u0422\u043e\u043b\u044c\u043a\u043e \u043a\u0440\u0438\u0442\u044b", "\u041e\u043a\u0440\u0430\u0448\u0438\u0432\u0430\u0442\u044c \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u0440\u0438 \u043a\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0445 \u0443\u0434\u0430\u0440\u0430\u0445").setValue(false);
    private final Map<Integer, HitInfo> hitEntities = new ConcurrentHashMap<Integer, HitInfo>();

    public HitColor() {
        super("HitColor", "HitColor", ModuleCategory.RENDER);
        this.setup(this.hitColorSetting, this.critColorSetting, this.durationSetting, this.onlyCrit);
    }

    @EventHandler
    public void onTick(TickEvent event) {
        if (!this.isState()) {
            return;
        }
        if (HitColor.mc.field_1687 == null) {
            return;
        }
        Iterator<Map.Entry<Integer, HitInfo>> iterator2 = this.hitEntities.entrySet().iterator();
        while (iterator2.hasNext()) {
            Map.Entry<Integer, HitInfo> entry = iterator2.next();
            HitInfo info = entry.getValue();
            ++info.ticks;
            if (!((float)info.ticks >= this.durationSetting.getValue())) continue;
            iterator2.remove();
        }
    }

    @EventHandler
    public void onAttack(AttackEvent event) {
        boolean isCrit;
        if (!this.isState()) {
            return;
        }
        if (HitColor.mc.field_1724 == null || HitColor.mc.field_1687 == null) {
            return;
        }
        class_1297 target = event.getEntity();
        if (!(target instanceof class_1309)) {
            return;
        }
        boolean bl = isCrit = HitColor.mc.field_1724.field_6017 > 0.0f && !HitColor.mc.field_1724.method_24828() && !HitColor.mc.field_1724.method_6101() && !HitColor.mc.field_1724.method_5799() && !HitColor.mc.field_1724.method_5765() && !HitColor.mc.field_1724.method_5624();
        if (this.onlyCrit.isValue() && !isCrit) {
            return;
        }
        int color = isCrit ? this.critColorSetting.getColor() : this.hitColorSetting.getColor();
        this.hitEntities.put(target.method_5628(), new HitInfo(color, 0));
    }

    @EventHandler
    public void onEntityColor(EntityColorEvent event) {
        if (!this.isState()) {
            return;
        }
        if (HitColor.mc.field_1687 == null || event.getEntity() == null) {
            return;
        }
        HitInfo info = this.hitEntities.get(event.getEntity().method_5628());
        if (info != null) {
            int finalColor = info.color | 0xFF000000;
            if ((finalColor & 0xFFFFFF) == 0xFFFFFF) {
                finalColor = -65794;
            }
            event.setColor(finalColor);
            event.cancel();
        }
    }

    @Override
    public void deactivate() {
        super.deactivate();
        this.hitEntities.clear();
    }

    private static class HitInfo {
        int color;
        int ticks;

        HitInfo(int color, int ticks) {
            this.color = color;
            this.ticks = ticks;
        }
    }
}

