/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 *  net.minecraft.class_2960
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_4587$class_4665
 *  net.minecraft.class_7833
 *  org.joml.Vector4i
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.player.JumpEvent;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.geometry.Render3D;
import fun.bloody.utils.math.Counter;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Vector4i;

public class JumpCircle
extends Module {
    private final List<Circle> circles = new ArrayList<Circle>();
    private final class_2960 circleTexture = class_2960.method_60654((String)"textures/circle2.png");
    private final SliderSettings maxSize = new SliderSettings("Max Size", "\u041c\u0430\u043a\u0441\u0438\u043c\u0430\u043b\u044c\u043d\u044b\u0439 \u0440\u0430\u0437\u043c\u0435\u0440 \u043a\u0440\u0443\u0433\u0430").setValue(2.5f).range(1.0f, 3.0f);
    private final SliderSettings speed = new SliderSettings("Speed", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u0438").setValue(1000.0f).range(500.0f, 5000.0f);
    private final ColorSetting color = new ColorSetting("\u0426\u0432\u0435\u0442", "\u0426\u0432\u0435\u0442 \u043a\u0440\u0443\u0433\u0430").value(ColorAssist.getColor(225, 225, 255, 255));

    public JumpCircle() {
        super("JumpCircle", "Jump Circle", ModuleCategory.RENDER);
        this.setup(this.maxSize, this.speed, this.color);
    }

    @EventHandler
    public void onJump(JumpEvent event) {
        if (JumpCircle.mc.field_1724 == null || event.getPlayer() != JumpCircle.mc.field_1724) {
            return;
        }
        class_243 pos = new class_243(JumpCircle.mc.field_1724.method_23317(), Math.floor(JumpCircle.mc.field_1724.method_23318()) + 0.001, JumpCircle.mc.field_1724.method_23321());
        this.circles.add(new Circle(pos, new Counter()));
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        this.circles.removeIf(c -> c.timer.passedMs((long)this.speed.getValue()));
        this.renderCircles();
    }

    private void renderCircles() {
        if (this.circles.isEmpty()) {
            return;
        }
        for (Circle circle : this.circles) {
            this.renderSingleCircle(circle);
        }
    }

    private void renderSingleCircle(Circle circle) {
        float alpha;
        float maxTime;
        float lifeTime = circle.timer.getPassedTimeMs();
        float progress = Math.min(lifeTime / (maxTime = this.speed.getValue()), 1.0f);
        if (progress >= 1.0f) {
            return;
        }
        float easedProgress = this.bounceOut(progress);
        float scale = easedProgress * this.maxSize.getValue();
        float fadeInDuration = 0.15f;
        float glowStart = 0.65f;
        float fadeOutStart = 0.85f;
        if (progress < fadeInDuration) {
            alpha = progress / fadeInDuration;
        } else if (progress >= fadeOutStart) {
            float fadeOutProgress = (progress - fadeOutStart) / (1.0f - fadeOutStart);
            alpha = 1.0f - fadeOutProgress;
            if (progress > glowStart) {
                float glowProgress = (progress - glowStart) / (fadeOutStart - glowStart);
                float glowPulse = (float)(Math.sin((double)glowProgress * Math.PI * 3.0) * 0.3 + 0.3);
                alpha += glowPulse * (1.0f - fadeOutProgress);
            }
        } else if (progress > glowStart) {
            float glowProgress = (progress - glowStart) / (fadeOutStart - glowStart);
            float glowPulse = (float)(Math.sin((double)glowProgress * Math.PI * 3.0) * 0.3 + 0.3);
            alpha = 1.0f + glowPulse;
        } else {
            alpha = 1.0f;
        }
        alpha = Math.max(0.0f, Math.min(1.0f, alpha));
        int finalColor = ColorAssist.multAlpha(this.color.getColor(), alpha);
        class_4184 camera = JumpCircle.mc.method_1561().field_4686;
        class_243 cameraPos = camera.method_19326();
        class_243 circlePos = circle.pos();
        class_4587 matrixStack = new class_4587();
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
        matrixStack.method_22904(circlePos.field_1352 - cameraPos.field_1352, circlePos.field_1351 - cameraPos.field_1351, circlePos.field_1350 - cameraPos.field_1350);
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(90.0f));
        class_4587.class_4665 entry = matrixStack.method_23760();
        Vector4i colors = new Vector4i(finalColor, finalColor, finalColor, finalColor);
        Render3D.drawTexture(entry, this.circleTexture, -scale / 2.0f, -scale / 2.0f, scale, scale, colors, true);
    }

    private float bounceOut(float value) {
        float n1 = 7.5625f;
        float d1 = 2.75f;
        if (value < 1.0f / d1) {
            return n1 * value * value;
        }
        if (value < 2.0f / d1) {
            return n1 * (value -= 1.5f / d1) * value + 0.75f;
        }
        if (value < 2.5f / d1) {
            return n1 * (value -= 2.25f / d1) * value + 0.9375f;
        }
        return n1 * (value -= 2.625f / d1) * value + 0.984375f;
    }

    public record Circle(class_243 pos, Counter timer) {
    }
}

