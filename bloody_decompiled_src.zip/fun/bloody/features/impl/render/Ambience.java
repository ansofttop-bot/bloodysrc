/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.player.TickEvent;
import fun.bloody.events.render.FogEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;

public class Ambience
extends Module {
    private final SliderSettings fogDistance = new SliderSettings("\u0414\u0430\u043b\u044c\u043d\u043e\u0441\u0442\u044c \u0442\u0443\u043c\u0430\u043d\u0430", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u0434\u0430\u043b\u044c\u043d\u043e\u0441\u0442\u0438 \u0442\u0443\u043c\u0430\u043d\u0430").setValue(0.5f).range(0.0f, 1.0f);
    private final ColorSetting fogColor = new ColorSetting("\u0426\u0432\u0435\u0442 \u0442\u0443\u043c\u0430\u043d\u0430", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u0446\u0432\u0435\u0442\u0430 \u0442\u0443\u043c\u0430\u043d\u0430").setColor(-1);
    public static boolean fogEnabled = false;
    public static float fogDensity = 0.5f;
    public static int fogColorValue = -1;

    public static Ambience getInstance() {
        return Instance.get(Ambience.class);
    }

    public Ambience() {
        super("Ambience", "Ambience", ModuleCategory.RENDER);
        this.setup(this.fogDistance, this.fogColor);
    }

    @EventHandler
    public void onTick(TickEvent event) {
        fogEnabled = this.isState();
        fogDensity = this.fogDistance.getValue();
        fogColorValue = this.fogColor.getColor();
    }

    @EventHandler
    public void onFog(FogEvent event) {
        if (this.isState()) {
            event.setColor(this.fogColor.getColor());
            event.setDistance(this.fogDistance.getValue() * 1000.0f);
            event.cancel();
        }
    }

    public SliderSettings getFogDistance() {
        return this.fogDistance;
    }

    public ColorSetting getFogColor() {
        return this.fogColor;
    }
}

