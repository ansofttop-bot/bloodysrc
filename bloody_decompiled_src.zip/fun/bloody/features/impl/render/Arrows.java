/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_4587
 *  net.minecraft.class_5498
 *  net.minecraft.class_742
 *  net.minecraft.class_7833
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 */
package fun.bloody.features.impl.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.common.repository.friend.FriendUtils;
import fun.bloody.events.player.TickEvent;
import fun.bloody.events.render.DrawEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.math.calc.Calculate;
import java.util.List;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5498;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

public class Arrows
extends Module {
    private final class_2960 iconId = class_2960.method_60654((String)"textures/features/arrows/arrow.png");
    private final Animation radiusAnim = new Decelerate().setMs(150).setValue(6.0);
    private final SliderSettings radiusSetting = new SliderSettings("\u0420\u0430\u0434\u0438\u0443\u0441", "\u0420\u0430\u0434\u0438\u0443\u0441 \u0441\u0442\u0440\u0435\u043b\u043e\u043a").setValue(50.0f).range(30, 100);
    private final SliderSettings sizeSetting = new SliderSettings("\u0420\u0430\u0437\u043c\u0435\u0440", "\u0420\u0430\u0437\u043c\u0435\u0440 \u0441\u0442\u0440\u0435\u043b\u043e\u043a").setValue(10.0f).range(8, 20);

    public Arrows() {
        super("Arrows", "Arrows", ModuleCategory.RENDER);
        this.setup(this.radiusSetting, this.sizeSetting);
    }

    @EventHandler
    public void onTick(TickEvent e) {
        this.radiusAnim.setDirection(Arrows.mc.field_1724.method_5624() ? Direction.FORWARDS : Direction.BACKWARDS);
    }

    @EventHandler
    public void onDraw(DrawEvent e) {
        class_4587 matrix = e.getDrawContext().method_51448();
        List<class_742> players = Arrows.mc.field_1687.method_18456().stream().filter(p -> p != Arrows.mc.field_1724 && p.method_5805() && p.method_6032() > 0.0f).filter(p -> !this.isGhostPlayer((class_742)p)).toList();
        float middleW = (float)mc.method_22683().method_4486() / 2.0f;
        float middleH = (float)mc.method_22683().method_4502() / 2.0f;
        float posY = middleH - this.radiusSetting.getValue() - this.radiusAnim.getOutput().floatValue();
        float size = this.sizeSetting.getValue();
        if (!Arrows.mc.field_1690.field_1842 && Arrows.mc.field_1690.method_31044().equals((Object)class_5498.field_26664) && !players.isEmpty()) {
            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            RenderSystem.disableDepthTest();
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_CONSTANT_ALPHA);
            RenderSystem.setShaderTexture((int)0, (class_2960)class_2960.method_60654((String)"textures/features/arrows/arrow.png"));
            RenderSystem.setShader((class_10156)class_10142.field_53880);
            class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1575);
            players.forEach(player -> {
                int color = FriendUtils.isFriend((class_1297)player) ? ColorAssist.getFriendColor() : ColorAssist.getClientColor();
                float yaw = Arrows.getRotations((class_1297)player) - Arrows.mc.field_1724.method_36454();
                matrix.method_22903();
                matrix.method_46416(middleW, middleH, 0.0f);
                matrix.method_22907(class_7833.field_40718.rotationDegrees(yaw));
                matrix.method_46416(-middleW, -middleH, 0.0f);
                Matrix4f matrix4f = matrix.method_23760().method_23761();
                buffer.method_22918(matrix4f, middleW - size / 2.0f, posY + size, 0.0f).method_22913(0.0f, 1.0f).method_39415(ColorAssist.multAlpha(ColorAssist.multDark(color, 0.4f), 0.5f));
                buffer.method_22918(matrix4f, middleW + size / 2.0f, posY + size, 0.0f).method_22913(1.0f, 1.0f).method_39415(ColorAssist.multAlpha(ColorAssist.multDark(color, 0.4f), 0.5f));
                buffer.method_22918(matrix4f, middleW + size / 2.0f, posY, 0.0f).method_22913(1.0f, 0.0f).method_39415(color);
                buffer.method_22918(matrix4f, middleW - size / 2.0f, posY, 0.0f).method_22913(0.0f, 0.0f).method_39415(color);
                matrix.method_46416(middleW, middleH, 0.0f);
                matrix.method_22907(class_7833.field_40718.rotationDegrees(-yaw));
                matrix.method_46416(-middleW, -middleH, 0.0f);
                matrix.method_22909();
            });
            class_286.method_43433((class_9801)buffer.method_60800());
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
        }
    }

    private boolean isGhostPlayer(class_742 player) {
        if (player.method_5797() != null) {
            String name = player.method_5797().getString();
            return name != null && name.startsWith("Ghost_");
        }
        return player.getClass().getSimpleName().equals("OtherClientPlayerEntity") && player.method_36455() == -30.0f;
    }

    public static float getRotations(class_1297 entity) {
        double x = Calculate.interpolate(entity.method_23317(), entity.method_23317()) - Calculate.interpolate(Arrows.mc.field_1724.method_23317(), Arrows.mc.field_1724.method_23317());
        double z = Calculate.interpolate(entity.method_23321(), entity.method_23321()) - Calculate.interpolate(Arrows.mc.field_1724.method_23321(), Arrows.mc.field_1724.method_23321());
        return (float)(-(Math.atan2(x, z) * 57.29577951308232));
    }
}

