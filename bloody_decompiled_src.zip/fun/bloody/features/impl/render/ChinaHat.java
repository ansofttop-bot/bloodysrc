/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_1304
 *  net.minecraft.class_1309
 *  net.minecraft.class_1738
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_4587
 *  net.minecraft.class_7833
 *  net.minecraft.class_9801
 */
package fun.bloody.features.impl.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_9801;

public class ChinaHat
extends Module {
    private final ColorSetting color = new ColorSetting("Color", "Hat color").value(ColorAssist.getColor(0, 0, 0, 255));
    private final SliderSettings transparency = new SliderSettings("Transparency", "Overall hat transparency").setValue(0.5f).range(0.1f, 1.0f);

    public ChinaHat() {
        super("ChinaHat", ModuleCategory.RENDER);
        this.setup(this.color, this.transparency);
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent event) {
        if (ChinaHat.mc.field_1724 == null || ChinaHat.mc.field_1690.method_31044().method_31034()) {
            return;
        }
        class_4587 stack = event.getStack();
        float partialTicks = event.getPartialTicks();
        class_243 playerPos = ChinaHat.mc.field_1724.method_30950(partialTicks);
        float yOffset = (float)(playerPos.field_1351 + (double)this.getYOffset((class_1297)ChinaHat.mc.field_1724)) + 1.7f;
        stack.method_22903();
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA, (GlStateManager.class_4535)GlStateManager.class_4535.ONE, (GlStateManager.class_4534)GlStateManager.class_4534.ZERO);
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc((int)515);
        RenderSystem.depthMask((boolean)false);
        RenderSystem.disableCull();
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        stack.method_22904(playerPos.field_1352, (double)yOffset, playerPos.field_1350);
        stack.method_22907(class_7833.field_40716.rotationDegrees((float)(System.currentTimeMillis() % 36000L) / 100.0f));
        class_287 cone = class_289.method_1348().method_60827(class_293.class_5596.field_27381, class_290.field_1576);
        float radiusValue = 0.6f;
        float heightValue = 0.3f;
        int rgb = this.color.getColor();
        int adjustedColor = ColorAssist.multAlpha(rgb, this.transparency.getValue());
        cone.method_22918(stack.method_23760().method_23761(), 0.0f, heightValue, 0.0f).method_39415(ColorAssist.multAlpha(ColorAssist.multBright(rgb, 0.86f), this.transparency.getValue()));
        float steps = 64.0f;
        double angleStep = Math.PI * 2 / (double)steps;
        int i = 0;
        while ((float)i <= steps) {
            float x = (float)(Math.cos((double)i * angleStep) * (double)radiusValue);
            float z = (float)(Math.sin((double)i * angleStep) * (double)radiusValue);
            cone.method_22918(stack.method_23760().method_23761(), x, 0.0f, z).method_39415(adjustedColor);
            ++i;
        }
        class_286.method_43433((class_9801)cone.method_60800());
        RenderSystem.depthMask((boolean)true);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthFunc((int)513);
        stack.method_22909();
    }

    private float getYOffset(class_1297 entity) {
        class_1309 livingEntity;
        float offset = 0.15f;
        if (entity instanceof class_1309 && (livingEntity = (class_1309)entity).method_6118(class_1304.field_6169).method_7909() instanceof class_1738) {
            offset -= 0.065f;
        }
        return offset;
    }
}

