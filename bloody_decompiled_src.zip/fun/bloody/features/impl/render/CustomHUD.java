/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.render;

import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import java.awt.Color;

public class CustomHUD
extends Module {
    public final ColorSetting targetHudBackground = new ColorSetting("\u0424\u043e\u043d TargetHud", "\u0426\u0432\u0435\u0442 \u0444\u043e\u043d\u0430 TargetHud").setColor(new Color(0, 0, 0, 150).getRGB());
    public final ColorSetting watermarkBackground = new ColorSetting("\u0424\u043e\u043d Watermark", "\u0426\u0432\u0435\u0442 \u0444\u043e\u043d\u0430 Watermark").setColor(new Color(0, 0, 0, 150).getRGB());
    public final ColorSetting keyBindsBackground = new ColorSetting("\u0424\u043e\u043d KeyBinds", "\u0426\u0432\u0435\u0442 \u0444\u043e\u043d\u0430 KeyBinds").setColor(new Color(0, 0, 0, 150).getRGB());
    public final ColorSetting staffBackground = new ColorSetting("\u0424\u043e\u043d Staff", "\u0426\u0432\u0435\u0442 \u0444\u043e\u043d\u0430 Staff").setColor(new Color(0, 0, 0, 150).getRGB());
    public final ColorSetting potionsBackground = new ColorSetting("\u0424\u043e\u043d Potions", "\u0426\u0432\u0435\u0442 \u0444\u043e\u043d\u0430 Potions").setColor(new Color(0, 0, 0, 150).getRGB());
    public final ColorSetting arrayListBackground = new ColorSetting("\u0424\u043e\u043d ArrayList", "\u0426\u0432\u0435\u0442 \u0444\u043e\u043d\u0430 ArrayList").setColor(new Color(0, 0, 0, 150).getRGB());
    public final ColorSetting targetHudText = new ColorSetting("\u0422\u0435\u043a\u0441\u0442 TargetHud", "\u0426\u0432\u0435\u0442 \u0442\u0435\u043a\u0441\u0442\u0430 TargetHud").setColor(new Color(255, 255, 255, 255).getRGB());
    public final ColorSetting watermarkText = new ColorSetting("\u0422\u0435\u043a\u0441\u0442 Watermark", "\u0426\u0432\u0435\u0442 \u0442\u0435\u043a\u0441\u0442\u0430 Watermark").setColor(new Color(255, 255, 255, 255).getRGB());
    public final ColorSetting keyBindsText = new ColorSetting("\u0422\u0435\u043a\u0441\u0442 KeyBinds", "\u0426\u0432\u0435\u0442 \u0442\u0435\u043a\u0441\u0442\u0430 KeyBinds").setColor(new Color(255, 255, 255, 255).getRGB());
    public final ColorSetting staffText = new ColorSetting("\u0422\u0435\u043a\u0441\u0442 Staff", "\u0426\u0432\u0435\u0442 \u0442\u0435\u043a\u0441\u0442\u0430 Staff").setColor(new Color(255, 255, 255, 255).getRGB());
    public final ColorSetting potionsText = new ColorSetting("\u0422\u0435\u043a\u0441\u0442 Potions", "\u0426\u0432\u0435\u0442 \u0442\u0435\u043a\u0441\u0442\u0430 Potions").setColor(new Color(255, 255, 255, 255).getRGB());
    public final ColorSetting arrayListText = new ColorSetting("\u0422\u0435\u043a\u0441\u0442 ArrayList", "\u0426\u0432\u0435\u0442 \u0442\u0435\u043a\u0441\u0442\u0430 ArrayList").setColor(new Color(255, 255, 255, 255).getRGB());
    public final SliderSettings targetHudScale = new SliderSettings("\u041c\u0430\u0441\u0448\u0442\u0430\u0431 TargetHud", "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 TargetHud").range(0.5f, 2.0f).setValue(1.0f);
    public final SliderSettings watermarkScale = new SliderSettings("\u041c\u0430\u0441\u0448\u0442\u0430\u0431 Watermark", "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 Watermark").range(0.5f, 2.0f).setValue(1.0f);
    public final SliderSettings keyBindsScale = new SliderSettings("\u041c\u0430\u0441\u0448\u0442\u0430\u0431 KeyBinds", "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 KeyBinds").range(0.5f, 2.0f).setValue(1.0f);
    public final SliderSettings staffScale = new SliderSettings("\u041c\u0430\u0441\u0448\u0442\u0430\u0431 Staff", "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 Staff").range(0.5f, 2.0f).setValue(1.0f);
    public final SliderSettings potionsScale = new SliderSettings("\u041c\u0430\u0441\u0448\u0442\u0430\u0431 Potions", "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 Potions").range(0.5f, 2.0f).setValue(1.0f);
    public final SliderSettings arrayListScale = new SliderSettings("\u041c\u0430\u0441\u0448\u0442\u0430\u0431 ArrayList", "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 ArrayList").range(0.5f, 2.0f).setValue(1.0f);

    public static CustomHUD getInstance() {
        return Instance.get(CustomHUD.class);
    }

    public CustomHUD() {
        super("CustomHUD", "Custom HUD", ModuleCategory.RENDER);
        this.setup(this.targetHudBackground, this.watermarkBackground, this.keyBindsBackground, this.staffBackground, this.potionsBackground, this.arrayListBackground, this.targetHudText, this.watermarkText, this.keyBindsText, this.staffText, this.potionsText, this.arrayListText);
    }

    public Color getTargetHudBackground() {
        return new Color(this.targetHudBackground.getColor(), true);
    }

    public Color getWatermarkBackground() {
        return new Color(this.watermarkBackground.getColor(), true);
    }

    public Color getKeyBindsBackground() {
        return new Color(this.keyBindsBackground.getColor(), true);
    }

    public Color getStaffBackground() {
        return new Color(this.staffBackground.getColor(), true);
    }

    public Color getPotionsBackground() {
        return new Color(this.potionsBackground.getColor(), true);
    }

    public Color getArrayListBackground() {
        return new Color(this.arrayListBackground.getColor(), true);
    }

    public int getTargetHudTextColor() {
        return this.targetHudText.getColor();
    }

    public int getWatermarkTextColor() {
        return this.watermarkText.getColor();
    }

    public int getKeyBindsTextColor() {
        return this.keyBindsText.getColor();
    }

    public int getStaffTextColor() {
        return this.staffText.getColor();
    }

    public int getPotionsTextColor() {
        return this.potionsText.getColor();
    }

    public int getArrayListTextColor() {
        return this.arrayListText.getColor();
    }
}

