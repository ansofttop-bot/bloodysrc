/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.render.EntityColorEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;

public class SeeInvisible
extends Module {
    private final SliderSettings alphaSetting = new SliderSettings("\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c", "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c \u0438\u0433\u0440\u043e\u043a\u0430").setValue(0.5f).range(0.1f, 1.0f);

    public SeeInvisible() {
        super("SeeInvisible", "See Invisible", ModuleCategory.RENDER);
        this.setup(this.alphaSetting);
    }

    @EventHandler
    public void onEntityColor(EntityColorEvent e) {
        if (e.getEntity().method_5767()) {
            e.setColor(ColorAssist.multAlpha(e.getColor(), this.alphaSetting.getValue()));
            e.cancel();
        }
    }
}

