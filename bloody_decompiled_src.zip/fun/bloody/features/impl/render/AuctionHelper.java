/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1707
 *  net.minecraft.class_1735
 *  net.minecraft.class_2653
 *  net.minecraft.class_332
 *  net.minecraft.class_437
 *  net.minecraft.class_4587
 *  net.minecraft.class_476
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.container.HandledScreenEvent;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.features.price.PriceParser;
import fun.bloody.utils.math.script.Script;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1707;
import net.minecraft.class_1735;
import net.minecraft.class_2653;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_476;

public class AuctionHelper
extends Module {
    private final PriceParser auctionPriceParser = new PriceParser();
    private final Script script = new Script();
    private class_1735 cheapestSlot;
    private class_1735 costEffectiveSlot;
    private final int[] RED_GREEN_COLORS = new int[]{-11796661, -46261};
    private final ColorSetting cheapestItemColorSetting = new ColorSetting("\u0421\u0430\u043c\u044b\u0439 \u0434\u0435\u0448\u0435\u0432\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442", "\u0426\u0432\u0435\u0442 \u043f\u043e\u0434\u0441\u0432\u0435\u0442\u043a\u0438 \u0434\u043b\u044f \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u0430 \u0441 \u043d\u0430\u0438\u043c\u0435\u043d\u044c\u0448\u0435\u0439 \u0446\u0435\u043d\u043e\u0439.").setColor(-11796661).presets(this.RED_GREEN_COLORS);
    private final ColorSetting costEffectiveItemColorSetting = new ColorSetting("\u042d\u043a\u043e\u043d\u043e\u043c\u0438\u0447\u043d\u044b\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442", "\u0426\u0432\u0435\u0442 \u043f\u043e\u0434\u0441\u0432\u0435\u0442\u043a\u0438 \u0434\u043b\u044f \u043b\u0443\u0447\u0448\u0435\u0433\u043e \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u0430.").setColor(-46261).presets(this.RED_GREEN_COLORS);

    public AuctionHelper() {
        super("AuctionHelper", "Auction Helper", ModuleCategory.RENDER);
        this.setup(this.cheapestItemColorSetting, this.costEffectiveItemColorSetting);
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        if (e.getPacket() instanceof class_2653) {
            this.script.cleanup().addTickStep(0, () -> {
                class_437 patt0$temp = AuctionHelper.mc.field_1755;
                if (patt0$temp instanceof class_476) {
                    class_476 screen = (class_476)patt0$temp;
                    this.cheapestSlot = this.findSlotWithLowestPrice((List<class_1735>)((class_1707)screen.method_17577()).field_7761);
                    this.costEffectiveSlot = this.findSlotWithBestPricePerItem((List<class_1735>)((class_1707)screen.method_17577()).field_7761);
                }
            });
        }
    }

    @EventHandler
    public void onTick(TickEvent e) {
        this.script.update();
    }

    @EventHandler
    public void onHandledScreen(HandledScreenEvent e) {
        class_332 context = e.getDrawContext();
        class_4587 matrix = context.method_51448();
        class_437 class_4372 = AuctionHelper.mc.field_1755;
        if (class_4372 instanceof class_476) {
            class_476 screen = (class_476)class_4372;
            int offsetX = (screen.field_22789 - e.getBackgroundWidth()) / 2;
            int offsetY = (screen.field_22790 - e.getBackgroundHeight()) / 2;
            int cheapItemColor = this.getBlinkingColor(this.cheapestItemColorSetting.getColor());
            int cheapestQuantityColor = this.getBlinkingColor(this.costEffectiveItemColorSetting.getColor());
            matrix.method_22903();
            matrix.method_46416((float)offsetX, (float)offsetY, 0.0f);
            if (this.cheapestSlot != this.costEffectiveSlot) {
                this.highlightSlot(context, this.cheapestSlot, cheapItemColor);
            }
            this.highlightSlot(context, this.costEffectiveSlot, cheapestQuantityColor);
            matrix.method_22909();
        }
    }

    private int getBlinkingColor(int color) {
        float alpha = (float)Math.abs(Math.sin((double)System.currentTimeMillis() / 10.0 * Math.PI / 180.0));
        return ColorAssist.multAlpha(color, alpha);
    }

    private class_1735 findSlotWithLowestPrice(List<class_1735> slots) {
        return slots.stream().filter(this::hasValidPrice).min(Comparator.comparingInt(slot -> this.auctionPriceParser.getPrice(slot.method_7677()))).orElse(null);
    }

    private class_1735 findSlotWithBestPricePerItem(List<class_1735> slots) {
        return slots.stream().filter(this::isValidMultiItemSlot).min(Comparator.comparingInt(slot -> this.auctionPriceParser.getPrice(slot.method_7677()) / slot.method_7677().method_7947())).orElse(null);
    }

    private boolean hasValidPrice(class_1735 slot) {
        return this.auctionPriceParser.getPrice(slot.method_7677()) >= 0;
    }

    private boolean isValidMultiItemSlot(class_1735 slot) {
        return this.hasValidPrice(slot) && slot.method_7677().method_7947() > 1;
    }

    private void highlightSlot(class_332 context, class_1735 slot, int color) {
        if (slot != null) {
            rectangle.render(ShapeProperties.create(context.method_51448(), slot.field_7873, slot.field_7872, 16.0, 16.0).color(color).build());
        }
    }
}

