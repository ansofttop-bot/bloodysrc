/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_2680
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.geometry.Render3D;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_2680;

public class XRay
extends Module {
    private final Set<class_2338> orePositions = ConcurrentHashMap.newKeySet();
    private final Set<class_2248> targetBlocks = new HashSet<class_2248>();
    private long lastScanTime = 0L;
    private final MultiSelectSetting blockTypeSetting = new MultiSelectSetting("\u0411\u043b\u043e\u043a\u0438", "\u0412\u044b\u0431\u043e\u0440 \u0431\u043b\u043e\u043a\u043e\u0432 \u0434\u043b\u044f XRay").value("Diamond", "Emerald", "Iron", "Gold", "Coal", "Redstone", "Lapis", "Copper", "Ancient Debris", "Netherite", "Quartz", "Amethyst");
    private final SliderSettings radiusFinder = new SliderSettings("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u043f\u043e\u0438\u0441\u043a\u0430", "\u0414\u0438\u0430\u043f\u0430\u0437\u043e\u043d \u043f\u043e\u0438\u0441\u043a\u0430").setValue(16.0f).range(8.0f, 64.0f);
    private final SliderSettings scanDelay = new SliderSettings("\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u0441\u043a\u0430\u043d\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u044f", "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u0432 \u0441\u0435\u043a\u0443\u043d\u0434\u0430\u0445").setValue(5.0f).range(1.0f, 30.0f);

    public XRay() {
        super("XRay", ModuleCategory.RENDER);
        this.setup(this.blockTypeSetting, this.radiusFinder, this.scanDelay);
    }

    @Override
    public void activate() {
        this.updateTargetBlocks();
        this.scanWorld();
        XRay.mc.field_1769.method_3279();
    }

    @Override
    public void deactivate() {
        this.orePositions.clear();
        XRay.mc.field_1769.method_3279();
    }

    @EventHandler
    public void onRender3D(WorldRenderEvent e) {
        if (XRay.mc.field_1687 == null || XRay.mc.field_1724 == null) {
            return;
        }
        this.updateTargetBlocks();
        long currentTime = System.currentTimeMillis();
        if ((float)(currentTime - this.lastScanTime) > this.scanDelay.getValue() * 1000.0f) {
            this.scanWorld();
            this.lastScanTime = currentTime;
        }
        double maxDistance = this.radiusFinder.getValue() * this.radiusFinder.getValue();
        class_2338 playerPos = XRay.mc.field_1724.method_24515();
        int rendered = 0;
        for (class_2338 pos : this.orePositions) {
            int color;
            class_2680 state;
            if (playerPos.method_10262((class_2382)pos) > maxDistance || !this.targetBlocks.contains((state = XRay.mc.field_1687.method_8320(pos)).method_26204()) || (color = this.getColorByBlock(state.method_26204())) == -1) continue;
            Render3D.drawBox(new class_238(pos), color, 2.0f);
            ++rendered;
        }
    }

    private void updateTargetBlocks() {
        this.targetBlocks.clear();
        if (this.blockTypeSetting.isSelected("Diamond")) {
            Collections.addAll(this.targetBlocks, class_2246.field_10442, class_2246.field_29029, class_2246.field_10201);
        }
        if (this.blockTypeSetting.isSelected("Emerald")) {
            Collections.addAll(this.targetBlocks, class_2246.field_10013, class_2246.field_29220, class_2246.field_10234);
        }
        if (this.blockTypeSetting.isSelected("Iron")) {
            Collections.addAll(this.targetBlocks, class_2246.field_10212, class_2246.field_29027, class_2246.field_10085, class_2246.field_33508);
        }
        if (this.blockTypeSetting.isSelected("Gold")) {
            Collections.addAll(this.targetBlocks, class_2246.field_10571, class_2246.field_29026, class_2246.field_23077, class_2246.field_10205, class_2246.field_33510);
        }
        if (this.blockTypeSetting.isSelected("Coal")) {
            Collections.addAll(this.targetBlocks, class_2246.field_10418, class_2246.field_29219, class_2246.field_10381);
        }
        if (this.blockTypeSetting.isSelected("Redstone")) {
            Collections.addAll(this.targetBlocks, class_2246.field_10080, class_2246.field_29030, class_2246.field_10002);
        }
        if (this.blockTypeSetting.isSelected("Lapis")) {
            Collections.addAll(this.targetBlocks, class_2246.field_10090, class_2246.field_29028, class_2246.field_10441);
        }
        if (this.blockTypeSetting.isSelected("Copper")) {
            Collections.addAll(this.targetBlocks, class_2246.field_27120, class_2246.field_29221, class_2246.field_27119, class_2246.field_33509);
        }
        if (this.blockTypeSetting.isSelected("Ancient Debris")) {
            this.targetBlocks.add(class_2246.field_22109);
        }
        if (this.blockTypeSetting.isSelected("Netherite")) {
            this.targetBlocks.add(class_2246.field_22108);
        }
        if (this.blockTypeSetting.isSelected("Quartz")) {
            Collections.addAll(this.targetBlocks, class_2246.field_10213, class_2246.field_10153);
        }
        if (this.blockTypeSetting.isSelected("Amethyst")) {
            Collections.addAll(this.targetBlocks, class_2246.field_27161, class_2246.field_27162, class_2246.field_27163, class_2246.field_27164, class_2246.field_27159);
        }
    }

    private void scanWorld() {
        this.orePositions.clear();
        if (XRay.mc.field_1687 == null) {
            return;
        }
        int radius = this.radiusFinder.getInt();
        class_2338 playerPos = XRay.mc.field_1724.method_24515();
        int found = 0;
        for (int x = -radius; x <= radius; ++x) {
            for (int y = -radius; y <= radius; ++y) {
                for (int z = -radius; z <= radius; ++z) {
                    class_2680 state;
                    class_2338 pos = playerPos.method_10069(x, y, z);
                    if (!XRay.mc.field_1687.method_24794(pos) || !this.targetBlocks.contains((state = XRay.mc.field_1687.method_8320(pos)).method_26204())) continue;
                    this.orePositions.add(pos.method_10062());
                    ++found;
                }
            }
        }
    }

    private int getColorByBlock(class_2248 block) {
        if (block == class_2246.field_10442 || block == class_2246.field_29029 || block == class_2246.field_10201) {
            return -15107199;
        }
        if (block == class_2246.field_10013 || block == class_2246.field_29220 || block == class_2246.field_10234) {
            return -12482789;
        }
        if (block == class_2246.field_10212 || block == class_2246.field_29027 || block == class_2246.field_10085 || block == class_2246.field_33508) {
            return -9090017;
        }
        if (block == class_2246.field_10571 || block == class_2246.field_29026 || block == class_2246.field_23077 || block == class_2246.field_10205 || block == class_2246.field_33510) {
            return -3819208;
        }
        if (block == class_2246.field_10418 || block == class_2246.field_29219 || block == class_2246.field_10381) {
            return -15527149;
        }
        if (block == class_2246.field_10080 || block == class_2246.field_29030 || block == class_2246.field_10002) {
            return -7667712;
        }
        if (block == class_2246.field_10090 || block == class_2246.field_29028 || block == class_2246.field_10441) {
            return -15910005;
        }
        if (block == class_2246.field_27120 || block == class_2246.field_29221 || block == class_2246.field_27119 || block == class_2246.field_33509) {
            return -4954035;
        }
        if (block == class_2246.field_22109) {
            return -5868204;
        }
        if (block == class_2246.field_22108) {
            return -11776948;
        }
        if (block == class_2246.field_10213 || block == class_2246.field_10153) {
            return -1846076;
        }
        if (block == class_2246.field_27161 || block == class_2246.field_27162 || block == class_2246.field_27163 || block == class_2246.field_27164 || block == class_2246.field_27159) {
            return -6596170;
        }
        return -1;
    }
}

