/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;

public class ItemPhysic
extends Module {
    public final SelectSetting mode = new SelectSetting("\u0424\u0438\u0437\u0438\u043a\u0430", "\u0420\u0435\u0436\u0438\u043c \u0444\u0438\u0437\u0438\u043a\u0438 \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u043e\u0432").value("\u041e\u0431\u044b\u0447\u043d\u0430\u044f", "\u041f\u043b\u043e\u0441\u043a\u0430\u044f").selected("\u041f\u043b\u043e\u0441\u043a\u0430\u044f");

    public static ItemPhysic getInstance() {
        return Instance.get(ItemPhysic.class);
    }

    public ItemPhysic() {
        super("ItemPhysic", "Item Physic", ModuleCategory.RENDER);
        this.setup(this.mode);
    }

    @EventHandler
    public void onTick(TickEvent e) {
    }
}

