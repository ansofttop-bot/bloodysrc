/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.render;

import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.utils.client.Instance;

public class BetterMinecraft
extends Module {
    private final BooleanSetting betterButton = new BooleanSetting("\u041a\u0430\u0441\u0442\u043e\u043c\u043d\u044b\u0435 \u043a\u043d\u043e\u043f\u043a\u0438", "\u044f\u0437\u0430\u0438\u043f\u0430\u043b\u0441\u044f\u044d\u0442\u043e\u043f\u0430\u0441\u0442\u0438\u0442\u044c\u0441\u043f\u0430\u0441\u0438\u0442\u0435").setValue(true);
    private final BooleanSetting tabVanishButton = new BooleanSetting("\u0421\u043f\u0435\u043a\u0442\u0430\u0442\u043e\u0440\u044b \u0432 \u0442\u0430\u0431\u0435", "\u044f\u0437\u0430\u0438\u043f\u0430\u043b\u0441\u044f\u044d\u0442\u043e\u043f\u0430\u0441\u0442\u0438\u0442\u044c\u0441\u043f\u0430\u0441\u0438\u0442\u0435").setValue(true);

    public static BetterMinecraft getInstance() {
        return Instance.get(BetterMinecraft.class);
    }

    public BetterMinecraft() {
        super("BetterMinecraft", "Better Minecraft", ModuleCategory.RENDER);
        this.setup(this.betterButton, this.tabVanishButton);
    }

    public BooleanSetting getBetterButton() {
        return this.betterButton;
    }

    public BooleanSetting getTabVanishButton() {
        return this.tabVanishButton;
    }
}

