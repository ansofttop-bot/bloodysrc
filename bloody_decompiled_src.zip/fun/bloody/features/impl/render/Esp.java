/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1541
 *  net.minecraft.class_1542
 *  net.minecraft.class_1657
 *  net.minecraft.class_1747
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1887
 *  net.minecraft.class_1921
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2487
 *  net.minecraft.class_2561
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_5250
 *  net.minecraft.class_5321
 *  net.minecraft.class_5348
 *  net.minecraft.class_640
 *  net.minecraft.class_9279
 *  net.minecraft.class_9288
 *  net.minecraft.class_9334
 *  org.joml.Vector4d
 */
package fun.bloody.features.impl.render;

import fun.bloody.common.repository.friend.FriendUtils;
import fun.bloody.events.player.TickEvent;
import fun.bloody.events.render.DrawEvent;
import fun.bloody.events.render.WorldLoadEvent;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.impl.combat.AntiBot;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.client.packet.network.Network;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.geometry.Render3D;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.math.calc.Calculate;
import fun.bloody.utils.math.projection.Projection;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1541;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.class_5348;
import net.minecraft.class_640;
import net.minecraft.class_9279;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import org.joml.Vector4d;

public class Esp
extends Module {
    private final class_2960 TEXTURE = class_2960.method_60654((String)"textures/features/esp/container.png");
    private final List<class_1657> players = new ArrayList<class_1657>();
    private final Map<class_5321<class_1887>, String> encMap = new HashMap<class_5321<class_1887>, String>();
    public final MultiSelectSetting entityType = new MultiSelectSetting("\u0422\u0438\u043f \u0441\u0443\u0449\u043d\u043e\u0441\u0442\u0438", "\u0421\u0443\u0449\u043d\u043e\u0441\u0442\u0438, \u043a\u043e\u0442\u043e\u0440\u044b\u0435 \u0431\u0443\u0434\u0443\u0442 \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0442\u044c\u0441\u044f").value("Player", "Item", "TNT").selected("Player", "Item");
    public final MultiSelectSetting playerSetting = new MultiSelectSetting("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0438\u0433\u0440\u043e\u043a\u0430", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0434\u043b\u044f \u0438\u0433\u0440\u043e\u043a\u043e\u0432").value("Box", "Armor", "NameTags", "Hand Items", "Glow").selected("Box", "Armor", "NameTags", "Hand Items").visible(() -> this.entityType.isSelected("Player"));
    public final SelectSetting boxType = new SelectSetting("\u0422\u0438\u043f", "\u0422\u0438\u043f").value("Corner", "Full", "3D Box", "Skeleton").selected("3D Box").visible(() -> this.playerSetting.isSelected("Box"));
    public final BooleanSetting flatBoxOutline = new BooleanSetting("\u041a\u043e\u043d\u0442\u0443\u0440", "\u041a\u043e\u043d\u0442\u0443\u0440 \u0434\u043b\u044f \u043f\u043b\u043e\u0441\u043a\u0438\u0445 \u0431\u043e\u043a\u0441\u043e\u0432").visible(() -> this.playerSetting.isSelected("Box") && (this.boxType.isSelected("Corner") || this.boxType.isSelected("Full")));
    public final SliderSettings boxAlpha = new SliderSettings("\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c", "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c \u0431\u043e\u043a\u0441\u0430").setValue(1.0f).range(0.1f, 1.0f).visible(() -> this.boxType.isSelected("3D Box"));
    public final SliderSettings skeletonWidth = new SliderSettings("\u0422\u043e\u043b\u0449\u0438\u043d\u0430 \u043b\u0438\u043d\u0438\u0439", "\u0422\u043e\u043b\u0449\u0438\u043d\u0430 \u043b\u0438\u043d\u0438\u0439 \u0441\u043a\u0435\u043b\u0435\u0442\u0430").setValue(2.5f).range(2.5f, 4.0f).visible(() -> this.boxType.isSelected("Skeleton"));
    private static final float DISTANCE = 128.0f;

    public static Esp getInstance() {
        return Instance.get(Esp.class);
    }

    public Esp() {
        super("Esp", "Esp", ModuleCategory.RENDER);
        this.setup(this.entityType, this.playerSetting, this.boxType, this.flatBoxOutline, this.boxAlpha, this.skeletonWidth);
    }

    @Override
    public void deactivate() {
        super.deactivate();
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent e) {
        this.players.clear();
    }

    @EventHandler
    public void onTick(TickEvent e) {
        this.players.clear();
        if (Esp.mc.field_1687 != null) {
            Esp.mc.field_1687.method_18456().stream().filter(player -> player != Esp.mc.field_1724).filter(player -> player.method_5797() == null || !player.method_5797().getString().startsWith("Ghost_")).forEach(this.players::add);
        }
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        if (!this.entityType.isSelected("Player")) {
            return;
        }
        float tickDelta = mc.method_61966().method_60637(false);
        for (class_1657 player : this.players) {
            if (player == null || player == Esp.mc.field_1724 || player.method_5797() != null && player.method_5797().getString().startsWith("Ghost_")) continue;
            double interpX = class_3532.method_16436((double)tickDelta, (double)player.field_6014, (double)player.method_23317());
            double interpY = class_3532.method_16436((double)tickDelta, (double)player.field_6036, (double)player.method_23318());
            double interpZ = class_3532.method_16436((double)tickDelta, (double)player.field_5969, (double)player.method_23321());
            class_243 interpCenter = new class_243(interpX, interpY, interpZ);
            float distance = (float)Esp.mc.method_1561().field_4686.method_19326().method_1022(interpCenter);
            if (distance < 1.0f) continue;
            boolean friend = FriendUtils.isFriend((class_1297)player);
            int baseColor = friend ? ColorAssist.getFriendColor() : ColorAssist.getClientColor();
            int alpha = (int)(this.boxAlpha.getValue() * 255.0f);
            int fillColor = baseColor & 0xFFFFFF | alpha << 24;
            int outlineColor = baseColor | 0xFF000000;
            if (!this.playerSetting.isSelected("Box")) continue;
            if (this.boxType.isSelected("3D Box")) {
                class_238 interpBox = player.method_18377(player.method_18376()).method_30231(interpX, interpY, interpZ);
                Render3D.drawBox(interpBox, fillColor, 2.0f, true, true, false);
                Render3D.drawBox(interpBox, outlineColor, 2.0f, false, false, true);
                continue;
            }
            if (!this.boxType.isSelected("Skeleton") || distance > 128.0f) continue;
            this.renderSkeleton(player, tickDelta, baseColor);
        }
    }

    @EventHandler
    public void onDraw(DrawEvent e) {
        class_332 context = e.getDrawContext();
        class_4587 matrix = context.method_51448();
        FontRenderer font = Fonts.getSize(13, Fonts.Type.SEMI);
        FontRenderer bigFont = Fonts.getSize(15, Fonts.Type.SEMI);
        if (this.entityType.isSelected("Player")) {
            for (class_1657 player : this.players) {
                float textHeight;
                if (player == null || player == Esp.mc.field_1724 || player.method_5797() != null && player.method_5797().getString().startsWith("Ghost_")) continue;
                Vector4d vec4d = Projection.getVector4D((class_1297)player);
                float distance = (float)Esp.mc.method_1561().field_4686.method_19326().method_1022(player.method_5829().method_1005());
                boolean friend = FriendUtils.isFriend((class_1297)player);
                if (distance < 1.0f || Projection.cantSee(vec4d)) continue;
                if (this.playerSetting.isSelected("Box") && !this.boxType.isSelected("Skeleton")) {
                    this.drawBox(friend, vec4d, player);
                }
                if (this.playerSetting.isSelected("Armor")) {
                    this.drawArmor(context, player, vec4d, font);
                }
                if (this.playerSetting.isSelected("Hand Items")) {
                    this.drawHands(matrix, player, font, vec4d);
                }
                class_5250 text = this.getTextPlayer(player, friend);
                if (Network.isAresMine()) {
                    float height;
                    float startX = (float)Projection.centerX(vec4d);
                    float startY = (float)vec4d.y;
                    float width = Esp.mc.field_1772.method_27525((class_5348)text);
                    Objects.requireNonNull(Esp.mc.field_1772);
                    float headSize = height = 9.0f;
                    float posX = startX - (width + headSize + 2.0f) / 2.0f;
                    float posY = startY - 11.0f;
                    blur.render(ShapeProperties.create(matrix, posX - 2.0f, posY - 0.75f, width + headSize + 6.0f, height + 1.5f).quality(5.0f).round(4.0f).softness(1.0f).round(height / 4.0f).color(ColorAssist.HALF_BLACK).build());
                    class_640 playerListEntry = mc.method_1562().method_2871(player.method_5667());
                    if (playerListEntry != null) {
                        class_2960 textureLocation = playerListEntry.method_52810().comp_1626();
                        Render2D.drawTexture(context, textureLocation, posX, posY, headSize, 4.0f, 8, 8, 64, ColorAssist.getRect(1.0f), -1);
                    }
                    context.method_51439(Esp.mc.field_1772, (class_2561)text, (int)(posX + headSize + 2.0f), (int)posY + 1, ColorAssist.getColor(255), false);
                    continue;
                }
                float textWidth = font.getStringWidth((class_2561)text);
                float headSize = textHeight = (float)font.getFont().getSize() / 1.5f;
                float startX = (float)Projection.centerX(vec4d);
                float startY = (float)(vec4d.y - 2.0);
                this.drawTextWithHead(matrix, context, (class_2561)text, startX, startY, font, player);
            }
        }
        List<class_1297> entities = PlayerInteractionHelper.streamEntities().sorted(Comparator.comparing(ent -> {
            class_1542 item;
            return ent instanceof class_1542 && (item = (class_1542)ent).method_6983().method_7964().method_10851().toString().equals("empty");
        })).toList();
        for (class_1297 entity : entities) {
            Vector4d vec4d;
            if (entity instanceof class_1542) {
                class_1542 item = (class_1542)entity;
                if (this.entityType.isSelected("Item")) {
                    List<class_1799> list;
                    vec4d = Projection.getVector4D(entity);
                    class_1799 stack = item.method_6983();
                    class_9288 compoundTag = (class_9288)stack.method_57824(class_9334.field_49622);
                    List<Object> list2 = list = compoundTag != null ? compoundTag.method_57489().toList() : List.of();
                    if (Projection.cantSee(vec4d)) continue;
                    class_2561 text = item.method_6983().method_7964();
                    if (stack.method_7947() > 1) {
                        text = text.method_27661().method_27693(String.valueOf(class_124.field_1070) + " [" + String.valueOf(class_124.field_1061) + stack.method_7947() + String.valueOf(class_124.field_1080) + "x" + String.valueOf(class_124.field_1070) + "]");
                    }
                    if (!list.isEmpty()) {
                        this.drawShulkerBox(context, stack, list, vec4d);
                        continue;
                    }
                    this.drawText(matrix, text, Projection.centerX(vec4d), vec4d.y, text.method_10851().toString().equals("empty") ? bigFont : font);
                    continue;
                }
            }
            if (!(entity instanceof class_1541)) continue;
            class_1541 tnt = (class_1541)entity;
            if (!this.entityType.isSelected("TNT") || Projection.cantSee(vec4d = Projection.getVector4D(entity))) continue;
            this.drawText(matrix, tnt.method_55423(), Projection.centerX(vec4d), vec4d.y, font);
        }
    }

    private void renderSkeleton(class_1657 player, float partialTicks, int color) {
        class_243 pos = Calculate.interpolate((class_1297)player);
        float width = this.skeletonWidth.getValue();
        float limbSwing = player.field_42108.method_48572(partialTicks);
        float limbSwingAmount = player.field_42108.method_48570(partialTicks);
        float bodyYaw = class_3532.method_17821((float)partialTicks, (float)player.field_6220, (float)player.field_6283);
        float bodyYawRad = (float)Math.toRadians(-bodyYaw + 90.0f);
        boolean isSwimming = player.method_5681() || player.method_6128();
        float sneakOffset = player.method_5715() ? 0.2f : 0.0f;
        float swimOffset = isSwimming ? 0.6f : 0.0f;
        class_243 head = pos.method_1031(0.0, (double)(1.62f - sneakOffset - swimOffset), 0.0);
        class_243 neck = pos.method_1031(0.0, (double)(1.4f - sneakOffset - swimOffset), 0.0);
        class_243 body = pos.method_1031(0.0, (double)(0.9f - sneakOffset - swimOffset), 0.0);
        class_243 pelvis = pos.method_1031(0.0, (double)(0.6f - sneakOffset - swimOffset), 0.0);
        Render3D.drawLine(head, neck, color, width, false);
        Render3D.drawLine(neck, body, color, width, false);
        Render3D.drawLine(body, pelvis, color, width, false);
        float rightArmSwing = class_3532.method_15362((float)(limbSwing * 0.6662f)) * limbSwingAmount * 0.5f;
        float leftArmSwing = class_3532.method_15362((float)(limbSwing * 0.6662f + (float)Math.PI)) * limbSwingAmount * 0.5f;
        float rightLegSwing = class_3532.method_15362((float)(limbSwing * 0.6662f + (float)Math.PI)) * limbSwingAmount * 0.7f;
        float leftLegSwing = class_3532.method_15362((float)(limbSwing * 0.6662f)) * limbSwingAmount * 0.7f;
        class_243 rightShoulder = neck.method_1031(Math.sin(bodyYawRad) * 0.3, -0.1, Math.cos(bodyYawRad) * 0.3);
        class_243 rightElbow = rightShoulder.method_1031(Math.sin(bodyYawRad) * 0.05 + Math.sin((double)bodyYawRad + 1.5707963267948966) * (double)rightArmSwing * 0.15, -0.25 - (double)Math.abs(rightArmSwing) * 0.1, Math.cos(bodyYawRad) * 0.05 + Math.cos((double)bodyYawRad + 1.5707963267948966) * (double)rightArmSwing * 0.15);
        class_243 rightHand = rightElbow.method_1031(Math.sin((double)bodyYawRad + 1.5707963267948966) * (double)rightArmSwing * 0.1, -0.25 - (double)Math.abs(rightArmSwing) * 0.05, Math.cos((double)bodyYawRad + 1.5707963267948966) * (double)rightArmSwing * 0.1);
        Render3D.drawLine(rightShoulder, rightElbow, color, width, false);
        Render3D.drawLine(rightElbow, rightHand, color, width, false);
        class_243 leftShoulder = neck.method_1031(-Math.sin(bodyYawRad) * 0.3, -0.1, -Math.cos(bodyYawRad) * 0.3);
        class_243 leftElbow = leftShoulder.method_1031(-Math.sin(bodyYawRad) * 0.05 + Math.sin((double)bodyYawRad + 1.5707963267948966) * (double)leftArmSwing * 0.15, -0.25 - (double)Math.abs(leftArmSwing) * 0.1, -Math.cos(bodyYawRad) * 0.05 + Math.cos((double)bodyYawRad + 1.5707963267948966) * (double)leftArmSwing * 0.15);
        class_243 leftHand = leftElbow.method_1031(Math.sin((double)bodyYawRad + 1.5707963267948966) * (double)leftArmSwing * 0.1, -0.25 - (double)Math.abs(leftArmSwing) * 0.05, Math.cos((double)bodyYawRad + 1.5707963267948966) * (double)leftArmSwing * 0.1);
        Render3D.drawLine(leftShoulder, leftElbow, color, width, false);
        Render3D.drawLine(leftElbow, leftHand, color, width, false);
        class_243 rightHip = pelvis.method_1031(Math.sin(bodyYawRad) * 0.15, 0.0, Math.cos(bodyYawRad) * 0.15);
        class_243 rightKnee = rightHip.method_1031(Math.sin((double)bodyYawRad + 1.5707963267948966) * (double)rightLegSwing * 0.1, -0.35 + (double)Math.max(0.0f, rightLegSwing) * 0.05, Math.cos((double)bodyYawRad + 1.5707963267948966) * (double)rightLegSwing * 0.1);
        class_243 rightFoot = rightKnee.method_1031(Math.sin((double)bodyYawRad + 1.5707963267948966) * (double)rightLegSwing * 0.08, -0.35 - (double)Math.max(0.0f, -rightLegSwing) * 0.05, Math.cos((double)bodyYawRad + 1.5707963267948966) * (double)rightLegSwing * 0.08);
        Render3D.drawLine(rightHip, rightKnee, color, width, false);
        Render3D.drawLine(rightKnee, rightFoot, color, width, false);
        class_243 leftHip = pelvis.method_1031(-Math.sin(bodyYawRad) * 0.15, 0.0, -Math.cos(bodyYawRad) * 0.15);
        class_243 leftKnee = leftHip.method_1031(Math.sin((double)bodyYawRad + 1.5707963267948966) * (double)leftLegSwing * 0.1, -0.35 + (double)Math.max(0.0f, leftLegSwing) * 0.05, Math.cos((double)bodyYawRad + 1.5707963267948966) * (double)leftLegSwing * 0.1);
        class_243 leftFoot = leftKnee.method_1031(Math.sin((double)bodyYawRad + 1.5707963267948966) * (double)leftLegSwing * 0.08, -0.35 - (double)Math.max(0.0f, -leftLegSwing) * 0.05, Math.cos((double)bodyYawRad + 1.5707963267948966) * (double)leftLegSwing * 0.08);
        Render3D.drawLine(leftHip, leftKnee, color, width, false);
        Render3D.drawLine(leftKnee, leftFoot, color, width, false);
        Render3D.drawLine(rightShoulder, leftShoulder, color, width, false);
        Render3D.drawLine(rightHip, leftHip, color, width, false);
    }

    private void drawBox(boolean friend, Vector4d vec, class_1657 player) {
        if (this.boxType.isSelected("3D Box") || this.boxType.isSelected("Skeleton")) {
            return;
        }
        int client = friend ? ColorAssist.getFriendColor() : ColorAssist.getClientColor();
        int black = ColorAssist.HALF_BLACK;
        float posX = (float)vec.x;
        float posY = (float)vec.y;
        float endPosX = (float)vec.z;
        float endPosY = (float)vec.w;
        float size = (endPosX - posX) / 3.0f;
        if (this.boxType.isSelected("Corner")) {
            Render2D.drawQuad(posX - 0.5f, posY - 0.5f, size, 0.5f, client);
            Render2D.drawQuad(posX - 0.5f, posY, 0.5f, size + 0.5f, client);
            Render2D.drawQuad(posX - 0.5f, endPosY - size - 0.5f, 0.5f, size, client);
            Render2D.drawQuad(posX - 0.5f, endPosY - 0.5f, size, 0.5f, client);
            Render2D.drawQuad(endPosX - size + 1.0f, posY - 0.5f, size, 0.5f, client);
            Render2D.drawQuad(endPosX + 0.5f, posY, 0.5f, size + 0.5f, client);
            Render2D.drawQuad(endPosX + 0.5f, endPosY - size - 0.5f, 0.5f, size, client);
            Render2D.drawQuad(endPosX - size + 1.0f, endPosY - 0.5f, size, 0.5f, client);
            if (this.flatBoxOutline.isValue()) {
                Render2D.drawQuad(posX - 1.0f, posY - 1.0f, size + 1.0f, 1.5f, black);
                Render2D.drawQuad(posX - 1.0f, posY + 0.5f, 1.5f, size + 0.5f, black);
                Render2D.drawQuad(posX - 1.0f, endPosY - size - 1.0f, 1.5f, size, black);
                Render2D.drawQuad(posX - 1.0f, endPosY - 1.0f, size + 1.0f, 1.5f, black);
                Render2D.drawQuad(endPosX - size + 0.5f, posY - 1.0f, size + 1.0f, 1.5f, black);
                Render2D.drawQuad(endPosX, posY + 0.5f, 1.5f, size + 0.5f, black);
                Render2D.drawQuad(endPosX, endPosY - size - 1.0f, 1.5f, size, black);
                Render2D.drawQuad(endPosX - size + 0.5f, endPosY - 1.0f, size + 1.0f, 1.5f, black);
            }
        } else if (this.boxType.isSelected("Full")) {
            if (this.flatBoxOutline.isValue()) {
                Render2D.drawQuad(posX - 1.0f, posY - 1.0f, endPosX - posX + 2.0f, 1.5f, black);
                Render2D.drawQuad(posX - 1.0f, posY - 1.0f, 1.5f, endPosY - posY + 2.0f, black);
                Render2D.drawQuad(posX - 1.0f, endPosY - 1.0f, endPosX - posX + 2.0f, 1.5f, black);
                Render2D.drawQuad(endPosX - 0.5f, posY - 1.0f, 1.5f, endPosY - posY + 2.0f, black);
            }
            Render2D.drawQuad(posX - 0.5f, posY - 0.5f, endPosX - posX + 1.0f, 0.5f, client);
            Render2D.drawQuad(posX - 0.5f, posY - 0.5f, 0.5f, endPosY - posY + 1.0f, client);
            Render2D.drawQuad(posX - 0.5f, endPosY - 0.5f, endPosX - posX + 1.0f, 0.5f, client);
            Render2D.drawQuad(endPosX, posY - 0.5f, 0.5f, endPosY - posY + 1.0f, client);
        }
    }

    private void drawArmor(class_332 context, class_1657 player, Vector4d vec, FontRenderer font) {
        class_4587 matrix = context.method_51448();
        ArrayList items = new ArrayList();
        player.method_56675().forEach(s -> {
            if (!s.method_7960()) {
                items.add(s);
            }
        });
        float posX = (float)(Projection.centerX(vec) - (double)items.size() * 5.5);
        float posY = (float)(vec.y - 8.666666666666666 - 15.0);
        float padding = 0.5f;
        float offset = -11.0f;
        if (!items.isEmpty()) {
            matrix.method_22903();
            matrix.method_46416(posX, posY, 0.0f);
            for (class_1799 stack : items) {
                Render2D.defaultDrawStack(context, stack, offset += 11.0f, 0.0f, false, false, 0.5f);
            }
            matrix.method_22909();
        }
    }

    private void drawHands(class_4587 matrix, class_1657 player, FontRenderer font, Vector4d vec) {
        double posY = vec.w;
        for (class_1799 stack : player.method_5877()) {
            if (stack.method_7960()) continue;
            class_5250 text = class_2561.method_43473().method_10852(stack.method_7964());
            if (stack.method_7947() > 1) {
                text.method_27693(String.valueOf(class_124.field_1070) + " [" + String.valueOf(class_124.field_1061) + stack.method_7947() + String.valueOf(class_124.field_1080) + "x" + String.valueOf(class_124.field_1070) + "]");
            }
            this.drawText(matrix, (class_2561)text, Projection.centerX(vec), posY += (double)(font.getStringHeight((class_2561)text) / 2.0f + 3.0f), font);
        }
    }

    private void drawShulkerBox(class_332 context, class_1799 itemStack, List<class_1799> stacks, Vector4d vec) {
        class_4587 matrix = context.method_51448();
        int width = 176;
        int height = 67;
        int color = ColorAssist.multBright(ColorAssist.replAlpha(((class_1747)itemStack.method_7909()).method_7711().method_26403().field_16011, 1.0f), 1.0f);
        matrix.method_22903();
        matrix.method_22904(Projection.centerX(vec) - (double)width / 4.0, vec.w + 2.0, -200.0 + Math.cos(vec.x));
        matrix.method_22905(0.5f, 0.5f, 1.0f);
        context.method_25291(class_1921::method_62277, this.TEXTURE, 0, 0, 0.0f, 0.0f, width, height, width, height, color);
        int posX = 7;
        int posY = 6;
        for (class_1799 stack : stacks.stream().toList()) {
            Render2D.defaultDrawStack(context, stack, posX, posY, false, true, 1.0f);
            if ((posX += 18) < 165) continue;
            posY += 18;
            posX = 7;
        }
        matrix.method_22909();
    }

    private void drawText(class_4587 matrix, class_2561 text, double startX, double startY, FontRenderer font) {
        int paddingX = 2;
        float paddingY = 0.75f;
        float height = (float)font.getFont().getSize() / 1.5f;
        float width = font.getStringWidth(text);
        float posX = (float)(startX - (double)(width / 2.0f));
        float posY = (float)startY - height;
        rectangle.render(ShapeProperties.create(matrix, posX - (float)paddingX, posY - paddingY, width + (float)(paddingX * 2), height + paddingY * 2.0f).round(2.0f).outlineColor(new Color(33, 33, 33, 255).getRGB()).color(new Color(33, 33, 33, 255).getRGB()).build());
        font.drawText(matrix, text, posX, posY + 3.0f);
    }

    private void drawTextWithHead(class_4587 matrix, class_332 context, class_2561 text, double startX, double startY, FontRenderer font, class_1657 player) {
        int paddingX = 2;
        float paddingY = 0.75f;
        float height = (float)font.getFont().getSize() / 1.5f;
        float width = font.getStringWidth(text);
        float headSize = height;
        float totalWidth = width + headSize + 2.0f;
        float posX = (float)(startX - (double)(totalWidth / 2.0f));
        float posY = (float)startY - height;
        rectangle.render(ShapeProperties.create(matrix, posX - (float)paddingX, posY - paddingY, totalWidth + (float)(paddingX * 2), height + paddingY * 2.0f).round(2.0f).outlineColor(new Color(33, 33, 33, 255).getRGB()).color(new Color(33, 33, 33, 255).getRGB()).build());
        class_640 playerListEntry = mc.method_1562().method_2871(player.method_5667());
        if (playerListEntry != null) {
            class_2960 textureLocation = playerListEntry.method_52810().comp_1626();
            Render2D.drawTexture(context, textureLocation, posX, posY, headSize, 4.0f, 8, 8, 64, ColorAssist.getRect(1.0f), -1);
        }
        font.drawText(matrix, text, posX + headSize + 2.0f, posY + 3.0f);
    }

    private class_5250 getTextPlayer(class_1657 player, boolean friend) {
        float health = PlayerInteractionHelper.getHealth((class_1309)player);
        class_5250 text = class_2561.method_43473();
        if (friend) {
            text.method_27693("[" + String.valueOf(class_124.field_1060) + "F" + String.valueOf(class_124.field_1070) + "] ");
        }
        if (AntiBot.getInstance().isBot(player)) {
            text.method_27693("[" + String.valueOf(class_124.field_1079) + "BOT" + String.valueOf(class_124.field_1070) + "] ");
        }
        if (this.playerSetting.isSelected("NameTags")) {
            text.method_10852(player.method_5476());
            if (player.method_6079().method_7909().equals(class_1802.field_8575) || player.method_6079().method_7909().equals(class_1802.field_8288)) {
                text.method_27693(String.valueOf(class_124.field_1070) + this.getSphere(player.method_6079()));
            }
            if (health >= 0.0f && health <= player.method_6063()) {
                text.method_27693(String.valueOf(class_124.field_1070) + "[" + String.valueOf(class_124.field_1061) + PlayerInteractionHelper.getHealthString((class_1309)player) + String.valueOf(class_124.field_1070) + "]");
            }
        }
        return text;
    }

    private String getSphere(class_1799 stack) {
        class_2487 compound;
        class_9279 component = (class_9279)stack.method_57824(class_9334.field_49628);
        if (Network.isFunTime() && component != null && (compound = component.method_57461()).method_10550("tslevel") != 0) {
            return " [" + String.valueOf(class_124.field_1065) + compound.method_10558("don-item").replace("sphere-", "").toUpperCase() + String.valueOf(class_124.field_1070) + "]";
        }
        return "";
    }
}

