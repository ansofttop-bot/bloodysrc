/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_2338
 *  net.minecraft.class_2374
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_2680
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_7833
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 */
package fun.bloody.features.impl.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.events.player.TickEvent;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.interfaces.QuickImports;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

public class WorldParticles
extends Module {
    private MultiSelectSetting mode = new MultiSelectSetting("Mode", "\u0422\u0438\u043f \u0447\u0430\u0441\u0442\u0438\u0446 (\u043c\u0430\u043a\u0441 2)").value("\u0417\u0432\u0435\u0437\u0434\u044b", "\u0411\u043b\u0443\u043c", "\u0421\u0430\u043a\u0443\u0440\u0430", "\u041b\u0443\u043d\u0430", "\u0421\u043f\u0430\u0440\u043a", "\u0422\u0440\u0435\u0443\u0433\u043e\u043b\u044c\u043d\u0438\u043a", "\u041a\u0443\u0431", "\u041a\u0440\u0435\u0441\u0442", "\u041c\u043e\u043b\u043d\u0438\u044f", "\u0421\u0435\u0440\u0434\u0446\u0435", "\u0414\u043e\u043b\u043b\u0430\u0440").maxSelected(2).selected("\u0417\u0432\u0435\u0437\u0434\u044b");
    private SliderSettings count = new SliderSettings("Count", "\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u0447\u0430\u0441\u0442\u0438\u0446").setValue(100.0f).range(20, 300).visible(() -> this.mode.getSelected().size() > 0);
    private SliderSettings size = new SliderSettings("Size", "\u0420\u0430\u0437\u043c\u0435\u0440 \u0447\u0430\u0441\u0442\u0438\u0446").setValue(1.0f).range(0.1f, 6.0f).visible(() -> this.mode.getSelected().size() > 0);
    private BooleanSetting throughWalls = new BooleanSetting("ThroughWalls", "\u0412\u0438\u0434\u0438\u043c\u043e\u0441\u0442\u044c \u0441\u043a\u0432\u043e\u0437\u044c \u0441\u0442\u0435\u043d\u044b").setValue(false);
    private SelectSetting colorMode = new SelectSetting("ColorMode", "\u0420\u0435\u0436\u0438\u043c \u0446\u0432\u0435\u0442\u0430").value("Sync", "Custom").selected("Sync");
    private ColorSetting customColor = new ColorSetting("Color", "\u041a\u0430\u0441\u0442\u043e\u043c\u043d\u044b\u0439 \u0446\u0432\u0435\u0442").value(-13125670).visible(() -> this.colorMode.isSelected("Custom"));
    private SelectSetting physics = new SelectSetting("Physics", "\u0424\u0438\u0437\u0438\u043a\u0430 \u0447\u0430\u0441\u0442\u0438\u0446").value("\u041f\u0430\u0440\u0435\u043d\u0438\u0435", "\u041f\u0430\u0434\u0435\u043d\u0438\u0435").selected("\u041f\u0430\u0440\u0435\u043d\u0438\u0435").visible(() -> this.mode.getSelected().size() > 0);
    private final class_2960 STAR_TEXTURE = class_2960.method_60654((String)"textures/new_particles/star.png");
    private final class_2960 BLOOM_TEXTURE = class_2960.method_60654((String)"textures/new_particles/glow.png");
    private final class_2960 SAKURA_TEXTURE = class_2960.method_60654((String)"textures/new_particles/feather.png");
    private final class_2960 MOON_TEXTURE = class_2960.method_60654((String)"textures/new_particles/moon.png");
    private final class_2960 SPARK_TEXTURE = class_2960.method_60654((String)"textures/new_particles/spark.png");
    private final class_2960 TRIANGLE_TEXTURE = class_2960.method_60654((String)"textures/new_particles/triangle.png");
    private final class_2960 CUBE_TEXTURE = class_2960.method_60654((String)"textures/new_particles/cube.png");
    private final class_2960 MCROSS_TEXTURE = class_2960.method_60654((String)"textures/new_particles/mcross.png");
    private final class_2960 LIGHTNING_TEXTURE = class_2960.method_60654((String)"textures/new_particles/lightning.png");
    private final class_2960 HEART_TEXTURE = class_2960.method_60654((String)"textures/new_particles/heart.png");
    private final class_2960 DOLLAR_TEXTURE = class_2960.method_60654((String)"textures/new_particles/dollar.png");
    private final ArrayList<ParticleBase> particles1 = new ArrayList();
    private final ArrayList<ParticleBase> particles2 = new ArrayList();
    private final ArrayList<ParticleBase> critParticles = new ArrayList();
    private final Random random = new Random();

    public static WorldParticles getInstance() {
        return Instance.get(WorldParticles.class);
    }

    public WorldParticles() {
        super("WorldParticles", "WorldParticles", ModuleCategory.RENDER);
        this.setup(this.mode, this.count, this.size, this.throughWalls, this.colorMode, this.customColor, this.physics);
    }

    @Override
    public void deactivate() {
        super.deactivate();
        this.particles1.clear();
        this.particles2.clear();
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (WorldParticles.mc.field_1724 == null || WorldParticles.mc.field_1687 == null) {
            return;
        }
        this.particles1.removeIf(ParticleBase::tick);
        this.particles2.removeIf(ParticleBase::tick);
        List<String> selected = this.mode.getSelected();
        if (!selected.isEmpty()) {
            ParticleBase newParticle;
            int attempts;
            boolean drop = this.physics.isSelected("\u041f\u0430\u0434\u0435\u043d\u0438\u0435");
            for (attempts = 0; this.particles1.size() < this.count.getInt() && attempts < 500; ++attempts) {
                newParticle = this.createParticle(drop);
                this.particles1.add(newParticle);
            }
            if (selected.size() > 1) {
                for (attempts = 0; this.particles2.size() < this.count.getInt() && attempts < 500; ++attempts) {
                    newParticle = this.createParticle(drop);
                    this.particles2.add(newParticle);
                }
            }
        }
    }

    private ParticleBase createParticle(boolean drop) {
        return new ParticleBase((float)(WorldParticles.mc.field_1724.method_23317() + (double)this.randomFloat(-48.0f, 48.0f)), (float)(WorldParticles.mc.field_1724.method_23318() + (double)this.randomFloat(2.0f, 48.0f)), (float)(WorldParticles.mc.field_1724.method_23321() + (double)this.randomFloat(-48.0f, 48.0f)), drop ? 0.0f : this.randomFloat(-0.4f, 0.4f), drop ? this.randomFloat(-0.2f, -0.05f) : this.randomFloat(-0.1f, 0.1f), drop ? 0.0f : this.randomFloat(-0.4f, 0.4f));
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        if (WorldParticles.mc.field_1724 == null || WorldParticles.mc.field_1687 == null) {
            return;
        }
        class_4587 stack = e.getStack();
        float tickDelta = e.getPartialTicks();
        List<String> selected = this.mode.getSelected();
        if (!selected.isEmpty()) {
            if (!this.particles1.isEmpty()) {
                stack.method_22903();
                this.renderParticleList(stack, tickDelta, this.getModeTexture(selected.get(0)), this.particles1);
                stack.method_22909();
            }
            if (selected.size() > 1 && !this.particles2.isEmpty()) {
                stack.method_22903();
                this.renderParticleList(stack, tickDelta, this.getModeTexture(selected.get(1)), this.particles2);
                stack.method_22909();
            }
        }
    }

    private void renderParticleList(class_4587 stack, float tickDelta, class_2960 texture, List<ParticleBase> list) {
        RenderSystem.setShaderTexture((int)0, (class_2960)texture);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.setShader((class_10156)class_10142.field_53880);
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask((boolean)false);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        int rendered = 0;
        int maxRender = 200;
        for (ParticleBase p : list) {
            if (rendered++ >= maxRender) break;
            p.render(bufferBuilder, tickDelta);
        }
        class_286.method_43433((class_9801)bufferBuilder.method_60800());
        RenderSystem.depthMask((boolean)true);
        RenderSystem.disableDepthTest();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.disableBlend();
    }

    private boolean isParticleVisible(ParticleBase particle) {
        class_243 particlePos;
        if (WorldParticles.mc.field_1687 == null || WorldParticles.mc.field_1724 == null) {
            return true;
        }
        class_243 cameraPos = WorldParticles.mc.field_1773.method_19418().method_19326();
        class_3959 context = new class_3959(cameraPos, particlePos = new class_243((double)particle.posX, (double)particle.posY, (double)particle.posZ), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)WorldParticles.mc.field_1724);
        class_3965 result = WorldParticles.mc.field_1687.method_17742(context);
        return result.method_17783() == class_239.class_240.field_1333;
    }

    private boolean isBlockOccluding(class_243 particlePos) {
        if (WorldParticles.mc.field_1687 == null || WorldParticles.mc.field_1724 == null) {
            return false;
        }
        class_243 cameraPos = WorldParticles.mc.field_1773.method_19418().method_19326();
        class_243 direction = particlePos.method_1020(cameraPos).method_1029();
        double distance = particlePos.method_1022(cameraPos);
        double step = 0.5;
        for (double d = 0.0; d < distance; d += step) {
            class_243 checkPos = cameraPos.method_1019(direction.method_1021(d));
            class_2338 blockPos = class_2338.method_49638((class_2374)checkPos);
            if (WorldParticles.mc.field_1687.method_8320(blockPos).method_26215()) continue;
            return true;
        }
        return false;
    }

    private class_2960 getModeTexture(String modeName) {
        if (modeName.equals("\u0411\u043b\u0443\u043c")) {
            return this.BLOOM_TEXTURE;
        }
        if (modeName.equals("\u0417\u0432\u0435\u0437\u0434\u044b")) {
            return this.STAR_TEXTURE;
        }
        if (modeName.equals("\u0421\u0430\u043a\u0443\u0440\u0430")) {
            return this.SAKURA_TEXTURE;
        }
        if (modeName.equals("\u041b\u0443\u043d\u0430")) {
            return this.MOON_TEXTURE;
        }
        if (modeName.equals("\u0421\u043f\u0430\u0440\u043a")) {
            return this.SPARK_TEXTURE;
        }
        if (modeName.equals("\u0422\u0440\u0435\u0443\u0433\u043e\u043b\u044c\u043d\u0438\u043a")) {
            return this.TRIANGLE_TEXTURE;
        }
        if (modeName.equals("\u041a\u0443\u0431")) {
            return this.CUBE_TEXTURE;
        }
        if (modeName.equals("\u041a\u0440\u0435\u0441\u0442")) {
            return this.MCROSS_TEXTURE;
        }
        if (modeName.equals("\u041c\u043e\u043b\u043d\u0438\u044f")) {
            return this.LIGHTNING_TEXTURE;
        }
        if (modeName.equals("\u0421\u0435\u0440\u0434\u0446\u0435")) {
            return this.HEART_TEXTURE;
        }
        if (modeName.equals("\u0414\u043e\u043b\u043b\u0430\u0440")) {
            return this.DOLLAR_TEXTURE;
        }
        return this.STAR_TEXTURE;
    }

    private Color getParticleColor(int index) {
        if (this.colorMode.isSelected("Sync")) {
            return new Color(Hud.getInstance().colorSetting.getColor());
        }
        return new Color(this.customColor.getColor());
    }

    private float randomFloat(float min, float max) {
        return min + this.random.nextFloat() * (max - min);
    }

    private class ParticleBase {
        protected float prevposX;
        protected float prevposY;
        protected float prevposZ;
        protected float posX;
        protected float posY;
        protected float posZ;
        protected float motionX;
        protected float motionY;
        protected float motionZ;
        protected long spawnTime;
        protected long collisionTime = -1L;
        protected float alpha;
        protected float fadeAlpha = 0.0f;
        protected boolean isFadingOut = false;

        private ParticleBase(float posX, float posY, float posZ, float motionX, float motionY, float motionZ) {
            this.posX = posX;
            this.posY = posY;
            this.posZ = posZ;
            this.prevposX = posX;
            this.prevposY = posY;
            this.prevposZ = posZ;
            this.motionX = motionX;
            this.motionY = motionY;
            this.motionZ = motionZ;
            this.spawnTime = System.currentTimeMillis();
            this.alpha = 1.0f;
            this.fadeAlpha = 0.0f;
            this.isFadingOut = false;
        }

        public boolean tick() {
            if (QuickImports.mc.field_1724 == null || QuickImports.mc.field_1687 == null) {
                return true;
            }
            long currentTime = System.currentTimeMillis();
            long lifetime = currentTime - this.spawnTime;
            if (lifetime > 7000L || this.alpha <= 0.0f) {
                return true;
            }
            if (QuickImports.mc.field_1724.method_5649((double)this.posX, (double)this.posY, (double)this.posZ) > 900.0) {
                return true;
            }
            if (this.collisionTime != -1L) {
                long timeSinceCollision = currentTime - this.collisionTime;
                this.alpha = Math.max(0.0f, 1.0f - (float)timeSinceCollision / 1000.0f);
            }
            float fadeSpeedValue = 0.05f;
            if (!WorldParticles.this.throughWalls.isValue()) {
                boolean isOccluded = WorldParticles.this.isBlockOccluding(new class_243((double)this.posX, (double)this.posY, (double)this.posZ));
                if (isOccluded) {
                    if (!this.isFadingOut) {
                        this.isFadingOut = true;
                    }
                } else if (this.isFadingOut) {
                    this.isFadingOut = false;
                }
                if (this.isFadingOut) {
                    this.fadeAlpha -= fadeSpeedValue;
                    if (this.fadeAlpha < 0.0f) {
                        this.fadeAlpha = 0.0f;
                    }
                } else {
                    this.fadeAlpha += fadeSpeedValue;
                    if (this.fadeAlpha > 1.0f) {
                        this.fadeAlpha = 1.0f;
                    }
                }
            } else {
                this.fadeAlpha = 1.0f;
                this.isFadingOut = false;
            }
            this.prevposX = this.posX;
            this.prevposY = this.posY;
            this.prevposZ = this.posZ;
            class_243 newPos = new class_243((double)(this.posX + this.motionX), (double)(this.posY + this.motionY), (double)(this.posZ + this.motionZ));
            class_2338 particlePos = class_2338.method_49638((class_2374)newPos);
            class_2680 blockState = QuickImports.mc.field_1687.method_8320(particlePos);
            if (!blockState.method_26215()) {
                if (this.collisionTime == -1L) {
                    this.collisionTime = currentTime;
                }
                if (!QuickImports.mc.field_1687.method_8320(class_2338.method_49637((double)(this.posX + this.motionX), (double)this.posY, (double)this.posZ)).method_26215()) {
                    this.motionX = 0.0f;
                }
                if (!QuickImports.mc.field_1687.method_8320(class_2338.method_49637((double)this.posX, (double)(this.posY + this.motionY), (double)this.posZ)).method_26215()) {
                    this.motionY = 0.0f;
                }
                if (!QuickImports.mc.field_1687.method_8320(class_2338.method_49637((double)this.posX, (double)this.posY, (double)(this.posZ + this.motionZ))).method_26215()) {
                    this.motionZ = 0.0f;
                }
                this.posX += this.motionX;
                this.posY += this.motionY;
                this.posZ += this.motionZ;
            } else {
                this.posX += this.motionX;
                this.posY += this.motionY;
                this.posZ += this.motionZ;
            }
            this.motionX *= 0.98f;
            this.motionY *= 0.95f;
            this.motionZ *= 0.98f;
            if (WorldParticles.this.physics.isSelected("\u041f\u0430\u0434\u0435\u043d\u0438\u0435")) {
                this.motionY -= 0.001f;
            }
            return false;
        }

        public void render(class_287 bufferBuilder, float tickDelta) {
            class_4184 camera = QuickImports.mc.field_1773.method_19418();
            Color c = WorldParticles.this.getParticleColor((int)(System.currentTimeMillis() - this.spawnTime));
            class_243 pos = this.interpolatePos(this.prevposX, this.prevposY, this.prevposZ, this.posX, this.posY, this.posZ, tickDelta);
            class_4587 matrices = new class_4587();
            matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
            matrices.method_22904(pos.field_1352, pos.field_1351, pos.field_1350);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
            Matrix4f matrix = matrices.method_23760().method_23761();
            long lifetime = System.currentTimeMillis() - this.spawnTime;
            float sizeMultiplier = 1.0f - (float)lifetime / 7000.0f;
            int finalAlpha = (int)(255.0f * this.alpha * sizeMultiplier * this.fadeAlpha);
            finalAlpha = Math.max(0, Math.min(255, finalAlpha));
            int finalColor = ColorAssist.replAlpha(c.getRGB(), finalAlpha);
            float quadSize = WorldParticles.this.size.getValue() * sizeMultiplier;
            bufferBuilder.method_22918(matrix, 0.0f, -quadSize, 0.0f).method_22913(0.0f, 1.0f).method_39415(finalColor);
            bufferBuilder.method_22918(matrix, -quadSize, -quadSize, 0.0f).method_22913(1.0f, 1.0f).method_39415(finalColor);
            bufferBuilder.method_22918(matrix, -quadSize, 0.0f, 0.0f).method_22913(1.0f, 0.0f).method_39415(finalColor);
            bufferBuilder.method_22918(matrix, 0.0f, 0.0f, 0.0f).method_22913(0.0f, 0.0f).method_39415(finalColor);
        }

        private class_243 interpolatePos(float prevX, float prevY, float prevZ, float x, float y, float z, float tickDelta) {
            double ix = prevX + (x - prevX) * tickDelta;
            double iy = prevY + (y - prevY) * tickDelta;
            double iz = prevZ + (z - prevZ) * tickDelta;
            class_243 cam = QuickImports.mc.method_1561().field_4686.method_19326();
            return new class_243(ix - cam.field_1352, iy - cam.field_1351, iz - cam.field_1350);
        }
    }
}

