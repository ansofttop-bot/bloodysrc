/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_4587
 */
package fun.bloody.features.impl.render;

import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.display.shape.ShapeProperties;
import java.awt.Color;
import net.minecraft.class_4587;

public class Hud
extends Module {
    private static final String BLUR_THEME = "\u0411\u043b\u044e\u0440";
    private static final String LEGACY_BLUR_THEME = "Blur";
    public final MultiSelectSetting interfaceSettings = new MultiSelectSetting("\u042d\u043b\u0435\u043c\u0435\u043d\u0442\u044b", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u043e\u0432 \u0438\u043d\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u0430").value("Potions", "TargetHud", "PlayerInfo", "Armor", "Notifications", "Staff", "Inventory", "KeyBinds", "HotBar", "Cooldowns", "Binds", "Scoreboard", "Watermark", "ArrayList").selected("Potions", "TargetHud", "PlayerInfo", "Armor", "Notifications", "Staff", "Inventory", "KeyBinds", "HotBar", "Cooldowns", "Binds", "Scoreboard", "Watermark");
    public final SelectSetting targetHudMode = new SelectSetting("\u0420\u0435\u0436\u0438\u043c TargetHud", "\u0420\u0435\u0436\u0438\u043c \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f TargetHud").value("Default", "\u041f\u0440\u0438 \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u0438").selected("Default").visible(() -> this.interfaceSettings.isSelected("TargetHud"));
    public final MultiSelectSetting watermarkElements = new MultiSelectSetting("\u042d\u043b\u0435\u043c\u0435\u043d\u0442\u044b \u0432\u043e\u0442\u0435\u0440\u043c\u0430\u0440\u043a\u0438", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u044b \u0434\u043b\u044f \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f").value("Nickname", "Server", "FPS", "Coordinates").selected("Nickname", "Server", "FPS", "Coordinates").visible(() -> this.interfaceSettings.isSelected("Watermark"));
    public final BooleanSetting watermarkGlow = new BooleanSetting("\u0421\u0432\u0435\u0447\u0435\u043d\u0438\u0435 \u0432\u043e\u0442\u0435\u0440\u043c\u0430\u0440\u043a\u0438", "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0441\u0432\u0435\u0447\u0435\u043d\u0438\u0435 \u0432\u043e\u0442\u0435\u0440\u043c\u0430\u0440\u043a\u0438").setValue(true).visible(() -> this.interfaceSettings.isSelected("Watermark"));
    public final BooleanSetting watermarkAnimation = new BooleanSetting("\u0410\u043d\u0438\u043c\u0430\u0446\u0438\u044f \u0432\u043e\u0442\u0435\u0440\u043c\u0430\u0440\u043a\u0438", "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u044e \u0442\u0435\u043a\u0441\u0442\u0430").setValue(true).visible(() -> this.interfaceSettings.isSelected("Watermark"));
    public final BooleanSetting arrayListBackground = new BooleanSetting("\u041f\u0440\u0438\u043c\u0435\u043d\u044f\u0442\u044c \u0442\u0435\u043c\u0443 \u043a ArrayList", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u0444\u043e\u043d \u0437\u0430 ArrayList").setValue(true).visible(() -> this.interfaceSettings.isSelected("ArrayList"));
    public final BooleanSetting arrayListColors = new BooleanSetting("\u0420\u0430\u0437\u043d\u044b\u0435 \u0446\u0432\u0435\u0442\u0430 ArrayList", "\u041a\u0430\u0436\u0434\u044b\u0439 \u043c\u043e\u0434\u0443\u043b\u044c \u0440\u0430\u0437\u043d\u044b\u043c \u0446\u0432\u0435\u0442\u043e\u043c \u043f\u043e \u043a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u0438").setValue(false).visible(() -> this.interfaceSettings.isSelected("ArrayList"));
    public final MultiSelectSetting notificationSettings = new MultiSelectSetting("\u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u0443\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u0439").value("Module Switch", "Break Shield", "Auto Armor").selected("Module Switch", "Break Shield", "Auto Armor");
    public final SliderSettings moduleVolume = new SliderSettings("\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c \u043c\u043e\u0434\u0443\u043b\u0435\u0439", "\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c \u0437\u0432\u0443\u043a\u043e\u0432 \u043c\u043e\u0434\u0443\u043b\u0435\u0439").range(0.0f, 1.0f).setValue(0.5f);
    public final SelectSetting transparencySetting = new SelectSetting("\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u043f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u0438 HUD \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u043e\u0432").value("\u0411\u0435\u0437 \u043f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u0438", "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c", "\u0411\u043b\u044e\u0440").selected("\u0411\u0435\u0437 \u043f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u0438");
    public final SelectSetting backgroundColorMode = new SelectSetting("\u0426\u0432\u0435\u0442 \u0444\u043e\u043d\u0430", "\u0412\u044b\u0431\u043e\u0440 \u0446\u0432\u0435\u0442\u0430 \u0444\u043e\u043d\u0430 HUD").value("Default", "White", "\u0411\u043b\u044e\u0440").selected("Default").visible(() -> this.transparencySetting.isSelected("\u0411\u0435\u0437 \u043f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u0438"));
    public final SliderSettings blurStrength = new SliderSettings("\u0421\u0438\u043b\u0430 \u0431\u043b\u044e\u0440\u0430", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u0441\u0438\u043b\u044b \u0440\u0430\u0437\u043c\u044b\u0442\u0438\u044f HUD").range(0.1f, 1.5f).setValue(1.0f).visible(this::isBlurTheme);
    public final SelectSetting themeSetting = new SelectSetting("\u0422\u0435\u043c\u0430", "\u041f\u0440\u0438\u043c\u0435\u043d\u044f\u0442\u044c \u0442\u0435\u043c\u0443 \u0438\u0437 ClickGUI \u0438\u043b\u0438 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c \u0431\u0435\u043b\u044b\u0439 \u0446\u0432\u0435\u0442").value("\u041f\u0440\u0438\u043c\u0435\u043d\u044f\u0442\u044c \u0442\u0435\u043c\u0443", "\u041d\u0435 \u043f\u0440\u0438\u043c\u0435\u043d\u044f\u0442\u044c \u0442\u0435\u043c\u0443").selected("\u041f\u0440\u0438\u043c\u0435\u043d\u044f\u0442\u044c \u0442\u0435\u043c\u0443");
    public final ColorSetting colorSetting = new ColorSetting("\u0418\u0437\u043c\u0435\u043d\u044f\u0435\u0442 \u0446\u0432\u0435\u0442 \u043d\u0435\u043a\u043e\u0442\u043e\u0440\u044b\u0445 \u043c\u043e\u0434\u0443\u043b\u0435\u0439", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0446\u0432\u0435\u0442 \u043a\u043b\u0438\u0435\u043d\u0442\u0430").setColor(new Color(255, 101, 57, 255).getRGB()).presets(-39623, -9659651, -7569409, -59580, -16718218, -5632, -49023, -16718337, -8978685, -2817799, -37312, -16728155, -21760, -8630785, -49920);

    public static Hud getInstance() {
        return Instance.get(Hud.class);
    }

    public Hud() {
        super("Hud", ModuleCategory.RENDER);
        this.setup(this.colorSetting, this.interfaceSettings, this.targetHudMode, this.watermarkElements, this.watermarkGlow, this.watermarkAnimation, this.arrayListBackground, this.arrayListColors, this.notificationSettings, this.transparencySetting, this.backgroundColorMode, this.blurStrength);
    }

    public float getModuleVolume() {
        return this.moduleVolume.getValue();
    }

    public float getBackgroundAlpha() {
        return switch (this.transparencySetting.getSelected()) {
            case "\u0411\u0435\u0437 \u043f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u0438" -> 1.0f;
            case "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c" -> 0.3f;
            case BLUR_THEME, LEGACY_BLUR_THEME -> 1.0f;
            default -> 1.0f;
        };
    }

    public Color getBackgroundColor() {
        String mode = this.transparencySetting.getSelected();
        if (mode.equals("\u0411\u0435\u0437 \u043f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u0438")) {
            if (this.backgroundColorMode.isSelected("White")) {
                return new Color(255, 255, 255, 255);
            }
            if (this.isBlurTheme()) {
                return new Color(0, 0, 0, 25);
            }
            return new Color(0, 0, 0, 255);
        }
        if (this.isBlurMode(mode)) {
            return new Color(0, 0, 0, 25);
        }
        return new Color(0, 0, 0, 77);
    }

    public int getTextColor() {
        if (this.transparencySetting.isSelected("\u0411\u0435\u0437 \u043f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u0438") && this.backgroundColorMode.isSelected("White")) {
            return new Color(0, 0, 0, 255).getRGB();
        }
        return new Color(255, 255, 255, 255).getRGB();
    }

    public int getThemeColor() {
        if (this.themeSetting.isSelected("\u041d\u0435 \u043f\u0440\u0438\u043c\u0435\u043d\u044f\u0442\u044c \u0442\u0435\u043c\u0443")) {
            return new Color(255, 255, 255, 255).getRGB();
        }
        return this.colorSetting.getColor();
    }

    public boolean isBlurTheme() {
        return this.isBlurMode(this.transparencySetting.getSelected()) || this.transparencySetting.isSelected("\u0411\u0435\u0437 \u043f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u0438") && this.isBlurMode(this.backgroundColorMode.getSelected());
    }

    public void renderElementBlur(class_4587 matrix, float x, float y, float width, float height, float radius) {
        if (!this.isBlurTheme() || width <= 0.0f || height <= 0.0f) {
            return;
        }
        float strength = Math.max(0.1f, Math.min(1.5f, this.blurStrength.getValue()));
        float quality = 35.0f + 61.0f * strength;
        int alpha = (int)(45.0f + 95.0f * strength);
        blur.render(ShapeProperties.create(matrix, x, y, width, height).round(radius).quality(quality).softness(1.0f).color(new Color(0, 0, 0, Math.max(0, Math.min(255, alpha))).getRGB()).build());
    }

    private boolean isBlurMode(String value) {
        return BLUR_THEME.equals(value) || LEGACY_BLUR_THEME.equals(value);
    }
}

