/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.render;

import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.utils.client.Instance;

public class NoRender
extends Module {
    public final MultiSelectSetting modeSetting = new MultiSelectSetting("\u042d\u043b\u0435\u043c\u0435\u043d\u0442\u044b", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u044b \u0434\u043b\u044f \u0438\u0433\u043d\u043e\u0440\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u044f").value("Fire", "Bad Effects", "Block Overlay", "Darkness", "Damage", "Chat").selected("Fire", "Bad Effects", "Block Overlay", "Darkness", "Damage");

    public static NoRender getInstance() {
        return Instance.get(NoRender.class);
    }

    public NoRender() {
        super("NoRender", "No Render", ModuleCategory.RENDER);
        this.setup(this.modeSetting);
    }

    public boolean shouldHideVegetation() {
        return this.isState() && this.modeSetting.isSelected("Vegetation");
    }

    public boolean shouldHideWeather() {
        return this.isState();
    }

    public boolean shouldHideWitherHearts() {
        return this.isState() && this.modeSetting.isSelected("Bad Effects");
    }

    public boolean shouldHideSmoke() {
        return this.isState();
    }

    public boolean shouldHideAirBubbles() {
        return this.isState();
    }

    public boolean shouldHideBadEffects() {
        return this.isState() && this.modeSetting.isSelected("Bad Effects");
    }

    public boolean shouldHideStuckArrows() {
        return this.isState() && this.modeSetting.isSelected("Damage");
    }

    public boolean shouldHideLavaOverlay() {
        return this.isState() && this.modeSetting.isSelected("Block Overlay");
    }

    public boolean shouldHideWaterOverlay() {
        return this.isState() && this.modeSetting.isSelected("Block Overlay");
    }

    public boolean shouldHideScoreboard() {
        return this.isState();
    }

    public boolean shouldHideVignette() {
        return this.isState();
    }

    public boolean shouldHideTotem() {
        return this.isState();
    }

    public boolean shouldHideShadows() {
        return this.isState();
    }

    public boolean shouldHideFriends() {
        return this.isState();
    }

    public boolean shouldHidePlayerGlow() {
        return this.isState();
    }

    public boolean shouldHideBossbar() {
        return this.isState();
    }

    public boolean shouldHideDarkness() {
        return this.isState() && this.modeSetting.isSelected("Darkness");
    }

    public boolean shouldHideArmorStands() {
        return this.isState();
    }
}

