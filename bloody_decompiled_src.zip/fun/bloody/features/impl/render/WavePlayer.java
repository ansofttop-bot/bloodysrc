/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_4587
 *  net.minecraft.class_4587$class_4665
 *  net.minecraft.class_742
 *  net.minecraft.class_7833
 *  org.joml.Matrix4fc
 *  org.joml.Vector4f
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.player.AttackEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.geometry.Render3D;
import fun.bloody.utils.math.time.StopWatch;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import org.joml.Matrix4fc;
import org.joml.Vector4f;

public class WavePlayer
extends Module {
    private final List<Ghost> ghosts = new ArrayList<Ghost>();
    private final SliderSettings riseHeight = new SliderSettings("\u0412\u044b\u0441\u043e\u0442\u0430 \u043f\u043e\u0434\u044a\u0435\u043c\u0430", "\u0412\u044b\u0441\u043e\u0442\u0430 \u043f\u043e\u0434\u044a\u0435\u043c\u0430 \u043f\u0440\u0438\u0437\u0440\u0430\u043a\u0430").setValue(2.0f).range(0.5f, 5.0f);
    private final SliderSettings duration = new SliderSettings("\u0412\u0440\u0435\u043c\u044f \u0436\u0438\u0437\u043d\u0438", "\u0412\u0440\u0435\u043c\u044f \u0436\u0438\u0437\u043d\u0438 \u043f\u0440\u0438\u0437\u0440\u0430\u043a\u0430").setValue(2000.0f).range(500.0f, 5000.0f);
    private final ColorSetting color = new ColorSetting("\u0426\u0432\u0435\u0442", "\u0426\u0432\u0435\u0442 \u043f\u0440\u0438\u0437\u0440\u0430\u043a\u0430").value(-9659651);
    private final BooleanSetting fillSetting = new BooleanSetting("\u0417\u0430\u043b\u0438\u0432\u043a\u0430", "\u0417\u0430\u043b\u0438\u0432\u043a\u0430 \u0432\u043d\u0443\u0442\u0440\u0438 \u043f\u0440\u0438\u0437\u0440\u0430\u043a\u0430").setValue(false);
    private final ColorSetting fillColorSetting = new ColorSetting("\u0426\u0432\u0435\u0442 \u0437\u0430\u043b\u0438\u0432\u043a\u0438", "\u0426\u0432\u0435\u0442 \u0437\u0430\u043b\u0438\u0432\u043a\u0438 \u0432\u043d\u0443\u0442\u0440\u0438 \u043f\u0440\u0438\u0437\u0440\u0430\u043a\u0430").setColor(-9659651).presets(-9659651, -7569409, -23178, -33925).visible(() -> this.fillSetting.isValue());
    private final BooleanSetting onJump = new BooleanSetting("\u041f\u0440\u0438 \u043f\u0440\u044b\u0436\u043a\u0435", "\u0421\u043e\u0437\u0434\u0430\u0432\u0430\u0442\u044c \u043f\u0440\u0438 \u043f\u0440\u044b\u0436\u043a\u0435").setValue(true);
    private final BooleanSetting onWalk = new BooleanSetting("\u041f\u0440\u0438 \u0445\u043e\u0434\u044c\u0431\u0435", "\u0421\u043e\u0437\u0434\u0430\u0432\u0430\u0442\u044c \u043f\u0440\u0438 \u0445\u043e\u0434\u044c\u0431\u0435").setValue(false);
    private final SliderSettings walkInterval = new SliderSettings("\u0418\u043d\u0442\u0435\u0440\u0432\u0430\u043b \u0445\u043e\u0434\u044c\u0431\u044b", "\u0418\u043d\u0442\u0435\u0440\u0432\u0430\u043b \u0441\u043e\u0437\u0434\u0430\u043d\u0438\u044f \u043f\u0440\u0438 \u0445\u043e\u0434\u044c\u0431\u0435").setValue(800.0f).range(200.0f, 2000.0f).visible(() -> this.onWalk.isValue());
    private final BooleanSetting onHit = new BooleanSetting("\u041f\u0440\u0438 \u0443\u0434\u0430\u0440\u0435", "\u0421\u043e\u0437\u0434\u0430\u0432\u0430\u0442\u044c \u043f\u0440\u0438 \u0443\u0434\u0430\u0440\u0435").setValue(false);
    private final BooleanSetting hitboxMode = new BooleanSetting("\u0425\u0438\u0442\u0431\u043e\u043a\u0441", "\u041e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0442\u044c \u043a\u0430\u043a \u0445\u0438\u0442\u0431\u043e\u043a\u0441").setValue(true);
    private final BooleanSetting skinMode = new BooleanSetting("\u0421\u043a\u0438\u043d", "\u041e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0442\u044c \u043f\u043e\u043b\u043d\u044b\u0439 \u0441\u043a\u0438\u043d \u0438\u0433\u0440\u043e\u043a\u0430").setValue(false);
    private final SelectSetting targetMode = new SelectSetting("\u0426\u0435\u043b\u044c", "\u0423 \u043a\u043e\u0433\u043e \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0442\u044c \u043f\u0440\u0438\u0437\u0440\u0430\u043a\u043e\u0432").value("\u041e\u0431\u0430", "\u0423 \u043c\u0435\u043d\u044f", "\u0418\u0433\u0440\u043e\u043a\u043e\u0432").selected("\u041e\u0431\u0430");
    private final Map<UUID, List<Ghost>> playerGhosts = new HashMap<UUID, List<Ghost>>();
    private final Map<UUID, class_243> lastPlayerPositions = new HashMap<UUID, class_243>();
    private final Map<UUID, Long> lastPlayerGhostTimes = new HashMap<UUID, Long>();
    private final Map<UUID, Boolean> lastPlayerOnGround = new HashMap<UUID, Boolean>();
    private final Map<UUID, Double> lastPlayerVelocityY = new HashMap<UUID, Double>();
    private class_243 lastPos = null;
    private long lastGhostTime = 0L;
    private final long MIN_GHOST_INTERVAL = 100L;
    private final long MIN_OTHER_PLAYERS_INTERVAL = 500L;

    public WavePlayer() {
        super("WavePlayer", ModuleCategory.RENDER);
        this.setup(this.riseHeight, this.duration, this.color, this.fillSetting, this.fillColorSetting, this.onJump, this.onWalk, this.walkInterval, this.onHit, this.hitboxMode, this.skinMode, this.targetMode);
    }

    @Override
    public void deactivate() {
        this.playerGhosts.clear();
        this.lastPlayerPositions.clear();
        this.lastPlayerGhostTimes.clear();
        this.lastPlayerOnGround.clear();
        this.lastPlayerVelocityY.clear();
        this.lastPos = null;
        this.lastGhostTime = 0L;
        super.deactivate();
    }

    @EventHandler
    public void onAttack(AttackEvent event) {
        class_1657 target;
        class_1297 class_12972;
        if (!this.isState()) {
            return;
        }
        if (!this.onHit.isValue()) {
            return;
        }
        if (WavePlayer.mc.field_1724 == null || WavePlayer.mc.field_1687 == null) {
            return;
        }
        if (this.targetMode.isSelected("\u041e\u0431\u0430") || this.targetMode.isSelected("\u0423 \u043c\u0435\u043d\u044f")) {
            this.addGhost((class_1657)WavePlayer.mc.field_1724, WavePlayer.mc.field_1724.method_19538());
        }
        if ((this.targetMode.isSelected("\u041e\u0431\u0430") || this.targetMode.isSelected("\u0418\u0433\u0440\u043e\u043a\u043e\u0432")) && (class_12972 = event.getEntity()) instanceof class_1657 && (target = (class_1657)class_12972) != WavePlayer.mc.field_1724 && target.method_5805()) {
            this.addGhost(target, target.method_19538());
        }
    }

    @EventHandler
    public void onTick(TickEvent event) {
        if (!this.isState()) {
            return;
        }
        if (WavePlayer.mc.field_1724 == null || WavePlayer.mc.field_1687 == null) {
            return;
        }
        long currentTime = System.currentTimeMillis();
        if (this.targetMode.isSelected("\u041e\u0431\u0430") || this.targetMode.isSelected("\u0423 \u043c\u0435\u043d\u044f")) {
            this.processPlayer((class_1657)WavePlayer.mc.field_1724, currentTime);
        }
        if (this.targetMode.isSelected("\u041e\u0431\u0430") || this.targetMode.isSelected("\u0418\u0433\u0440\u043e\u043a\u043e\u0432")) {
            for (class_742 player : WavePlayer.mc.field_1687.method_18456()) {
                if (player == WavePlayer.mc.field_1724 || !player.method_5805()) continue;
                this.processPlayer((class_1657)player, currentTime);
            }
        }
    }

    private void processPlayer(class_1657 player, long currentTime) {
        long minInterval;
        UUID playerId = player.method_5667();
        class_243 currentPos = player.method_19538();
        boolean isMyPlayer = player == WavePlayer.mc.field_1724;
        class_243 lastPos = this.lastPlayerPositions.get(playerId);
        Long lastGhostTime = this.lastPlayerGhostTimes.get(playerId);
        Boolean lastOnGround = this.lastPlayerOnGround.get(playerId);
        Double lastVelY = this.lastPlayerVelocityY.get(playerId);
        if (lastGhostTime == null) {
            lastGhostTime = 0L;
        }
        if (lastOnGround == null) {
            lastOnGround = true;
        }
        if (lastVelY == null) {
            lastVelY = 0.0;
        }
        long l = minInterval = isMyPlayer ? 100L : 500L;
        if (currentTime - lastGhostTime < minInterval) {
            this.updatePlayerState(playerId, currentPos, player);
            return;
        }
        boolean shouldCreateGhost = false;
        double currentVelY = player.method_18798().field_1351;
        boolean currentOnGround = player.method_24828();
        if (this.onJump.isValue()) {
            if (isMyPlayer) {
                if (currentVelY > 0.1 && currentOnGround) {
                    shouldCreateGhost = true;
                }
            } else if (currentVelY > 0.2 && !lastOnGround.booleanValue() && currentOnGround && Math.abs(currentVelY - lastVelY) > 0.15) {
                shouldCreateGhost = true;
            }
        }
        if (this.onWalk.isValue() && lastPos != null) {
            double distance = currentPos.method_1022(lastPos);
            long walkIntervalValue = (long)this.walkInterval.getValue();
            if (isMyPlayer) {
                if (distance > 0.1 && currentTime - lastGhostTime >= walkIntervalValue) {
                    shouldCreateGhost = true;
                }
            } else if (distance > 0.3 && currentTime - lastGhostTime >= Math.max(walkIntervalValue, 1000L)) {
                shouldCreateGhost = true;
            }
        }
        if (shouldCreateGhost) {
            this.addGhost(player, currentPos);
            this.lastPlayerGhostTimes.put(playerId, currentTime);
        }
        this.updatePlayerState(playerId, currentPos, player);
    }

    private void updatePlayerState(UUID playerId, class_243 currentPos, class_1657 player) {
        this.lastPlayerPositions.put(playerId, currentPos);
        this.lastPlayerOnGround.put(playerId, player.method_24828());
        this.lastPlayerVelocityY.put(playerId, player.method_18798().field_1351);
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        if (!this.isState()) {
            return;
        }
        for (List<Ghost> ghosts : this.playerGhosts.values()) {
            ghosts.removeIf(g -> g.timer.elapsedTime() >= (long)this.duration.getValue());
        }
        this.renderAllGhosts();
    }

    private void addGhost(class_1657 player, class_243 pos) {
        if (player == null) {
            return;
        }
        UUID playerId = player.method_5667();
        List ghosts = this.playerGhosts.computeIfAbsent(playerId, k -> new ArrayList());
        if (ghosts.size() >= 10) {
            ghosts.remove(0);
        }
        float bodyYaw = player.method_43078();
        float headYaw = player.method_5791();
        float pitch = player.method_36455();
        boolean sneaking = player.method_5715();
        ghosts.add(new Ghost(pos, new StopWatch(), bodyYaw, headYaw, pitch, sneaking));
    }

    private void renderAllGhosts() {
        if (this.playerGhosts.isEmpty()) {
            return;
        }
        for (List<Ghost> ghosts : this.playerGhosts.values()) {
            for (Ghost ghost : ghosts) {
                this.renderSingleGhost(ghost);
            }
        }
    }

    private void renderSingleGhost(Ghost ghost) {
        float maxTime;
        float lifeTime = ghost.timer.elapsedTime();
        float progress = Math.min(lifeTime / (maxTime = this.duration.getValue()), 1.0f);
        if (progress >= 1.0f) {
            return;
        }
        float yOffset = progress * this.riseHeight.getValue();
        float alpha = 1.0f - progress;
        alpha = Math.max(0.0f, Math.min(1.0f, alpha));
        class_243 ghostPos = ghost.pos().method_1031(0.0, (double)yOffset, 0.0);
        int ghostColor = this.color.getColor();
        int finalColor = ColorAssist.setAlpha(ghostColor, (int)(alpha * 255.0f));
        if (this.hitboxMode.isValue()) {
            class_238 playerBox = new class_238(ghostPos.field_1352 - 0.3, ghostPos.field_1351, ghostPos.field_1350 - 0.3, ghostPos.field_1352 + 0.3, ghostPos.field_1351 + 1.8, ghostPos.field_1350 + 0.3);
            boolean fill = this.fillSetting.isValue();
            if (fill) {
                int fillColor = this.fillColorSetting.getColor();
                fillColor = ColorAssist.setAlpha(fillColor, 255);
                Render3D.drawBox(playerBox, fillColor, 1.5f, false, true, false);
            }
            Render3D.drawBox(playerBox, finalColor, 1.5f, true, false, false);
        }
        if (this.skinMode.isValue()) {
            this.renderSimplePlayerShape(ghostPos, finalColor, ghost.sneaking, ghost.bodyYaw, ghost.headYaw, ghost.pitch);
        }
    }

    private void renderSimplePlayerShape(class_243 ghostPos, int color, boolean sneaking, float bodyYaw, float headYaw, float pitch) {
        float relativeHeadYaw;
        double x = ghostPos.field_1352;
        double y = ghostPos.field_1351;
        double z = ghostPos.field_1350;
        double sneakOffset = sneaking ? 0.15 : 0.0;
        class_4587 matrices = new class_4587();
        matrices.method_22904(x, y, z);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(180.0f - bodyYaw));
        if (sneaking) {
            matrices.method_22907(class_7833.field_40714.rotationDegrees(28.0f));
        }
        boolean fill = this.fillSetting.isValue();
        int fillColor = this.fillColorSetting.getColor();
        fillColor = ColorAssist.setAlpha(fillColor, 255);
        class_243 bodyPos = this.getTransformedPosition(matrices, 0.0, 1.125 - sneakOffset, 0.0);
        class_238 body = new class_238(bodyPos.field_1352 - 0.25, bodyPos.field_1351 - 0.375, bodyPos.field_1350 - 0.125, bodyPos.field_1352 + 0.25, bodyPos.field_1351 + 0.375, bodyPos.field_1350 + 0.125);
        if (fill) {
            Render3D.drawBox(body, fillColor, 1.0f, false, true, false);
        }
        Render3D.drawBox(body, color, 1.0f, true, false, false);
        matrices.method_22903();
        matrices.method_22904(0.0, 1.75 - sneakOffset, 0.0);
        for (relativeHeadYaw = headYaw - bodyYaw; relativeHeadYaw > 180.0f; relativeHeadYaw -= 360.0f) {
        }
        while (relativeHeadYaw < -180.0f) {
            relativeHeadYaw += 360.0f;
        }
        relativeHeadYaw = Math.max(-75.0f, Math.min(75.0f, relativeHeadYaw));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(relativeHeadYaw));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(pitch));
        class_243 headPos = this.getTransformedPosition(matrices, 0.0, 0.0, 0.0);
        class_238 head = new class_238(headPos.field_1352 - 0.25, headPos.field_1351 - 0.25, headPos.field_1350 - 0.25, headPos.field_1352 + 0.25, headPos.field_1351 + 0.25, headPos.field_1350 + 0.25);
        if (fill) {
            Render3D.drawBox(head, fillColor, 1.0f, false, true, false);
        }
        Render3D.drawBox(head, color, 1.0f, true, false, false);
        matrices.method_22909();
        class_243 rightArmPos = this.getTransformedPosition(matrices, -0.375, 1.125 - sneakOffset, 0.0);
        class_238 rightArm = new class_238(rightArmPos.field_1352 - 0.125, rightArmPos.field_1351 - 0.375, rightArmPos.field_1350 - 0.125, rightArmPos.field_1352 + 0.125, rightArmPos.field_1351 + 0.375, rightArmPos.field_1350 + 0.125);
        if (fill) {
            Render3D.drawBox(rightArm, fillColor, 1.0f, false, true, false);
        }
        Render3D.drawBox(rightArm, color, 1.0f, true, false, false);
        class_243 leftArmPos = this.getTransformedPosition(matrices, 0.375, 1.125 - sneakOffset, 0.0);
        class_238 leftArm = new class_238(leftArmPos.field_1352 - 0.125, leftArmPos.field_1351 - 0.375, leftArmPos.field_1350 - 0.125, leftArmPos.field_1352 + 0.125, leftArmPos.field_1351 + 0.375, leftArmPos.field_1350 + 0.125);
        if (fill) {
            Render3D.drawBox(leftArm, fillColor, 1.0f, false, true, false);
        }
        Render3D.drawBox(leftArm, color, 1.0f, true, false, false);
        class_243 rightLegPos = this.getTransformedPosition(matrices, -0.125, 0.375 - sneakOffset, 0.0);
        class_238 rightLeg = new class_238(rightLegPos.field_1352 - 0.125, rightLegPos.field_1351 - 0.375, rightLegPos.field_1350 - 0.125, rightLegPos.field_1352 + 0.125, rightLegPos.field_1351 + 0.375, rightLegPos.field_1350 + 0.125);
        if (fill) {
            Render3D.drawBox(rightLeg, fillColor, 1.0f, false, true, false);
        }
        Render3D.drawBox(rightLeg, color, 1.0f, true, false, false);
        class_243 leftLegPos = this.getTransformedPosition(matrices, 0.125, 0.375 - sneakOffset, 0.0);
        class_238 leftLeg = new class_238(leftLegPos.field_1352 - 0.125, leftLegPos.field_1351 - 0.375, leftLegPos.field_1350 - 0.125, leftLegPos.field_1352 + 0.125, leftLegPos.field_1351 + 0.375, leftLegPos.field_1350 + 0.125);
        if (fill) {
            Render3D.drawBox(leftLeg, fillColor, 1.0f, false, true, false);
        }
        Render3D.drawBox(leftLeg, color, 1.0f, true, false, false);
    }

    private class_243 getTransformedPosition(class_4587 matrices, double x, double y, double z) {
        class_4587.class_4665 entry = matrices.method_23760();
        Vector4f vec = new Vector4f((float)x, (float)y, (float)z, 1.0f);
        vec.mul((Matrix4fc)entry.method_23761());
        return new class_243((double)vec.x, (double)vec.y, (double)vec.z);
    }

    public record Ghost(class_243 pos, StopWatch timer, float bodyYaw, float headYaw, float pitch, boolean sneaking) {
    }
}

