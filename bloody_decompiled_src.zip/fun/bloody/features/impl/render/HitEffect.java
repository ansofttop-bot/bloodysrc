/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1922
 *  net.minecraft.class_2338
 *  net.minecraft.class_265
 *  net.minecraft.class_2680
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.geometry.Render3D;
import fun.bloody.utils.display.interfaces.QuickImports;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;

public class HitEffect
extends Module {
    private final List<WaveEffect> waveEffects = new ArrayList<WaveEffect>();

    public static HitEffect getInstance() {
        return Instance.get(HitEffect.class);
    }

    public HitEffect() {
        super("HitEffect", "Hit Effect", ModuleCategory.RENDER);
    }

    public void addWave(class_2338 pos) {
        if (HitEffect.mc.field_1687 != null) {
            this.waveEffects.add(new WaveEffect(this, pos, System.currentTimeMillis()));
        }
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        if (this.waveEffects.isEmpty() || HitEffect.mc.field_1687 == null) {
            return;
        }
        Iterator<WaveEffect> iterator2 = this.waveEffects.iterator();
        while (iterator2.hasNext()) {
            WaveEffect wave = iterator2.next();
            if (wave.isExpired()) {
                iterator2.remove();
                continue;
            }
            wave.render();
        }
    }

    private class WaveEffect {
        private final class_2338 centerPos;
        private final long startTime;
        private final long duration = 2000L;
        private final int maxRadius = 15;

        public WaveEffect(HitEffect hitEffect, class_2338 centerPos, long startTime) {
            this.centerPos = centerPos;
            this.startTime = startTime;
        }

        public boolean isExpired() {
            return System.currentTimeMillis() - this.startTime > 2000L;
        }

        public void render() {
            if (QuickImports.mc.field_1687 == null) {
                return;
            }
            long elapsed = System.currentTimeMillis() - this.startTime;
            float progress = (float)elapsed / 2000.0f;
            float currentRadius = progress * 15.0f;
            float waveWidth = 3.0f;
            float globalAlpha = 1.0f - progress;
            globalAlpha = (float)Math.pow(globalAlpha, 0.5);
            int rendered = 0;
            int maxPerFrame = 350;
            for (int x = -15; x <= 15; ++x) {
                for (int z = -15; z <= 15; ++z) {
                    class_265 shape;
                    class_2680 state;
                    class_2338 checkPos;
                    class_2338 renderPos;
                    if (rendered >= maxPerFrame) {
                        return;
                    }
                    double distance = Math.sqrt(x * x + z * z);
                    if (distance < (double)(currentRadius - waveWidth) || distance > (double)currentRadius + 0.5 || (renderPos = this.findBlock(checkPos = this.centerPos.method_10069(x, 0, z))) == null || (state = QuickImports.mc.field_1687.method_8320(renderPos)).method_26215() || (shape = state.method_26218((class_1922)QuickImports.mc.field_1687, renderPos)).method_1110()) continue;
                    ++rendered;
                    float localAlpha = 1.0f - (float)Math.abs(distance - (double)currentRadius) / waveWidth;
                    localAlpha = Math.max(0.0f, Math.min(1.0f, localAlpha));
                    if (!((localAlpha *= globalAlpha) > 0.02f)) continue;
                    int baseColor = ColorAssist.getClientColor();
                    int color = ColorAssist.setAlpha(baseColor, (int)(localAlpha * 255.0f));
                    float heightWave = (float)(Math.sin(distance * 0.35 - (double)progress * Math.PI * 2.8) * 0.7 + 0.7);
                    int heightOffset = Math.max(0, (int)((heightWave *= globalAlpha) * 3.0f));
                    float lineWidth = 2.2f + (1.0f - localAlpha) * 2.5f;
                    try {
                        Render3D.drawShapeAlternative(renderPos.method_10086(heightOffset), shape, color, lineWidth, true, true);
                        continue;
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
            }
        }

        private class_2338 findBlock(class_2338 start) {
            if (!QuickImports.mc.field_1687.method_24794(start)) {
                return null;
            }
            class_2680 state = QuickImports.mc.field_1687.method_8320(start);
            if (!state.method_26215()) {
                return start;
            }
            for (int y = 1; y <= 10; ++y) {
                class_2680 upState;
                class_2680 downState;
                class_2338 down = start.method_10087(y);
                if (QuickImports.mc.field_1687.method_24794(down) && !(downState = QuickImports.mc.field_1687.method_8320(down)).method_26215()) {
                    return down;
                }
                class_2338 up = start.method_10086(y);
                if (!QuickImports.mc.field_1687.method_24794(up) || (upState = QuickImports.mc.field_1687.method_8320(up)).method_26215()) continue;
                return up;
            }
            return null;
        }
    }
}

