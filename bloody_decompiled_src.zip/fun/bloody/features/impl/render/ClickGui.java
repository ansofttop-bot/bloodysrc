/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.render;

import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.SelectSetting;

public class ClickGui
extends Module {
    public static final String THEME_TRANSPARENT = "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u0430\u044f";
    public static final String THEME_WHITE = "\u0411\u0435\u043b\u0430\u044f";
    public static final String THEME_BLACK = "\u0427\u0435\u0440\u043d\u0430\u044f";
    public static final String THEME_RASPBERRY = "\u041c\u0430\u043b\u0438\u043d\u043e\u0432\u0430\u044f";
    public static final String THEME_GRASS = "\u0422\u0440\u0430\u0432\u0430";
    public static final String THEME_OCEAN = "\u041e\u043a\u0435\u0430\u043d";
    public static final String THEME_AMETHYST = "\u0410\u043c\u0435\u0442\u0438\u0441\u0442";
    public static final String THEME_SAKURA = "\u0421\u0430\u043a\u0443\u0440\u0430";
    public static final String THEME_NEON = "\u041d\u0435\u043e\u043d";
    public static final String THEME_GOLD = "\u0417\u043e\u043b\u043e\u0442\u043e";
    public static final String THEME_ICE = "\u041b\u0435\u0434";
    public static final String THEME_COSMOS = "\u041a\u043e\u0441\u043c\u043e\u0441";
    public SelectSetting themeSetting = new SelectSetting("\u0422\u0435\u043c\u0430", "\u0412\u044b\u0431\u043e\u0440 \u0442\u0435\u043c\u044b ClickGUI").value("\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u0430\u044f", "\u0411\u0435\u043b\u0430\u044f", "\u0427\u0435\u0440\u043d\u0430\u044f", "\u041c\u0430\u043b\u0438\u043d\u043e\u0432\u0430\u044f", "\u0422\u0440\u0430\u0432\u0430", "\u041e\u043a\u0435\u0430\u043d", "\u0410\u043c\u0435\u0442\u0438\u0441\u0442", "\u0421\u0430\u043a\u0443\u0440\u0430", "\u041d\u0435\u043e\u043d", "\u0417\u043e\u043b\u043e\u0442\u043e", "\u041b\u0435\u0434", "\u041a\u043e\u0441\u043c\u043e\u0441").selected("\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u0430\u044f");

    public ClickGui() {
        super("ClickGui", ModuleCategory.RENDER);
        this.setKey(260);
        this.setup(this.themeSetting);
    }

    public String getTheme() {
        return this.themeSetting.getSelected();
    }

    public boolean isTransparent() {
        return this.themeSetting.isSelected(THEME_TRANSPARENT);
    }

    public boolean isWhite() {
        return this.themeSetting.isSelected(THEME_WHITE);
    }

    public boolean isBlack() {
        return this.themeSetting.isSelected(THEME_BLACK);
    }

    public boolean isRaspberry() {
        return this.themeSetting.isSelected(THEME_RASPBERRY);
    }

    public boolean isGrass() {
        return this.themeSetting.isSelected(THEME_GRASS);
    }

    public boolean isOcean() {
        return this.themeSetting.isSelected(THEME_OCEAN);
    }

    public boolean isAmethyst() {
        return this.themeSetting.isSelected(THEME_AMETHYST);
    }

    public boolean isSakura() {
        return this.themeSetting.isSelected(THEME_SAKURA);
    }

    public boolean isNeon() {
        return this.themeSetting.isSelected(THEME_NEON);
    }

    public boolean isGold() {
        return this.themeSetting.isSelected(THEME_GOLD);
    }

    public boolean isIce() {
        return this.themeSetting.isSelected(THEME_ICE);
    }

    public boolean isCosmos() {
        return this.themeSetting.isSelected(THEME_COSMOS);
    }

    public boolean isColorTheme() {
        return this.isRaspberry() || this.isGrass() || this.isOcean() || this.isAmethyst() || this.isSakura() || this.isNeon() || this.isGold() || this.isIce() || this.isCosmos();
    }

    public int getAccentColor() {
        return switch (this.getTheme()) {
            case THEME_RASPBERRY -> -50297;
            case THEME_GRASS -> -11151765;
            case THEME_OCEAN -> -12404737;
            case THEME_AMETHYST -> -5870593;
            case THEME_SAKURA -> -34120;
            case THEME_NEON -> -16714284;
            case THEME_GOLD -> -14249;
            case THEME_ICE -> -7607809;
            case THEME_COSMOS -> -7643905;
            case THEME_WHITE -> -11572993;
            case THEME_BLACK -> -8418049;
            default -> -12163896;
        };
    }

    public int getAccentColor(int alpha) {
        return ClickGui.withAlpha(this.getAccentColor(), alpha);
    }

    public int getPanelColor() {
        return switch (this.getTheme()) {
            case THEME_RASPBERRY -> -14413799;
            case THEME_GRASS -> -15720428;
            case THEME_OCEAN -> -15917784;
            case THEME_AMETHYST -> -15265498;
            case THEME_SAKURA -> -14413029;
            case THEME_NEON -> -16310757;
            case THEME_GOLD -> -14410738;
            case THEME_ICE -> -15852252;
            case THEME_COSMOS -> -15921116;
            case THEME_WHITE -> -1;
            case THEME_BLACK -> -16777216;
            default -> -1275068416;
        };
    }

    public int getPanelColor(int alpha) {
        return ClickGui.withAlpha(this.getPanelColor(), alpha);
    }

    public int getOutlineColor() {
        return switch (this.getTheme()) {
            case THEME_RASPBERRY -> -38237;
            case THEME_GRASS -> -8591223;
            case THEME_OCEAN -> -9385217;
            case THEME_AMETHYST -> -3892481;
            case THEME_SAKURA -> -23607;
            case THEME_NEON -> -10158103;
            case THEME_GOLD -> -9606;
            case THEME_ICE -> -3672321;
            case THEME_COSMOS -> -4875009;
            case THEME_WHITE -> -3618616;
            case THEME_BLACK -> -13487566;
            default -> 1414681757;
        };
    }

    public int getOutlineColor(int alpha) {
        return ClickGui.withAlpha(this.getOutlineColor(), alpha);
    }

    public int getTextColor() {
        return this.isWhite() ? -16777216 : -1;
    }

    public int getInactiveTextColor() {
        return this.isWhite() ? -11513776 : -2828575;
    }

    public int getModuleColor(boolean enabled, float progress) {
        if (this.isTransparent()) {
            int r = (int)(82.0f + -12.0f * progress);
            int g = (int)(84.0f + 16.0f * progress);
            int b = (int)(157.0f + 43.0f * progress);
            int a = (int)(26.0f + 14.0f * progress);
            return ClickGui.rgba(r, g, b, a);
        }
        if (this.isWhite()) {
            return -1;
        }
        if (this.isBlack()) {
            return -16777216;
        }
        return ClickGui.mix(this.getPanelColor(), this.getAccentColor(), enabled ? 0.34f + progress * 0.18f : 0.1f);
    }

    public int getModuleOutlineColor(boolean enabled) {
        if (this.isTransparent()) {
            return -1761607681;
        }
        if (this.isWhite()) {
            return -3618616;
        }
        if (this.isBlack()) {
            return -13487566;
        }
        return enabled ? this.getAccentColor(230) : this.getOutlineColor(165);
    }

    public int getControlOffColor() {
        if (this.isTransparent()) {
            return 525489309;
        }
        if (this.isWhite()) {
            return -1183753;
        }
        if (this.isBlack()) {
            return -14803421;
        }
        return ClickGui.mix(this.getPanelColor(), this.getAccentColor(), 0.16f);
    }

    public int getControlOnColor() {
        if (this.isTransparent()) {
            return -1270455096;
        }
        if (this.isWhite()) {
            return -11572993;
        }
        if (this.isBlack()) {
            return -8418049;
        }
        return this.getAccentColor(225);
    }

    public int getControlOutlineColor(boolean hovered) {
        if (this.isTransparent()) {
            return hovered ? -922746881 : -1774766281;
        }
        if (this.isWhite()) {
            return hovered ? -9799425 : -3551523;
        }
        if (this.isBlack()) {
            return hovered ? -1972993 : -12237493;
        }
        return hovered ? this.getAccentColor(235) : this.getOutlineColor(175);
    }

    public int getCheckColor(int alpha) {
        return ClickGui.withAlpha(this.isWhite() ? -16777216 : -1, alpha);
    }

    private static int withAlpha(int color, int alpha) {
        int clampedAlpha = Math.max(0, Math.min(255, alpha));
        return clampedAlpha << 24 | color & 0xFFFFFF;
    }

    private static int rgba(int r, int g, int b, int a) {
        return a << 24 | r << 16 | g << 8 | b;
    }

    private static int mix(int colorA, int colorB, float progress) {
        float clampedProgress = Math.max(0.0f, Math.min(1.0f, progress));
        int r1 = colorA >> 16 & 0xFF;
        int g1 = colorA >> 8 & 0xFF;
        int b1 = colorA & 0xFF;
        int r2 = colorB >> 16 & 0xFF;
        int g2 = colorB >> 8 & 0xFF;
        int b2 = colorB & 0xFF;
        int r = (int)((float)r1 + (float)(r2 - r1) * clampedProgress);
        int g = (int)((float)g1 + (float)(g2 - g1) * clampedProgress);
        int b = (int)((float)b1 + (float)(b2 - b1) * clampedProgress);
        return ClickGui.rgba(r, g, b, 255);
    }
}

