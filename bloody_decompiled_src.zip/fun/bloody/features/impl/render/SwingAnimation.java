/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1306
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_7833
 */
package fun.bloody.features.impl.render;

import fun.bloody.events.item.HandAnimationEvent;
import fun.bloody.events.item.SwingDurationEvent;
import fun.bloody.features.impl.combat.AimAssist;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public class SwingAnimation
extends Module {
    private final SelectSetting swingType = new SelectSetting("\u0422\u0438\u043f \u0432\u0437\u043c\u0430\u0445\u0430", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0442\u0438\u043f \u0432\u0437\u043c\u0430\u0445\u0430").value("Default", "Swipe", "Down", "Smooth", "Smooth 2", "Power", "Feast", "Twist", "Self", "Self 2", "Forward", "Touch", "BlockHit", "Pander", "Curt");
    private final SliderSettings hitStrengthSetting = new SliderSettings("\u0421\u0438\u043b\u0430 \u0432\u0437\u043c\u0430\u0445\u0430", "\u0421\u0438\u043b\u0430 \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u0438 \u0432\u0437\u043c\u0430\u0445\u0430").setValue(1.0f).range(0.5f, 3.0f);
    private final SliderSettings swingSpeedSetting = new SliderSettings("\u0414\u043b\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u044c \u0432\u0437\u043c\u0430\u0445\u0430", "\u0414\u043b\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u044c \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u0438 \u0443\u0434\u0430\u0440\u0430").setValue(1.0f).range(0.5f, 4.0f);
    private final BooleanSetting onlySwing = new BooleanSetting("\u0422\u043e\u043b\u044c\u043a\u043e \u043f\u0440\u0438 \u0432\u0437\u043c\u0430\u0445\u0435", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u044e \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u0440\u0438 \u0432\u0437\u043c\u0430\u0445\u0435").setValue(false);
    private final BooleanSetting onlyAimbot = new BooleanSetting("\u0420\u0430\u0431\u043e\u0442\u0430\u0442\u044c \u0442\u043e\u043b\u044c\u043a\u043e \u0441 Aimbot", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u044e \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u0440\u0438 \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u043d\u043e\u043c Aimbot").setValue(false);
    private float spinAngle = 0.0f;
    private float spinBackTimer = 0.0f;
    private boolean wasSwinging = false;

    public SwingAnimation() {
        super("SwingAnimation", "Swing Animation", ModuleCategory.RENDER);
        this.setup(this.swingType, this.hitStrengthSetting, this.swingSpeedSetting, this.onlySwing, this.onlyAimbot);
    }

    @EventHandler
    public void onSwingDuration(SwingDurationEvent e) {
        if (!this.onlyAimbot.isValue() || AimAssist.isActive) {
            e.setAnimation(this.swingSpeedSetting.getValue());
            e.cancel();
        }
    }

    @EventHandler
    public void onHandAnimation(HandAnimationEvent e) {
        boolean isMainHand = e.getHand().equals((Object)class_1268.field_5808);
        if (isMainHand) {
            class_4587 matrix = e.getMatrices();
            float swingProgress = e.getSwingProgress();
            int i = SwingAnimation.mc.field_1724.method_6068().equals((Object)class_1306.field_6183) ? 1 : -1;
            float sin1 = class_3532.method_15374((float)(swingProgress * swingProgress * (float)Math.PI));
            float sin2 = class_3532.method_15374((float)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
            float sinSmooth = (float)(Math.sin((double)swingProgress * Math.PI) * 0.5);
            float strength = this.hitStrengthSetting.getValue();
            if (!this.onlyAimbot.isValue() || AimAssist.isActive) {
                if (!this.onlySwing.isValue() || SwingAnimation.mc.field_1724.field_6279 != 0) {
                    switch (this.swingType.getSelected()) {
                        case "Twist": {
                            matrix.method_46416((float)i * 0.56f, -0.36f, -0.72f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)(80 * i)));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -90.0f * strength));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees((sin1 - sin2) * 60.0f * (float)i * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-30.0f));
                            matrix.method_46416(0.0f, -0.1f, 0.05f);
                            break;
                        }
                        case "Swipe": {
                            matrix.method_46416(0.56f * (float)i, -0.32f, -0.72f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)(70 * i)));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees((float)(-20 * i)));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(sin2 * sin1 * -5.0f * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * sin1 * -120.0f * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-70.0f));
                            break;
                        }
                        case "Default": {
                            matrix.method_46416((float)i * 0.56f, -0.52f - sin2 * 0.5f * strength, -0.72f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)(45 * i)));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)(-45 * i)));
                            break;
                        }
                        case "Down": {
                            matrix.method_46416((float)i * 0.56f, -0.32f, -0.72f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)(76 * i)));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(sin2 * -5.0f * strength));
                            matrix.method_22907(class_7833.field_40713.rotationDegrees(sin2 * -100.0f * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -155.0f * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-100.0f));
                            break;
                        }
                        case "Smooth": {
                            matrix.method_46416((float)i * 0.56f, -0.42f, -0.72f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)i * (45.0f + sin1 * -20.0f * strength)));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees((float)i * sin2 * -20.0f * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -80.0f * strength));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)i * -45.0f));
                            matrix.method_22904(0.0, -0.1, 0.0);
                            break;
                        }
                        case "Smooth 2": {
                            matrix.method_46416((float)i * 0.56f, -0.42f, -0.72f);
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -80.0f * strength));
                            matrix.method_22904(0.0, -0.1, 0.0);
                            break;
                        }
                        case "Power": {
                            matrix.method_46416((float)i * 0.56f, -0.32f, -0.72f);
                            matrix.method_46416(-sinSmooth * sinSmooth * sin1 * (float)i * strength, 0.0f, 0.0f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)(61 * i)));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees(sin2 * strength));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(sin2 * sin1 * -5.0f * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * sin1 * -30.0f * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-60.0f));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sinSmooth * -60.0f * strength));
                            break;
                        }
                        case "Feast": {
                            matrix.method_46416((float)i * 0.56f, -0.32f, -0.72f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)(30 * i)));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(sin2 * 75.0f * (float)i * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -45.0f * strength));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)(30 * i)));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-80.0f));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float)(35 * i)));
                            break;
                        }
                        case "Self": {
                            matrix.method_46416((float)i * 0.56f, -0.52f, -0.72f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(90.0f));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees(-60.0f));
                            float anim = (float)Math.sin((double)swingProgress * 1.5707963267948966 * 2.0);
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-90.0f - strength * 10.0f * anim));
                            break;
                        }
                        case "Self 2": {
                            matrix.method_46416((float)i * 0.56f, -0.52f, -0.72f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(90.0f));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees(-30.0f));
                            float anim = (float)Math.sin((double)swingProgress * 1.5707963267948966 * 2.0);
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-90.0f - strength * 10.0f * anim));
                            break;
                        }
                        case "Forward": {
                            matrix.method_46416((float)i * 0.56f, -0.52f, -0.72f);
                            matrix.method_22904(0.0, 0.0, -0.3 * (double)sin2);
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -35.0f));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees(sin2 * 35.0f));
                            break;
                        }
                        case "Touch": {
                            matrix.method_46416((float)i * 0.56f, -0.52f, -0.72f);
                            float anim = (float)Math.sin((double)swingProgress * 1.5707963267948966 * 2.0);
                            matrix.method_22905(1.0f, 1.0f, 1.0f + anim * strength / 4.0f);
                            matrix.method_46416(0.0f, 0.0f, -0.265f);
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-100.0f));
                            break;
                        }
                        case "Curt": {
                            matrix.method_46416((float)i * 0.56f, -0.52f, -0.72f);
                            float sqrtSwing = class_3532.method_15355((float)swingProgress);
                            float sinMain = class_3532.method_15374((float)(sqrtSwing * (float)Math.PI));
                            float sinExtra = class_3532.method_15374((float)(swingProgress * (float)Math.PI));
                            matrix.method_46416(0.4f - sinMain * 0.2f, -0.2f + sinMain * 0.3f, -0.5f - sinExtra * 0.2f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(91.0f));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees(-40.0f + sinMain * -100.0f));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-60.0f));
                            break;
                        }
                        case "Pander": {
                            matrix.method_46416((float)i * 0.56f, -0.52f, -0.72f);
                            matrix.method_22905(0.8f, 0.8f, 0.8f);
                            float anim = (float)Math.sin((double)swingProgress * 1.5707963267948966 * 2.0);
                            float equipAnim = 1.0f - swingProgress;
                            matrix.method_22904(0.3 - (double)(anim * 0.15f), (double)(0.2f - equipAnim * 0.12f), (double)(-0.15f - anim * 0.13f));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(76.0f - 10.0f * anim));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees(-16.0f - 8.0f * anim));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-83.0f - 26.0f * anim));
                            break;
                        }
                        case "BlockHit": {
                            matrix.method_46416((float)i * 0.56f, -0.52f, -0.72f);
                            float f = class_3532.method_15374((float)((float)((double)(swingProgress * swingProgress) * Math.PI)));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(45.0f));
                            float g = class_3532.method_15374((float)((float)((double)class_3532.method_15355((float)swingProgress) * Math.PI)));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(f * -20.0f));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees(g * -20.0f));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(g * -80.0f));
                            matrix.method_46416(0.4f, 0.2f, 0.2f);
                            matrix.method_46416(-0.5f, 0.08f, 0.0f);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(20.0f));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-80.0f));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(20.0f));
                        }
                    }
                } else {
                    matrix.method_46416((float)i * 0.56f, -0.52f, -0.72f);
                }
            } else {
                return;
            }
            e.cancel();
        }
    }
}

