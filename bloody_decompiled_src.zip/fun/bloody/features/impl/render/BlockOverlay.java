/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_10149
 *  net.minecraft.class_10156
 *  net.minecraft.class_1922
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_265
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_3965
 *  net.minecraft.class_4587
 *  net.minecraft.class_5944
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 */
package fun.bloody.features.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.geometry.Render3D;
import java.awt.Color;
import net.minecraft.class_10149;
import net.minecraft.class_10156;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_5944;
import net.minecraft.class_9801;
import org.joml.Matrix4f;

public class BlockOverlay
extends Module {
    private static final class_10156 COSMIC_WAVE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/cosmicwave"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 RAINBOW_FLOW_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/rainbowflow"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 ELECTRIC_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/electric"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 GALAXY_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/galaxy"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 PLASMA_STORM_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/plasmastorm"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 ASTRAL_VOID_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/astralvoid"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 DIVINE_ASCENSION_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/divineascension"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 INFERNO_BLAZE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/infernoblaze"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 FROZEN_CRYSTAL_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/frozencrystal"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 NEON_DREAMS_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/neondreams"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 SUPERNOVA_BURST_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/supernovaburst"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 NEBULA_DREAMS_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/nebuladreams"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 LUNAR_ECLIPSE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/lunareclipse"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 STARFIELD_WARP_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/starfieldwarp"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 DRAGON_FIRE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/dragonfire"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 AURORA_BOREALIS_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/auroraborealis"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 QUANTUM_FLUX_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/quantumflux"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 MYSTIC_PORTAL_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/mysticportal"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 LIGHTNING_STORM_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/lightningstorm"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 PRISMATIC_WAVES_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/prismaticwaves"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 SPACE_VOYAGE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/spacevoyage"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 HYPERSPACE_TRAVEL_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/hyperspacetravel"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 CELESTIAL_DANCE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/celestialdance"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 STELLAR_CASCADE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/stellarcascade"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 CRYSTAL_CAVERN_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/crystalcavern"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 PHOENIX_REBIRTH_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/phoenixrebirth"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 UNDERWATER_PARADISE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/underwaterparadise"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 VOLCANIC_ERUPTION_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/volcaniceruption"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 TIME_FRACTURE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/timefracture"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 COSMIC_STORM_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/cosmicstorm"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 BLACK_HOLE_VORTEX_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/blackholevortex"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 DIMENSIONAL_RIFT_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/dimensionalrift"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 ETHEREAL_WINGS_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/etherealwings"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 RADIANT_BURST_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/radiantburst"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 CELESTIAL_ECLIPSE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/celestialeclipse"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 ANCIENT_MAGIC_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/ancientmagic"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 FIRE_WAVE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/firewave"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 ICE_PULSE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/icepulse"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 TOXIC_GLOW_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/toxicglow"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 BLOOD_RAIN_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/bloodrain"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 GOLDEN_AURA_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/goldenaura"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 SILVER_MIST_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/silvermist"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 EMERALD_DREAM_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/emeralddream"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 RUBY_FLAME_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/rubyflame"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 SAPPHIRE_OCEAN_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/sapphireocean"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 AMETHYST_STORM_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/amethyststorm"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 DIAMOND_SHINE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/diamondshine"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 OBSIDIAN_VOID_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/obsidianvoid"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 COPPER_RUST_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/copperrust"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 NEON_PINK_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/neonpink"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 CYBER_BLUE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/cyberblue"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 TOXIC_GREEN_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/toxicgreen"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 LAVA_FLOW_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/lavaflow"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 WATER_RIPPLE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/waterripple"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 WIND_SPIRAL_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/windspiral"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 EARTH_CRACK_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/earthcrack"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 DIAMOND_RAIN_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/diamondrain"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 ICE_CRYSTALS_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/icecrystals"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 FIRE_TORNADO_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/firetornado"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 WATER_RIPPLES_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/waterripples"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 LIGHTNING_WEB_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/lightningweb"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 STAR_DUST_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/stardust"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 NEON_PULSE_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/neonpulse"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 RAINBOW_SPIRAL_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/rainbowspiral"), class_290.field_1592, class_10149.field_53930);
    private static final class_10156 GLOWING_ORBS_SHADER_KEY = new class_10156(class_2960.method_60655((String)"minecraft", (String)"core/glowingorbs"), class_290.field_1592, class_10149.field_53930);
    public ColorSetting colorSetting = new ColorSetting("\u0426\u0432\u0435\u0442 \u043a\u043e\u043d\u0442\u0443\u0440\u0430", "\u0426\u0432\u0435\u0442 \u043b\u0438\u043d\u0438\u0439 \u043a\u043e\u043d\u0442\u0443\u0440\u0430 \u0431\u043b\u043e\u043a\u0430").setColor(new Color(100, 200, 255, 200).getRGB()).presets(-9659651, -7569409, -23178, -33925);
    public BooleanSetting fillSetting = new BooleanSetting("\u0417\u0430\u043b\u0438\u0432\u043a\u0430", "\u0417\u0430\u043b\u0438\u0432\u043a\u0430 \u0432\u043d\u0443\u0442\u0440\u0438 \u0431\u043b\u043e\u043a\u0430").setValue(true);
    public ColorSetting fillColorSetting = new ColorSetting("\u0426\u0432\u0435\u0442 \u0437\u0430\u043b\u0438\u0432\u043a\u0438", "\u0426\u0432\u0435\u0442 \u0437\u0430\u043b\u0438\u0432\u043a\u0438 \u0432\u043d\u0443\u0442\u0440\u0438 \u0431\u043b\u043e\u043a\u0430").setColor(new Color(100, 200, 255, 150).getRGB()).presets(-1771267331, -1769177089, -1761630858, -1761641605).visible(() -> this.fillSetting.isValue());
    public BooleanSetting glowSetting = new BooleanSetting("\u0421\u0432\u0435\u0447\u0435\u043d\u0438\u0435", "\u041a\u0440\u0430\u0441\u0438\u0432\u043e\u0435 \u0441\u0432\u0435\u0447\u0435\u043d\u0438\u0435 \u0431\u043b\u043e\u043a\u0430").setValue(true);
    public SliderSettings glowIntensity = new SliderSettings("\u0418\u043d\u0442\u0435\u043d\u0441\u0438\u0432\u043d\u043e\u0441\u0442\u044c \u0441\u0432\u0435\u0447\u0435\u043d\u0438\u044f", "\u042f\u0440\u043a\u043e\u0441\u0442\u044c \u0441\u0432\u0435\u0447\u0435\u043d\u0438\u044f").range(0.1f, 2.0f).setValue(1.0f).visible(() -> this.glowSetting.isValue());
    public BooleanSetting shaderSetting = new BooleanSetting("Shader", "\u041a\u043e\u0441\u043c\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u0448\u0435\u0439\u0434\u0435\u0440").setValue(false);
    public SelectSetting shaderMode = new SelectSetting("\u0420\u0435\u0436\u0438\u043c \u0448\u0435\u0439\u0434\u0435\u0440\u0430", "\u0412\u044b\u0431\u043e\u0440 \u044d\u0444\u0444\u0435\u043a\u0442\u0430 \u0448\u0435\u0439\u0434\u0435\u0440\u0430").value("Cosmic Wave", "Rainbow Flow", "Electric", "Galaxy", "Plasma Storm", "Astral Void", "Divine Ascension", "Inferno Blaze", "Frozen Crystal", "Neon Dreams", "Supernova Burst", "Nebula Dreams", "Lunar Eclipse", "Starfield Warp", "Dragon Fire", "Aurora Borealis", "Quantum Flux", "Mystic Portal", "Lightning Storm", "Prismatic Waves", "Space Voyage", "Hyperspace Travel", "Celestial Dance", "Stellar Cascade", "Crystal Cavern", "Phoenix Rebirth", "Underwater Paradise", "Volcanic Eruption", "Time Fracture", "Cosmic Storm", "Black Hole Vortex", "Dimensional Rift", "Ethereal Wings", "Radiant Burst", "Celestial Eclipse", "Ancient Magic", "Diamond Rain", "Lava Flow", "Ice Crystals", "Fire Tornado", "Water Ripples", "Lightning Web", "Star Dust", "Neon Pulse", "Rainbow Spiral", "Glowing Orbs").selected("Cosmic Wave").visible(() -> this.shaderSetting.isValue());
    public SliderSettings transitionSpeed = new SliderSettings("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u043f\u0435\u0440\u0435\u0445\u043e\u0434\u0430", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u043f\u0435\u0440\u0435\u0445\u043e\u0434\u0430 \u043c\u0435\u0436\u0434\u0443 \u0431\u043b\u043e\u043a\u0430\u043c\u0438").range(1.0f, 20.0f).setValue(8.0f);
    private class_243 currentCenter = null;
    private class_243 currentSize = null;
    private class_243 targetCenter = null;
    private class_243 targetSize = null;
    private class_2338 lastPos = null;
    private long lastTime = System.currentTimeMillis();
    private long lastBlockHitTime = 0L;
    private static final long FADE_OUT_DELAY = 1000L;

    public static BlockOverlay getInstance() {
        return Instance.get(BlockOverlay.class);
    }

    public BlockOverlay() {
        super("BlockOverlay", "Block Overlay", ModuleCategory.RENDER);
        this.setup(this.colorSetting, this.fillColorSetting, this.fillSetting, this.glowSetting, this.glowIntensity, this.shaderSetting, this.shaderMode, this.transitionSpeed);
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent event) {
        class_3965 result;
        boolean hasBlockTarget;
        float deltaTime = this.getDeltaTime();
        class_239 class_2392 = BlockOverlay.mc.field_1765;
        boolean bl = hasBlockTarget = class_2392 instanceof class_3965 && (result = (class_3965)class_2392).method_17783().equals((Object)class_239.class_240.field_1332);
        if (hasBlockTarget) {
            result = (class_3965)BlockOverlay.mc.field_1765;
            class_2338 pos = result.method_17777();
            if (BlockOverlay.mc.field_1687 == null) {
                return;
            }
            class_265 shape = BlockOverlay.mc.field_1687.method_8320(pos).method_26218((class_1922)BlockOverlay.mc.field_1687, pos);
            if (!shape.method_1110()) {
                class_238 box = shape.method_1107().method_996(pos);
                class_243 center = new class_243((box.field_1323 + box.field_1320) / 2.0, (box.field_1322 + box.field_1325) / 2.0, (box.field_1321 + box.field_1324) / 2.0);
                class_243 size = new class_243(box.field_1320 - box.field_1323, box.field_1325 - box.field_1322, box.field_1324 - box.field_1321);
                if (this.lastPos == null || !this.lastPos.equals((Object)pos)) {
                    this.lastPos = pos;
                    this.targetCenter = center;
                    this.targetSize = size;
                    this.lastBlockHitTime = System.currentTimeMillis();
                    if (this.currentCenter == null) {
                        this.currentCenter = this.targetCenter;
                        this.currentSize = this.targetSize;
                    }
                }
            }
        } else {
            this.currentCenter = null;
            this.currentSize = null;
            this.targetCenter = null;
            this.targetSize = null;
            this.lastPos = null;
            this.lastBlockHitTime = 0L;
            return;
        }
        if (this.currentCenter != null && this.currentSize != null) {
            if (this.targetCenter != null && this.targetSize != null) {
                float speed = this.transitionSpeed.getValue();
                float factor = Math.min(1.0f, deltaTime * speed);
                this.currentCenter = this.interpolate(this.currentCenter, this.targetCenter, factor);
                this.currentSize = this.interpolate(this.currentSize, this.targetSize, factor);
            }
            class_243 min = new class_243(this.currentCenter.field_1352 - this.currentSize.field_1352 / 2.0, this.currentCenter.field_1351 - this.currentSize.field_1351 / 2.0, this.currentCenter.field_1350 - this.currentSize.field_1350 / 2.0);
            class_243 max = new class_243(this.currentCenter.field_1352 + this.currentSize.field_1352 / 2.0, this.currentCenter.field_1351 + this.currentSize.field_1351 / 2.0, this.currentCenter.field_1350 + this.currentSize.field_1350 / 2.0);
            class_238 renderBox = new class_238(min.field_1352, min.field_1351, min.field_1350, max.field_1352, max.field_1351, max.field_1350);
            boolean fill = this.fillSetting.isValue();
            if (this.glowSetting.isValue()) {
                int baseColor = this.colorSetting.getColor();
                float intensity = this.glowIntensity.getValue();
                int layers = 6;
                for (int i = 0; i < layers; ++i) {
                    float progress = (float)i / (float)layers;
                    double expand = 0.01 + (double)progress * 0.12;
                    float alphaFactor = (1.0f - progress) * (1.0f - progress);
                    int alpha = (int)((float)ColorAssist.getAlpha(baseColor) * (alphaFactor *= intensity) * 0.5f);
                    alpha = Math.max(0, Math.min(255, alpha));
                    class_238 glowBox = renderBox.method_1014(expand);
                    int glowColor = ColorAssist.setAlpha(baseColor, alpha);
                    Render3D.drawBox(glowBox, glowColor, 2.0f + progress * 2.0f, true, false, false);
                }
            }
            if (fill) {
                int fillColor = this.fillColorSetting.getColor();
                if (this.shaderSetting.isValue()) {
                    this.drawBoxWithShader(renderBox, fillColor, event.getStack());
                } else {
                    Render3D.drawBox(renderBox, fillColor, 2.0f, false, true, false);
                }
            }
            Render3D.drawBox(renderBox, this.colorSetting.getColor(), 2.0f, true, false, false);
        }
    }

    private void drawBoxWithShader(class_238 box, int color, class_4587 matrices) {
        String mode;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        Matrix4f matrix4f = matrices.method_23760().method_23761();
        float time = (float)(System.currentTimeMillis() % 100000L) / 1000.0f;
        class_5944 shader = RenderSystem.setShader((class_10156)(switch (mode = this.shaderMode.getSelected()) {
            case "Rainbow Flow" -> RAINBOW_FLOW_SHADER_KEY;
            case "Electric" -> ELECTRIC_SHADER_KEY;
            case "Galaxy" -> GALAXY_SHADER_KEY;
            case "Plasma Storm" -> PLASMA_STORM_SHADER_KEY;
            case "Astral Void" -> ASTRAL_VOID_SHADER_KEY;
            case "Divine Ascension" -> DIVINE_ASCENSION_SHADER_KEY;
            case "Inferno Blaze" -> INFERNO_BLAZE_SHADER_KEY;
            case "Frozen Crystal" -> FROZEN_CRYSTAL_SHADER_KEY;
            case "Neon Dreams" -> NEON_DREAMS_SHADER_KEY;
            case "Supernova Burst" -> SUPERNOVA_BURST_SHADER_KEY;
            case "Nebula Dreams" -> NEBULA_DREAMS_SHADER_KEY;
            case "Lunar Eclipse" -> LUNAR_ECLIPSE_SHADER_KEY;
            case "Starfield Warp" -> STARFIELD_WARP_SHADER_KEY;
            case "Dragon Fire" -> DRAGON_FIRE_SHADER_KEY;
            case "Aurora Borealis" -> AURORA_BOREALIS_SHADER_KEY;
            case "Quantum Flux" -> QUANTUM_FLUX_SHADER_KEY;
            case "Mystic Portal" -> MYSTIC_PORTAL_SHADER_KEY;
            case "Lightning Storm" -> LIGHTNING_STORM_SHADER_KEY;
            case "Prismatic Waves" -> PRISMATIC_WAVES_SHADER_KEY;
            case "Space Voyage" -> SPACE_VOYAGE_SHADER_KEY;
            case "Hyperspace Travel" -> HYPERSPACE_TRAVEL_SHADER_KEY;
            case "Celestial Dance" -> CELESTIAL_DANCE_SHADER_KEY;
            case "Stellar Cascade" -> STELLAR_CASCADE_SHADER_KEY;
            case "Crystal Cavern" -> CRYSTAL_CAVERN_SHADER_KEY;
            case "Phoenix Rebirth" -> PHOENIX_REBIRTH_SHADER_KEY;
            case "Underwater Paradise" -> UNDERWATER_PARADISE_SHADER_KEY;
            case "Volcanic Eruption" -> VOLCANIC_ERUPTION_SHADER_KEY;
            case "Time Fracture" -> TIME_FRACTURE_SHADER_KEY;
            case "Cosmic Storm" -> COSMIC_STORM_SHADER_KEY;
            case "Black Hole Vortex" -> BLACK_HOLE_VORTEX_SHADER_KEY;
            case "Dimensional Rift" -> DIMENSIONAL_RIFT_SHADER_KEY;
            case "Ethereal Wings" -> ETHEREAL_WINGS_SHADER_KEY;
            case "Radiant Burst" -> RADIANT_BURST_SHADER_KEY;
            case "Celestial Eclipse" -> CELESTIAL_ECLIPSE_SHADER_KEY;
            case "Ancient Magic" -> ANCIENT_MAGIC_SHADER_KEY;
            case "Diamond Rain" -> DIAMOND_RAIN_SHADER_KEY;
            case "Lava Flow" -> LAVA_FLOW_SHADER_KEY;
            case "Ice Crystals" -> ICE_CRYSTALS_SHADER_KEY;
            case "Fire Tornado" -> FIRE_TORNADO_SHADER_KEY;
            case "Water Ripples" -> WATER_RIPPLES_SHADER_KEY;
            case "Lightning Web" -> LIGHTNING_WEB_SHADER_KEY;
            case "Star Dust" -> STAR_DUST_SHADER_KEY;
            case "Neon Pulse" -> NEON_PULSE_SHADER_KEY;
            case "Rainbow Spiral" -> RAINBOW_SPIRAL_SHADER_KEY;
            case "Glowing Orbs" -> GLOWING_ORBS_SHADER_KEY;
            default -> COSMIC_WAVE_SHADER_KEY;
        }));
        if (shader == null) {
            Render3D.drawBox(box, color, 2.0f, false, true, false);
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            return;
        }
        shader.method_35785("Time").method_1251(time);
        float r = (float)ColorAssist.getRed(color) / 255.0f;
        float g = (float)ColorAssist.getGreen(color) / 255.0f;
        float b = (float)ColorAssist.getBlue(color) / 255.0f;
        float a = (float)ColorAssist.getAlpha(color) / 255.0f;
        shader.method_35785("Color").method_35657(r, g, b, a);
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        double x1 = box.field_1323;
        double y1 = box.field_1322;
        double z1 = box.field_1321;
        double x2 = box.field_1320;
        double y2 = box.field_1325;
        double z2 = box.field_1324;
        buffer.method_22918(matrix4f, (float)x1, (float)y1, (float)z1);
        buffer.method_22918(matrix4f, (float)x2, (float)y1, (float)z1);
        buffer.method_22918(matrix4f, (float)x2, (float)y1, (float)z2);
        buffer.method_22918(matrix4f, (float)x1, (float)y1, (float)z2);
        buffer.method_22918(matrix4f, (float)x1, (float)y1, (float)z1);
        buffer.method_22918(matrix4f, (float)x1, (float)y2, (float)z1);
        buffer.method_22918(matrix4f, (float)x2, (float)y2, (float)z1);
        buffer.method_22918(matrix4f, (float)x2, (float)y1, (float)z1);
        buffer.method_22918(matrix4f, (float)x2, (float)y1, (float)z1);
        buffer.method_22918(matrix4f, (float)x2, (float)y2, (float)z1);
        buffer.method_22918(matrix4f, (float)x2, (float)y2, (float)z2);
        buffer.method_22918(matrix4f, (float)x2, (float)y1, (float)z2);
        buffer.method_22918(matrix4f, (float)x1, (float)y1, (float)z2);
        buffer.method_22918(matrix4f, (float)x2, (float)y1, (float)z2);
        buffer.method_22918(matrix4f, (float)x2, (float)y2, (float)z2);
        buffer.method_22918(matrix4f, (float)x1, (float)y2, (float)z2);
        buffer.method_22918(matrix4f, (float)x1, (float)y1, (float)z1);
        buffer.method_22918(matrix4f, (float)x1, (float)y1, (float)z2);
        buffer.method_22918(matrix4f, (float)x1, (float)y2, (float)z2);
        buffer.method_22918(matrix4f, (float)x1, (float)y2, (float)z1);
        buffer.method_22918(matrix4f, (float)x1, (float)y2, (float)z1);
        buffer.method_22918(matrix4f, (float)x1, (float)y2, (float)z2);
        buffer.method_22918(matrix4f, (float)x2, (float)y2, (float)z2);
        buffer.method_22918(matrix4f, (float)x2, (float)y2, (float)z1);
        class_286.method_43433((class_9801)buffer.method_60800());
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private float getDeltaTime() {
        long currentTime = System.currentTimeMillis();
        float delta = (float)(currentTime - this.lastTime) / 1000.0f;
        this.lastTime = currentTime;
        return Math.min(delta, 0.1f);
    }

    private class_243 interpolate(class_243 from, class_243 to, float factor) {
        return new class_243(from.field_1352 + (to.field_1352 - from.field_1352) * (double)factor, from.field_1351 + (to.field_1351 - from.field_1351) * (double)factor, from.field_1350 + (to.field_1350 - from.field_1350) * (double)factor);
    }

    @Override
    public void deactivate() {
        this.currentCenter = null;
        this.currentSize = null;
        this.targetCenter = null;
        this.targetSize = null;
        this.lastPos = null;
    }
}

