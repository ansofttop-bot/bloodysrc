/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_243
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_2960
 *  net.minecraft.class_3532
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_4587$class_4665
 *  net.minecraft.class_7833
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 *  org.joml.Vector4i
 *  org.lwjgl.opengl.GL11
 */
package fun.bloody.features.impl.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.Bloody;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.events.player.RotationUpdateEvent;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.impl.combat.Aura;
import fun.bloody.features.impl.combat.TriggerBot;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.geometry.Render3D;
import fun.bloody.utils.math.calc.CalcVector;
import fun.bloody.utils.math.calc.Calculate;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Vector4i;
import org.lwjgl.opengl.GL11;

public class TargetESP
extends Module {
    private Animation esp_anim = new Decelerate().setMs(400).setValue(1.0);
    private SelectSetting targetEspType = new SelectSetting("\u041e\u0442\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f \u0442\u0430\u0440\u0433\u0435\u0442\u0430", "\u0412\u044b\u0431\u0438\u0440\u0430\u0435\u0442 \u0442\u0438\u043f \u0446\u0435\u043b\u0438 esp").value("Cube", "Circle", "Rhombus", "Spiral Crystals", "Crystals V2", "Chain", "Spiral", "Souls").selected("Circle");
    private SelectSetting cubeType = new SelectSetting("\u041a\u0430\u0440\u0442\u0438\u043d\u043a\u0430 \u0434\u043b\u044f \u043a\u0443\u0431\u0430", "\u0412\u044b\u0431\u0438\u0440\u0430\u0435\u0442 \u0442\u0438\u043f \u043a\u0443\u0431\u0430").value("1", "2", "3", "4", "5", "target2", "wexide").visible(() -> this.targetEspType.isSelected("Cube"));
    private SliderSettings ghostSpeed = new SliderSettings("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u043f\u0440\u0438\u0437\u0440\u0430\u043a\u043e\u0432", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438 \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u0438 Souls").range(0.5f, 2.0f).setValue(1.0f).visible(() -> this.targetEspType.isSelected("Souls") || this.targetEspType.isSelected("Spiral") || this.targetEspType.isSelected("Soulsed"));
    private SliderSettings souls2Size = new SliderSettings("\u0420\u0430\u0437\u043c\u0435\u0440 \u043f\u0440\u0438\u0437\u0440\u0430\u043a\u043e\u0432", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u0440\u0430\u0437\u043c\u0435\u0440\u0430 \u043f\u0440\u0438\u0437\u0440\u0430\u043a\u043e\u0432 Souls").range(0.1f, 1.0f).setValue(0.4f).visible(() -> this.targetEspType.isSelected("Souls") || this.targetEspType.isSelected("Spiral") || this.targetEspType.isSelected("Soulsed"));
    private BooleanSetting syncWithAura = new BooleanSetting("\u0421\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0441 AttackAura", "TargetESP \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u0442\u043e\u043b\u044c\u043a\u043e \u043d\u0430 \u0446\u0435\u043b\u0438 AttackAura").setValue(false);
    public ColorSetting colorSetting = new ColorSetting("\u0426\u0432\u0435\u0442 TargetESP", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0446\u0432\u0435\u0442 \u0434\u043b\u044f TargetESP");
    private class_1309 cachedTarget = null;
    private float rhombusRotation = 0.0f;
    private final List<AnimatedCrystal> spiralCrystalList = new ArrayList<AnimatedCrystal>();
    private float spiralRotation = 0.0f;
    private class_1297 lastSpiralTarget = null;
    private long spiralSpawnTime = 0L;
    private final List<AnimatedCrystal> crystalsV2List = new ArrayList<AnimatedCrystal>();
    private float v2Rotation = 0.0f;
    private class_1297 lastV2Target = null;
    private long v2SpawnTime = 0L;
    private long soulsStartTime = System.currentTimeMillis();
    private static long lastSoulsTime = System.currentTimeMillis();
    private static long lastSpiralTime = System.currentTimeMillis();
    private float chainMovingValue = 0.0f;

    public static TargetESP getInstance() {
        return Instance.get(TargetESP.class);
    }

    public TargetESP() {
        super("TargetEsp", "Target Esp", ModuleCategory.RENDER);
        this.setup(this.targetEspType, this.cubeType, this.ghostSpeed, this.souls2Size, this.colorSetting, this.syncWithAura);
    }

    @EventHandler
    public void onRotationUpdate(RotationUpdateEvent e) {
        if (e.getType() == 2) {
            Render3D.updateTargetEsp();
        }
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        class_1309 currentTarget = null;
        if (this.syncWithAura.isValue()) {
            Aura Aura2 = Bloody.getInstance().getModuleRepository().modules().stream().filter(m -> m instanceof Aura).map(m -> (Aura)m).findFirst().orElse(null);
            if (Aura2 != null && Aura2.isState() && Aura2.target != null) {
                currentTarget = Aura2.target;
                this.cachedTarget = Aura2.target;
            }
        } else {
            if (TriggerBot.getInstance() != null && TriggerBot.getInstance().isState()) {
                currentTarget = TriggerBot.getInstance().target;
                this.cachedTarget = TriggerBot.getInstance().target;
            }
            if (currentTarget == null && TargetESP.mc.field_1687 != null && TargetESP.mc.field_1724 != null) {
                double closestDistance = 6.0;
                for (class_1297 entity : TargetESP.mc.field_1687.method_18112()) {
                    double distance;
                    if (!(entity instanceof class_1309)) continue;
                    class_1309 livingEntity = (class_1309)entity;
                    if (entity == TargetESP.mc.field_1724 || !livingEntity.method_5805() || !((distance = (double)TargetESP.mc.field_1724.method_5739((class_1297)livingEntity)) < closestDistance)) continue;
                    closestDistance = distance;
                    currentTarget = livingEntity;
                    this.cachedTarget = livingEntity;
                }
            }
        }
        this.esp_anim.setDirection(currentTarget != null ? Direction.FORWARDS : Direction.BACKWARDS);
    }

    public void renderAfterWorld(class_4587 matrices, float tickDelta) {
        float anim = this.esp_anim.getOutput().floatValue();
        if (this.cachedTarget != null && !this.esp_anim.isFinished(Direction.BACKWARDS) && anim > 0.01f) {
            RenderSystem.disableDepthTest();
            GL11.glDisable((int)2929);
            GL11.glDepthFunc((int)519);
            GL11.glDepthMask((boolean)false);
            float red = class_3532.method_15363((float)(((float)this.cachedTarget.field_6235 - tickDelta) / 20.0f), (float)0.0f, (float)1.0f);
            switch (this.targetEspType.getSelected()) {
                case "Cube": {
                    Render3D.drawCube(this.cachedTarget, anim, red, this.cubeType.getSelected());
                    break;
                }
                case "Circle": {
                    Render3D.drawCircle(matrices, this.cachedTarget, anim, red);
                    break;
                }
                case "Rhombus": {
                    this.renderRhombus(matrices, this.cachedTarget, anim, red);
                    break;
                }
                case "Spiral Crystals": {
                    this.renderSpiralCrystals(matrices, this.cachedTarget, anim, red);
                    break;
                }
                case "Crystals V2": {
                    this.renderCrystalsV2(matrices, this.cachedTarget, anim, red);
                    break;
                }
                case "Chain": {
                    this.renderChain(matrices, this.cachedTarget, anim, red, tickDelta);
                    break;
                }
                case "Spiral": {
                    this.renderSpiral(matrices, this.cachedTarget, anim, red);
                    break;
                }
                case "Souls": {
                    this.renderSouls(matrices, this.cachedTarget, anim, red);
                }
            }
        }
    }

    private void renderRhombus(class_4587 ms, class_1309 target, float anim, float red) {
        class_243 targetPos = CalcVector.lerpPosition((class_1297)target);
        this.rhombusRotation = (this.rhombusRotation + 2.0f) % 360.0f;
        float hitEffect = (float)Math.sin((double)red * Math.PI) * 0.3f;
        float scale = anim * (1.0f + hitEffect);
        int baseColor = ColorAssist.interpolateColor(this.colorSetting.getColor(), new Color(255, 50, 50).getRGB(), red);
        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        ms.method_22903();
        ms.method_22904(targetPos.field_1352, targetPos.field_1351 + (double)(target.method_17682() / 2.0f), targetPos.field_1350);
        for (int i = 0; i < 4; ++i) {
            ms.method_22903();
            float angle = this.rhombusRotation + (float)(i * 90);
            float radius = 0.8f * scale;
            float yOffset = (float)Math.sin(Math.toRadians(this.rhombusRotation * 2.0f + (float)(i * 45))) * 0.3f;
            double x = Math.cos(Math.toRadians(angle)) * (double)radius;
            double z = Math.sin(Math.toRadians(angle)) * (double)radius;
            ms.method_22904(x, (double)yOffset, z);
            ms.method_22907(class_7833.field_40716.rotationDegrees(angle));
            ms.method_22907(class_7833.field_40714.rotationDegrees(this.rhombusRotation));
            ms.method_22905(scale * 0.15f, scale * 0.15f, scale * 0.15f);
            this.drawRhombusShape(ms, baseColor, anim);
            ms.method_22909();
        }
        ms.method_22909();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private void drawRhombusShape(class_4587 ms, int color, float anim) {
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27379, class_290.field_1576);
        Matrix4f matrix = ms.method_23760().method_23761();
        int c = ColorAssist.setAlpha(color, (int)(200.0f * anim));
        buffer.method_22918(matrix, 0.0f, 1.0f, 0.0f).method_39415(c);
        buffer.method_22918(matrix, 0.5f, 0.0f, 0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.5f, 0.0f, -0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.0f, 1.0f, 0.0f).method_39415(c);
        buffer.method_22918(matrix, 0.5f, 0.0f, -0.5f).method_39415(c);
        buffer.method_22918(matrix, -0.5f, 0.0f, -0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.0f, 1.0f, 0.0f).method_39415(c);
        buffer.method_22918(matrix, -0.5f, 0.0f, -0.5f).method_39415(c);
        buffer.method_22918(matrix, -0.5f, 0.0f, 0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.0f, 1.0f, 0.0f).method_39415(c);
        buffer.method_22918(matrix, -0.5f, 0.0f, 0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.5f, 0.0f, 0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.0f, -1.0f, 0.0f).method_39415(c);
        buffer.method_22918(matrix, 0.5f, 0.0f, -0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.5f, 0.0f, 0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.0f, -1.0f, 0.0f).method_39415(c);
        buffer.method_22918(matrix, -0.5f, 0.0f, -0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.5f, 0.0f, -0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.0f, -1.0f, 0.0f).method_39415(c);
        buffer.method_22918(matrix, -0.5f, 0.0f, 0.5f).method_39415(c);
        buffer.method_22918(matrix, -0.5f, 0.0f, -0.5f).method_39415(c);
        buffer.method_22918(matrix, 0.0f, -1.0f, 0.0f).method_39415(c);
        buffer.method_22918(matrix, 0.5f, 0.0f, 0.5f).method_39415(c);
        buffer.method_22918(matrix, -0.5f, 0.0f, 0.5f).method_39415(c);
        class_286.method_43433((class_9801)buffer.method_60800());
    }

    private void createSpiralCrystals() {
        this.spiralCrystalList.clear();
        for (int i = 0; i < 12; ++i) {
            float angle = i * 30;
            float height = 0.3f + (float)i * 0.15f;
            float radius = 0.45f + (float)Math.sin((double)i * 0.5) * 0.15f;
            float x = (float)Math.cos(Math.toRadians(angle)) * radius;
            float z = (float)Math.sin(Math.toRadians(angle)) * radius;
            this.spiralCrystalList.add(new AnimatedCrystal(new class_243((double)x, (double)height, (double)z), i));
        }
        this.spiralSpawnTime = System.currentTimeMillis();
    }

    private void renderSpiralCrystals(class_4587 ms, class_1309 target, float anim, float red) {
        if (this.spiralCrystalList.isEmpty() || this.lastSpiralTarget != target) {
            this.createSpiralCrystals();
            this.lastSpiralTarget = target;
        }
        class_243 targetPos = CalcVector.lerpPosition((class_1297)target);
        this.spiralRotation = (this.spiralRotation + 1.8f) % 360.0f;
        float hitPull = class_3532.method_15363((float)red, (float)0.0f, (float)1.0f);
        hitPull *= hitPull;
        long timeSinceSpawn = System.currentTimeMillis() - this.spiralSpawnTime;
        ms.method_22903();
        ms.method_22904(targetPos.field_1352, targetPos.field_1351, targetPos.field_1350);
        ms.method_22907(class_7833.field_40716.rotationDegrees(this.spiralRotation));
        class_4184 camera = TargetESP.mc.field_1773.method_19418();
        for (int i = 0; i < this.spiralCrystalList.size(); ++i) {
            AnimatedCrystal crystal = this.spiralCrystalList.get(i);
            float wave = (float)Math.sin((double)System.currentTimeMillis() / 400.0 + (double)i * 0.4) * 0.08f;
            ms.method_22903();
            ms.method_46416(0.0f, wave, 0.0f);
            crystal.render(ms, anim, red, hitPull, camera, this.spiralRotation, timeSinceSpawn);
            ms.method_22909();
        }
        ms.method_22909();
    }

    private void createCrystalsV2() {
        this.crystalsV2List.clear();
        Random rand = new Random();
        int count = 20;
        for (int i = 0; i < count; ++i) {
            float angle = rand.nextFloat() * 360.0f;
            float height = 0.4f + rand.nextFloat() * 1.6f;
            float radius = 0.4f + rand.nextFloat() * 0.35f;
            float x = (float)Math.cos(Math.toRadians(angle)) * radius;
            float z = (float)Math.sin(Math.toRadians(angle)) * radius;
            this.crystalsV2List.add(new AnimatedCrystal(new class_243((double)(x += (rand.nextFloat() - 0.5f) * 0.15f), (double)height, (double)(z += (rand.nextFloat() - 0.5f) * 0.15f)), i));
        }
        this.v2SpawnTime = System.currentTimeMillis();
    }

    private void renderCrystalsV2(class_4587 ms, class_1309 target, float anim, float red) {
        if (this.crystalsV2List.isEmpty() || this.lastV2Target != target) {
            this.createCrystalsV2();
            this.lastV2Target = target;
        }
        class_243 targetPos = CalcVector.lerpPosition((class_1297)target);
        this.v2Rotation = (this.v2Rotation + 0.7f) % 360.0f;
        float hitPull = class_3532.method_15363((float)red, (float)0.0f, (float)1.0f);
        hitPull *= hitPull;
        long timeSinceSpawn = System.currentTimeMillis() - this.v2SpawnTime;
        ms.method_22903();
        ms.method_22904(targetPos.field_1352, targetPos.field_1351, targetPos.field_1350);
        ms.method_22907(class_7833.field_40716.rotationDegrees(this.v2Rotation));
        class_4184 camera = TargetESP.mc.field_1773.method_19418();
        for (int i = 0; i < this.crystalsV2List.size(); ++i) {
            AnimatedCrystal crystal = this.crystalsV2List.get(i);
            float wave = (float)Math.sin((double)System.currentTimeMillis() / 350.0 + (double)i * 0.7) * 0.06f;
            float sway = (float)Math.cos((double)System.currentTimeMillis() / 500.0 + (double)i * 0.5) * 0.03f;
            ms.method_22903();
            ms.method_46416(sway, wave, sway * 0.5f);
            crystal.render(ms, anim, red, hitPull, camera, this.v2Rotation, timeSinceSpawn);
            ms.method_22909();
        }
        ms.method_22909();
    }

    private float getMovingValue() {
        this.chainMovingValue += 0.5f;
        if (this.chainMovingValue > 360.0f) {
            this.chainMovingValue = 0.0f;
        }
        return this.chainMovingValue;
    }

    private void renderSpiral(class_4587 matrices, class_1309 target, float anim, float red) {
        class_4184 camera = TargetESP.mc.method_1561().field_4686;
        class_243 targetPos = Calculate.interpolate((class_1297)target).method_1020(camera.method_19326());
        double radius = 0.7;
        float speed = 30.0f / this.ghostSpeed.getValue();
        float size = this.souls2Size.getValue();
        double distance = 15.0;
        int length = 15;
        long now = System.currentTimeMillis();
        GL11.glDisable((int)2929);
        GL11.glDepthFunc((int)519);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask((boolean)false);
        float timeScale = speed / 30.0f;
        float verticalProgress = (float)Math.sin((double)now / 1000.0 / (double)timeScale) * 0.5f + 0.5f;
        float heightOffset = target.method_17682() * verticalProgress;
        for (int j = 0; j < 3; ++j) {
            for (int i = 0; i < length; ++i) {
                double angle = (double)0.15f * ((double)(now - lastSpiralTime) - (double)i * distance) / (double)speed + (double)j * Math.PI * 2.0 / 3.0;
                double s = Math.sin(angle) * radius;
                double c = Math.cos(angle) * radius;
                double xOffset = s;
                double yOffset = 0.0;
                double zOffset = c;
                class_4587 ms = new class_4587();
                ms.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                ms.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
                ms.method_22904(targetPos.field_1352 + xOffset, targetPos.field_1351 + (double)heightOffset + yOffset, targetPos.field_1350 + zOffset);
                ms.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
                ms.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                class_4587.class_4665 entry = ms.method_23760().method_56822();
                float offset = (float)i / (float)length;
                int color = ColorAssist.multRedAndAlpha(TargetESP.getInstance().colorSetting.getColor(), 1.0f + red * 10.0f, offset * anim);
                Render3D.drawTexture(entry, class_2960.method_60654((String)"textures/features/particles/bloom.png"), -size / 2.0f, -size / 2.0f, size, size, new Vector4i(color), false);
            }
        }
    }

    private void renderSouls(class_4587 matrices, class_1309 target, float anim, float red) {
        class_4184 camera = TargetESP.mc.method_1561().field_4686;
        class_243 targetPos = Calculate.interpolate((class_1297)target).method_1020(camera.method_19326());
        double radius = 0.7;
        float speed = 30.0f / this.ghostSpeed.getValue();
        float size = this.souls2Size.getValue();
        double distance = 15.0;
        int length = 15;
        long now = System.currentTimeMillis();
        GL11.glDisable((int)2929);
        GL11.glDepthFunc((int)519);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask((boolean)false);
        for (int j = 0; j < 3; ++j) {
            float heightOffset = 0.0f;
            switch (j) {
                case 0: {
                    heightOffset = target.method_17682() * 0.8f;
                    break;
                }
                case 1: {
                    heightOffset = target.method_17682() * 0.5f;
                    break;
                }
                case 2: {
                    heightOffset = target.method_17682() * 0.2f;
                }
            }
            for (int i = 0; i < length; ++i) {
                double angle = (double)0.15f * ((double)(now - lastSoulsTime) - (double)i * distance) / (double)speed + (double)j * Math.PI * 2.0 / 3.0;
                double s = Math.sin(angle) * radius;
                double c = Math.cos(angle) * radius;
                double xOffset = s;
                double yOffset = 0.0;
                double zOffset = c;
                class_4587 ms = new class_4587();
                ms.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                ms.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
                ms.method_22904(targetPos.field_1352 + xOffset, targetPos.field_1351 + (double)heightOffset + yOffset, targetPos.field_1350 + zOffset);
                ms.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
                ms.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
                class_4587.class_4665 entry = ms.method_23760().method_56822();
                float offset = (float)i / (float)length;
                int color = ColorAssist.multRedAndAlpha(TargetESP.getInstance().colorSetting.getColor(), 1.0f + red * 10.0f, offset * anim);
                Render3D.drawTexture(entry, class_2960.method_60654((String)"textures/features/particles/bloom.png"), -size / 2.0f, -size / 2.0f, size, size, new Vector4i(color), false);
            }
        }
    }

    private void putBloomQuad(class_287 builder, class_4587 ms, double x, double y, double z, float scale, float r, float g, float b, float a, float camYaw, float camPitch) {
        if (a <= 0.001f || scale <= 1.0E-4f) {
            return;
        }
        ms.method_22903();
        ms.method_22904(x, y, z);
        ms.method_22907(class_7833.field_40716.rotationDegrees(-camYaw));
        ms.method_22907(class_7833.field_40714.rotationDegrees(camPitch));
        ms.method_22905(scale, scale, scale);
        Matrix4f m = ms.method_23760().method_23761();
        int ri = (int)(r * 255.0f);
        int gi = (int)(g * 255.0f);
        int bi = (int)(b * 255.0f);
        int ai = (int)(a * 255.0f);
        builder.method_22918(m, -0.5f, 0.5f, 0.0f).method_22913(0.0f, 1.0f).method_1336(ri, gi, bi, ai);
        builder.method_22918(m, 0.5f, 0.5f, 0.0f).method_22913(1.0f, 1.0f).method_1336(ri, gi, bi, ai);
        builder.method_22918(m, 0.5f, -0.5f, 0.0f).method_22913(1.0f, 0.0f).method_1336(ri, gi, bi, ai);
        builder.method_22918(m, -0.5f, -0.5f, 0.0f).method_22913(0.0f, 0.0f).method_1336(ri, gi, bi, ai);
        ms.method_22909();
    }

    private void restoreRenderState() {
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask((boolean)true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    private void renderChain(class_4587 ms, class_1309 target, float anim, float red, float partialTicks) {
        class_243 targetPos = CalcVector.lerpPosition((class_1297)target);
        float movingValue = this.getMovingValue();
        float gradusX = (float)(20.0 * Math.min(1.0 + Math.sin(Math.toRadians(movingValue)), 1.0));
        float gradusZ = (float)(20.0 * (Math.min(1.0 + Math.sin(Math.toRadians(movingValue)), 2.0) - 1.0));
        float width = target.method_17681() * 1.5f;
        int baseColor = this.colorSetting.getColor();
        int blendedColor = red > 0.0f ? ColorAssist.interpolateColor(baseColor, new Color(255, 0, 0).getRGB(), red) : baseColor;
        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        class_289 tess = class_289.method_1348();
        RenderSystem.depthMask((boolean)true);
        class_2960 chainTexture = class_2960.method_60655((String)"minecraft", (String)"textures/features/targetesp/chain.png");
        int linksStep = 18;
        int totalAngle = 720;
        float chainSize = 4.0f;
        float down = 1.0f;
        for (int chain = 0; chain < 2; ++chain) {
            float val = 1.2f - 0.5f * (chain == 0 ? 1.0f : 0.9f);
            ms.method_22903();
            ms.method_22904(targetPos.field_1352, targetPos.field_1351 + (double)(target.method_17682() / 2.0f) - 0.5, targetPos.field_1350);
            float x = 0.0f;
            float y = 0.0f;
            float z = 0.0f;
            ms.method_22907(class_7833.field_40718.rotationDegrees(chain == 0 ? gradusX : -gradusX));
            ms.method_22907(class_7833.field_40714.rotationDegrees(chain == 0 ? gradusZ : -gradusZ));
            Matrix4f matrix = ms.method_23760().method_23761();
            int alphaVal = class_3532.method_15340((int)((int)(anim * 255.0f)), (int)0, (int)255);
            RenderSystem.setShaderTexture((int)0, (class_2960)chainTexture);
            RenderSystem.setShader((class_10156)class_10142.field_53878);
            int color = ColorAssist.setAlpha(blendedColor, alphaVal);
            class_287 builder = tess.method_60827(class_293.class_5596.field_27382, class_290.field_20888);
            int modif = linksStep / 2;
            for (int i = 0; i < totalAngle; i += modif) {
                float prevSin = (float)((double)(x + (chain == 0 ? gradusX : -gradusX) / 100.0f) + Math.sin(Math.toRadians((float)(i - modif) + movingValue * 0.5f)) * (double)width * (double)val);
                float prevCos = (float)((double)(z + (chain == 0 ? -gradusZ : gradusZ) / 100.0f) + Math.cos(Math.toRadians((float)(i - modif) + movingValue * 0.5f)) * (double)width * (double)val);
                float sin = (float)((double)(x + (chain == 0 ? gradusX : -gradusX) / 100.0f) + Math.sin(Math.toRadians((float)i + movingValue * 0.5f)) * (double)width * (double)val);
                float cos = (float)((double)(z + (chain == 0 ? -gradusZ : gradusZ) / 100.0f) + Math.cos(Math.toRadians((float)i + movingValue * 0.5f)) * (double)width * (double)val);
                int r = ColorAssist.getRed(color);
                int g = ColorAssist.getGreen(color);
                int b = ColorAssist.getBlue(color);
                int a = ColorAssist.getAlpha(color);
                builder.method_22918(matrix, prevSin, y, prevCos).method_1336(r, g, b, a).method_22913(0.0027777778f * (float)(i - modif) * chainSize, 0.0f).method_60803(0xF000F0);
                builder.method_22918(matrix, sin, y, cos).method_1336(r, g, b, a).method_22913(0.0027777778f * (float)i * chainSize, 0.0f).method_60803(0xF000F0);
                builder.method_22918(matrix, sin, y + down, cos).method_1336(r, g, b, a).method_22913(0.0027777778f * (float)i * chainSize, 0.99f).method_60803(0xF000F0);
                builder.method_22918(matrix, prevSin, y + down, prevCos).method_1336(r, g, b, a).method_22913(0.0027777778f * (float)(i - modif) * chainSize, 0.99f).method_60803(0xF000F0);
            }
            class_286.method_43433((class_9801)builder.method_60800());
            ms.method_22909();
        }
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
    }

    private static class AnimatedCrystal {
        private final class_243 targetPosition;
        private final class_243 spawnDirection;
        private final float spawnDistance;
        private final float size;
        private final float spawnDelay;

        public AnimatedCrystal(class_243 targetPosition, float spawnDelay) {
            this.targetPosition = targetPosition;
            this.size = 0.065f;
            this.spawnDelay = spawnDelay;
            double angle = Math.random() * Math.PI * 2.0;
            double vertAngle = (Math.random() - 0.5) * Math.PI;
            this.spawnDirection = new class_243(Math.cos(angle) * Math.cos(vertAngle), Math.sin(vertAngle), Math.sin(angle) * Math.cos(vertAngle));
            this.spawnDistance = 2.0f + (float)(Math.random() * 1.5);
        }

        public void render(class_4587 ms, float anim, float red, float hitPull, class_4184 camera, float globalYawDegrees, long timeSinceSpawn) {
            float spawnProgress = Math.min(1.0f, Math.max(0.0f, ((float)timeSinceSpawn - this.spawnDelay * 150.0f) / 400.0f));
            float easeProgress = 1.0f - (1.0f - spawnProgress) * (1.0f - spawnProgress);
            if (spawnProgress <= 0.0f) {
                return;
            }
            float disappearProgress = 1.0f - anim;
            float disappearEase = disappearProgress * disappearProgress;
            float finalProgress = easeProgress * (1.0f - disappearEase);
            if (finalProgress <= 0.01f) {
                return;
            }
            class_243 currentPos = new class_243(this.targetPosition.field_1352 + this.spawnDirection.field_1352 * (double)this.spawnDistance * (double)(1.0f - finalProgress), this.targetPosition.field_1351 + this.spawnDirection.field_1351 * (double)this.spawnDistance * (double)(1.0f - finalProgress), this.targetPosition.field_1350 + this.spawnDirection.field_1350 * (double)this.spawnDistance * (double)(1.0f - finalProgress));
            ms.method_22903();
            float pullK = 1.0f - hitPull * 0.25f;
            ms.method_22904(currentPos.field_1352 * (double)pullK, currentPos.field_1351, currentPos.field_1350 * (double)pullK);
            double dx = -currentPos.field_1352;
            double dz = -currentPos.field_1350;
            float yawToCenter = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
            float centerY = 1.2f;
            float pitch = currentPos.field_1351 < (double)(centerY - 0.2f) ? 60.0f : (currentPos.field_1351 > (double)(centerY + 0.2f) ? 120.0f : 90.0f);
            ms.method_22907(class_7833.field_40716.rotationDegrees(-yawToCenter));
            ms.method_22907(class_7833.field_40714.rotationDegrees(pitch));
            float scaleAnim = finalProgress;
            ms.method_22905(scaleAnim, scaleAnim, scaleAnim);
            RenderSystem.disableCull();
            RenderSystem.enableBlend();
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShader((class_10156)class_10142.field_53876);
            int baseColor = ColorAssist.interpolateColor(ColorAssist.getClientColor(), new Color(255, 0, 0).getRGB(), red);
            float crystalAnim = finalProgress;
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
            this.drawCrystal(ms, baseColor, 0.2f, true, crystalAnim);
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
            this.drawCrystal(ms, baseColor, 0.3f, true, crystalAnim);
            this.drawCrystal(ms, baseColor, 0.8f, false, crystalAnim);
            RenderSystem.depthMask((boolean)false);
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
            ms.method_22903();
            ms.method_22905(1.2f, 1.2f, 1.2f);
            this.drawCrystal(ms, baseColor, 0.3f, true, crystalAnim);
            ms.method_22909();
            this.drawBloomSphere(ms, baseColor, crystalAnim, camera);
            RenderSystem.depthMask((boolean)true);
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
            RenderSystem.disableBlend();
            RenderSystem.enableCull();
            ms.method_22909();
        }

        private void drawBloomSphere(class_4587 ms, int baseColor, float anim, class_4184 camera) {
            class_287 bufferBuilder;
            Matrix4f matrix;
            float angle;
            int i;
            RenderSystem.setShader((class_10156)class_10142.field_53880);
            RenderSystem.setShaderTexture((int)0, (class_2960)class_2960.method_60654((String)"textures/features/particles/bloom.png"));
            RenderSystem.enableBlend();
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
            RenderSystem.depthMask((boolean)false);
            int bloomColor = ColorAssist.setAlpha(baseColor, (int)(10.0f * anim));
            float bloomSize = this.size * 13.0f;
            float pitch = camera.method_19329();
            float yaw = camera.method_19330();
            int segments = 6;
            for (i = 0; i < segments; ++i) {
                ms.method_22903();
                angle = 360.0f / (float)segments * (float)i;
                ms.method_22907(class_7833.field_40716.rotationDegrees(angle));
                ms.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
                ms.method_22907(class_7833.field_40714.rotationDegrees(pitch));
                matrix = ms.method_23760().method_23761();
                bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
                bufferBuilder.method_22918(matrix, -bloomSize / 2.0f, -bloomSize / 2.0f, 0.0f).method_22913(0.0f, 1.0f).method_39415(bloomColor);
                bufferBuilder.method_22918(matrix, bloomSize / 2.0f, -bloomSize / 2.0f, 0.0f).method_22913(1.0f, 1.0f).method_39415(bloomColor);
                bufferBuilder.method_22918(matrix, bloomSize / 2.0f, bloomSize / 2.0f, 0.0f).method_22913(1.0f, 0.0f).method_39415(bloomColor);
                bufferBuilder.method_22918(matrix, -bloomSize / 2.0f, bloomSize / 2.0f, 0.0f).method_22913(0.0f, 0.0f).method_39415(bloomColor);
                class_286.method_43433((class_9801)bufferBuilder.method_60800());
                ms.method_22909();
            }
            for (i = 0; i < segments; ++i) {
                ms.method_22903();
                angle = 360.0f / (float)segments * (float)i;
                ms.method_22907(class_7833.field_40714.rotationDegrees(90.0f));
                ms.method_22907(class_7833.field_40716.rotationDegrees(angle));
                ms.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
                ms.method_22907(class_7833.field_40714.rotationDegrees(pitch));
                matrix = ms.method_23760().method_23761();
                bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
                bufferBuilder.method_22918(matrix, -bloomSize / 2.0f, -bloomSize / 2.0f, 0.0f).method_22913(0.0f, 1.0f).method_39415(bloomColor);
                bufferBuilder.method_22918(matrix, bloomSize / 2.0f, -bloomSize / 2.0f, 0.0f).method_22913(1.0f, 1.0f).method_39415(bloomColor);
                bufferBuilder.method_22918(matrix, bloomSize / 2.0f, bloomSize / 2.0f, 0.0f).method_22913(1.0f, 0.0f).method_39415(bloomColor);
                bufferBuilder.method_22918(matrix, -bloomSize / 2.0f, bloomSize / 2.0f, 0.0f).method_22913(0.0f, 0.0f).method_39415(bloomColor);
                class_286.method_43433((class_9801)bufferBuilder.method_60800());
                ms.method_22909();
            }
            RenderSystem.depthMask((boolean)true);
            RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        }

        private void drawCrystal(class_4587 ms, int baseColor, float alpha, boolean filled, float anim) {
            class_243 b;
            class_243 a;
            int i;
            class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27379, class_290.field_1576);
            float s = this.size;
            float h = this.size * 2.2f;
            int finalColor = ColorAssist.setAlpha(baseColor, (int)(alpha * 255.0f * anim));
            class_243 vTop = new class_243(0.0, (double)h, 0.0);
            class_243 vBottom = new class_243(0.0, (double)(-h), 0.0);
            class_243[] mid = new class_243[]{new class_243((double)s, 0.0, 0.0), new class_243(0.0, 0.0, (double)s), new class_243((double)(-s), 0.0, 0.0), new class_243(0.0, 0.0, (double)(-s))};
            for (i = 0; i < 4; ++i) {
                a = mid[i];
                b = mid[(i + 1) % 4];
                this.drawTriangle(ms, bufferBuilder, vTop, a, b, finalColor, true);
            }
            for (i = 0; i < 4; ++i) {
                a = mid[(i + 1) % 4];
                b = mid[i];
                this.drawTriangle(ms, bufferBuilder, vBottom, a, b, finalColor, true);
            }
            class_286.method_43433((class_9801)bufferBuilder.method_60800());
        }

        private void drawTriangle(class_4587 ms, class_287 bb, class_243 v1, class_243 v2, class_243 v3, int color, boolean filled) {
            if (filled) {
                bb.method_22918(ms.method_23760().method_23761(), (float)v1.field_1352, (float)v1.field_1351, (float)v1.field_1350).method_39415(color);
                bb.method_22918(ms.method_23760().method_23761(), (float)v2.field_1352, (float)v2.field_1351, (float)v2.field_1350).method_39415(color);
                bb.method_22918(ms.method_23760().method_23761(), (float)v3.field_1352, (float)v3.field_1351, (float)v3.field_1350).method_39415(color);
            }
        }
    }
}

