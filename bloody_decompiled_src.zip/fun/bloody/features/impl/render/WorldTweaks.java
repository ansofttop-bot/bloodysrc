/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.render;

import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;

public class WorldTweaks
extends Module {
    public final MultiSelectSetting modeSetting = new MultiSelectSetting("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043c\u0438\u0440\u0430", "\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u043d\u0430\u0441\u0442\u0440\u043e\u0438\u0442\u044c \u043c\u0438\u0440").value("Time");
    public final SliderSettings timeSetting = new SliderSettings("\u0412\u0440\u0435\u043c\u044f", "\u0423\u0441\u0442\u0430\u043d\u0430\u0432\u043b\u0438\u0432\u0430\u0435\u0442 \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435 \u0432\u0440\u0435\u043c\u0435\u043d\u0438").setValue(12.0f).range(0, 24).visible(() -> this.modeSetting.isSelected("Time"));

    public static WorldTweaks getInstance() {
        return Instance.get(WorldTweaks.class);
    }

    public WorldTweaks() {
        super("WorldTweaks", "World Tweaks", ModuleCategory.RENDER);
        this.setup(this.modeSetting, this.timeSetting);
    }

    @Override
    public void deactivate() {
        super.deactivate();
    }
}

