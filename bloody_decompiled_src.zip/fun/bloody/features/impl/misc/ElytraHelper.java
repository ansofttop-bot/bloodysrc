/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1304
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_1802
 *  net.minecraft.class_3675
 */
package fun.bloody.features.impl.misc;

import antidaunleak.api.annotation.Native;
import fun.bloody.events.keyboard.KeyEvent;
import fun.bloody.events.player.InputEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.impl.movement.AutoSprint;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.chat.ChatMessage;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.interactions.inv.InventoryResult;
import fun.bloody.utils.interactions.inv.InventoryTask;
import fun.bloody.utils.interactions.inv.InventoryToolkit;
import fun.bloody.utils.math.script.Script;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1802;
import net.minecraft.class_3675;

public class ElytraHelper
extends Module {
    private final SelectSetting modeSetting = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "\u0421\u043f\u043e\u0441\u043e\u0431 \u0437\u0430\u043c\u0435\u043d\u044b").value("Default", "Legit").selected("Default");
    private final BindSetting elytraSetting = new BindSetting("\u0417\u0430\u043c\u0435\u043d\u0430 \u044d\u043b\u0438\u0442\u0440", "\u041c\u0435\u043d\u044f\u0435\u0442 \u043d\u0430\u0433\u0440\u0443\u0434\u043d\u0438\u043a \u043d\u0430 \u044d\u043b\u0438\u0442\u0440\u044b");
    private final BindSetting fireworkSetting = new BindSetting("\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a", "\u041c\u0435\u043d\u044f\u0435\u0442 \u0438 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442 \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a\u0438");
    private final BooleanSetting startSetting = new BooleanSetting("\u0411\u044b\u0441\u0442\u0440\u044b\u0439 \u0441\u0442\u0430\u0440\u0442", "\u041f\u0440\u0438 \u0437\u0430\u043c\u0435\u043d\u0435 \u043d\u0430 \u044d\u043b\u0438\u0442\u0440\u044b \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0432\u0437\u043b\u0435\u0442\u0430\u0435\u0442 \u0438 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442 \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a\u0438").setValue(false);
    private final BooleanSetting recast = new BooleanSetting("\u0410\u0432\u0442\u043e \u0432\u0437\u043b\u0435\u0442", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043d\u0430\u0447\u0438\u043d\u0430\u0435\u0442 \u043f\u043e\u043b\u0435\u0442").setValue(false);
    private final BooleanSetting autoFireworkSetting = new BooleanSetting("\u0410\u0432\u0442\u043e \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a \u043a\u0430\u0436\u0434\u044b\u0435 X \u043c\u0441").setValue(false);
    private final SliderSettings fireworkDelay = new SliderSettings("\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u044f \u0432 \u043c\u0441", "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u044f \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a\u0430 \u0432 \u043c\u0441").setValue(500.0f).range(10.0f, 1500.0f).visible(() -> this.autoFireworkSetting.isValue());
    private final Script script = new Script();
    private ElytraPhase elytraPhase = ElytraPhase.READY;
    private long actionStartTime = 0L;
    private class_1735 targetSlot = null;
    private boolean playerFullyStopped = false;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private boolean wasJumpPressed;
    private boolean keysOverridden = false;
    private FireworkPhase fireworkPhase = FireworkPhase.READY;
    private int fireworkSlot = -1;
    private int savedHotbarSlot = -1;
    private int originalHotbarSlot = -1;
    private long useDelayStartTime = 0L;
    private long lastAutoFireworkTime = 0L;

    public ElytraHelper() {
        super("ElytraHelper", "Elytra Helper", ModuleCategory.MISC);
        this.setup(this.modeSetting, this.elytraSetting, this.fireworkSetting, this.startSetting, this.recast, this.autoFireworkSetting, this.fireworkDelay);
    }

    @EventHandler
    public void onInput(InputEvent e) {
        if (ElytraHelper.mc.field_1724.method_6118(class_1304.field_6174).method_7909().equals(class_1802.field_8833) && this.recast.isValue()) {
            if (ElytraHelper.mc.field_1724.method_24828()) {
                e.setJumping(true);
            } else if (!ElytraHelper.mc.field_1724.method_6128()) {
                PlayerInteractionHelper.startFallFlying();
            }
        }
    }

    @EventHandler
    public void onKey(KeyEvent e) {
        if (!this.script.isFinished()) {
            return;
        }
        if (e.isKeyDown(this.elytraSetting.getKey())) {
            if (this.modeSetting.getSelected().equals("Default")) {
                this.executeDefaultSwap();
            } else if (this.modeSetting.getSelected().equals("Legit") && this.elytraPhase == ElytraPhase.READY) {
                this.startLegitSwap();
            }
        } else if (e.isKeyDown(this.fireworkSetting.getKey()) && ElytraHelper.mc.field_1724.method_6128() && this.fireworkPhase == FireworkPhase.READY) {
            this.fireworkPhase = FireworkPhase.START;
        }
    }

    @EventHandler
    @Native(type=Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        long now;
        this.script.update();
        if (this.elytraPhase != ElytraPhase.READY) {
            this.processLegitSwap();
        }
        if (this.fireworkPhase != FireworkPhase.READY) {
            if (this.modeSetting.getSelected().equals("Default")) {
                this.processDefaultFireworkUsage();
            } else {
                this.processLegitFireworkUsage();
            }
        }
        if (this.autoFireworkSetting.isValue() && ElytraHelper.mc.field_1724 != null && ElytraHelper.mc.field_1724.method_6128() && (now = System.currentTimeMillis()) - this.lastAutoFireworkTime >= (long)this.fireworkDelay.getValue() && this.fireworkPhase == FireworkPhase.READY && this.elytraPhase == ElytraPhase.READY) {
            if (this.modeSetting.getSelected().equals("Default")) {
                InventoryResult hotbar = InventoryToolkit.findItemInHotBar(class_1802.field_8639);
                if (hotbar.found()) {
                    InventoryTask.swapAndUse(class_1802.field_8639);
                    this.lastAutoFireworkTime = now;
                } else {
                    InventoryResult inv = InventoryToolkit.findItemInInventory(class_1802.field_8639);
                    if (inv.found()) {
                        int fireworkInvSlot = inv.slot();
                        int currentHotbarSlot = ElytraHelper.mc.field_1724.method_31548().field_7545;
                        InventoryToolkit.clickSlot(fireworkInvSlot, currentHotbarSlot, class_1713.field_7791);
                        PlayerInteractionHelper.interactItem(class_1268.field_5808);
                        InventoryToolkit.clickSlot(fireworkInvSlot, currentHotbarSlot, class_1713.field_7791);
                        this.lastAutoFireworkTime = now;
                    }
                }
            } else {
                this.fireworkPhase = FireworkPhase.START;
                this.lastAutoFireworkTime = now;
            }
        }
    }

    private void processDefaultFireworkUsage() {
        if (ElytraHelper.mc.field_1724 == null) {
            this.resetFireworkState();
            return;
        }
        InventoryResult hotbar = InventoryToolkit.findItemInHotBar(class_1802.field_8639);
        if (hotbar.found()) {
            InventoryTask.swapAndUse(class_1802.field_8639);
        } else {
            InventoryResult inv = InventoryToolkit.findItemInInventory(class_1802.field_8639);
            if (inv.found()) {
                int fireworkInvSlot = inv.slot();
                int currentHotbarSlot = ElytraHelper.mc.field_1724.method_31548().field_7545;
                InventoryToolkit.clickSlot(fireworkInvSlot, currentHotbarSlot, class_1713.field_7791);
                PlayerInteractionHelper.interactItem(class_1268.field_5808);
                InventoryToolkit.clickSlot(fireworkInvSlot, currentHotbarSlot, class_1713.field_7791);
            } else {
                ChatMessage.brandmessage("\u041d\u0435\u0442\u0443 \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a\u043e\u0432");
            }
        }
        this.resetFireworkState();
    }

    private void processLegitFireworkUsage() {
        if (ElytraHelper.mc.field_1724 == null || ElytraHelper.mc.field_1755 != null) {
            this.resetFireworkState();
            return;
        }
        switch (this.fireworkPhase.ordinal()) {
            case 1: {
                this.originalHotbarSlot = ElytraHelper.mc.field_1724.method_31548().field_7545;
                InventoryResult hotbar = InventoryToolkit.findItemInHotBar(class_1802.field_8639);
                if (hotbar.found()) {
                    this.savedHotbarSlot = hotbar.slot();
                    InventoryToolkit.switchTo(this.savedHotbarSlot);
                    this.useDelayStartTime = System.currentTimeMillis();
                    this.fireworkPhase = FireworkPhase.WAITING_TO_USE;
                    break;
                }
                InventoryResult inv = InventoryToolkit.findItemInInventory(class_1802.field_8639);
                if (inv.found()) {
                    this.fireworkSlot = inv.slot();
                    this.savedHotbarSlot = this.originalHotbarSlot;
                    this.fireworkPhase = FireworkPhase.SWAP_TO_HOTBAR;
                    break;
                }
                ChatMessage.brandmessage("\u041d\u0435\u0442\u0443 \u0444\u0435\u0439\u0435\u0440\u0432\u0435\u0440\u043a\u043e\u0432");
                this.resetFireworkState();
                break;
            }
            case 2: {
                InventoryToolkit.clickSlot(this.fireworkSlot, this.savedHotbarSlot, class_1713.field_7791);
                this.useDelayStartTime = System.currentTimeMillis();
                this.fireworkPhase = FireworkPhase.WAITING_TO_USE;
                break;
            }
            case 3: {
                if (System.currentTimeMillis() - this.useDelayStartTime <= 20L) break;
                this.fireworkPhase = FireworkPhase.USE_FIREWORK;
                break;
            }
            case 4: {
                if (ElytraHelper.mc.field_1724.method_6047().method_7909() == class_1802.field_8639) {
                    PlayerInteractionHelper.interactItem(class_1268.field_5808);
                }
                this.fireworkPhase = this.fireworkSlot != -1 ? FireworkPhase.SWAP_BACK_TO_INV : FireworkPhase.FINISH;
                break;
            }
            case 5: {
                InventoryToolkit.clickSlot(this.fireworkSlot, this.savedHotbarSlot, class_1713.field_7791);
                this.fireworkPhase = FireworkPhase.FINISH;
                break;
            }
            case 6: {
                this.resetFireworkState();
            }
        }
    }

    private void resetFireworkState() {
        if (this.originalHotbarSlot != -1 && ElytraHelper.mc.field_1724 != null) {
            InventoryToolkit.switchTo(this.originalHotbarSlot);
        }
        this.fireworkPhase = FireworkPhase.READY;
        this.fireworkSlot = -1;
        this.savedHotbarSlot = -1;
        this.originalHotbarSlot = -1;
        this.useDelayStartTime = 0L;
    }

    private void executeDefaultSwap() {
        class_1735 slot = this.chestPlate();
        if (slot != null) {
            class_1735 fireWork = InventoryTask.getSlot(class_1802.field_8639);
            boolean elytra = slot.method_7677().method_7909().equals(class_1802.field_8833);
            InventoryTask.moveItem(slot, 6, false, true);
            if (this.startSetting.isValue() && fireWork != null && elytra) {
                this.script.cleanup().addTickStep(4, () -> {
                    if (ElytraHelper.mc.field_1724.method_24828()) {
                        ElytraHelper.mc.field_1724.method_6043();
                    }
                }).addTickStep(3, () -> {
                    PlayerInteractionHelper.startFallFlying();
                    InventoryTask.swapAndUse(class_1802.field_8639);
                });
            }
        }
    }

    private void startLegitSwap() {
        this.targetSlot = this.chestPlate();
        if (this.targetSlot == null) {
            return;
        }
        this.wasForwardPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1894.method_1429().method_1444());
        this.wasBackPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1881.method_1429().method_1444());
        this.wasLeftPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1913.method_1429().method_1444());
        this.wasRightPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1849.method_1429().method_1444());
        this.wasJumpPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1903.method_1429().method_1444());
        this.elytraPhase = ElytraPhase.SLOWING_DOWN;
        this.actionStartTime = System.currentTimeMillis();
        this.playerFullyStopped = false;
        this.keysOverridden = false;
    }

    private void processLegitSwap() {
        if (ElytraHelper.mc.field_1724 == null || ElytraHelper.mc.field_1755 != null) {
            this.resetLegitState();
            return;
        }
        long elapsed = System.currentTimeMillis() - this.actionStartTime;
        switch (this.elytraPhase.ordinal()) {
            case 1: {
                ElytraHelper.mc.field_1724.field_3913.field_3905 = 0.0f;
                ElytraHelper.mc.field_1724.field_3913.field_3907 = 0.0f;
                if (ElytraHelper.mc.field_1724.method_5624()) {
                    ElytraHelper.mc.field_1724.method_5728(false);
                    AutoSprint.tickStop = 1;
                }
                if (!this.keysOverridden) {
                    ElytraHelper.mc.field_1690.field_1894.method_23481(false);
                    ElytraHelper.mc.field_1690.field_1881.method_23481(false);
                    ElytraHelper.mc.field_1690.field_1913.method_23481(false);
                    ElytraHelper.mc.field_1690.field_1849.method_23481(false);
                    ElytraHelper.mc.field_1690.field_1903.method_23481(false);
                    this.keysOverridden = true;
                }
                if (elapsed <= 1L) break;
                this.elytraPhase = ElytraPhase.WAITING_STOP;
                break;
            }
            case 2: {
                ElytraHelper.mc.field_1724.field_3913.field_3905 = 0.0f;
                ElytraHelper.mc.field_1724.field_3913.field_3907 = 0.0f;
                double velocityX = Math.abs(ElytraHelper.mc.field_1724.method_18798().field_1352);
                double velocityZ = Math.abs(ElytraHelper.mc.field_1724.method_18798().field_1350);
                if (!(velocityX < 0.001 && velocityZ < 0.001) && elapsed <= 1L) break;
                this.playerFullyStopped = true;
                this.elytraPhase = ElytraPhase.SWAP;
                break;
            }
            case 3: {
                if (!this.playerFullyStopped) break;
                if (this.targetSlot != null) {
                    class_1735 fireWork;
                    boolean elytra = this.targetSlot.method_7677().method_7909().equals(class_1802.field_8833);
                    InventoryTask.moveItem(this.targetSlot, 6, false, false);
                    if (this.startSetting.isValue() && elytra && (fireWork = InventoryTask.getSlot(class_1802.field_8639)) != null) {
                        this.script.cleanup().addTickStep(2, () -> {
                            if (ElytraHelper.mc.field_1724.method_24828()) {
                                ElytraHelper.mc.field_1724.method_6043();
                            }
                        }).addTickStep(1, () -> {
                            PlayerInteractionHelper.startFallFlying();
                            InventoryTask.swapAndUse(class_1802.field_8639);
                        });
                    }
                }
                this.elytraPhase = ElytraPhase.SPEEDING_UP;
                this.actionStartTime = System.currentTimeMillis();
                if (!this.keysOverridden) break;
                this.restoreKeyStates();
                break;
            }
            case 4: {
                long speedupElapsed = System.currentTimeMillis() - this.actionStartTime;
                float speedupProgress = Math.min(1.0f, (float)speedupElapsed / 1.0f);
                if (ElytraHelper.mc.field_1724.field_3913 != null) {
                    boolean forward = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1894.method_1429().method_1444());
                    float targetForward = forward ? 1.0f : 0.0f;
                    ElytraHelper.mc.field_1724.field_3913.field_3905 = this.lerp(ElytraHelper.mc.field_1724.field_3913.field_3905, targetForward * speedupProgress, 0.4f);
                    if (speedupProgress > 0.4f && forward && !ElytraHelper.mc.field_1724.method_5624()) {
                        ElytraHelper.mc.field_1724.method_5728(true);
                    }
                }
                if (speedupElapsed <= 1L) break;
                this.elytraPhase = ElytraPhase.FINISHED;
                break;
            }
            case 5: {
                this.resetLegitState();
            }
        }
    }

    private void restoreKeyStates() {
        boolean currentForward = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1894.method_1429().method_1444());
        boolean currentBack = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1881.method_1429().method_1444());
        boolean currentLeft = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1913.method_1429().method_1444());
        boolean currentRight = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1849.method_1429().method_1444());
        boolean currentJump = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ElytraHelper.mc.field_1690.field_1903.method_1429().method_1444());
        ElytraHelper.mc.field_1690.field_1894.method_23481(this.wasForwardPressed && currentForward);
        ElytraHelper.mc.field_1690.field_1881.method_23481(this.wasBackPressed && currentBack);
        ElytraHelper.mc.field_1690.field_1913.method_23481(this.wasLeftPressed && currentLeft);
        ElytraHelper.mc.field_1690.field_1849.method_23481(this.wasRightPressed && currentRight);
        ElytraHelper.mc.field_1690.field_1903.method_23481(this.wasJumpPressed && currentJump);
        this.keysOverridden = false;
    }

    private float lerp(float start, float end, float delta) {
        return start + (end - start) * delta;
    }

    private void resetLegitState() {
        if (this.keysOverridden) {
            this.restoreKeyStates();
        }
        this.elytraPhase = ElytraPhase.READY;
        this.targetSlot = null;
        this.playerFullyStopped = false;
    }

    private class_1735 chestPlate() {
        if (Objects.requireNonNull(ElytraHelper.mc.field_1724).method_6118(class_1304.field_6174).method_7909().equals(class_1802.field_8833)) {
            return InventoryTask.getSlot(List.of(class_1802.field_22028, class_1802.field_8058, class_1802.field_8523, class_1802.field_8678, class_1802.field_8873, class_1802.field_8577));
        }
        return InventoryTask.getSlot(class_1802.field_8833);
    }

    static enum ElytraPhase {
        READY,
        SLOWING_DOWN,
        WAITING_STOP,
        SWAP,
        SPEEDING_UP,
        FINISHED;

    }

    static enum FireworkPhase {
        READY,
        START,
        SWAP_TO_HOTBAR,
        WAITING_TO_USE,
        USE_FIREWORK,
        SWAP_BACK_TO_INV,
        FINISH;

    }
}

