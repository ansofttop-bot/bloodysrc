/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_1268
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2561
 *  net.minecraft.class_3675
 *  net.minecraft.class_5250
 *  org.lwjgl.glfw.GLFW
 */
package fun.bloody.features.impl.misc;

import fun.bloody.display.hud.CoolDowns;
import fun.bloody.display.hud.Notifications;
import fun.bloody.events.player.RotationUpdateEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.chat.StringHelper;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.GradientAssist;
import fun.bloody.utils.interactions.inv.InventoryTask;
import fun.bloody.utils.math.time.StopWatch;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3675;
import net.minecraft.class_5250;
import org.lwjgl.glfw.GLFW;

public class ReallyworldAssist
extends Module {
    private final List<KeyBind> keyBindings = new ArrayList<KeyBind>();
    private final List<String> potionQueue = new ArrayList<String>();
    private final StopWatch potionTimer = new StopWatch();
    private final Map<String, ItemInfo> itemConfig = new HashMap<String, ItemInfo>();
    private final Map<String, Boolean> itemStates = new HashMap<String, Boolean>();
    private final Map<String, Boolean> lastKeyStates = new HashMap<String, Boolean>();
    private final Map<String, Boolean> keyPressedThisTick = new HashMap<String, Boolean>();
    private int originalSlot = -1;
    private int targetSlot = -1;
    private ActionState actionState = ActionState.IDLE;
    private long actionTimer = 0L;
    private String pendingItemKey = null;
    private long stopMovementUntil = 0L;
    private boolean keysOverridden = false;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private int originalSourceSlot = -1;

    public static ReallyworldAssist getInstance() {
        return Instance.get(ReallyworldAssist.class);
    }

    public ReallyworldAssist() {
        super("Reallyworld Assist", "Reallyworld Assist", ModuleCategory.MISC);
        this.initialize();
    }

    public void initialize() {
        this.keyBindings.add(new KeyBind(class_1802.field_8450, new BindSetting("\u0410\u043d\u0442\u0438 \u043f\u043e\u043b\u0435\u0442", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0430\u043d\u0442\u0438 \u043f\u043e\u043b\u0435\u0442\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8498, new BindSetting("\u0421\u0432\u0438\u0442\u043e\u043a \u043e\u043f\u044b\u0442\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0441\u0432\u0438\u0442\u043a\u0430 \u043e\u043f\u044b\u0442\u0430"), 0.0f));
        this.keyBindings.forEach(bind -> this.setup(bind.setting));
        this.itemConfig.put("antiflight", new ItemInfo("\u0430\u043d\u0442\u0438 \u043f\u043e\u043b\u0435\u0442", class_1802.field_8450, "\u0410\u043d\u0442\u0438 \u043f\u043e\u043b\u0435\u0442"));
        this.itemConfig.put("expscroll", new ItemInfo("\u0441\u0432\u0438\u0442\u043e\u043a \u043e\u043f\u044b\u0442\u0430", class_1802.field_8498, "\u0421\u0432\u0438\u0442\u043e\u043a \u043e\u043f\u044b\u0442\u0430"));
        this.itemConfig.keySet().forEach(key -> {
            this.itemStates.put((String)key, false);
            this.lastKeyStates.put((String)key, false);
            this.keyPressedThisTick.put((String)key, false);
        });
    }

    @Override
    public void activate() {
        this.potionQueue.clear();
        this.potionTimer.reset();
        this.itemStates.replaceAll((k, v) -> false);
        this.lastKeyStates.replaceAll((k, v) -> false);
        this.keyPressedThisTick.replaceAll((k, v) -> false);
        this.actionState = ActionState.IDLE;
        this.originalSlot = -1;
        this.targetSlot = -1;
        this.originalSourceSlot = -1;
        this.pendingItemKey = null;
        this.stopMovementUntil = 0L;
        this.keysOverridden = false;
    }

    @Override
    public void deactivate() {
        this.itemStates.replaceAll((k, v) -> false);
        this.lastKeyStates.replaceAll((k, v) -> false);
        this.keyPressedThisTick.replaceAll((k, v) -> false);
        this.potionQueue.clear();
        this.potionTimer.reset();
        this.actionState = ActionState.IDLE;
        this.originalSlot = -1;
        this.targetSlot = -1;
        this.originalSourceSlot = -1;
        this.pendingItemKey = null;
        this.stopMovementUntil = 0L;
        if (this.keysOverridden) {
            ReallyworldAssist.mc.field_1690.field_1894.method_23481(false);
            ReallyworldAssist.mc.field_1690.field_1881.method_23481(false);
            ReallyworldAssist.mc.field_1690.field_1913.method_23481(false);
            ReallyworldAssist.mc.field_1690.field_1849.method_23481(false);
        }
        this.keysOverridden = false;
    }

    @EventHandler
    public void onRotationUpdate(RotationUpdateEvent e) {
        String potionKey;
        ItemInfo info;
        boolean noMoveOrAction;
        if (e.getType() != 0 || ReallyworldAssist.mc.field_1755 != null) {
            return;
        }
        boolean bl = noMoveOrAction = System.currentTimeMillis() < this.stopMovementUntil || this.actionState != ActionState.IDLE && this.actionState != ActionState.SPEEDING_UP;
        if (noMoveOrAction) {
            ReallyworldAssist.mc.field_1690.field_1894.method_23481(false);
            ReallyworldAssist.mc.field_1690.field_1881.method_23481(false);
            ReallyworldAssist.mc.field_1690.field_1913.method_23481(false);
            ReallyworldAssist.mc.field_1690.field_1849.method_23481(false);
            if (ReallyworldAssist.mc.field_1724.field_3913 != null) {
                ReallyworldAssist.mc.field_1724.field_3913.field_3905 = 0.0f;
                ReallyworldAssist.mc.field_1724.field_3913.field_3907 = 0.0f;
            }
            if (ReallyworldAssist.mc.field_1724.method_5624()) {
                ReallyworldAssist.mc.field_1724.method_5728(false);
            }
        }
        for (KeyBind bind : this.keyBindings) {
            ItemInfo info2;
            String key;
            if ((key = (switch (bind.setting.getName()) {
                case "\u0410\u043d\u0442\u0438 \u043f\u043e\u043b\u0435\u0442" -> "antiflight";
                case "\u0421\u0432\u0438\u0442\u043e\u043a \u043e\u043f\u044b\u0442\u0430" -> "expscroll";
                default -> null;
            })) == null || !bind.setting.isVisible()) continue;
            boolean currentKey = false;
            if (bind.setting.getKey() != -1) {
                currentKey = bind.setting.getKey() >= 0 && bind.setting.getKey() <= 7 ? GLFW.glfwGetMouseButton((long)mc.method_22683().method_4490(), (int)bind.setting.getKey()) == 1 : class_3675.method_15987((long)mc.method_22683().method_4490(), (int)bind.setting.getKey());
            }
            boolean wasPressedLastTick = this.lastKeyStates.getOrDefault(key, false);
            if (currentKey && !wasPressedLastTick && (info2 = this.itemConfig.get(key)) != null) {
                class_1735 slot = InventoryTask.getSlot(s -> s.method_7677().method_7909().equals(info.item) && InventoryTask.getCleanName(s.method_7677().method_7964()).contains(info.searchName.toLowerCase()));
                boolean addStarPrefix = false;
                if (slot != null) {
                    class_1799 stack = slot.method_7677();
                    if (ReallyworldAssist.mc.field_1724.method_7357().method_7904(stack)) {
                        CoolDowns.getInstance().list.stream().filter(c -> c.item().equals(info.item)).findFirst().ifPresent(coolDown -> {
                            int time = Math.toIntExact(-coolDown.time().elapsedTime() / 1000L);
                            String duration = StringHelper.getDuration(time);
                            class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u0431\u0443\u0434\u0435\u0442  \u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d  \u0447\u0435\u0440\u0435\u0437 ").method_10852((class_2561)class_2561.method_43470((String)duration).method_27692(class_124.field_1080));
                            Notifications.getInstance().addList((class_2561)text, 4000L);
                        });
                    } else if (!this.potionQueue.contains(key)) {
                        this.potionQueue.add(key);
                    }
                } else {
                    class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info2.displayName, GradientAssist.getGradientColors(info2.displayName), addStarPrefix)).method_27693("  \u043d\u0435  \u043d\u0430\u0439\u0434\u0435\u043d\u043e");
                    Notifications.getInstance().addList((class_2561)text, 4000L);
                }
            }
            this.lastKeyStates.put(key, currentKey);
            this.keyPressedThisTick.put(key, currentKey);
        }
        if (this.actionState != ActionState.IDLE) {
            this.processItemAction();
        }
        if (this.actionState == ActionState.IDLE && !this.potionQueue.isEmpty() && this.potionTimer.finished(150.0) && (info = this.itemConfig.get(potionKey = this.potionQueue.remove(0))) != null) {
            class_1735 slot = InventoryTask.getSlot(s -> s.method_7677().method_7909().equals(info.item) && InventoryTask.getCleanName(s.method_7677().method_7964()).contains(info.searchName.toLowerCase()));
            boolean addStarPrefix = false;
            if (slot != null) {
                class_1799 stack = slot.method_7677();
                if (!ReallyworldAssist.mc.field_1724.method_7357().method_7904(stack)) {
                    this.startItemUse(slot, info, addStarPrefix);
                } else {
                    CoolDowns.getInstance().list.stream().filter(c -> c.item().equals(info.item)).findFirst().ifPresent(coolDown -> {
                        int time = Math.toIntExact(-coolDown.time().elapsedTime() / 1000L);
                        String duration = StringHelper.getDuration(time);
                        class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u0431\u0443\u0434\u0435\u0442  \u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d  \u0447\u0435\u0440\u0435\u0437 ").method_10852((class_2561)class_2561.method_43470((String)duration).method_27692(class_124.field_1080));
                        Notifications.getInstance().addList((class_2561)text, 4000L);
                    });
                }
            } else {
                class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u043d\u0435  \u043d\u0430\u0439\u0434\u0435\u043d\u043e");
                Notifications.getInstance().addList((class_2561)text, 4000L);
            }
            this.potionTimer.reset();
        }
    }

    private void startItemUse(class_1735 slot, ItemInfo info, boolean addStarPrefix) {
        this.originalSlot = ReallyworldAssist.mc.field_1724.method_31548().field_7545;
        this.originalSourceSlot = slot.field_7874;
        this.targetSlot = slot.field_7874;
        this.pendingItemKey = info.searchName;
        boolean needsSwap = !(slot.field_7874 >= 0 && slot.field_7874 < 9 || slot.field_7874 >= 36 && slot.field_7874 < 45);
        this.wasForwardPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ReallyworldAssist.mc.field_1690.field_1894.method_1429().method_1444());
        this.wasBackPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ReallyworldAssist.mc.field_1690.field_1881.method_1429().method_1444());
        this.wasLeftPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ReallyworldAssist.mc.field_1690.field_1913.method_1429().method_1444());
        this.wasRightPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)ReallyworldAssist.mc.field_1690.field_1849.method_1429().method_1444());
        this.actionState = ActionState.SLOWING_DOWN;
        this.actionTimer = System.currentTimeMillis();
        this.stopMovementUntil = System.currentTimeMillis() + 300L;
        this.keysOverridden = true;
        ReallyworldAssist.mc.field_1690.field_1894.method_23481(false);
        ReallyworldAssist.mc.field_1690.field_1881.method_23481(false);
        ReallyworldAssist.mc.field_1690.field_1913.method_23481(false);
        ReallyworldAssist.mc.field_1690.field_1849.method_23481(false);
        class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0430");
        Notifications.getInstance().addList((class_2561)text, 4000L);
    }

    private void processItemAction() {
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - this.actionTimer;
        switch (this.actionState.ordinal()) {
            case 1: {
                ReallyworldAssist.mc.field_1724.field_3913.field_3905 = 0.0f;
                ReallyworldAssist.mc.field_1724.field_3913.field_3907 = 0.0f;
                if (ReallyworldAssist.mc.field_1724.method_5624()) {
                    ReallyworldAssist.mc.field_1724.method_5728(false);
                }
                if (elapsed <= 50L) break;
                this.actionState = ActionState.WAITING_STOP;
                this.actionTimer = currentTime;
                break;
            }
            case 2: {
                ReallyworldAssist.mc.field_1724.field_3913.field_3905 = 0.0f;
                ReallyworldAssist.mc.field_1724.field_3913.field_3907 = 0.0f;
                double velocityX = Math.abs(ReallyworldAssist.mc.field_1724.method_18798().field_1352);
                double velocityZ = Math.abs(ReallyworldAssist.mc.field_1724.method_18798().field_1350);
                if (!(velocityX < 0.05 && velocityZ < 0.05) && elapsed <= 100L) break;
                this.actionState = ActionState.SWAP_TO_ITEM;
                this.actionTimer = currentTime;
                break;
            }
            case 3: {
                if (elapsed <= 50L) break;
                if (this.targetSlot >= 0 && this.targetSlot < 9) {
                    ReallyworldAssist.mc.field_1724.method_31548().field_7545 = this.targetSlot;
                } else if (this.targetSlot >= 36 && this.targetSlot < 45) {
                    int hotbarSlot;
                    ReallyworldAssist.mc.field_1724.method_31548().field_7545 = hotbarSlot = this.targetSlot - 36;
                    this.targetSlot = hotbarSlot;
                } else {
                    int swapSlot = 8;
                    InventoryTask.clickSlot(this.targetSlot, swapSlot, class_1713.field_7791, false);
                    this.targetSlot = swapSlot;
                    ReallyworldAssist.mc.field_1724.method_31548().field_7545 = swapSlot;
                }
                this.actionState = ActionState.USE_ITEM;
                this.actionTimer = currentTime;
                break;
            }
            case 4: {
                if (elapsed <= 80L) break;
                class_1799 heldItem = ReallyworldAssist.mc.field_1724.method_6047();
                if (!heldItem.method_7960() && ReallyworldAssist.mc.field_1724.method_31548().field_7545 == this.targetSlot) {
                    ReallyworldAssist.mc.field_1761.method_2919((class_1657)ReallyworldAssist.mc.field_1724, class_1268.field_5808);
                }
                this.actionState = ActionState.SWAP_BACK;
                this.actionTimer = currentTime;
                break;
            }
            case 5: {
                boolean wasFromInventory;
                if (elapsed <= 50L) break;
                boolean bl = wasFromInventory = !(this.originalSourceSlot >= 0 && this.originalSourceSlot < 9 || this.originalSourceSlot >= 36 && this.originalSourceSlot < 45);
                if (wasFromInventory) {
                    if (this.targetSlot >= 0 && this.targetSlot < 9) {
                        InventoryTask.clickSlot(this.originalSourceSlot, this.targetSlot, class_1713.field_7791, false);
                    }
                } else if (this.originalSourceSlot >= 36 && this.originalSourceSlot < 45) {
                    int hotbarSlot = this.originalSourceSlot - 36;
                    if (this.targetSlot != hotbarSlot) {
                        ReallyworldAssist.mc.field_1724.method_31548().field_7545 = hotbarSlot;
                    }
                } else if (this.originalSourceSlot >= 0 && this.originalSourceSlot < 9 && this.targetSlot != this.originalSourceSlot) {
                    ReallyworldAssist.mc.field_1724.method_31548().field_7545 = this.originalSourceSlot;
                }
                if (ReallyworldAssist.mc.field_1724.method_31548().field_7545 != this.originalSlot) {
                    ReallyworldAssist.mc.field_1724.method_31548().field_7545 = this.originalSlot;
                }
                this.restoreKeyStates();
                this.actionState = ActionState.SPEEDING_UP;
                this.actionTimer = currentTime;
                break;
            }
            case 6: {
                long speedupElapsed = currentTime - this.actionTimer;
                if (speedupElapsed <= 80L) break;
                this.actionState = ActionState.IDLE;
                this.originalSlot = -1;
                this.targetSlot = -1;
                this.originalSourceSlot = -1;
                this.pendingItemKey = null;
            }
        }
    }

    private void restoreKeyStates() {
        if (!this.keysOverridden) {
            return;
        }
        ReallyworldAssist.mc.field_1690.field_1894.method_23481(this.wasForwardPressed);
        ReallyworldAssist.mc.field_1690.field_1881.method_23481(this.wasBackPressed);
        ReallyworldAssist.mc.field_1690.field_1913.method_23481(this.wasLeftPressed);
        ReallyworldAssist.mc.field_1690.field_1849.method_23481(this.wasRightPressed);
        if (ReallyworldAssist.mc.field_1724.field_3913 != null) {
            if (this.wasForwardPressed) {
                ReallyworldAssist.mc.field_1724.field_3913.field_3905 = 1.0f;
                if (!ReallyworldAssist.mc.field_1724.method_5624()) {
                    ReallyworldAssist.mc.field_1724.method_5728(true);
                }
            }
            if (this.wasBackPressed) {
                ReallyworldAssist.mc.field_1724.field_3913.field_3905 = -1.0f;
            }
            if (this.wasLeftPressed) {
                ReallyworldAssist.mc.field_1724.field_3913.field_3907 = 1.0f;
            }
            if (this.wasRightPressed) {
                ReallyworldAssist.mc.field_1724.field_3913.field_3907 = -1.0f;
            }
        }
        this.keysOverridden = false;
    }

    public List<KeyBind> getKeyBindings() {
        return this.keyBindings;
    }

    public BindSetting getSetting(String name) {
        return this.keyBindings.stream().filter(bind -> bind.setting().getName().equals(name)).map(KeyBind::setting).findFirst().orElse(null);
    }

    private static enum ActionState {
        IDLE,
        SLOWING_DOWN,
        WAITING_STOP,
        SWAP_TO_ITEM,
        USE_ITEM,
        SWAP_BACK,
        SPEEDING_UP;

    }

    public record KeyBind(class_1792 item, BindSetting setting, float distance) {
    }

    private static class ItemInfo {
        String searchName;
        class_1792 item;
        String displayName;

        ItemInfo(String searchName, class_1792 item, String displayName) {
            this.searchName = searchName;
            this.item = item;
            this.displayName = displayName;
        }
    }
}

