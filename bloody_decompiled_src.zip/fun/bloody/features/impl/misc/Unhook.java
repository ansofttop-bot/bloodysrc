/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.misc;

import fun.bloody.Bloody;
import fun.bloody.commands.CommandDispatcher;
import fun.bloody.events.chat.ChatEvent;
import fun.bloody.events.chat.TabCompleteEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.managers.event.EventHandler;
import java.io.File;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;

public class Unhook
extends Module {
    public static boolean unhooked = false;

    public Unhook() {
        super("Unhook", "Unhook", ModuleCategory.MISC);
        this.setType(0);
    }

    @Override
    public void activate() {
        unhooked = true;
        Bloody.getInstance().getDiscordManager().stopRPC();
        for (Module module : Bloody.getInstance().getModuleProvider().getModules()) {
            if (module == this || !module.isState()) continue;
            module.setState(false);
        }
        for (Module module : Bloody.getInstance().getModuleProvider().getModules()) {
            module.setKey(-1);
        }
        if (Unhook.mc.field_1755 != null) {
            mc.method_1507(null);
        }
        this.deleteBloodyFolder();
        super.activate();
    }

    private void deleteBloodyFolder() {
        try {
            File richFolder;
            File tabParserFile;
            File runDir = Unhook.mc.field_1697;
            File bloodyFolder = new File(runDir, "Bloody");
            if (bloodyFolder.exists() && bloodyFolder.isDirectory()) {
                this.deleteDirectory(bloodyFolder.toPath());
            }
            if ((tabParserFile = new File(runDir, "tabparser_results.txt")).exists()) {
                tabParserFile.delete();
            }
            if ((richFolder = new File(runDir, "Rich")).exists() && richFolder.isDirectory()) {
                this.deleteDirectory(richFolder.toPath());
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void deleteDirectory(Path path) {
        try {
            Files.walk(path, new FileVisitOption[0]).sorted(Comparator.reverseOrder()).map(Path::toFile).forEach(File::delete);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @EventHandler
    public void onSendMessage(ChatEvent event) {
        if (!this.isState()) {
            String message = event.getMessage();
            Bloody.getInstance().getCommandDispatcher();
            if (message.startsWith(CommandDispatcher.prefix)) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onTabComplete(TabCompleteEvent event) {
        if (!this.isState()) {
            String input = event.prefix;
            Bloody.getInstance().getCommandDispatcher();
            if (input.startsWith(CommandDispatcher.prefix)) {
                event.setCancelled(true);
            }
        } else {
            event.setCancelled(true);
            event.completions = new String[0];
        }
    }

    @Override
    public void deactivate() {
        if (unhooked) {
            this.state = true;
        }
    }
}

