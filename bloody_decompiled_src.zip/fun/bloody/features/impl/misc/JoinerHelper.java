/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_1759
 *  net.minecraft.class_1799
 *  net.minecraft.class_2596
 *  net.minecraft.class_2661
 *  net.minecraft.class_2886
 *  net.minecraft.class_437
 *  net.minecraft.class_476
 *  org.lwjgl.glfw.GLFW
 */
package fun.bloody.features.impl.misc;

import antidaunleak.api.annotation.Native;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.client.packet.network.Network;
import fun.bloody.utils.interactions.inv.InventoryTask;
import net.minecraft.class_1268;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1759;
import net.minecraft.class_1799;
import net.minecraft.class_2596;
import net.minecraft.class_2661;
import net.minecraft.class_2886;
import net.minecraft.class_437;
import net.minecraft.class_476;
import org.lwjgl.glfw.GLFW;

public class JoinerHelper
extends Module {
    private final SelectSetting serverSelection = new SelectSetting("\u0421\u0435\u0440\u0432\u0435\u0440", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0446\u0435\u043b\u0435\u0432\u043e\u0439 \u0441\u0435\u0440\u0432\u0435\u0440").value("ReallyWorld", "SpookyTime Duels").selected("ReallyWorld");
    private final SliderSettings griefSelection = new SliderSettings("\u041d\u043e\u043c\u0435\u0440 \u0433\u0440\u0438\u0444\u0430", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043d\u043e\u043c\u0435\u0440 \u0441\u0435\u0440\u0432\u0435\u0440\u0430 \u0434\u043b\u044f \u0433\u0440\u0438\u0444\u0430").setValue(1.0f).range(1, 54).visible(() -> this.serverSelection.isSelected("ReallyWorld"));
    private long lastActionTime;
    private boolean isToggling;
    private boolean retryDuels;
    private String lastWorldName;
    private int lastCompassSlot = -1;

    public static JoinerHelper getInstance() {
        return Instance.get(JoinerHelper.class);
    }

    public JoinerHelper() {
        super("JoinerHelper", "Joiner Helper", ModuleCategory.MISC);
        this.setup(this.serverSelection, this.griefSelection);
    }

    @EventHandler
    @Native(type=Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent event) {
        block13: {
            block15: {
                block14: {
                    if (!this.state) {
                        return;
                    }
                    if (GLFW.glfwGetKey((long)mc.method_22683().method_4490(), (int)260) == 1) {
                        this.deactivate();
                        return;
                    }
                    if (!this.serverSelection.isSelected("SpookyTime Duels") || !Network.isSpookyTime()) break block13;
                    if (JoinerHelper.mc.field_1724 != null) {
                        int currentCompassSlot = -1;
                        for (int i = 0; i < 9; ++i) {
                            class_1799 stack = JoinerHelper.mc.field_1724.method_31548().method_5438(i);
                            if (!(stack.method_7909() instanceof class_1759)) continue;
                            currentCompassSlot = i;
                            break;
                        }
                        if (this.lastCompassSlot == 4 && currentCompassSlot == 0) {
                            this.deactivate();
                            return;
                        }
                        this.lastCompassSlot = currentCompassSlot;
                    }
                    if (JoinerHelper.mc.field_1755 != null || JoinerHelper.mc.field_1724 == null) break block14;
                    if (JoinerHelper.mc.field_1724.method_31548().field_7545 != 4) {
                        JoinerHelper.mc.field_1724.method_31548().field_7545 = 4;
                    }
                    if (System.currentTimeMillis() - this.lastActionTime <= 500L) break block15;
                    JoinerHelper.mc.field_1724.field_3944.method_52787((class_2596)new class_2886(class_1268.field_5808, 4, JoinerHelper.mc.field_1724.method_36454(), JoinerHelper.mc.field_1724.method_36455()));
                    this.lastActionTime = System.currentTimeMillis();
                    break block15;
                }
                class_437 i = JoinerHelper.mc.field_1755;
                if (i instanceof class_476) {
                    class_476 container = (class_476)i;
                    for (int i2 = 0; i2 < ((class_1707)container.method_17577()).field_7761.size(); ++i2) {
                        String s = ((class_1735)((class_1707)container.method_17577()).field_7761.get(i2)).method_7677().method_7964().getString().toLowerCase();
                        if (!s.contains("\u00bb \u0434\u0443\u044d\u043b\u0438") && !s.contains("\u0434\u0443\u044d\u043b\u0438")) continue;
                        if (System.currentTimeMillis() - this.lastActionTime <= 100L) break;
                        InventoryTask.clickSlot(i2, 0, class_1713.field_7790, false);
                        this.lastActionTime = System.currentTimeMillis();
                        break;
                    }
                }
            }
            return;
        }
        if (JoinerHelper.mc.field_1755 == null && JoinerHelper.mc.field_1724 != null && JoinerHelper.mc.field_1724.field_6012 < 5) {
            InventoryTask.selectCompass();
            JoinerHelper.mc.field_1724.field_3944.method_52787((class_2596)new class_2886(class_1268.field_5808, JoinerHelper.mc.field_1724.method_31548().field_7545, JoinerHelper.mc.field_1724.method_36454(), JoinerHelper.mc.field_1724.method_36455()));
        } else {
            class_437 i2 = JoinerHelper.mc.field_1755;
            if (i2 instanceof class_476) {
                class_476 container = (class_476)i2;
                for (int i = 0; i < ((class_1707)container.method_17577()).field_7761.size(); ++i) {
                    int numberGrief;
                    String s = ((class_1735)((class_1707)container.method_17577()).field_7761.get(i)).method_7677().method_7964().getString().toLowerCase();
                    if (!this.serverSelection.isSelected("ReallyWorld") || !Network.isReallyWorld()) continue;
                    if (s.contains("\u0433\u0440\u0438\u0444\u0435\u0440\u0441\u043a\u043e\u0435 \u0432\u044b\u0436\u0438\u0432\u0430\u043d\u0438\u0435") && System.currentTimeMillis() - this.lastActionTime > 50L) {
                        InventoryTask.clickSlot(i, 0, class_1713.field_7790, false);
                        this.lastActionTime = System.currentTimeMillis();
                    }
                    if (!s.contains("\u0433\u0440\u0438\u0444 #" + (numberGrief = (int)this.griefSelection.getValue())) || System.currentTimeMillis() - this.lastActionTime <= 50L) continue;
                    InventoryTask.clickSlot(i, 0, class_1713.field_7790, false);
                    this.lastActionTime = System.currentTimeMillis();
                }
            }
        }
    }

    @EventHandler
    public void onPacket(PacketEvent event) {
        class_2661 packet;
        String message;
        if (!this.state || event.getType() != PacketEvent.Type.RECEIVE) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2661 && ((message = (packet = (class_2661)class_25962).comp_2325().getString().toLowerCase()).contains("\u043a \u0441\u043e\u0436\u0430\u043b\u0435\u043d\u0438\u044e \u0441\u0435\u0440\u0432\u0435\u0440 \u043f\u0435\u0440\u0435\u043f\u043e\u043b\u043d\u0435\u043d") || message.contains("\u043f\u043e\u0434\u043e\u0436\u0434\u0438\u0442\u0435 20 \u0441\u0435\u043a\u0443\u043d\u0434!") || message.contains("\u0432\u044b \u0443\u0436\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u044b \u043d\u0430 \u044d\u0442\u043e\u0442 \u0441\u0435\u0440\u0432\u0435\u0440!") || message.contains("\u043f\u043e\u0434\u043e\u0436\u0434\u0438\u0442\u0435 \u043d\u0435\u0441\u043a\u043e\u043b\u044c\u043a\u043e \u0441\u0435\u043a\u0443\u043d\u0434 \u043f\u0435\u0440\u0435\u0434 \u043f\u043e\u0432\u0442\u043e\u0440\u043d\u044b\u043c \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435\u043c!") || message.contains("\u0432\u044b \u0431\u044b\u043b\u0438 \u043a\u0438\u043a\u043d\u0443\u0442\u044b \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430 1duels:") || message.contains("\u0412\u044b \u0431\u044b\u043b\u0438 \u043a\u0438\u043a\u043d\u0443\u0442\u044b") || message.contains("\u0431\u043e\u043b\u044c\u0448\u043e\u0439 \u043f\u043e\u0442\u043e\u043a \u0438\u0433\u0440\u043e\u043a\u043e\u0432") || message.contains("\u0441\u0435\u0440\u0432\u0435\u0440 \u0437\u0430\u043f\u043e\u043b\u043d\u0435\u043d!"))) {
            InventoryTask.selectCompass();
            JoinerHelper.mc.field_1724.field_3944.method_52787((class_2596)new class_2886(class_1268.field_5808, JoinerHelper.mc.field_1724.method_31548().field_7545, JoinerHelper.mc.field_1724.method_36454(), JoinerHelper.mc.field_1724.method_36455()));
        }
    }

    @Override
    public void activate() {
        super.activate();
        this.isToggling = false;
        this.retryDuels = false;
        this.lastActionTime = 0L;
        this.lastCompassSlot = -1;
        if (JoinerHelper.mc.field_1687 != null) {
            this.lastWorldName = JoinerHelper.mc.field_1687.method_27983().method_29177().toString();
        }
    }

    @Override
    public void deactivate() {
        super.deactivate();
        this.lastActionTime = 0L;
        this.isToggling = false;
        this.retryDuels = false;
        this.lastWorldName = null;
        this.lastCompassSlot = -1;
    }
}

