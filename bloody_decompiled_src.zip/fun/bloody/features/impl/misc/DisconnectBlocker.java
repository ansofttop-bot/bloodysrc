/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 *  net.minecraft.class_2661
 */
package fun.bloody.features.impl.misc;

import fun.bloody.common.proxy.FakerConfig;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.managers.event.EventHandler;
import net.minecraft.class_2596;
import net.minecraft.class_2661;

public class DisconnectBlocker
extends Module {
    public DisconnectBlocker() {
        super("DisconnectBlocker", "\u0411\u043b\u043e\u043a\u0438\u0440\u0443\u0435\u0442 disconnect \u043f\u0430\u043a\u0435\u0442\u044b \u043f\u0440\u0438 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0438 Faker/Savemod", ModuleCategory.MISC);
    }

    @EventHandler
    public void onPacket(PacketEvent event) {
        if (!FakerConfig.fakerEnabled || !FakerConfig.blockDisconnect) {
            return;
        }
        if (event.getType() != PacketEvent.Type.RECEIVE) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (class_25962 instanceof class_2661) {
            class_2661 packet = (class_2661)class_25962;
            String reason = packet.comp_2325().getString();
            event.cancel();
        }
    }
}

