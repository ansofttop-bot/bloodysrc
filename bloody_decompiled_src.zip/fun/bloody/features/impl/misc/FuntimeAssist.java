/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_124
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_2596
 *  net.minecraft.class_2637
 *  net.minecraft.class_2680
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_3675
 *  net.minecraft.class_4587
 *  net.minecraft.class_4588
 *  net.minecraft.class_5250
 *  net.minecraft.class_7439
 *  net.minecraft.class_9801
 *  org.apache.commons.lang3.StringUtils
 *  org.joml.Vector4f
 *  org.lwjgl.glfw.GLFW
 *  org.lwjgl.opengl.GL11
 */
package fun.bloody.features.impl.misc;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.common.repository.friend.FriendUtils;
import fun.bloody.display.hud.CoolDowns;
import fun.bloody.display.hud.Notifications;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.events.player.RotationUpdateEvent;
import fun.bloody.events.render.DrawEvent;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.impl.render.ProjectilePrediction;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.chat.StringHelper;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.client.packet.network.Network;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.color.GradientAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.geometry.Render2D;
import fun.bloody.utils.display.geometry.Render3D;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.interactions.inv.InventoryTask;
import fun.bloody.utils.interactions.simulate.PlayerSimulation;
import fun.bloody.utils.math.calc.Calculate;
import fun.bloody.utils.math.projection.Projection;
import fun.bloody.utils.math.script.Script;
import fun.bloody.utils.math.time.StopWatch;
import java.lang.invoke.CallSite;
import java.lang.runtime.SwitchBootstraps;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2637;
import net.minecraft.class_2680;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5250;
import net.minecraft.class_7439;
import net.minecraft.class_9801;
import org.apache.commons.lang3.StringUtils;
import org.joml.Vector4f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

public class FuntimeAssist
extends Module {
    private final Map<class_2338, class_2680> blockStateMap = new HashMap<class_2338, class_2680>();
    private final List<ServerEvent> serverEvents = new ArrayList<ServerEvent>();
    private final List<Structure> structures = new ArrayList<Structure>();
    private final List<KeyBind> keyBindings = new ArrayList<KeyBind>();
    private final StopWatch itemsWatch = new StopWatch();
    private final Script script = new Script();
    private final Map<Integer, class_1792> stacks = new HashMap<Integer, class_1792>();
    private final BooleanSetting consumablesSetting = new BooleanSetting("\u0422\u0430\u0439\u043c\u0435\u0440 \u0440\u0430\u0441\u0445\u043e\u0434\u043d\u0438\u043a\u043e\u0432", "\u041e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0435\u0442 \u0432\u0440\u0435\u043c\u044f \u0434\u043e \u043e\u043a\u043e\u043d\u0447\u0430\u043d\u0438\u044f \u0440\u0430\u0441\u0445\u043e\u0434\u043d\u0438\u043a\u043e\u0432").setValue(true);
    private final BooleanSetting autoPointSetting = new BooleanSetting("\u0410\u0432\u0442\u043e \u043f\u043e\u0438\u043d\u0442", "\u041e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0435\u0442 \u0438\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044e \u043e\u0431 \u0438\u0432\u0435\u043d\u0442\u0435").setValue(true);
    private final List<String> potionQueue = new ArrayList<String>();
    private final StopWatch potionTimer = new StopWatch();
    private final Map<String, ItemInfo> itemConfig = new HashMap<String, ItemInfo>();
    private final Map<String, Boolean> itemStates = new HashMap<String, Boolean>();
    private final Map<String, Boolean> lastKeyStates = new HashMap<String, Boolean>();
    private final Map<String, Boolean> keyPressedThisTick = new HashMap<String, Boolean>();
    private int originalSlot = -1;
    private int targetSlot = -1;
    private ActionState actionState = ActionState.IDLE;
    private long actionTimer = 0L;
    private String pendingItemKey = null;
    private long stopMovementUntil = 0L;
    private boolean keysOverridden = false;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private int originalSourceSlot = -1;

    public static FuntimeAssist getInstance() {
        return Instance.get(FuntimeAssist.class);
    }

    public FuntimeAssist() {
        super("Funtime Assist", "Funtime Assist", ModuleCategory.MISC);
        this.initialize();
    }

    public void initialize() {
        this.setup(this.consumablesSetting, this.autoPointSetting);
        this.keyBindings.add(new KeyBind(class_1802.field_8543, new BindSetting("\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0441\u043d\u0435\u0436\u043a\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8614, new BindSetting("\u0411\u043e\u0436\u044c\u044f \u0430\u0443\u0440\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0431\u043e\u0436\u044c\u0435\u0439 \u0430\u0443\u0440\u044b"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_22021, new BindSetting("\u0422\u0440\u0430\u043f\u043a\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0442\u0440\u0430\u043f\u043a\u0438"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8551, new BindSetting("\u041f\u043b\u0430\u0441\u0442", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u043f\u043b\u0430\u0441\u0442\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8479, new BindSetting("\u042f\u0432\u043d\u0430\u044f \u043f\u044b\u043b\u044c", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u044f\u0432\u043d\u043e\u0439 \u043f\u044b\u043b\u0438"), 10.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8814, new BindSetting("\u041e\u0433\u043d\u0435\u043d\u043d\u044b\u0439 \u0441\u043c\u0435\u0440\u0447", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u043e\u0433\u043d\u0435\u043d\u043d\u043e\u0433\u043e \u0441\u043c\u0435\u0440\u0447\u0430"), 10.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8449, new BindSetting("\u0414\u0435\u0437\u043e\u0440\u0438\u0435\u043d\u0442\u0430\u0446\u0438\u044f", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0434\u0435\u0437\u043e\u0440\u0438\u0435\u043d\u0442\u0430\u0446\u0438\u0438"), 10.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u043e\u0442\u0440\u044b\u0436\u043a\u0438", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u043e\u0442\u0440\u044b\u0436\u043a\u0438"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u0441\u0435\u0440\u043d\u043e\u0439 \u043a\u0438\u0441\u043b\u043e\u0442\u044b", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u0441\u0435\u0440\u043d\u043e\u0439 \u043a\u0438\u0441\u043b\u043e\u0442\u044b"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u0432\u0441\u043f\u044b\u0448\u043a\u0438", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u0432\u0441\u043f\u044b\u0448\u043a\u0438"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u043c\u043e\u0447\u0438 \u0424\u043b\u0435\u0448\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u043c\u043e\u0447\u0438 \u0424\u043b\u0435\u0448\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u0430\u0433\u0435\u043d\u0442\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u0430\u0433\u0435\u043d\u0442\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u043c\u0435\u0434\u0438\u043a\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u043c\u0435\u0434\u0438\u043a\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u043a\u0438\u043b\u043b\u0435\u0440\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u043a\u0438\u043b\u043b\u0435\u0440\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u0410\u0441\u0441\u0430\u0441\u0438\u043d\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u0410\u0441\u0441\u0430\u0441\u0438\u043d\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u0420\u0430\u0434\u0438\u0430\u0446\u0438\u0438", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u0420\u0430\u0434\u0438\u0430\u0446\u0438\u0438"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u041f\u0430\u043b\u043b\u0430\u0434\u0438\u043d\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u041f\u0430\u043b\u043b\u0430\u0434\u0438\u043d\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0421\u0432\u044f\u0442\u0430\u044f \u0432\u043e\u0434\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0441\u0432\u044f\u0442\u043e\u0439 \u0432\u043e\u0434\u044b"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0421\u043d\u043e\u0442\u0432\u043e\u0440\u043d\u043e\u0435", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0441\u043d\u043e\u0442\u0432\u043e\u0440\u043d\u043e\u0433\u043e"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8639, new BindSetting("\u0425\u043b\u043e\u043f\u0443\u0448\u043a\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0445\u043b\u043e\u043f\u0443\u0448\u043a\u0438"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("\u0417\u0435\u043b\u044c\u0435 \u0413\u043d\u0435\u0432\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0437\u0435\u043b\u044c\u044f \u0413\u043d\u0435\u0432\u0430"), 0.0f));
        this.keyBindings.forEach(bind -> this.setup(bind.setting));
        this.itemConfig.put("disorientation", new ItemInfo("\u0434\u0435\u0437\u043e\u0440\u0438\u0435\u043d\u0442\u0430\u0446\u0438\u044f", class_1802.field_8449, "\u0414\u0435\u0437\u043e\u0440\u0438\u0435\u043d\u0442\u0430\u0446\u0438\u044f"));
        this.itemConfig.put("sugar", new ItemInfo("\u044f\u0432\u043d\u0430\u044f", class_1802.field_8479, "\u042f\u0432\u043d\u0430\u044f \u043f\u044b\u043b\u044c"));
        this.itemConfig.put("bojaura", new ItemInfo("\u0431\u043e\u0436\u044c\u044f \u0430\u0443\u0440\u0430", class_1802.field_8614, "\u0411\u043e\u0436\u044c\u044f \u0430\u0443\u0440\u0430"));
        this.itemConfig.put("snow", new ItemInfo("\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430", class_1802.field_8543, "\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430"));
        this.itemConfig.put("plast", new ItemInfo("\u043f\u043b\u0430\u0441\u0442", class_1802.field_8551, "\u041f\u043b\u0430\u0441\u0442"));
        this.itemConfig.put("trap", new ItemInfo("\u0442\u0440\u0430\u043f\u043a\u0430", class_1802.field_22021, "\u0422\u0440\u0430\u043f\u043a\u0430"));
        this.itemConfig.put("fireSwirl", new ItemInfo("\u043e\u0433\u043d\u0435\u043d\u043d\u044b\u0439 \u0441\u043c\u0435\u0440\u0447", class_1802.field_8814, "\u041e\u0433\u043d\u0435\u043d\u043d\u044b\u0439 \u0441\u043c\u0435\u0440\u0447"));
        this.itemConfig.put("otriga", new ItemInfo("\u043e\u0442\u0440\u044b\u0436\u043a\u0438", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u043e\u0442\u0440\u044b\u0436\u043a\u0438"));
        this.itemConfig.put("serka", new ItemInfo("\u0441\u0435\u0440\u043d\u0430\u044f", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u0441\u0435\u0440\u043d\u043e\u0439 \u043a\u0438\u0441\u043b\u043e\u0442\u044b"));
        this.itemConfig.put("vspihka", new ItemInfo("\u0432\u0441\u043f\u044b\u0448\u043a\u0430", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u0432\u0441\u043f\u044b\u0448\u043a\u0438"));
        this.itemConfig.put("mochaflesha", new ItemInfo("\u043c\u043e\u0447\u0430 \u0444\u043b\u0435\u0448\u0430", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u043c\u043e\u0447\u0438 \u0424\u043b\u0435\u0448\u0430"));
        this.itemConfig.put("pobedilka", new ItemInfo("\u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f"));
        this.itemConfig.put("agent", new ItemInfo("\u0430\u0433\u0435\u043d\u0442\u0430", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u0430\u0433\u0435\u043d\u0442\u0430"));
        this.itemConfig.put("medik", new ItemInfo("\u043c\u0435\u0434\u0438\u043a\u0430", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u043c\u0435\u0434\u0438\u043a\u0430"));
        this.itemConfig.put("killer", new ItemInfo("\u043a\u0438\u043b\u043b\u0435\u0440\u0430", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u043a\u0438\u043b\u043b\u0435\u0440\u0430"));
        this.itemConfig.put("assassin", new ItemInfo("\u0430\u0441\u0441\u0430\u0441\u0438\u043d\u0430", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u0410\u0441\u0441\u0430\u0441\u0438\u043d\u0430"));
        this.itemConfig.put("radiation", new ItemInfo("\u0440\u0430\u0434\u0438\u0430\u0446\u0438\u0438", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u0420\u0430\u0434\u0438\u0430\u0446\u0438\u0438"));
        this.itemConfig.put("palladin", new ItemInfo("\u043f\u0430\u043b\u043b\u0430\u0434\u0438\u043d\u0430", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u041f\u0430\u043b\u043b\u0430\u0434\u0438\u043d\u0430"));
        this.itemConfig.put("holywater", new ItemInfo("\u0441\u0432\u044f\u0442\u0430\u044f \u0432\u043e\u0434\u0430", class_1802.field_8436, "\u0421\u0432\u044f\u0442\u0430\u044f \u0432\u043e\u0434\u0430"));
        this.itemConfig.put("sleeping", new ItemInfo("\u0441\u043d\u043e\u0442\u0432\u043e\u0440\u043d\u043e\u0435", class_1802.field_8436, "\u0421\u043d\u043e\u0442\u0432\u043e\u0440\u043d\u043e\u0435"));
        this.itemConfig.put("firecracker", new ItemInfo("\u0445\u043b\u043e\u043f\u0443\u0448\u043a\u0430", class_1802.field_8639, "\u0425\u043b\u043e\u043f\u0443\u0448\u043a\u0430"));
        this.itemConfig.put("anger", new ItemInfo("\u0433\u043d\u0435\u0432\u0430", class_1802.field_8436, "\u0417\u0435\u043b\u044c\u0435 \u0413\u043d\u0435\u0432\u0430"));
        this.itemConfig.keySet().forEach(key -> {
            this.itemStates.put((String)key, false);
            this.lastKeyStates.put((String)key, false);
            this.keyPressedThisTick.put((String)key, false);
        });
    }

    @Override
    public void activate() {
        this.stacks.clear();
        this.potionQueue.clear();
        this.potionTimer.reset();
        this.itemStates.replaceAll((k, v) -> false);
        this.lastKeyStates.replaceAll((k, v) -> false);
        this.keyPressedThisTick.replaceAll((k, v) -> false);
        this.actionState = ActionState.IDLE;
        this.originalSlot = -1;
        this.targetSlot = -1;
        this.originalSourceSlot = -1;
        this.pendingItemKey = null;
        this.stopMovementUntil = 0L;
        this.keysOverridden = false;
    }

    @Override
    public void deactivate() {
        this.itemStates.replaceAll((k, v) -> false);
        this.lastKeyStates.replaceAll((k, v) -> false);
        this.keyPressedThisTick.replaceAll((k, v) -> false);
        this.potionQueue.clear();
        this.potionTimer.reset();
        this.actionState = ActionState.IDLE;
        this.originalSlot = -1;
        this.targetSlot = -1;
        this.originalSourceSlot = -1;
        this.pendingItemKey = null;
        this.stopMovementUntil = 0L;
        if (this.keysOverridden) {
            FuntimeAssist.mc.field_1690.field_1894.method_23481(false);
            FuntimeAssist.mc.field_1690.field_1881.method_23481(false);
            FuntimeAssist.mc.field_1690.field_1913.method_23481(false);
            FuntimeAssist.mc.field_1690.field_1849.method_23481(false);
        }
        this.keysOverridden = false;
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        if (!PlayerInteractionHelper.nullCheck()) {
            class_2596<?> class_25962 = e.getPacket();
            Objects.requireNonNull(class_25962);
            class_2596<?> class_25963 = class_25962;
            int n = 0;
            block26: while (true) {
                switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{class_2637.class, class_7439.class}, class_25963, n)) {
                    case 0: {
                        class_2637 chunkDelta = (class_2637)class_25963;
                        if (!this.consumablesSetting.isValue()) {
                            n = 1;
                            continue block26;
                        }
                        chunkDelta.method_30621((pos, state) -> this.blockStateMap.put(pos.method_10069(0, 0, 0), (class_2680)state));
                        this.script.addTickStep(0, () -> chunkDelta.method_30621((pos, state) -> {
                            class_243 vec = pos.method_10069(0, 0, 0).method_46558();
                            if (this.blockStateMap.size() > 50 && this.blockStateMap.size() < 600) {
                                if (this.isTrap(pos.method_10086(2))) {
                                    this.addStructure(class_1802.field_22021, vec, System.currentTimeMillis() + 15000L);
                                } else if (this.isBigTrap(pos.method_10086(3))) {
                                    this.addStructure(class_1802.field_22021, vec, System.currentTimeMillis() + 30000L);
                                }
                            }
                        }));
                        break block26;
                    }
                    case 1: {
                        class_7439 gameMessage = (class_7439)class_25963;
                        if (!this.autoPointSetting.isValue()) {
                            n = 2;
                            continue block26;
                        }
                        class_2561 content = gameMessage.comp_763();
                        String contentString = content.toString();
                        String message = content.getString();
                        String name = StringUtils.substringBetween((String)message, (String)"||| [", (String)"] ");
                        if (name != null) {
                            String position = StringUtils.substringBetween((String)contentString, (String)"value='/gps ", (String)"'");
                            String lvl = StringUtils.substringBetween((String)message, (String)"\u0423\u0440\u043e\u0432\u0435\u043d\u044c \u043b\u0443\u0442\u0430: ", (String)"\n \u2551");
                            String owner = StringUtils.substringBetween((String)message, (String)"\u041f\u0440\u0438\u0437\u0432\u0430\u043d \u0438\u0433\u0440\u043e\u043a\u043e\u043c: ", (String)"\n \u2551");
                            if (position != null) {
                                String[] pose = position.split(" ");
                                class_243 center = class_2338.method_49637((double)Integer.parseInt(pose[0]), (double)Integer.parseInt(pose[1]), (double)Integer.parseInt(pose[2])).method_46558();
                                switch (name) {
                                    case "\u041c\u0438\u0441\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u0441\u0443\u043d\u0434\u0443\u043a": {
                                        this.addEvent(name, lvl, owner, center, "overworld", 300, 0);
                                        break;
                                    }
                                    case "\u0412\u0443\u043b\u043a\u0430\u043d": {
                                        this.addEvent(name, lvl, owner, center, "overworld", 300, 120);
                                        break;
                                    }
                                    case "\u041c\u0435\u0442\u0435\u043e\u0440\u0438\u0442\u043d\u044b\u0439 \u0434\u043e\u0436\u0434\u044c": 
                                    case "\u041c\u0430\u044f\u043a \u0443\u0431\u0438\u0439\u0446\u0430": 
                                    case "\u041c\u0438\u0441\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u0410\u043b\u0442\u0430\u0440\u044c": {
                                        this.addEvent(name, lvl, owner, center, "overworld", 360, 0);
                                        break;
                                    }
                                    case "\u0417\u0430\u0433\u0430\u0434\u043e\u0447\u043d\u044b\u0439 \u043c\u0430\u044f\u043a": {
                                        this.addEvent(name, lvl, owner, center, "overworld", 60, 180);
                                    }
                                }
                                break block26;
                            }
                            switch (name) {
                                case "\u0421\u0443\u043d\u0434\u0443\u043a \u0441\u043c\u0435\u0440\u0442\u0438": {
                                    this.addEvent(name, lvl, owner, class_2338.method_49637((double)-155.0, (double)64.0, (double)205.0).method_46558(), "lobby", 300, 0);
                                    break;
                                }
                                case "\u0410\u0434\u0441\u043a\u0430\u044f \u0440\u0435\u0437\u043d\u044f": {
                                    this.addEvent(name, lvl, owner, class_2338.method_49637((double)48.0, (double)87.0, (double)73.0).method_46558(), "lobby", 180, 120);
                                }
                            }
                        }
                        break block26;
                    }
                }
                break;
            }
        }
    }

    @EventHandler
    public void onRotationUpdate(RotationUpdateEvent e) {
        String potionKey;
        ItemInfo info;
        boolean noMoveOrAction;
        if (e.getType() != 0 || FuntimeAssist.mc.field_1755 != null) {
            return;
        }
        boolean bl = noMoveOrAction = System.currentTimeMillis() < this.stopMovementUntil || this.actionState != ActionState.IDLE && this.actionState != ActionState.SPEEDING_UP;
        if (noMoveOrAction) {
            FuntimeAssist.mc.field_1690.field_1894.method_23481(false);
            FuntimeAssist.mc.field_1690.field_1881.method_23481(false);
            FuntimeAssist.mc.field_1690.field_1913.method_23481(false);
            FuntimeAssist.mc.field_1690.field_1849.method_23481(false);
            if (FuntimeAssist.mc.field_1724.field_3913 != null) {
                FuntimeAssist.mc.field_1724.field_3913.field_3905 = 0.0f;
                FuntimeAssist.mc.field_1724.field_3913.field_3907 = 0.0f;
            }
            if (FuntimeAssist.mc.field_1724.method_5624()) {
                FuntimeAssist.mc.field_1724.method_5728(false);
            }
        }
        for (KeyBind bind : this.keyBindings) {
            ItemInfo info2;
            String key;
            if ((key = (switch (bind.setting.getName()) {
                case "\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430" -> "snow";
                case "\u0411\u043e\u0436\u044c\u044f \u0430\u0443\u0440\u0430" -> "bojaura";
                case "\u0422\u0440\u0430\u043f\u043a\u0430" -> "trap";
                case "\u041f\u043b\u0430\u0441\u0442" -> "plast";
                case "\u042f\u0432\u043d\u0430\u044f \u043f\u044b\u043b\u044c" -> "sugar";
                case "\u041e\u0433\u043d\u0435\u043d\u043d\u044b\u0439 \u0441\u043c\u0435\u0440\u0447" -> "fireSwirl";
                case "\u0414\u0435\u0437\u043e\u0440\u0438\u0435\u043d\u0442\u0430\u0446\u0438\u044f" -> "disorientation";
                case "\u0417\u0435\u043b\u044c\u0435 \u043e\u0442\u0440\u044b\u0436\u043a\u0438" -> "otriga";
                case "\u0417\u0435\u043b\u044c\u0435 \u0441\u0435\u0440\u043d\u043e\u0439 \u043a\u0438\u0441\u043b\u043e\u0442\u044b" -> "serka";
                case "\u0417\u0435\u043b\u044c\u0435 \u0432\u0441\u043f\u044b\u0448\u043a\u0438" -> "vspihka";
                case "\u0417\u0435\u043b\u044c\u0435 \u043c\u043e\u0447\u0438 \u0424\u043b\u0435\u0448\u0430" -> "mochaflesha";
                case "\u0417\u0435\u043b\u044c\u0435 \u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f" -> "pobedilka";
                case "\u0417\u0435\u043b\u044c\u0435 \u0430\u0433\u0435\u043d\u0442\u0430" -> "agent";
                case "\u0417\u0435\u043b\u044c\u0435 \u043c\u0435\u0434\u0438\u043a\u0430" -> "medik";
                case "\u0417\u0435\u043b\u044c\u0435 \u043a\u0438\u043b\u043b\u0435\u0440\u0430" -> "killer";
                case "\u0417\u0435\u043b\u044c\u0435 \u0410\u0441\u0441\u0430\u0441\u0438\u043d\u0430" -> "assassin";
                case "\u0417\u0435\u043b\u044c\u0435 \u0420\u0430\u0434\u0438\u0430\u0446\u0438\u0438" -> "radiation";
                case "\u0417\u0435\u043b\u044c\u0435 \u041f\u0430\u043b\u043b\u0430\u0434\u0438\u043d\u0430" -> "palladin";
                case "\u0421\u0432\u044f\u0442\u0430\u044f \u0432\u043e\u0434\u0430" -> "holywater";
                case "\u0421\u043d\u043e\u0442\u0432\u043e\u0440\u043d\u043e\u0435" -> "sleeping";
                case "\u0425\u043b\u043e\u043f\u0443\u0448\u043a\u0430" -> "firecracker";
                case "\u0417\u0435\u043b\u044c\u0435 \u0413\u043d\u0435\u0432\u0430" -> "anger";
                default -> null;
            })) == null || !bind.setting.isVisible()) continue;
            boolean currentKey = false;
            if (bind.setting.getKey() != -1) {
                currentKey = bind.setting.getKey() >= 0 && bind.setting.getKey() <= 7 ? GLFW.glfwGetMouseButton((long)mc.method_22683().method_4490(), (int)bind.setting.getKey()) == 1 : class_3675.method_15987((long)mc.method_22683().method_4490(), (int)bind.setting.getKey());
            }
            boolean wasPressedLastTick = this.lastKeyStates.getOrDefault(key, false);
            if (currentKey && !wasPressedLastTick && (info2 = this.itemConfig.get(key)) != null) {
                boolean addStarPrefix;
                class_1735 slot = InventoryTask.getSlot(s -> s.method_7677().method_7909().equals(info.item) && InventoryTask.getCleanName(s.method_7677().method_7964()).contains(info.searchName.toLowerCase()));
                boolean bl2 = addStarPrefix = info2.displayName.equals("\u0414\u0435\u0437\u043e\u0440\u0438\u0435\u043d\u0442\u0430\u0446\u0438\u044f") || info2.displayName.equals("\u0411\u043e\u0436\u044c\u044f \u0430\u0443\u0440\u0430") || info2.displayName.equals("\u041f\u043b\u0430\u0441\u0442") || info2.displayName.equals("\u0422\u0440\u0430\u043f\u043a\u0430") || info2.displayName.equals("\u041e\u0433\u043d\u0435\u043d\u043d\u044b\u0439 \u0441\u043c\u0435\u0440\u0447") || info2.displayName.equals("\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430") || info2.displayName.equals("\u042f\u0432\u043d\u0430\u044f \u043f\u044b\u043b\u044c") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u043e\u0442\u0440\u044b\u0436\u043a\u0438") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0441\u0435\u0440\u043d\u043e\u0439 \u043a\u0438\u0441\u043b\u043e\u0442\u044b") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0432\u0441\u043f\u044b\u0448\u043a\u0438") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u043c\u043e\u0447\u0438 \u0424\u043b\u0435\u0448\u0430") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0430\u0433\u0435\u043d\u0442\u0430") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u043c\u0435\u0434\u0438\u043a\u0430") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u043a\u0438\u043b\u043b\u0435\u0440\u0430") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0410\u0441\u0441\u0430\u0441\u0438\u043d\u0430") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0420\u0430\u0434\u0438\u0430\u0446\u0438\u0438") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u041f\u0430\u043b\u043b\u0430\u0434\u0438\u043d\u0430") || info2.displayName.equals("\u0421\u0432\u044f\u0442\u0430\u044f \u0432\u043e\u0434\u0430") || info2.displayName.equals("\u0421\u043d\u043e\u0442\u0432\u043e\u0440\u043d\u043e\u0435") || info2.displayName.equals("\u0425\u043b\u043e\u043f\u0443\u0448\u043a\u0430") || info2.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0413\u043d\u0435\u0432\u0430");
                if (slot != null) {
                    class_1799 stack = slot.method_7677();
                    if (FuntimeAssist.mc.field_1724.method_7357().method_7904(stack)) {
                        CoolDowns.getInstance().list.stream().filter(c -> c.item().equals(info.item)).findFirst().ifPresent(coolDown -> {
                            int time = Math.toIntExact(-coolDown.time().elapsedTime() / 1000L);
                            String duration = StringHelper.getDuration(time);
                            class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u0431\u0443\u0434\u0435\u0442  \u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d  \u0447\u0435\u0440\u0435\u0437 ").method_10852((class_2561)class_2561.method_43470((String)duration).method_27692(class_124.field_1080));
                            Notifications.getInstance().addList((class_2561)text, 4000L);
                        });
                    } else if (!this.potionQueue.contains(key)) {
                        this.potionQueue.add(key);
                    }
                } else {
                    class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info2.displayName, GradientAssist.getGradientColors(info2.displayName), addStarPrefix)).method_27693("  \u043d\u0435  \u043d\u0430\u0439\u0434\u0435\u043d\u043e");
                    Notifications.getInstance().addList((class_2561)text, 4000L);
                }
            }
            this.lastKeyStates.put(key, currentKey);
            this.keyPressedThisTick.put(key, currentKey);
        }
        if (this.actionState != ActionState.IDLE) {
            this.processItemAction();
        }
        if (this.actionState == ActionState.IDLE && !this.potionQueue.isEmpty() && this.potionTimer.finished(80.0) && (info = this.itemConfig.get(potionKey = this.potionQueue.remove(0))) != null) {
            boolean addStarPrefix;
            class_1735 slot = InventoryTask.getSlot(s -> s.method_7677().method_7909().equals(info.item) && InventoryTask.getCleanName(s.method_7677().method_7964()).contains(info.searchName.toLowerCase()));
            boolean bl3 = addStarPrefix = info.displayName.equals("\u0414\u0435\u0437\u043e\u0440\u0438\u0435\u043d\u0442\u0430\u0446\u0438\u044f") || info.displayName.equals("\u0411\u043e\u0436\u044c\u044f \u0430\u0443\u0440\u0430") || info.displayName.equals("\u041f\u043b\u0430\u0441\u0442") || info.displayName.equals("\u0422\u0440\u0430\u043f\u043a\u0430") || info.displayName.equals("\u041e\u0433\u043d\u0435\u043d\u043d\u044b\u0439 \u0441\u043c\u0435\u0440\u0447") || info.displayName.equals("\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430") || info.displayName.equals("\u042f\u0432\u043d\u0430\u044f \u043f\u044b\u043b\u044c") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u043e\u0442\u0440\u044b\u0436\u043a\u0438") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0441\u0435\u0440\u043d\u043e\u0439 \u043a\u0438\u0441\u043b\u043e\u0442\u044b") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0432\u0441\u043f\u044b\u0448\u043a\u0438") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u043c\u043e\u0447\u0438 \u0424\u043b\u0435\u0448\u0430") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u043f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044f") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0430\u0433\u0435\u043d\u0442\u0430") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u043c\u0435\u0434\u0438\u043a\u0430") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u043a\u0438\u043b\u043b\u0435\u0440\u0430") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0410\u0441\u0441\u0430\u0441\u0438\u043d\u0430") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0420\u0430\u0434\u0438\u0430\u0446\u0438\u0438") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u041f\u0430\u043b\u043b\u0430\u0434\u0438\u043d\u0430") || info.displayName.equals("\u0421\u0432\u044f\u0442\u0430\u044f \u0432\u043e\u0434\u0430") || info.displayName.equals("\u0421\u043d\u043e\u0442\u0432\u043e\u0440\u043d\u043e\u0435") || info.displayName.equals("\u0425\u043b\u043e\u043f\u0443\u0448\u043a\u0430") || info.displayName.equals("\u0417\u0435\u043b\u044c\u0435 \u0413\u043d\u0435\u0432\u0430");
            if (slot != null) {
                class_1799 stack = slot.method_7677();
                if (!FuntimeAssist.mc.field_1724.method_7357().method_7904(stack)) {
                    this.startItemUse(slot, info, addStarPrefix);
                } else {
                    CoolDowns.getInstance().list.stream().filter(c -> c.item().equals(info.item)).findFirst().ifPresent(coolDown -> {
                        int time = Math.toIntExact(-coolDown.time().elapsedTime() / 1000L);
                        String duration = StringHelper.getDuration(time);
                        class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u0431\u0443\u0434\u0435\u0442  \u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d  \u0447\u0435\u0440\u0435\u0437 ").method_10852((class_2561)class_2561.method_43470((String)duration).method_27692(class_124.field_1080));
                        Notifications.getInstance().addList((class_2561)text, 4000L);
                    });
                }
            } else {
                class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u043d\u0435  \u043d\u0430\u0439\u0434\u0435\u043d\u043e");
                Notifications.getInstance().addList((class_2561)text, 4000L);
            }
            this.potionTimer.reset();
        }
        this.script.cleanupIfFinished().update();
        this.blockStateMap.clear();
        this.structures.removeIf(cons -> cons.time - (double)System.currentTimeMillis() <= 0.0);
        this.serverEvents.removeIf(event -> event.timeEnd + 90000.0 - (double)System.currentTimeMillis() <= 0.0);
    }

    private void startItemUse(class_1735 slot, ItemInfo info, boolean addStarPrefix) {
        this.originalSlot = FuntimeAssist.mc.field_1724.method_31548().field_7545;
        this.originalSourceSlot = slot.field_7874;
        this.targetSlot = slot.field_7874;
        this.pendingItemKey = info.searchName;
        this.wasForwardPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)FuntimeAssist.mc.field_1690.field_1894.method_1429().method_1444());
        this.wasBackPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)FuntimeAssist.mc.field_1690.field_1881.method_1429().method_1444());
        this.wasLeftPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)FuntimeAssist.mc.field_1690.field_1913.method_1429().method_1444());
        this.wasRightPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)FuntimeAssist.mc.field_1690.field_1849.method_1429().method_1444());
        this.actionState = ActionState.SLOWING_DOWN;
        this.actionTimer = System.currentTimeMillis();
        this.stopMovementUntil = System.currentTimeMillis() + 80L;
        this.keysOverridden = true;
        FuntimeAssist.mc.field_1690.field_1894.method_23481(false);
        FuntimeAssist.mc.field_1690.field_1881.method_23481(false);
        FuntimeAssist.mc.field_1690.field_1913.method_23481(false);
        FuntimeAssist.mc.field_1690.field_1849.method_23481(false);
        class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0430");
        Notifications.getInstance().addList((class_2561)text, 4000L);
    }

    private void processItemAction() {
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - this.actionTimer;
        switch (this.actionState.ordinal()) {
            case 1: {
                FuntimeAssist.mc.field_1724.field_3913.field_3905 = 0.0f;
                FuntimeAssist.mc.field_1724.field_3913.field_3907 = 0.0f;
                if (FuntimeAssist.mc.field_1724.method_5624()) {
                    FuntimeAssist.mc.field_1724.method_5728(false);
                }
                if (elapsed <= 20L) break;
                this.actionState = ActionState.WAITING_STOP;
                this.actionTimer = currentTime;
                break;
            }
            case 2: {
                FuntimeAssist.mc.field_1724.field_3913.field_3905 = 0.0f;
                FuntimeAssist.mc.field_1724.field_3913.field_3907 = 0.0f;
                double velocityX = Math.abs(FuntimeAssist.mc.field_1724.method_18798().field_1352);
                double velocityZ = Math.abs(FuntimeAssist.mc.field_1724.method_18798().field_1350);
                if (!(velocityX < 0.05 && velocityZ < 0.05) && elapsed <= 60L) break;
                this.actionState = ActionState.SWAP_TO_ITEM;
                this.actionTimer = currentTime;
                break;
            }
            case 3: {
                boolean isInHotbar;
                if (elapsed <= 10L) break;
                boolean bl = isInHotbar = this.targetSlot >= 0 && this.targetSlot < 9 || this.targetSlot >= 36 && this.targetSlot < 45;
                if (isInHotbar) {
                    int hotbarSlot;
                    FuntimeAssist.mc.field_1724.method_31548().field_7545 = hotbarSlot = this.targetSlot >= 36 ? this.targetSlot - 36 : this.targetSlot;
                    this.targetSlot = hotbarSlot;
                } else {
                    int swapSlot = FuntimeAssist.mc.field_1724.method_31548().field_7545;
                    InventoryTask.clickSlot(this.targetSlot, swapSlot, class_1713.field_7791, false);
                    this.targetSlot = swapSlot;
                }
                this.actionState = ActionState.USE_ITEM;
                this.actionTimer = currentTime;
                break;
            }
            case 4: {
                if (elapsed <= 2L) break;
                class_1799 heldItem = FuntimeAssist.mc.field_1724.method_6047();
                if (!heldItem.method_7960() && FuntimeAssist.mc.field_1724.method_31548().field_7545 == this.targetSlot) {
                    FuntimeAssist.mc.field_1761.method_2919((class_1657)FuntimeAssist.mc.field_1724, class_1268.field_5808);
                }
                this.actionState = ActionState.SWAP_BACK;
                this.actionTimer = currentTime;
                break;
            }
            case 5: {
                boolean wasFromInventory;
                if (elapsed <= 15L) break;
                boolean bl = wasFromInventory = !(this.originalSourceSlot >= 0 && this.originalSourceSlot < 9 || this.originalSourceSlot >= 36 && this.originalSourceSlot < 45);
                if (wasFromInventory && this.targetSlot >= 0 && this.targetSlot < 9) {
                    InventoryTask.clickSlot(this.originalSourceSlot, this.targetSlot, class_1713.field_7791, false);
                }
                if (FuntimeAssist.mc.field_1724.method_31548().field_7545 != this.originalSlot) {
                    FuntimeAssist.mc.field_1724.method_31548().field_7545 = this.originalSlot;
                }
                this.restoreKeyStates();
                this.actionState = ActionState.SPEEDING_UP;
                this.actionTimer = currentTime;
                break;
            }
            case 6: {
                if (elapsed <= 20L) break;
                this.actionState = ActionState.IDLE;
                this.originalSlot = -1;
                this.targetSlot = -1;
                this.originalSourceSlot = -1;
                this.pendingItemKey = null;
            }
        }
    }

    private void restoreKeyStates() {
        if (!this.keysOverridden) {
            return;
        }
        FuntimeAssist.mc.field_1690.field_1894.method_23481(this.wasForwardPressed);
        FuntimeAssist.mc.field_1690.field_1881.method_23481(this.wasBackPressed);
        FuntimeAssist.mc.field_1690.field_1913.method_23481(this.wasLeftPressed);
        FuntimeAssist.mc.field_1690.field_1849.method_23481(this.wasRightPressed);
        if (FuntimeAssist.mc.field_1724.field_3913 != null) {
            if (this.wasForwardPressed) {
                FuntimeAssist.mc.field_1724.field_3913.field_3905 = 1.0f;
                if (!FuntimeAssist.mc.field_1724.method_5624()) {
                    FuntimeAssist.mc.field_1724.method_5728(true);
                }
            }
            if (this.wasBackPressed) {
                FuntimeAssist.mc.field_1724.field_3913.field_3905 = -1.0f;
            }
            if (this.wasLeftPressed) {
                FuntimeAssist.mc.field_1724.field_3913.field_3907 = 1.0f;
            }
            if (this.wasRightPressed) {
                FuntimeAssist.mc.field_1724.field_3913.field_3907 = -1.0f;
            }
        }
        this.keysOverridden = false;
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        class_4587 matrix = e.getStack();
        this.keyBindings.stream().filter(bind -> PlayerInteractionHelper.isKey(bind.setting) && InventoryTask.getSlot(bind.item) != null).forEach(bind -> {
            class_2338 playerPos = FuntimeAssist.mc.field_1724.method_24515();
            class_243 smooth = Calculate.interpolate(class_243.method_24954((class_2382)class_2338.method_49637((double)FuntimeAssist.mc.field_1724.field_6014, (double)FuntimeAssist.mc.field_1724.field_6036, (double)FuntimeAssist.mc.field_1724.field_5969)), class_243.method_24954((class_2382)playerPos)).method_1020(class_243.method_24954((class_2382)playerPos));
            int[] gradientColors = GradientAssist.getGradientColors(bind.setting.getName());
            int color = gradientColors.length > 1 ? ColorAssist.gradient(10, 0, gradientColors) : gradientColors[0];
            switch (bind.setting.getName()) {
                case "\u0422\u0440\u0430\u043f\u043a\u0430": 
                case "\u041e\u0431\u044b\u0447\u043d\u0430\u044f \u0442\u0440\u0430\u043f\u043a\u0430": {
                    this.drawItemCube(playerPos, smooth, 1.99f, color);
                    break;
                }
                case "\u0414\u0435\u0437\u043e\u0440\u0438\u0435\u043d\u0442\u0430\u0446\u0438\u044f": 
                case "\u041e\u0433\u043d\u0435\u043d\u043d\u044b\u0439 \u0441\u043c\u0435\u0440\u0447": 
                case "\u042f\u0432\u043d\u0430\u044f \u043f\u044b\u043b\u044c": {
                    this.drawItemRadius(matrix, bind.distance, color);
                    break;
                }
                case "\u0412\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0448\u0442\u0443\u0447\u043a\u0430": {
                    this.drawItemRadius(matrix, 5.0f, color);
                    break;
                }
                case "\u041f\u043b\u0430\u0441\u0442": {
                    float yaw = class_3532.method_15393((float)FuntimeAssist.mc.field_1724.method_36454());
                    if (Math.abs(FuntimeAssist.mc.field_1724.method_36455()) > 60.0f) {
                        class_2338 blockPos = playerPos.method_10084().method_10079(FuntimeAssist.mc.field_1724.method_58149(), 3);
                        class_243 pos1 = class_243.method_24954((class_2382)blockPos.method_10089(3).method_10077(3).method_10074()).method_1019(smooth);
                        class_243 pos2 = class_243.method_24954((class_2382)blockPos.method_10088(2).method_10076(2).method_10084()).method_1019(smooth);
                        Render3D.drawBox(new class_238(pos1, pos2), color, 3.0f, true, true, true);
                        break;
                    }
                    if (yaw <= -157.5f || yaw >= 157.5f) {
                        class_2338 blockPos = playerPos.method_10076(3).method_10084();
                        class_243 pos1 = class_243.method_24954((class_2382)blockPos.method_10087(2).method_10089(3)).method_1019(smooth);
                        class_243 pos2 = class_243.method_24954((class_2382)blockPos.method_10086(3).method_10088(2).method_10077(2)).method_1019(smooth);
                        Render3D.drawBox(new class_238(pos1, pos2), color, 3.0f, true, true, true);
                        break;
                    }
                    if (yaw <= -112.5f) {
                        this.drawSidePlast(playerPos.method_10089(5).method_10072().method_10074(), smooth, color, -1, true);
                        break;
                    }
                    if (yaw <= -67.5f) {
                        class_2338 blockPos = playerPos.method_10089(2).method_10084();
                        class_243 pos1 = class_243.method_24954((class_2382)blockPos.method_10087(2).method_10077(3)).method_1019(smooth);
                        class_243 pos2 = class_243.method_24954((class_2382)blockPos.method_10086(3).method_10076(2).method_10089(2)).method_1019(smooth);
                        Render3D.drawBox(new class_238(pos1, pos2), color, 3.0f, true, true, true);
                        break;
                    }
                    if (yaw <= -22.5f) {
                        this.drawSidePlast(playerPos.method_10089(5).method_10074(), smooth, color, 1, false);
                        break;
                    }
                    if ((double)yaw >= -22.5 && (double)yaw <= 22.5) {
                        class_2338 blockPos = playerPos.method_10077(2).method_10084();
                        class_243 pos1 = class_243.method_24954((class_2382)blockPos.method_10087(2).method_10089(3)).method_1019(smooth);
                        class_243 pos2 = class_243.method_24954((class_2382)blockPos.method_10086(3).method_10088(2).method_10077(2)).method_1019(smooth);
                        Render3D.drawBox(new class_238(pos1, pos2), color, 3.0f, true, true, true);
                        break;
                    }
                    if (yaw <= 67.5f) {
                        this.drawSidePlast(playerPos.method_10088(4).method_10074(), smooth, color, 1, true);
                        break;
                    }
                    if (yaw <= 112.5f) {
                        class_2338 blockPos = playerPos.method_10088(3).method_10084();
                        class_243 pos1 = class_243.method_24954((class_2382)blockPos.method_10087(2).method_10077(3)).method_1019(smooth);
                        class_243 pos2 = class_243.method_24954((class_2382)blockPos.method_10086(3).method_10076(2).method_10089(2)).method_1019(smooth);
                        Render3D.drawBox(new class_238(pos1, pos2), color, 3.0f, true, true, true);
                        break;
                    }
                    if (!(yaw <= 157.5f)) break;
                    this.drawSidePlast(playerPos.method_10088(4).method_10072().method_10074(), smooth, color, -1, false);
                    break;
                }
                case "\u0412\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0442\u0440\u0430\u043f\u043a\u0430": {
                    this.drawItemCube(playerPos, smooth, 3.99f, color);
                    break;
                }
                case "\u0421\u0442\u0430\u043d": {
                    this.drawItemCube(playerPos, smooth, 15.01f, color);
                    break;
                }
                case "\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430": {
                    ProjectilePrediction.getInstance().drawPredictionInHand(matrix, List.of(class_1802.field_8543.method_7854()), MathAngle.cameraAngle());
                }
            }
        });
    }

    @EventHandler
    public void onDraw(DrawEvent e) {
        class_332 context = e.getDrawContext();
        class_4587 matrix = context.method_51448();
        this.structures.forEach(cons -> {
            double time = (cons.time - (double)System.currentTimeMillis()) / 1000.0;
            class_243 vec3d = Projection.worldSpaceToScreenSpace(cons.vec);
            String text = Calculate.round(time, 0.1f) + "\u0441";
            FontRenderer font = Fonts.getSize(14);
            float width = font.getStringWidth(text);
            float posX = (float)(vec3d.field_1352 - (double)(width / 2.0f));
            float posY = (float)vec3d.field_1351;
            float padding = 2.0f;
            if (Projection.canSee(cons.vec) && cons.anarchy == Network.getAnarchy() && Network.getWorldType().equals(cons.world)) {
                blur.render(ShapeProperties.create(matrix, posX - padding, posY - padding, width + padding * 2.0f, 10.0).round(1.5f).color(ColorAssist.HALF_BLACK).build());
                font.drawString(matrix, text, posX, posY + 1.0f, ColorAssist.getText());
                Render2D.defaultDrawStack(context, cons.item.method_7854(), posX - 14.0f, posY - 2.5f, true, false, 0.5f);
            }
        });
        this.serverEvents.forEach(event -> {
            String time;
            class_243 vec3d = Projection.worldSpaceToScreenSpace(event.vec);
            double timeOpen = (event.timeOpen - (double)System.currentTimeMillis()) / 1000.0;
            double timeEnd = (event.timeEnd - (double)System.currentTimeMillis()) / 1000.0;
            String distance = " [" + Calculate.round(FuntimeAssist.mc.method_1561().field_4686.method_19326().method_1022(event.vec), 0.1) + "m]";
            String string = timeOpen > 0.0 ? ("\u0414\u043e \u043d\u0430\u0447\u0430\u043b\u0430: " + Calculate.round(timeOpen, timeOpen < 30.0 ? (double)0.1f : 1.0) + "\u0441").replace(".0", "") : (timeEnd > 0.0 ? ("\u0414\u043e \u043a\u043e\u043d\u0446\u0430: " + Calculate.round(timeEnd, timeEnd < 30.0 ? (double)0.1f : 1.0) + "\u0441").replace(".0", "") : (time = "\u041a\u043e\u043d\u0435\u0446 \u0438\u0432\u0435\u043d\u0442\u0430!"));
            if (Projection.canSee(event.vec) && event.anarchy == Network.getAnarchy() && Network.getWorldType().equals(event.world)) {
                ArrayList<CallSite> list = new ArrayList<CallSite>(Collections.singletonList(event.name + distance));
                if (event.owner != null) {
                    list.add((CallSite)((Object)("\u041f\u0440\u0438\u0437\u0432\u0430\u043d: " + String.valueOf(class_124.field_1065) + event.owner)));
                }
                list.add((CallSite)((Object)time));
                if (event.lvl != null) {
                    list.add((CallSite)((Object)event.lvl));
                }
                this.draw(matrix, Fonts.getSize(14), list, vec3d);
            }
        });
    }

    private void drawItemCube(class_2338 playerPos, class_243 smooth, float size, int color) {
        class_238 box = new class_238(playerPos.method_10084()).method_997(smooth).method_1014((double)size);
        boolean inBox = FuntimeAssist.mc.field_1687.method_18456().stream().map(player -> PlayerSimulation.simulateOtherPlayer((class_1657)player, 2)).anyMatch(simulated -> simulated.player != FuntimeAssist.mc.field_1724 && box.method_994(simulated.boundingBox) && !FriendUtils.isFriend((class_1297)simulated.player));
        Render3D.drawBox(box, inBox ? ColorAssist.getFriendColor() : color, 3.0f, true, true, true);
    }

    private void drawItemRadius(class_4587 matrix, float distance, int color) {
        class_243 cosSin;
        int i;
        float playerHalfWidth = FuntimeAssist.mc.field_1724.method_17681() / 2.0f;
        int finalColor = this.validDistance(distance) ? ColorAssist.getFriendColor() : color;
        class_243 pos = Calculate.interpolate((class_1297)FuntimeAssist.mc.field_1724).method_1031((double)playerHalfWidth, 0.02, (double)playerHalfWidth);
        GL11.glEnable((int)2881);
        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask((boolean)false);
        RenderSystem.disableCull();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE_MINUS_CONSTANT_ALPHA);
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        int size = 90;
        for (i = 0; i <= size; ++i) {
            cosSin = Calculate.cosSin(i, size, distance);
            class_243 nextCosSin = Calculate.cosSin(i + 1, size, distance);
            Render3D.vertexLine(matrix, (class_4588)buffer, pos.method_1019(cosSin), pos.method_1031(cosSin.field_1352, cosSin.field_1351 + 2.0, cosSin.field_1350), ColorAssist.multAlpha(finalColor, 0.2f), ColorAssist.multAlpha(finalColor, 0.0f));
            Render3D.drawLine(pos.method_1019(cosSin), pos.method_1019(nextCosSin), finalColor, 2.0f, true);
        }
        size = 90;
        for (i = 0; i <= size; ++i) {
            cosSin = Calculate.cosSin(i, size, distance);
            Render3D.vertexLine(matrix, (class_4588)buffer, pos.method_1019(cosSin), pos.method_1031(cosSin.field_1352, cosSin.field_1351 - 2.0, cosSin.field_1350), ColorAssist.multAlpha(finalColor, 0.2f), ColorAssist.multAlpha(finalColor, 0.0f));
        }
        class_286.method_43433((class_9801)buffer.method_60800());
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask((boolean)true);
        RenderSystem.disableBlend();
        GL11.glDisable((int)2881);
    }

    private void draw(class_4587 matrix, FontRenderer font, List<String> list, class_243 vec3d) {
        float offsetY = 0.0f;
        for (int i = 0; i < list.size(); ++i) {
            String string = list.get(i);
            float width = font.getStringWidth(string);
            float posX = (float)(vec3d.field_1352 - (double)(width / 2.0f));
            blur.render(ShapeProperties.create(matrix, posX - 2.0f, vec3d.field_1351 - 2.0 + (double)offsetY, width + 4.0f, 10.0).softness(3.0f).round(this.getRound(font, list, i, width)).color(ColorAssist.HALF_BLACK).build());
            font.drawString(matrix, string, posX, vec3d.field_1351 + 1.0 + (double)offsetY, ColorAssist.getText());
            offsetY += 10.0f;
        }
    }

    private void drawSidePlast(class_2338 blockPos, class_243 smooth, int color, int i, boolean ff) {
        class_243 vec3d = class_243.method_24954((class_2382)blockPos).method_1019(smooth);
        float width = 2.0f;
        int quadColor = ColorAssist.multAlpha(color, 0.15f);
        this.drawHorizontalLines(vec3d, color, width, i, ff);
        this.drawHorizontalLines(vec3d, color, width, i, ff);
        this.drawVerticalLines(vec3d, color, width, i, ff);
        this.drawHorizontalQuads(vec3d, quadColor, i, ff);
        this.drawHorizontalQuads(vec3d, quadColor, i, ff);
        this.drawVerticalQuads(vec3d, quadColor, i, ff);
    }

    private void drawHorizontalLines(class_243 vec3d, int color, float width, int i, boolean ff) {
        int f;
        float x = ff ? (float)i : (float)(-i);
        class_243 class_2432 = vec3d;
        vec3d = vec3d.method_1031((double)x, 0.0, 0.0);
        Render3D.drawLine(class_2432, vec3d, color, width, true);
        for (f = 0; f < 4; ++f) {
            class_243 class_2433 = vec3d;
            vec3d = vec3d.method_1031(0.0, 0.0, (double)i);
            Render3D.drawLine(class_2433, vec3d, color, width, true);
            class_243 class_2434 = vec3d;
            vec3d = vec3d.method_1031((double)x, 0.0, 0.0);
            Render3D.drawLine(class_2434, vec3d, color, width, true);
        }
        class_243 class_2435 = vec3d;
        vec3d = vec3d.method_1031(0.0, 0.0, (double)i);
        Render3D.drawLine(class_2435, vec3d, color, width, true);
        class_243 class_2436 = vec3d;
        vec3d = vec3d.method_1031((double)(x * -2.0f), 0.0, 0.0);
        Render3D.drawLine(class_2436, vec3d, color, width, true);
        for (f = 0; f < 3; ++f) {
            class_243 class_2437 = vec3d;
            vec3d = vec3d.method_1031(0.0, 0.0, (double)(i * -1));
            Render3D.drawLine(class_2437, vec3d, color, width, true);
            class_243 class_2438 = vec3d;
            vec3d = vec3d.method_1031((double)(x * -1.0f), 0.0, 0.0);
            Render3D.drawLine(class_2438, vec3d, color, width, true);
        }
        Render3D.drawLine(vec3d, vec3d.method_1031(0.0, 0.0, (double)(i * -2)), color, width, true);
    }

    private void drawVerticalLines(class_243 vec3d, int color, float width, int i, boolean ff) {
        int f;
        float x = ff ? (float)i : (float)(-i);
        class_243 class_2432 = vec3d;
        vec3d = vec3d.method_1031((double)x, 0.0, 0.0);
        Render3D.drawLine(class_2432, vec3d, color, width, true);
        for (f = 0; f < 4; ++f) {
            class_243 class_2433 = vec3d;
            vec3d = vec3d.method_1031(0.0, 0.0, (double)i);
            Render3D.drawLine(class_2433, vec3d, color, width, true);
            class_243 class_2434 = vec3d;
            vec3d = vec3d.method_1031((double)x, 0.0, 0.0);
            Render3D.drawLine(class_2434, vec3d, color, width, true);
        }
        class_243 class_2435 = vec3d;
        vec3d = vec3d.method_1031(0.0, 0.0, (double)i);
        Render3D.drawLine(class_2435, vec3d, color, width, true);
        class_243 class_2436 = vec3d;
        vec3d = vec3d.method_1031((double)(x * -2.0f), 0.0, 0.0);
        Render3D.drawLine(class_2436, vec3d, color, width, true);
        for (f = 0; f < 3; ++f) {
            class_243 class_2437 = vec3d;
            vec3d = vec3d.method_1031(0.0, 0.0, (double)(i * -1));
            Render3D.drawLine(class_2437, vec3d, color, width, true);
            class_243 class_2438 = vec3d;
            vec3d = vec3d.method_1031((double)(x * -1.0f), 0.0, 0.0);
            Render3D.drawLine(class_2438, vec3d, color, width, true);
        }
        Render3D.drawLine(vec3d, vec3d.method_1031(0.0, 0.0, (double)(i * -2)), color, width, true);
    }

    private void drawHorizontalQuads(class_243 vec3d, int color, int i, boolean ff) {
        vec3d = vec3d.method_1031(0.0, 0.001, 0.0);
        float x = ff ? (float)i : (float)(-i);
        Render3D.drawQuad(vec3d, vec3d.method_1031((double)x, 0.0, 0.0), vec3d.method_1031((double)x, 0.0, (double)(i * 2)), vec3d.method_1031(0.0, 0.0, (double)(i * 2)), color, true);
        for (int f = 0; f < 3; ++f) {
            vec3d = vec3d.method_1031((double)x, 0.0, (double)i);
            Render3D.drawQuad(vec3d, vec3d.method_1031((double)x, 0.0, 0.0), vec3d.method_1031((double)x, 0.0, (double)(i * 2)), vec3d.method_1031(0.0, 0.0, (double)(i * 2)), color, true);
        }
        vec3d = vec3d.method_1031((double)x, 0.0, (double)i);
        Render3D.drawQuad(vec3d, vec3d.method_1031((double)x, 0.0, 0.0), vec3d.method_1031((double)x, 0.0, (double)i), vec3d.method_1031(0.0, 0.0, (double)i), color, true);
    }

    private void drawVerticalQuads(class_243 vec3d, int color, int i, boolean ff) {
        int f;
        float x = ff ? (float)i : (float)(-i);
        Render3D.drawQuad(vec3d, vec3d.method_1031((double)x, 0.0, 0.0), vec3d.method_1031((double)x, 5.0, 0.0), vec3d.method_1031(0.0, 5.0, 0.0), color, true);
        for (f = 0; f < 4; ++f) {
            vec3d = vec3d.method_1031((double)x, 0.0, 0.0);
            Render3D.drawQuad(vec3d, vec3d.method_1031(0.0, 0.0, (double)i), vec3d.method_1031(0.0, 5.0, (double)i), vec3d.method_1031(0.0, 5.0, 0.0), color, true);
            vec3d = vec3d.method_1031(0.0, 0.0, (double)i);
            Render3D.drawQuad(vec3d, vec3d.method_1031((double)x, 0.0, 0.0), vec3d.method_1031((double)x, 5.0, 0.0), vec3d.method_1031(0.0, 5.0, 0.0), color, true);
        }
        vec3d = vec3d.method_1031((double)x, 0.0, 0.0);
        Render3D.drawQuad(vec3d, vec3d.method_1031(0.0, 0.0, (double)i), vec3d.method_1031(0.0, 5.0, (double)i), vec3d.method_1031(0.0, 5.0, 0.0), color, true);
        vec3d = vec3d.method_1031(0.0, 0.0, (double)i);
        Render3D.drawQuad(vec3d, vec3d.method_1031((double)(x * -2.0f), 0.0, 0.0), vec3d.method_1031((double)(x * -2.0f), 5.0, 0.0), vec3d.method_1031(0.0, 5.0, 0.0), color, true);
        vec3d = vec3d.method_1031((double)(x * -1.0f), 0.0, 0.0);
        for (f = 0; f < 3; ++f) {
            vec3d = vec3d.method_1031((double)(x * -1.0f), 0.0, 0.0);
            Render3D.drawQuad(vec3d, vec3d.method_1031(0.0, 0.0, (double)(i * -1)), vec3d.method_1031(0.0, 5.0, (double)(i * -1)), vec3d.method_1031(0.0, 5.0, 0.0), color, true);
            vec3d = vec3d.method_1031(0.0, 0.0, (double)(i * -1));
            Render3D.drawQuad(vec3d, vec3d.method_1031((double)(x * -1.0f), 0.0, 0.0), vec3d.method_1031((double)(x * -1.0f), 5.0, 0.0), vec3d.method_1031(0.0, 5.0, 0.0), color, true);
        }
        vec3d = vec3d.method_1031((double)(x * -1.0f), 0.0, 0.0);
        Render3D.drawQuad(vec3d, vec3d.method_1031(0.0, 0.0, (double)(i * -2)), vec3d.method_1031(0.0, 5.0, (double)(i * -2)), vec3d.method_1031(0.0, 5.0, 0.0), color, true);
    }

    private void addEvent(String name, String lvl, String owner, class_243 vec3d, String world, int timeOpen, int timeLoot) {
        if (this.serverEvents.stream().noneMatch(server -> server.vec.equals((Object)vec3d))) {
            long open = System.currentTimeMillis() + (long)timeOpen * 1000L;
            long loot = open + (long)timeLoot * 1000L;
            this.serverEvents.add(new ServerEvent(name, lvl, owner, vec3d, world, Network.getAnarchy(), open, loot));
        }
    }

    private void addStructure(class_1792 item, class_243 vec, double time) {
        if (this.structures.stream().noneMatch(str -> str.vec.equals((Object)vec))) {
            this.structures.add(new Structure(item, vec, Network.getWorldType(), Network.getAnarchy(), time));
        }
    }

    private Vector4f getRound(FontRenderer font, List<String> list, int i, float width) {
        if (i == 0) {
            float next = font.getStringWidth(list.get(i + 1));
            return next >= width ? new Vector4f(2.0f, 0.0f, 2.0f, 0.0f) : new Vector4f(2.0f);
        }
        if (i == list.size() - 1) {
            float prev = font.getStringWidth(list.get(i - 1));
            return prev >= width ? new Vector4f(0.0f, 2.0f, 0.0f, 2.0f) : new Vector4f(2.0f);
        }
        float prev = font.getStringWidth(list.get(i - 1));
        float next = font.getStringWidth(list.get(i + 1));
        return prev >= width ? (next >= width ? new Vector4f() : new Vector4f(0.0f, 2.0f, 0.0f, 2.0f)) : new Vector4f(2.0f);
    }

    private boolean validDistance(float dist) {
        return dist == 0.0f || FuntimeAssist.mc.field_1687.method_18456().stream().anyMatch(p -> p != FuntimeAssist.mc.field_1724 && !FriendUtils.isFriend((class_1297)p) && FuntimeAssist.mc.field_1724.method_5739((class_1297)p) <= dist);
    }

    private boolean isTrap(class_2338 center) {
        int inconsistencies = 0;
        for (class_2338 pos : PlayerInteractionHelper.getCube(center, 2.0f)) {
            class_2680 state;
            if (pos.method_46558().method_1022(center.method_46558()) < 2.0) {
                state = this.blockStateMap.get(pos);
                if (state != null && !state.method_26215()) {
                    ++inconsistencies;
                }
            } else if (!(pos.equals((Object)center.method_10086(2).method_10095().method_10078()) || pos.equals((Object)center.method_10086(2).method_10095().method_10067()) || pos.equals((Object)center.method_10086(2).method_10072().method_10078()) || pos.equals((Object)center.method_10086(2).method_10072().method_10067()) || (state = this.blockStateMap.get(pos)) != null && !state.method_26215())) {
                ++inconsistencies;
            }
            if (inconsistencies <= true) continue;
            return false;
        }
        return true;
    }

    private boolean isBigTrap(class_2338 center) {
        int inconsistencies = 0;
        for (class_2338 pos : PlayerInteractionHelper.getCube(center, 3.0f)) {
            class_2680 state;
            if (Math.abs(pos.method_10263() - center.method_10263()) <= 2 && Math.abs(pos.method_10264() - center.method_10264()) <= 2 && Math.abs(pos.method_10260() - center.method_10260()) <= 2) {
                state = this.blockStateMap.get(pos);
                if (state != null && !state.method_26215()) {
                    ++inconsistencies;
                }
            } else if (!pos.equals((Object)center.method_10086(3)) && ((state = this.blockStateMap.get(pos)) == null || state.method_26215())) {
                ++inconsistencies;
            }
            if (inconsistencies <= true) continue;
            return false;
        }
        return true;
    }

    public List<KeyBind> getKeyBindings() {
        return this.keyBindings;
    }

    public BindSetting getSetting(String name) {
        return this.keyBindings.stream().filter(bind -> bind.setting().getName().equals(name)).map(KeyBind::setting).findFirst().orElse(null);
    }

    private static enum ActionState {
        IDLE,
        SLOWING_DOWN,
        WAITING_STOP,
        SWAP_TO_ITEM,
        USE_ITEM,
        SWAP_BACK,
        SPEEDING_UP;

    }

    public record KeyBind(class_1792 item, BindSetting setting, float distance) {
    }

    private static class ItemInfo {
        String searchName;
        class_1792 item;
        String displayName;

        ItemInfo(String searchName, class_1792 item, String displayName) {
            this.searchName = searchName;
            this.item = item;
            this.displayName = displayName;
        }
    }

    public record ServerEvent(String name, String lvl, String owner, class_243 vec, String world, int anarchy, double timeOpen, double timeEnd) {
    }

    public record Structure(class_1792 item, class_243 vec, String world, int anarchy, double time) {
    }
}

