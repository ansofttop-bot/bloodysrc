/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1703
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 *  net.minecraft.class_437
 *  net.minecraft.class_476
 */
package fun.bloody.features.impl.misc;

import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.interactions.inv.InventoryTask;
import fun.bloody.utils.math.time.StopWatch;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_437;
import net.minecraft.class_476;

public class ChestStealer
extends Module {
    private final StopWatch stopWatch = new StopWatch();
    private final SelectSetting modeSetting = new SelectSetting("\u0422\u0438\u043f", "\u0412\u044b\u0431\u0438\u0440\u0430\u0435\u0442 \u0442\u0438\u043f \u0441\u0442\u0438\u043b\u0430").value("FunTime", "WhiteList", "Default").selected("FunTime");
    private final SliderSettings delaySetting = new SliderSettings("\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430", "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u043c\u0435\u0436\u0434\u0443 \u043a\u043b\u0438\u043a\u0430\u043c\u0438 \u043f\u043e \u0441\u043b\u043e\u0442\u0443").setValue(100.0f).range(0, 1000).visible(() -> this.modeSetting.isSelected("WhiteList") || this.modeSetting.isSelected("Default"));
    private final MultiSelectSetting itemSettings = new MultiSelectSetting("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u044b, \u043a\u043e\u0442\u043e\u0440\u044b\u0435 \u0432\u043e\u0440 \u0431\u0443\u0434\u0435\u0442 \u043f\u043e\u0434\u0431\u0438\u0440\u0430\u0442\u044c").value("Player Head", "Totem Of Undying", "Elytra", "Netherite Sword", "Netherite Helmet", "Netherite ChestPlate", "Netherite Leggings", "Netherite Boots", "Netherite Ingot", "Netherite Scrap").visible(() -> this.modeSetting.isSelected("WhiteList"));

    public ChestStealer() {
        super("ChestStealer", "Chest Stealer", ModuleCategory.MISC);
        this.setup(this.modeSetting, this.delaySetting, this.itemSettings);
    }

    @EventHandler
    public void onTick(TickEvent e) {
        switch (this.modeSetting.getSelected()) {
            case "FunTime": {
                class_476 sh;
                class_437 class_4372 = ChestStealer.mc.field_1755;
                if (!(class_4372 instanceof class_476) || !(sh = (class_476)class_4372).method_25440().getString().toLowerCase().contains("\u043c\u0438\u0441\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0439") || ChestStealer.mc.field_1724.method_7357().method_7904(class_1802.field_8054.method_7854())) break;
                ((class_1707)sh.method_17577()).field_7761.stream().filter(s -> s.method_7681() && !s.field_7871.equals((Object)ChestStealer.mc.field_1724.method_31548()) && this.stopWatch.every(150.0)).forEach(s -> InventoryTask.clickSlot(s, 0, class_1713.field_7794, true));
                break;
            }
            case "WhiteList": 
            case "Default": {
                class_1703 class_17032 = ChestStealer.mc.field_1724.field_7512;
                if (!(class_17032 instanceof class_1707)) break;
                class_1707 sh = (class_1707)class_17032;
                sh.field_7761.forEach(s -> {
                    if (s.method_7681() && !s.field_7871.equals((Object)ChestStealer.mc.field_1724.method_31548()) && (this.modeSetting.isSelected("Default") || this.whiteList(s.method_7677().method_7909())) && this.stopWatch.every(this.delaySetting.getValue())) {
                        InventoryTask.clickSlot(s, 0, class_1713.field_7794, true);
                    }
                });
            }
        }
    }

    private boolean whiteList(class_1792 item) {
        return this.itemSettings.getSelected().toString().toLowerCase().contains(item.toString().toLowerCase().replace("_", ""));
    }
}

