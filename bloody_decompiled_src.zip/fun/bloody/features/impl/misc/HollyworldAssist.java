/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1304
 *  net.minecraft.class_1309
 *  net.minecraft.class_1542
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_1792
 *  net.minecraft.class_1796
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1890
 *  net.minecraft.class_1893
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_2596
 *  net.minecraft.class_2653
 *  net.minecraft.class_2656
 *  net.minecraft.class_2775
 *  net.minecraft.class_2824
 *  net.minecraft.class_332
 *  net.minecraft.class_3675
 *  net.minecraft.class_3944
 *  net.minecraft.class_3988
 *  net.minecraft.class_437
 *  net.minecraft.class_4587
 *  net.minecraft.class_476
 *  net.minecraft.class_5250
 *  net.minecraft.class_6880
 *  net.minecraft.class_7439
 *  net.minecraft.class_7924
 *  net.minecraft.class_9279
 *  net.minecraft.class_9288
 *  net.minecraft.class_9331
 *  net.minecraft.class_9334
 *  org.apache.commons.lang3.StringUtils
 *  org.lwjgl.glfw.GLFW
 */
package fun.bloody.features.impl.misc;

import fun.bloody.display.hud.CoolDowns;
import fun.bloody.display.hud.Notifications;
import fun.bloody.events.container.SetScreenEvent;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.events.player.RotationUpdateEvent;
import fun.bloody.events.render.DrawEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.chat.StringHelper;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.color.ColorAssist;
import fun.bloody.utils.display.color.GradientAssist;
import fun.bloody.utils.display.font.FontRenderer;
import fun.bloody.utils.display.font.Fonts;
import fun.bloody.utils.display.shape.ShapeProperties;
import fun.bloody.utils.features.aura.point.MultiPoint;
import fun.bloody.utils.features.aura.rotations.constructor.LinearConstructor;
import fun.bloody.utils.features.aura.utils.MathAngle;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.features.aura.warp.TurnsConfig;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.interactions.inv.InventoryFlowManager;
import fun.bloody.utils.interactions.inv.InventoryTask;
import fun.bloody.utils.math.calc.Calculate;
import fun.bloody.utils.math.projection.Projection;
import fun.bloody.utils.math.script.Script;
import fun.bloody.utils.math.task.TaskPriority;
import fun.bloody.utils.math.time.StopWatch;
import java.lang.runtime.SwitchBootstraps;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.StreamSupport;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1796;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2653;
import net.minecraft.class_2656;
import net.minecraft.class_2775;
import net.minecraft.class_2824;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_3944;
import net.minecraft.class_3988;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_476;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_7439;
import net.minecraft.class_7924;
import net.minecraft.class_9279;
import net.minecraft.class_9288;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.glfw.GLFW;

public class HollyworldAssist
extends Module {
    private final List<KeyBind> keyBindings = new ArrayList<KeyBind>();
    private final MultiPoint pointFinder = new MultiPoint();
    private final StopWatch itemsWatch = new StopWatch();
    private final StopWatch shulkerWatch = new StopWatch();
    private final StopWatch repairWatch = new StopWatch();
    private final Script script2 = new Script();
    private UUID entityUUID;
    private final Map<Integer, class_1792> stacks = new HashMap<Integer, class_1792>();
    private final BooleanSetting autoLootSetting = new BooleanSetting("\u0410\u0432\u0442\u043e \u043b\u0443\u0442", "\u041a\u0440\u0430\u0436\u0430 \u043b\u0443\u0442\u0430 \u0441 \u0431\u043e\u0442\u043e\u0432 \u043d\u0430 \u0438\u0432\u0435\u043d\u0442\u0435").setValue(true);
    private final BooleanSetting autoShulkerSetting = new BooleanSetting("\u0410\u0432\u0442\u043e \u0448\u0430\u043b\u043a\u0435\u0440", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043a\u043b\u0430\u0434\u0435\u0442 \u043b\u0443\u0442 \u0432 \u0448\u0430\u043b\u043a\u0435\u0440").setValue(true);
    private final BooleanSetting autoRepairSetting = new BooleanSetting("\u0410\u0432\u0442\u043e \u0440\u0435\u043c\u043e\u043d\u0442", "\u0410\u0432\u0442\u043e \u0440\u0435\u043c\u043e\u043d\u0442\u0438\u0440\u0443\u0435\u0442 \u0431\u0440\u043e\u043d\u044e \u043f\u0443\u0437\u044b\u0440\u0435\u043c \u043e\u043f\u044b\u0442\u0430 \u043f\u0440\u0438 \u043d\u0438\u0437\u043a\u043e\u0439 \u043f\u0440\u043e\u0447\u043d\u043e\u0441\u0442\u0438").setValue(true);
    private final List<String> potionQueue = new ArrayList<String>();
    private final StopWatch potionTimer = new StopWatch();
    private final Map<String, ItemInfo> itemConfig = new HashMap<String, ItemInfo>();
    private final Map<String, Boolean> itemStates = new HashMap<String, Boolean>();
    private final Map<String, Boolean> lastKeyStates = new HashMap<String, Boolean>();
    private final Map<String, Boolean> keyPressedThisTick = new HashMap<String, Boolean>();
    private int originalSlot = -1;
    private int targetSlot = -1;
    private ActionState actionState = ActionState.IDLE;
    private long actionTimer = 0L;
    private String pendingItemKey = null;
    private long stopMovementUntil = 0L;
    private boolean keysOverridden = false;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private int originalSourceSlot = -1;

    public static HollyworldAssist getInstance() {
        return Instance.get(HollyworldAssist.class);
    }

    public HollyworldAssist() {
        super("Hollyworld Assist", "Hollyworld Assist", ModuleCategory.MISC);
        this.initialize();
    }

    public void initialize() {
        this.setup(this.autoLootSetting, this.autoShulkerSetting, this.autoRepairSetting);
        this.keyBindings.add(new KeyBind(class_1802.field_8662, new BindSetting("\u0412\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0442\u0440\u0430\u043f\u043a\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0432\u0437\u0440\u044b\u0432\u043d\u043e\u0439 \u0442\u0440\u0430\u043f\u043a\u0438"), 5.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8882, new BindSetting("\u041e\u0431\u044b\u0447\u043d\u0430\u044f \u0442\u0440\u0430\u043f\u043a\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u043e\u0431\u044b\u0447\u043d\u043e\u0439 \u0442\u0440\u0430\u043f\u043a\u0438"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8137, new BindSetting("\u0421\u0442\u0430\u043d", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0441\u0442\u0430\u043d\u0430"), 30.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8814, new BindSetting("\u0412\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0448\u0442\u0443\u0447\u043a\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0432\u0437\u0440\u044b\u0432\u043d\u043e\u0439 \u0448\u0442\u0443\u0447\u043a\u0438"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8543, new BindSetting("\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0441\u043d\u0435\u0436\u043a\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8693, new BindSetting("\u0421\u0432\u0435\u0442\u0438\u043b\u044c\u043d\u0438\u043a \u0414\u0436\u0435\u043a\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0441\u0432\u0435\u0442\u0438\u043b\u044c\u043d\u0438\u043a\u0430 \u0414\u0436\u0435\u043a\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8287, new BindSetting("\u041f\u0443\u0437\u044b\u0440\u044c \u043e\u043f\u044b\u0442\u0430", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u043f\u0443\u0437\u044b\u0440\u044f \u043e\u043f\u044b\u0442\u0430"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8520, new BindSetting("\u0420\u044e\u043a\u0437\u0430\u043a 1 \u0443\u0440\u043e\u0432\u043d\u044f", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0440\u044e\u043a\u0437\u0430\u043a\u0430 1 \u0443\u0440\u043e\u0432\u043d\u044f"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8350, new BindSetting("\u0420\u044e\u043a\u0437\u0430\u043a 2 \u0443\u0440\u043e\u0432\u043d\u044f", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0440\u044e\u043a\u0437\u0430\u043a\u0430 2 \u0443\u0440\u043e\u0432\u043d\u044f"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8676, new BindSetting("\u0420\u044e\u043a\u0437\u0430\u043a 3 \u0443\u0440\u043e\u0432\u043d\u044f", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0440\u044e\u043a\u0437\u0430\u043a\u0430 3 \u0443\u0440\u043e\u0432\u043d\u044f"), 0.0f));
        this.keyBindings.add(new KeyBind(class_1802.field_8520, new BindSetting("\u0420\u044e\u043a\u0437\u0430\u043a 4 \u0443\u0440\u043e\u0432\u043d\u044f", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430 \u0440\u044e\u043a\u0437\u0430\u043a\u0430 4 \u0443\u0440\u043e\u0432\u043d\u044f"), 0.0f));
        this.keyBindings.forEach(bind -> this.setup(bind.setting));
        this.itemConfig.put("dtrap", new ItemInfo("\u0432\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0442\u0440\u0430\u043f\u043a\u0430", class_1802.field_8662, "\u0412\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0442\u0440\u0430\u043f\u043a\u0430"));
        this.itemConfig.put("trap_holy", new ItemInfo("\u0442\u0440\u0430\u043f\u043a\u0430", class_1802.field_8882, "\u041e\u0431\u044b\u0447\u043d\u0430\u044f \u0442\u0440\u0430\u043f\u043a\u0430"));
        this.itemConfig.put("stan", new ItemInfo("\u0441\u0442\u0430\u043d", class_1802.field_8137, "\u0421\u0442\u0430\u043d"));
        this.itemConfig.put("ditem", new ItemInfo("\u0432\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0448\u0442\u0443\u0447\u043a\u0430", class_1802.field_8814, "\u0412\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0448\u0442\u0443\u0447\u043a\u0430"));
        this.itemConfig.put("snow", new ItemInfo("\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430", class_1802.field_8543, "\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430"));
        this.itemConfig.put("tikva", new ItemInfo("\u0441\u0432\u0435\u0442\u0438\u043b\u044c\u043d\u0438\u043a \u0434\u0436\u0435\u0439\u043a\u0430", class_1802.field_8693, "\u0421\u0432\u0435\u0442\u0438\u043b\u044c\u043d\u0438\u043a \u0414\u0436\u0435\u043a\u0430"));
        this.itemConfig.put("exp", new ItemInfo("\u043f\u0443\u0437\u044b\u0440\u044c \u043e\u043f\u044b\u0442\u0430", class_1802.field_8287, "\u041f\u0443\u0437\u044b\u0440\u044c \u043e\u043f\u044b\u0442\u0430"));
        this.itemConfig.put("shulker1", new ItemInfo("\u0440\u044e\u043a\u0437\u0430\u043a (i \u0443\u0440\u043e\u0432\u0435\u043d\u044c)", class_1802.field_8520, "\u0420\u044e\u043a\u0437\u0430\u043a 1 \u0443\u0440\u043e\u0432\u043d\u044f"));
        this.itemConfig.put("shulker2", new ItemInfo("\u0440\u044e\u043a\u0437\u0430\u043a (ii \u0443\u0440\u043e\u0432\u0435\u043d\u044c)", class_1802.field_8350, "\u0420\u044e\u043a\u0437\u0430\u043a 2 \u0443\u0440\u043e\u0432\u043d\u044f"));
        this.itemConfig.put("shulker3", new ItemInfo("\u0440\u044e\u043a\u0437\u0430\u043a (iii \u0443\u0440\u043e\u0432\u0435\u043d\u044c)", class_1802.field_8676, "\u0420\u044e\u043a\u0437\u0430\u043a 3 \u0443\u0440\u043e\u0432\u043d\u044f"));
        this.itemConfig.put("shulker4", new ItemInfo("\u0440\u044e\u043a\u0437\u0430\u043a (iv \u0443\u0440\u043e\u0432\u0435\u043d\u044c)", class_1802.field_8520, "\u0420\u044e\u043a\u0437\u0430\u043a 4 \u0443\u0440\u043e\u0432\u043d\u044f"));
        this.itemConfig.keySet().forEach(key -> {
            this.itemStates.put((String)key, false);
            this.lastKeyStates.put((String)key, false);
            this.keyPressedThisTick.put((String)key, false);
        });
    }

    @Override
    public void activate() {
        this.script2.cleanup();
        this.stacks.clear();
        this.potionQueue.clear();
        this.potionTimer.reset();
        this.itemStates.replaceAll((k, v) -> false);
        this.lastKeyStates.replaceAll((k, v) -> false);
        this.keyPressedThisTick.replaceAll((k, v) -> false);
        this.actionState = ActionState.IDLE;
        this.originalSlot = -1;
        this.targetSlot = -1;
        this.originalSourceSlot = -1;
        this.pendingItemKey = null;
        this.stopMovementUntil = 0L;
        this.keysOverridden = false;
    }

    @Override
    public void deactivate() {
        this.itemStates.replaceAll((k, v) -> false);
        this.lastKeyStates.replaceAll((k, v) -> false);
        this.keyPressedThisTick.replaceAll((k, v) -> false);
        this.potionQueue.clear();
        this.potionTimer.reset();
        this.actionState = ActionState.IDLE;
        this.originalSlot = -1;
        this.targetSlot = -1;
        this.originalSourceSlot = -1;
        this.pendingItemKey = null;
        this.stopMovementUntil = 0L;
        if (this.keysOverridden) {
            HollyworldAssist.mc.field_1690.field_1894.method_23481(false);
            HollyworldAssist.mc.field_1690.field_1881.method_23481(false);
            HollyworldAssist.mc.field_1690.field_1913.method_23481(false);
            HollyworldAssist.mc.field_1690.field_1849.method_23481(false);
        }
        this.keysOverridden = false;
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        if (!PlayerInteractionHelper.nullCheck()) {
            class_2596<?> class_25962 = e.getPacket();
            Objects.requireNonNull(class_25962);
            class_2596<?> class_25963 = class_25962;
            int n = 0;
            block6: while (true) {
                switch (SwitchBootstraps.typeSwitch("typeSwitch", new Object[]{class_2775.class, class_2653.class, class_7439.class, class_3944.class}, class_25963, n)) {
                    case 0: {
                        class_1297 class_12972;
                        class_2775 item = (class_2775)class_25963;
                        if (!this.autoShulkerSetting.isValue() || item.method_11912() != HollyworldAssist.mc.field_1724.method_5628() || !((class_12972 = HollyworldAssist.mc.field_1687.method_8469(item.method_11915())) instanceof class_1542)) {
                            n = 1;
                            continue block6;
                        }
                        class_1542 entity = (class_1542)class_12972;
                        class_1799 stack = entity.method_6983();
                        if (stack.method_57824(class_9334.field_49622) != null) break block6;
                        this.stacks.put(-Calculate.getRandom(1, 999999999), stack.method_7909());
                        this.shulkerWatch.reset();
                        break block6;
                    }
                    case 1: {
                        class_2653 slot = (class_2653)class_25963;
                        if (slot.method_11452() != 0) break block6;
                        class_1792 item = slot.method_11449().method_7909();
                        this.stacks.entrySet().stream().filter(entry -> (Integer)entry.getKey() < 0 && ((class_1792)entry.getValue()).equals(item)).findFirst().ifPresent(entry -> {
                            this.stacks.put(slot.method_11450() + 18, item);
                            this.stacks.remove(entry.getKey());
                        });
                        break block6;
                    }
                    case 2: {
                        String subString;
                        class_7439 gameMessage = (class_7439)class_25963;
                        String message = gameMessage.comp_763().getString();
                        if (!message.contains("\u25b6 \u041f\u043e\u0432\u0442\u043e\u0440\u043d\u043e \u0430\u043a\u0442\u0438\u0432\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u041f\u0443\u0437\u044b\u0440\u044c \u043e\u043f\u044b\u0442\u0430 \u0432\u043e\u0437\u043c\u043e\u0436\u043d\u043e \u0447\u0435\u0440\u0435\u0437") || (subString = StringUtils.substringBetween((String)message, (String)"\u0447\u0435\u0440\u0435\u0437 ", (String)" \u0441\u0435\u043a\u0443\u043d\u0434")) == null || subString.isEmpty()) break block6;
                        int duration = Integer.parseInt(subString) * 20;
                        class_1796 manager = HollyworldAssist.mc.field_1724.method_7357();
                        manager.method_62835(class_1802.field_8287.method_7854(), duration);
                        CoolDowns.getInstance().packet(new PacketEvent((class_2596<?>)new class_2656(manager.method_62836(class_1802.field_8287.method_7854()), duration), PacketEvent.Type.RECEIVE));
                        break block6;
                    }
                    case 3: {
                        class_3944 openScreen = (class_3944)class_25963;
                        if (!openScreen.method_17594().getString().contains("\u0420\u044e\u043a\u0437\u0430\u043a") || this.stacks.isEmpty()) {
                            n = 4;
                            continue block6;
                        }
                        this.script2.update();
                        break block6;
                    }
                }
                break;
            }
        }
    }

    @EventHandler
    public void onSetScreen(SetScreenEvent e) {
        class_476 screen;
        class_437 class_4372 = e.getScreen();
        if (class_4372 instanceof class_476 && (screen = (class_476)class_4372).method_25440().getString().contains("\u0420\u044e\u043a\u0437\u0430\u043a") && !this.script2.isFinished()) {
            e.setScreen(null);
        }
    }

    @EventHandler
    public void onRotationUpdate(RotationUpdateEvent e) {
        String potionKey;
        ItemInfo info;
        boolean noMoveOrAction;
        if (e.getType() != 0 || HollyworldAssist.mc.field_1755 != null) {
            return;
        }
        boolean bl = noMoveOrAction = System.currentTimeMillis() < this.stopMovementUntil || this.actionState != ActionState.IDLE && this.actionState != ActionState.SPEEDING_UP;
        if (noMoveOrAction) {
            HollyworldAssist.mc.field_1690.field_1894.method_23481(false);
            HollyworldAssist.mc.field_1690.field_1881.method_23481(false);
            HollyworldAssist.mc.field_1690.field_1913.method_23481(false);
            HollyworldAssist.mc.field_1690.field_1849.method_23481(false);
            if (HollyworldAssist.mc.field_1724.field_3913 != null) {
                HollyworldAssist.mc.field_1724.field_3913.field_3905 = 0.0f;
                HollyworldAssist.mc.field_1724.field_3913.field_3907 = 0.0f;
            }
            if (HollyworldAssist.mc.field_1724.method_5624()) {
                HollyworldAssist.mc.field_1724.method_5728(false);
            }
        }
        for (KeyBind bind : this.keyBindings) {
            ItemInfo info2;
            String key;
            if ((key = (switch (bind.setting.getName()) {
                case "\u0412\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0442\u0440\u0430\u043f\u043a\u0430" -> "dtrap";
                case "\u041e\u0431\u044b\u0447\u043d\u0430\u044f \u0442\u0440\u0430\u043f\u043a\u0430" -> "trap_holy";
                case "\u0421\u0442\u0430\u043d" -> "stan";
                case "\u0412\u0437\u0440\u044b\u0432\u043d\u0430\u044f \u0448\u0442\u0443\u0447\u043a\u0430" -> "ditem";
                case "\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430" -> "snow";
                case "\u0421\u0432\u0435\u0442\u0438\u043b\u044c\u043d\u0438\u043a \u0414\u0436\u0435\u043a\u0430" -> "tikva";
                case "\u041f\u0443\u0437\u044b\u0440\u044c \u043e\u043f\u044b\u0442\u0430" -> "exp";
                case "\u0420\u044e\u043a\u0437\u0430\u043a 1 \u0443\u0440\u043e\u0432\u043d\u044f" -> "shulker1";
                case "\u0420\u044e\u043a\u0437\u0430\u043a 2 \u0443\u0440\u043e\u0432\u043d\u044f" -> "shulker2";
                case "\u0420\u044e\u043a\u0437\u0430\u043a 3 \u0443\u0440\u043e\u0432\u043d\u044f" -> "shulker3";
                case "\u0420\u044e\u043a\u0437\u0430\u043a 4 \u0443\u0440\u043e\u0432\u043d\u044f" -> "shulker4";
                default -> null;
            })) == null || !bind.setting.isVisible()) continue;
            boolean currentKey = false;
            if (bind.setting.getKey() != -1) {
                currentKey = bind.setting.getKey() >= 0 && bind.setting.getKey() <= 7 ? GLFW.glfwGetMouseButton((long)mc.method_22683().method_4490(), (int)bind.setting.getKey()) == 1 : class_3675.method_15987((long)mc.method_22683().method_4490(), (int)bind.setting.getKey());
            }
            boolean wasPressedLastTick = this.lastKeyStates.getOrDefault(key, false);
            if (currentKey && !wasPressedLastTick && (info2 = this.itemConfig.get(key)) != null) {
                class_1735 slot2 = InventoryTask.getSlot(s -> s.method_7677().method_7909().equals(info.item) && InventoryTask.getCleanName(s.method_7677().method_7964()).contains(info.searchName.toLowerCase()));
                boolean addStarPrefix = false;
                if (slot2 != null) {
                    class_1799 stack2 = slot2.method_7677();
                    if (HollyworldAssist.mc.field_1724.method_7357().method_7904(stack2)) {
                        CoolDowns.getInstance().list.stream().filter(c -> c.item().equals(info.item)).findFirst().ifPresent(coolDown -> {
                            int time = Math.toIntExact(-coolDown.time().elapsedTime() / 1000L);
                            String duration = StringHelper.getDuration(time);
                            class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u0431\u0443\u0434\u0435\u0442  \u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d  \u0447\u0435\u0440\u0435\u0437 ").method_10852((class_2561)class_2561.method_43470((String)duration).method_27692(class_124.field_1080));
                            Notifications.getInstance().addList((class_2561)text, 4000L);
                        });
                    } else if (!this.potionQueue.contains(key)) {
                        this.potionQueue.add(key);
                    }
                } else {
                    class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info2.displayName, GradientAssist.getGradientColors(info2.displayName), addStarPrefix)).method_27693("  \u043d\u0435  \u043d\u0430\u0439\u0434\u0435\u043d\u043e");
                    Notifications.getInstance().addList((class_2561)text, 4000L);
                }
            }
            this.lastKeyStates.put(key, currentKey);
            this.keyPressedThisTick.put(key, currentKey);
        }
        if (this.actionState != ActionState.IDLE) {
            this.processItemAction();
        }
        if (this.actionState == ActionState.IDLE && !this.potionQueue.isEmpty() && this.potionTimer.finished(150.0) && (info = this.itemConfig.get(potionKey = this.potionQueue.remove(0))) != null) {
            class_1735 slot3 = InventoryTask.getSlot(s -> s.method_7677().method_7909().equals(info.item) && InventoryTask.getCleanName(s.method_7677().method_7964()).contains(info.searchName.toLowerCase()));
            boolean addStarPrefix = false;
            if (slot3 != null) {
                class_1799 stack3 = slot3.method_7677();
                if (!HollyworldAssist.mc.field_1724.method_7357().method_7904(stack3)) {
                    this.startItemUse(slot3, info, addStarPrefix);
                } else {
                    CoolDowns.getInstance().list.stream().filter(c -> c.item().equals(info.item)).findFirst().ifPresent(coolDown -> {
                        int time = Math.toIntExact(-coolDown.time().elapsedTime() / 1000L);
                        String duration = StringHelper.getDuration(time);
                        class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u0431\u0443\u0434\u0435\u0442  \u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d  \u0447\u0435\u0440\u0435\u0437 ").method_10852((class_2561)class_2561.method_43470((String)duration).method_27692(class_124.field_1080));
                        Notifications.getInstance().addList((class_2561)text, 4000L);
                    });
                }
            } else {
                class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u043d\u0435  \u043d\u0430\u0439\u0434\u0435\u043d\u043e");
                Notifications.getInstance().addList((class_2561)text, 4000L);
            }
            this.potionTimer.reset();
        }
        if (this.autoRepairSetting.isValue() && StreamSupport.stream(HollyworldAssist.mc.field_1724.method_5661().spliterator(), false).anyMatch(stack -> {
            if ((double)stack.method_7919() / (double)stack.method_7936() < 0.94) {
                return false;
            }
            class_6880 mendingEntry = HollyworldAssist.mc.field_1687.method_30349().method_30530(class_7924.field_41265).method_10223(class_1893.field_9101.method_29177()).orElse(null);
            return mendingEntry != null && class_1890.method_8225((class_6880)mendingEntry, (class_1799)stack) > 0;
        })) {
            InventoryTask.slots().filter(slot -> {
                class_1799 stack = slot.method_7677();
                class_9279 component = (class_9279)stack.method_57824(class_9334.field_49628);
                return !HollyworldAssist.mc.field_1724.method_7357().method_7904(stack) && stack.method_7909().equals(class_1802.field_8287) && component != null && component.toString().contains("\"text\":\" - \u043f\u0440\u0438 \u043d\u0430\u0436\u0430\u0442\u0438\u0435 \u041f\u041a\u041c, \u043f\u043e\u043b\u043d\u043e\u0441\u0442\u044c\u044e \u0440\u0435\u043c\u043e\u043d\u0442\u0438\u0440\u0443\u0435\u0442\"") && this.repairWatch.every(5000.0);
            }).findFirst().ifPresent(slot -> InventoryFlowManager.addTask(() -> InventoryTask.swapAndUse(slot, MathAngle.cameraAngle())));
        }
        if (!InventoryTask.isServerScreen() && !this.stacks.isEmpty() && this.script2.isFinished() && this.shulkerWatch.finished(300.0)) {
            InventoryTask.slots().filter(s -> s.method_7677().method_57824(class_9334.field_49622) != null).max(Comparator.comparingDouble(s -> ((class_9288)s.method_7677().method_57825((class_9331)class_9334.field_49622, null)).field_49338.stream().filter(item -> !item.method_7960()).toList().size())).ifPresent(shulker -> {
                InventoryTask.swapHand(shulker, class_1268.field_5808, false);
                InventoryTask.closeScreen(false);
                PlayerInteractionHelper.interactItem(class_1268.field_5808);
                this.script2.cleanup().addTickStep(0, () -> {
                    ArrayList integers = new ArrayList();
                    InventoryTask.slots().forEach(slot -> this.stacks.entrySet().stream().filter(entry -> slot.field_7871.equals((Object)HollyworldAssist.mc.field_1724.method_31548()) && ((class_1792)entry.getValue()).equals(slot.method_7677().method_7909()) && (Integer)entry.getKey() == slot.field_7874).forEach(entry -> {
                        InventoryTask.clickSlot(slot, 0, class_1713.field_7794, false);
                        integers.add(slot.field_7874);
                    }));
                    integers.forEach(this.stacks::remove);
                    InventoryTask.closeScreen(false);
                    InventoryTask.swapHand(shulker, class_1268.field_5808, false);
                    InventoryTask.closeScreen(false);
                    this.shulkerWatch.reset();
                });
            });
        }
        if (this.autoLootSetting.isValue()) {
            PlayerInteractionHelper.streamEntities().filter(class_3988.class::isInstance).map(class_3988.class::cast).filter(m -> m.method_6084(class_1304.field_6173) || m.method_6084(class_1304.field_6171)).findFirst().ifPresent(merchant -> {
                class_243 attackVector = (class_243)this.pointFinder.computeVector((class_1309)merchant, 6.0f, TurnsConnection.INSTANCE.getRotation(), new LinearConstructor().randomValue(), true).method_15442();
                Turns angle = MathAngle.calculateAngle(attackVector);
                this.itemsWatch.reset();
                this.entityUUID = merchant.method_5667();
                if (HollyworldAssist.mc.field_1724.method_33571().method_1022(merchant.method_5829().method_1005()) <= 6.0) {
                    HollyworldAssist.mc.field_1724.field_3944.method_52787((class_2596)class_2824.method_34208((class_1297)merchant, (boolean)false, (class_1268)class_1268.field_5808, (class_243)merchant.method_5829().method_1005()));
                    HollyworldAssist.mc.field_1724.field_3944.method_52787((class_2596)class_2824.method_34207((class_1297)merchant, (boolean)false, (class_1268)class_1268.field_5808));
                    TurnsConnection.INSTANCE.rotateTo(angle, TurnsConfig.DEFAULT, TaskPriority.HIGH_IMPORTANCE_3, this);
                }
            });
        }
    }

    private void startItemUse(class_1735 slot, ItemInfo info, boolean addStarPrefix) {
        this.originalSlot = HollyworldAssist.mc.field_1724.method_31548().field_7545;
        this.originalSourceSlot = slot.field_7874;
        this.targetSlot = slot.field_7874;
        this.pendingItemKey = info.searchName;
        boolean needsSwap = !(slot.field_7874 >= 0 && slot.field_7874 < 9 || slot.field_7874 >= 36 && slot.field_7874 < 45);
        this.wasForwardPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)HollyworldAssist.mc.field_1690.field_1894.method_1429().method_1444());
        this.wasBackPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)HollyworldAssist.mc.field_1690.field_1881.method_1429().method_1444());
        this.wasLeftPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)HollyworldAssist.mc.field_1690.field_1913.method_1429().method_1444());
        this.wasRightPressed = class_3675.method_15987((long)mc.method_22683().method_4490(), (int)HollyworldAssist.mc.field_1690.field_1849.method_1429().method_1444());
        this.actionState = ActionState.SLOWING_DOWN;
        this.actionTimer = System.currentTimeMillis();
        this.stopMovementUntil = System.currentTimeMillis() + 300L;
        this.keysOverridden = true;
        HollyworldAssist.mc.field_1690.field_1894.method_23481(false);
        HollyworldAssist.mc.field_1690.field_1881.method_23481(false);
        HollyworldAssist.mc.field_1690.field_1913.method_23481(false);
        HollyworldAssist.mc.field_1690.field_1849.method_23481(false);
        class_5250 text = class_2561.method_43473().method_10852((class_2561)GradientAssist.applyGradientToText(info.displayName, GradientAssist.getGradientColors(info.displayName), addStarPrefix)).method_27693("  \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0430");
        Notifications.getInstance().addList((class_2561)text, 4000L);
    }

    private void processItemAction() {
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - this.actionTimer;
        switch (this.actionState.ordinal()) {
            case 1: {
                HollyworldAssist.mc.field_1724.field_3913.field_3905 = 0.0f;
                HollyworldAssist.mc.field_1724.field_3913.field_3907 = 0.0f;
                if (HollyworldAssist.mc.field_1724.method_5624()) {
                    HollyworldAssist.mc.field_1724.method_5728(false);
                }
                if (elapsed <= 50L) break;
                this.actionState = ActionState.WAITING_STOP;
                this.actionTimer = currentTime;
                break;
            }
            case 2: {
                HollyworldAssist.mc.field_1724.field_3913.field_3905 = 0.0f;
                HollyworldAssist.mc.field_1724.field_3913.field_3907 = 0.0f;
                double velocityX = Math.abs(HollyworldAssist.mc.field_1724.method_18798().field_1352);
                double velocityZ = Math.abs(HollyworldAssist.mc.field_1724.method_18798().field_1350);
                if (!(velocityX < 0.05 && velocityZ < 0.05) && elapsed <= 100L) break;
                this.actionState = ActionState.SWAP_TO_ITEM;
                this.actionTimer = currentTime;
                break;
            }
            case 3: {
                if (elapsed <= 50L) break;
                if (this.targetSlot >= 0 && this.targetSlot < 9) {
                    HollyworldAssist.mc.field_1724.method_31548().field_7545 = this.targetSlot;
                } else if (this.targetSlot >= 36 && this.targetSlot < 45) {
                    int hotbarSlot;
                    HollyworldAssist.mc.field_1724.method_31548().field_7545 = hotbarSlot = this.targetSlot - 36;
                    this.targetSlot = hotbarSlot;
                } else {
                    int swapSlot = 8;
                    InventoryTask.clickSlot(this.targetSlot, swapSlot, class_1713.field_7791, false);
                    this.targetSlot = swapSlot;
                    HollyworldAssist.mc.field_1724.method_31548().field_7545 = swapSlot;
                }
                this.actionState = ActionState.USE_ITEM;
                this.actionTimer = currentTime;
                break;
            }
            case 4: {
                if (elapsed <= 80L) break;
                class_1799 heldItem = HollyworldAssist.mc.field_1724.method_6047();
                if (!heldItem.method_7960() && HollyworldAssist.mc.field_1724.method_31548().field_7545 == this.targetSlot) {
                    HollyworldAssist.mc.field_1761.method_2919((class_1657)HollyworldAssist.mc.field_1724, class_1268.field_5808);
                }
                this.actionState = ActionState.SWAP_BACK;
                this.actionTimer = currentTime;
                break;
            }
            case 5: {
                boolean wasFromInventory;
                if (elapsed <= 50L) break;
                boolean bl = wasFromInventory = !(this.originalSourceSlot >= 0 && this.originalSourceSlot < 9 || this.originalSourceSlot >= 36 && this.originalSourceSlot < 45);
                if (wasFromInventory) {
                    if (this.targetSlot >= 0 && this.targetSlot < 9) {
                        InventoryTask.clickSlot(this.originalSourceSlot, this.targetSlot, class_1713.field_7791, false);
                    }
                } else if (this.originalSourceSlot >= 36 && this.originalSourceSlot < 45) {
                    int hotbarSlot = this.originalSourceSlot - 36;
                    if (this.targetSlot != hotbarSlot) {
                        HollyworldAssist.mc.field_1724.method_31548().field_7545 = hotbarSlot;
                    }
                } else if (this.originalSourceSlot >= 0 && this.originalSourceSlot < 9 && this.targetSlot != this.originalSourceSlot) {
                    HollyworldAssist.mc.field_1724.method_31548().field_7545 = this.originalSourceSlot;
                }
                if (HollyworldAssist.mc.field_1724.method_31548().field_7545 != this.originalSlot) {
                    HollyworldAssist.mc.field_1724.method_31548().field_7545 = this.originalSlot;
                }
                this.restoreKeyStates();
                this.actionState = ActionState.SPEEDING_UP;
                this.actionTimer = currentTime;
                break;
            }
            case 6: {
                long speedupElapsed = currentTime - this.actionTimer;
                if (speedupElapsed <= 80L) break;
                this.actionState = ActionState.IDLE;
                this.originalSlot = -1;
                this.targetSlot = -1;
                this.originalSourceSlot = -1;
                this.pendingItemKey = null;
            }
        }
    }

    private void restoreKeyStates() {
        if (!this.keysOverridden) {
            return;
        }
        HollyworldAssist.mc.field_1690.field_1894.method_23481(this.wasForwardPressed);
        HollyworldAssist.mc.field_1690.field_1881.method_23481(this.wasBackPressed);
        HollyworldAssist.mc.field_1690.field_1913.method_23481(this.wasLeftPressed);
        HollyworldAssist.mc.field_1690.field_1849.method_23481(this.wasRightPressed);
        if (HollyworldAssist.mc.field_1724.field_3913 != null) {
            if (this.wasForwardPressed) {
                HollyworldAssist.mc.field_1724.field_3913.field_3905 = 1.0f;
                if (!HollyworldAssist.mc.field_1724.method_5624()) {
                    HollyworldAssist.mc.field_1724.method_5728(true);
                }
            }
            if (this.wasBackPressed) {
                HollyworldAssist.mc.field_1724.field_3913.field_3905 = -1.0f;
            }
            if (this.wasLeftPressed) {
                HollyworldAssist.mc.field_1724.field_3913.field_3907 = 1.0f;
            }
            if (this.wasRightPressed) {
                HollyworldAssist.mc.field_1724.field_3913.field_3907 = -1.0f;
            }
        }
        this.keysOverridden = false;
    }

    @EventHandler
    public void onDraw(DrawEvent e) {
        class_332 context = e.getDrawContext();
        class_4587 matrix = context.method_51448();
        PlayerInteractionHelper.streamEntities().filter(ent -> ent.method_5667().equals(this.entityUUID)).forEach(ent -> {
            class_124 formatting;
            class_243 pos = ent.method_24515().method_10074().method_46558();
            class_243 vec = Projection.worldSpaceToScreenSpace(pos);
            String text = !this.itemsWatch.finished(200.0) ? "\u041c\u043e\u0436\u043d\u043e \u0437\u0430\u0431\u0440\u0430\u0442\u044c" : (!this.itemsWatch.finished(20000.0) ? Calculate.round(20.0f - (float)this.itemsWatch.elapsedTime() / 1000.0f, 0.1f) + "\u0441" : "\u0421\u043a\u043e\u0440\u043e");
            FontRenderer font = Fonts.getSize(14);
            float height = 4.0f;
            float width = font.getStringWidth(text);
            float padding = 3.0f;
            double x = vec.method_10216() - (double)(width / 2.0f);
            double y = vec.method_10214() - (double)(height / 2.0f);
            class_124 class_1242 = formatting = HollyworldAssist.mc.field_1724.method_33571().method_1022(ent.method_33571()) < 5.0 ? class_124.field_1060 : class_124.field_1061;
            if (Projection.canSee(pos)) {
                blur.render(ShapeProperties.create(matrix, x - (double)padding, y - (double)padding, width + padding * 2.0f, height + padding * 2.0f).round(2.0f).color(ColorAssist.HALF_BLACK).build());
                font.drawString(matrix, String.valueOf(formatting) + text, x, y, ColorAssist.getText());
            }
        });
    }

    public List<KeyBind> getKeyBindings() {
        return this.keyBindings;
    }

    public BindSetting getSetting(String name) {
        return this.keyBindings.stream().filter(bind -> bind.setting().getName().equals(name)).map(KeyBind::setting).findFirst().orElse(null);
    }

    private static enum ActionState {
        IDLE,
        SLOWING_DOWN,
        WAITING_STOP,
        SWAP_TO_ITEM,
        USE_ITEM,
        SWAP_BACK,
        SPEEDING_UP;

    }

    public record KeyBind(class_1792 item, BindSetting setting, float distance) {
    }

    private static class ItemInfo {
        String searchName;
        class_1792 item;
        String displayName;

        ItemInfo(String searchName, class_1792 item, String displayName) {
            this.searchName = searchName;
            this.item = item;
            this.displayName = displayName;
        }
    }
}

