/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.misc;

import fun.bloody.events.container.SetScreenEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.managers.event.EventHandler;
import java.io.File;

public class TLauncherResourcePacks
extends Module {
    public TLauncherResourcePacks() {
        super("TLauncherRP", "TLauncher Resource Packs", ModuleCategory.MISC);
    }

    @EventHandler
    public void onSetScreen(SetScreenEvent event) {
        if (event.getScreen() == null) {
            return;
        }
        String screenClass = event.getScreen().getClass().getName();
        if (screenClass.contains("PackScreen") || screenClass.contains("ResourcePack")) {
            String username = System.getProperty("user.name");
            String tlauncherPath = "C:\\Users\\" + username + "\\AppData\\Roaming\\.tlauncher\\legacy\\Minecraft\\game\\resourcepacks";
            try {
                File folder = new File(tlauncherPath);
                if (!folder.exists()) {
                    folder.mkdirs();
                }
                Runtime.getRuntime().exec("explorer.exe \"" + tlauncherPath + "\"");
                System.out.println("[TLauncherRP] Opened TLauncher resourcepacks folder: " + tlauncherPath);
            }
            catch (Exception ex) {
                System.err.println("[TLauncherRP] Error opening folder:");
                ex.printStackTrace();
            }
        }
    }
}

