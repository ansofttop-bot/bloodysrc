/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$class_4534
 *  com.mojang.blaze3d.platform.GlStateManager$class_4535
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.class_10142
 *  net.minecraft.class_10156
 *  net.minecraft.class_1297
 *  net.minecraft.class_1531
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2586
 *  net.minecraft.class_2595
 *  net.minecraft.class_2646
 *  net.minecraft.class_2818
 *  net.minecraft.class_286
 *  net.minecraft.class_287
 *  net.minecraft.class_289
 *  net.minecraft.class_290
 *  net.minecraft.class_293$class_5596
 *  net.minecraft.class_3675
 *  net.minecraft.class_4587
 *  net.minecraft.class_9801
 *  org.joml.Matrix4f
 *  org.lwjgl.glfw.GLFW
 */
package fun.bloody.features.impl.misc;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import fun.bloody.display.hud.Notifications;
import fun.bloody.events.player.TickEvent;
import fun.bloody.events.render.WorldRenderEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.utils.client.managers.event.EventHandler;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_10142;
import net.minecraft.class_10156;
import net.minecraft.class_1297;
import net.minecraft.class_1531;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2646;
import net.minecraft.class_2818;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

public class WardenHelper
extends Module {
    private final BooleanSetting autoGPS = new BooleanSetting("\u0410\u0432\u0442\u043e GPS", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0441\u0442\u0430\u0432\u0438\u0442 GPS-\u043c\u0435\u0442\u043a\u0443 \u043d\u0430 \u0433\u043e\u0442\u043e\u0432\u044b\u0439 \u0441\u0443\u043d\u0434\u0443\u043a").setValue(true);
    private final BooleanSetting notifications = new BooleanSetting("\u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0443\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u0435 \u043a\u043e\u0433\u0434\u0430 \u0441\u0443\u043d\u0434\u0443\u043a \u0433\u043e\u0442\u043e\u0432 \u0438\u043b\u0438 \u0441\u043a\u043e\u0440\u043e \u043e\u0442\u043a\u0440\u043e\u0435\u0442\u0441\u044f").setValue(true);
    private final BindSetting resetBind = new BindSetting("\u0420\u0435\u0441\u0435\u0442 \u0441\u0443\u043d\u0434\u0443\u043a\u043e\u0432", "\u041a\u043d\u043e\u043f\u043a\u0430 \u0434\u043b\u044f \u0441\u0431\u0440\u043e\u0441\u0430 \u0432\u0441\u0435\u0445 \u0441\u0443\u043d\u0434\u0443\u043a\u043e\u0432");
    private final Map<class_2338, ChestData> chestDataMap = new ConcurrentHashMap<class_2338, ChestData>();
    private final Set<class_2338> gpsVisited = new HashSet<class_2338>();
    private final Set<class_2338> notified = new HashSet<class_2338>();
    private class_2338 currentGPSTarget = null;
    static final double WARDEN_X = 2000.0;
    static final double WARDEN_Z = 2000.0;
    static final double ZONE_RADIUS = 250.0;
    static final Pattern TIME_PATTERN = Pattern.compile("(\\d{1,2}):(\\d{2})(?::(\\d{2}))?");
    static final Pattern SECONDS_PATTERN = Pattern.compile("(\\d+)\\s*(\u0441|s|\u0441\u0435\u043a|sec)");
    private boolean prevKeyPressed = false;

    public WardenHelper() {
        super("WardenHelper", "Warden Helper", ModuleCategory.MISC);
        this.setup(this.autoGPS, this.notifications, this.resetBind);
    }

    @Override
    public void activate() {
        this.clearAll();
    }

    @Override
    public void deactivate() {
        this.clearAll();
    }

    @EventHandler
    public void onTick(TickEvent event) {
        if (WardenHelper.mc.field_1724 == null || WardenHelper.mc.field_1687 == null || !this.isInWardenZone()) {
            return;
        }
        boolean keyDown = this.isBindActive(this.resetBind);
        if (!this.prevKeyPressed && keyDown) {
            this.clearAll();
            Notifications.getInstance().addList("Warden Helper: \u0421\u0443\u043d\u0434\u0443\u043a\u0438 \u0441\u0431\u0440\u043e\u0448\u0435\u043d\u044b!", 3000L);
        }
        this.prevKeyPressed = keyDown;
        this.updateTimersFromEntities();
        this.updateGPSAndNotifications();
    }

    private boolean isBindActive(BindSetting bind) {
        long window = mc.method_22683().method_4490();
        int key = bind.getKey();
        if (key >= 0 && key <= 7) {
            return GLFW.glfwGetMouseButton((long)window, (int)key) == 1;
        }
        return class_3675.method_15987((long)window, (int)key);
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent event) {
        if (WardenHelper.mc.field_1687 == null || WardenHelper.mc.field_1724 == null) {
            return;
        }
        class_4587 matrices = event.getStack();
        class_243 cam = WardenHelper.mc.field_1773.method_19418().method_19326();
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc((GlStateManager.class_4535)GlStateManager.class_4535.SRC_ALPHA, (GlStateManager.class_4534)GlStateManager.class_4534.ONE);
        RenderSystem.setShader((class_10156)class_10142.field_53876);
        class_287 quadsBuffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        for (class_2586 be : this.getBlockEntitiesInRange()) {
            if (!this.isWardenChest(be)) continue;
            class_2338 pos = be.method_11016();
            this.chestDataMap.computeIfAbsent(pos, ChestData::new);
            int color = this.getESPColor(this.chestDataMap.get(pos), 50);
            class_238 box = new class_238(pos).method_989(-cam.method_10216(), -cam.method_10214(), -cam.method_10215());
            this.renderFilledBox(matrices, quadsBuffer, box, color);
        }
        class_286.method_43433((class_9801)quadsBuffer.method_60800());
        class_287 linesBuffer = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        for (class_2586 be : this.getBlockEntitiesInRange()) {
            if (!this.isWardenChest(be)) continue;
            class_2338 pos = be.method_11016();
            int color = this.getESPColor(this.chestDataMap.getOrDefault(pos, new ChestData(pos)), 200);
            class_238 box = new class_238(pos).method_989(-cam.method_10216(), -cam.method_10214(), -cam.method_10215());
            this.renderOutlinedBox(matrices, linesBuffer, box, color);
        }
        class_286.method_43433((class_9801)linesBuffer.method_60800());
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private Iterable<class_2586> getBlockEntitiesInRange() {
        ArrayList<class_2586> entities = new ArrayList<class_2586>();
        int renderDistance = (Integer)WardenHelper.mc.field_1690.method_42503().method_41753();
        int chunkX = WardenHelper.mc.field_1724.method_31476().field_9181;
        int chunkZ = WardenHelper.mc.field_1724.method_31476().field_9180;
        for (int x = chunkX - renderDistance; x <= chunkX + renderDistance; ++x) {
            for (int z = chunkZ - renderDistance; z <= chunkZ + renderDistance; ++z) {
                class_2818 chunk = WardenHelper.mc.field_1687.method_8497(x, z);
                if (chunk == null) continue;
                entities.addAll(chunk.method_12214().values());
            }
        }
        return entities;
    }

    private void clearAll() {
        this.chestDataMap.clear();
        this.gpsVisited.clear();
        this.notified.clear();
        this.currentGPSTarget = null;
    }

    private boolean isWardenChest(class_2586 be) {
        return be instanceof class_2595 || be instanceof class_2646;
    }

    private boolean isInWardenZone() {
        return Math.abs(WardenHelper.mc.field_1724.method_23317() - 2000.0) <= 250.0 && Math.abs(WardenHelper.mc.field_1724.method_23321() - 2000.0) <= 250.0;
    }

    private void updateTimersFromEntities() {
        for (Map.Entry<class_2338, ChestData> entry : this.chestDataMap.entrySet()) {
            class_2338 pos = entry.getKey();
            ChestData data = entry.getValue();
            boolean found = false;
            class_238 searchBox = new class_238(pos).method_1009(1.0, 3.0, 1.0);
            for (class_1531 stand : WardenHelper.mc.field_1687.method_8390(class_1531.class, searchBox, class_1297::method_16914)) {
                String name = stand.method_5797().getString().replaceAll("\u00a7[0-9a-fk-or]", "");
                long seconds = this.parseTimeToSeconds(name);
                if (seconds < 0L) continue;
                data.setTimer(seconds);
                found = true;
                break;
            }
            if (found) continue;
            data.hasTimer = false;
        }
    }

    private long parseTimeToSeconds(String str) {
        Matcher m1 = TIME_PATTERN.matcher(str);
        if (m1.find()) {
            if (m1.group(3) == null) {
                return (long)Integer.parseInt(m1.group(1)) * 60L + (long)Integer.parseInt(m1.group(2));
            }
            return (long)Integer.parseInt(m1.group(1)) * 3600L + (long)Integer.parseInt(m1.group(2)) * 60L + (long)Integer.parseInt(m1.group(3));
        }
        Matcher m2 = SECONDS_PATTERN.matcher(str);
        if (m2.find()) {
            return Long.parseLong(m2.group(1));
        }
        String digits = str.replaceAll("[^0-9]", "").trim();
        if (digits.isEmpty()) {
            return -1L;
        }
        long val = Long.parseLong(digits);
        return val > 0L && val < 36000L ? val : -1L;
    }

    private void updateGPSAndNotifications() {
        if (this.currentGPSTarget != null && WardenHelper.mc.field_1724.method_5707(class_243.method_24953((class_2382)this.currentGPSTarget)) <= 100.0) {
            WardenHelper.mc.field_1724.field_3944.method_45730("gps off");
            this.currentGPSTarget = null;
        }
        for (Map.Entry<class_2338, ChestData> entry : this.chestDataMap.entrySet()) {
            class_2338 pos = entry.getKey();
            ChestData data = entry.getValue();
            if (!data.hasTimer) continue;
            float t = data.getTimeLeft();
            if (t <= 0.0f) {
                if (this.autoGPS.isValue() && !this.gpsVisited.contains(pos)) {
                    this.sendGPS(pos);
                }
                if (!this.notifications.isValue() || this.notified.contains(pos)) continue;
                Notifications.getInstance().addList("Warden Helper: \u0421\u0443\u043d\u0434\u0443\u043a \u0433\u043e\u0442\u043e\u0432! [" + pos.method_10263() + " " + pos.method_10260() + "]", 5000L);
                this.notified.add(pos);
                continue;
            }
            if (!(t <= 20.0f)) continue;
            if (this.autoGPS.isValue() && !this.gpsVisited.contains(pos)) {
                this.sendGPS(pos);
            }
            if (!this.notifications.isValue() || this.notified.contains(pos)) continue;
            Notifications.getInstance().addList("Warden Helper: \u0421\u0443\u043d\u0434\u0443\u043a \u0447\u0435\u0440\u0435\u0437 " + (int)t + " \u0441\u0435\u043a! [" + pos.method_10263() + " " + pos.method_10260() + "]", 5000L);
            this.notified.add(pos);
        }
    }

    private void sendGPS(class_2338 pos) {
        WardenHelper.mc.field_1724.field_3944.method_45730("gps set " + pos.method_10263() + " " + pos.method_10260());
        this.gpsVisited.add(pos);
        this.currentGPSTarget = pos;
    }

    private int getESPColor(ChestData data, int alpha) {
        if (!data.hasTimer) {
            return this.rgba(180, 180, 180, alpha);
        }
        float t = data.getTimeLeft();
        if (t <= 0.0f) {
            float p = (float)(Math.sin((double)System.currentTimeMillis() / 200.0) * 0.3 + 0.7);
            return this.rgba(0, (int)(255.0f * p), (int)(128.0f * p), 220);
        }
        if (t > 120.0f) {
            return this.rgba(255, 60, 60, alpha);
        }
        if (t > 20.0f) {
            float factor = 1.0f - (t - 20.0f) / 100.0f;
            return this.lerpColor(this.rgba(255, 60, 60, alpha), this.rgba(255, 220, 50, alpha), factor);
        }
        float factor = 1.0f - t / 20.0f;
        return this.lerpColor(this.rgba(255, 220, 50, alpha), this.rgba(60, 255, 60, alpha), factor);
    }

    private int rgba(int r, int g, int b, int a) {
        return a << 24 | r << 16 | g << 8 | b;
    }

    private int lerpColor(int colorA, int colorB, float t) {
        t = Math.max(0.0f, Math.min(1.0f, t));
        int aA = colorA >> 24 & 0xFF;
        int rA = colorA >> 16 & 0xFF;
        int gA = colorA >> 8 & 0xFF;
        int bA = colorA & 0xFF;
        int aB = colorB >> 24 & 0xFF;
        int rB = colorB >> 16 & 0xFF;
        int gB = colorB >> 8 & 0xFF;
        int bB = colorB & 0xFF;
        int a = (int)((float)aA + (float)(aB - aA) * t);
        int r = (int)((float)rA + (float)(rB - rA) * t);
        int g = (int)((float)gA + (float)(gB - gA) * t);
        int b = (int)((float)bA + (float)(bB - bA) * t);
        return this.rgba(r, g, b, a);
    }

    private void renderFilledBox(class_4587 matrices, class_287 buffer, class_238 box, int color) {
        Matrix4f matrix = matrices.method_23760().method_23761();
        float minX = (float)box.field_1323;
        float minY = (float)box.field_1322;
        float minZ = (float)box.field_1321;
        float maxX = (float)box.field_1320;
        float maxY = (float)box.field_1325;
        float maxZ = (float)box.field_1324;
        buffer.method_22918(matrix, minX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, minX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, minX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, minX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_39415(color);
    }

    private void renderOutlinedBox(class_4587 matrices, class_287 buffer, class_238 box, int color) {
        Matrix4f matrix = matrices.method_23760().method_23761();
        float minX = (float)box.field_1323;
        float minY = (float)box.field_1322;
        float minZ = (float)box.field_1321;
        float maxX = (float)box.field_1320;
        float maxY = (float)box.field_1325;
        float maxZ = (float)box.field_1324;
        buffer.method_22918(matrix, minX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, minX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, minZ).method_39415(color);
        buffer.method_22918(matrix, maxX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, maxX, maxY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, minY, maxZ).method_39415(color);
        buffer.method_22918(matrix, minX, maxY, maxZ).method_39415(color);
    }

    static class ChestData {
        boolean hasTimer = false;
        long timerEndMs = 0L;

        ChestData(class_2338 pos) {
        }

        void setTimer(long secondsLeft) {
            this.timerEndMs = System.currentTimeMillis() + secondsLeft * 1000L;
            this.hasTimer = true;
        }

        float getTimeLeft() {
            return (float)(this.timerEndMs - System.currentTimeMillis()) / 1000.0f;
        }
    }
}

