/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1802
 */
package fun.bloody.features.impl.misc;

import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import net.minecraft.class_1802;

public class MaceHelper
extends Module {
    private boolean wasUsingWindCharge = false;
    private int previousSlot = -1;
    private static boolean isWindChargeActive = false;

    public MaceHelper() {
        super("MaceHelper", "Mace Helper", ModuleCategory.MISC);
    }

    public static MaceHelper getInstance() {
        return Instance.get(MaceHelper.class);
    }

    public static boolean isUsingWindCharge() {
        return isWindChargeActive;
    }

    @EventHandler
    public void onTick(TickEvent e) {
        boolean isUsingWindCharge;
        if (PlayerInteractionHelper.nullCheck()) {
            isWindChargeActive = false;
            this.wasUsingWindCharge = false;
            return;
        }
        isWindChargeActive = isUsingWindCharge = MaceHelper.mc.field_1724.method_6115() && MaceHelper.mc.field_1724.method_6030().method_7909() == class_1802.field_49098;
        if (!isUsingWindCharge && this.wasUsingWindCharge) {
            int maceSlot;
            if (this.previousSlot == -1) {
                this.previousSlot = MaceHelper.mc.field_1724.method_31548().field_7545;
            }
            if ((maceSlot = this.findMaceInHotbar()) != -1 && maceSlot != MaceHelper.mc.field_1724.method_31548().field_7545) {
                MaceHelper.mc.field_1724.method_31548().field_7545 = maceSlot;
            }
        }
        if (MaceHelper.mc.field_1724.method_24828() && this.previousSlot != -1 && !isUsingWindCharge) {
            MaceHelper.mc.field_1724.method_31548().field_7545 = this.previousSlot;
            this.previousSlot = -1;
        }
        this.wasUsingWindCharge = isUsingWindCharge;
    }

    private int findMaceInHotbar() {
        for (int i = 0; i < 9; ++i) {
            if (MaceHelper.mc.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_49814) continue;
            return i;
        }
        return -1;
    }

    @Override
    public void deactivate() {
        super.deactivate();
        this.wasUsingWindCharge = false;
        this.previousSlot = -1;
        isWindChargeActive = false;
    }
}

