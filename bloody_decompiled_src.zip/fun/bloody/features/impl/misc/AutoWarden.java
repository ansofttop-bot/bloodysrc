/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1531
 *  net.minecraft.class_1657
 *  net.minecraft.class_1703
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_2586
 *  net.minecraft.class_2591
 *  net.minecraft.class_3532
 *  net.minecraft.class_3965
 */
package fun.bloody.features.impl.misc;

import fun.bloody.display.hud.Notifications;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.utils.client.managers.event.EventHandler;
import java.util.Locale;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

public class AutoWarden
extends Module {
    private static final String MINUTE_KEYWORDS = "(?:\u043c\u0438\u043d(?:\u0443\u0442(?:\u044b|\u0443|\u044f)?)?|m|min|minutes?)";
    private static final String SECOND_KEYWORDS = "(?:\u0441\u0435\u043a(?:\u0443\u043d\u0434(?:\u044b|\u0443|\u044f)?)?|s|sec|seconds?)";
    private static final Pattern TIMER_MMSS = Pattern.compile("(\\d{1,2})\\s*[:.]\\s*(\\d{1,2})");
    private static final Pattern TIMER_MINUTE_SECOND = Pattern.compile("(\\d{1,2})\\s*(?:\u043c\u0438\u043d(?:\u0443\u0442(?:\u044b|\u0443|\u044f)?)?|m|min|minutes?)\\s*(\\d{1,2})\\s*(?:\u0441\u0435\u043a(?:\u0443\u043d\u0434(?:\u044b|\u0443|\u044f)?)?|s|sec|seconds?)", 66);
    private static final Pattern TIMER_MINUTE_UNIT = Pattern.compile("(\\d{1,2})\\s*(?:\u043c\u0438\u043d(?:\u0443\u0442(?:\u044b|\u0443|\u044f)?)?|m|min|minutes?)", 66);
    private static final Pattern TIMER_SECOND_UNIT = Pattern.compile("(\\d{1,3})\\s*(?:\u0441\u0435\u043a(?:\u0443\u043d\u0434(?:\u044b|\u0443|\u044f)?)?|s|sec|seconds?)", 66);
    private static final Pattern TIMER_NUMBER = Pattern.compile("(\\d{1,3})");
    private static final Set<class_2591<?>> LOOT_BLOCK_TYPES = Set.of(class_2591.field_11914, class_2591.field_11891, class_2591.field_16411, class_2591.field_11896);
    private static final int SEARCH_RADIUS = 2;
    private static final double APPROACH_DISTANCE = 1.5;
    private static final double RETREAT_DISTANCE = 2.0;
    private static final long RETREAT_TIMEOUT_MS = 2500L;
    private static final long POST_LOOT_WAIT_MS = 30000L;
    private static final int MAX_INITIAL_TIMER_SECONDS = 60;
    private static final int OPEN_THRESHOLD_SECONDS = 0;
    private State state = State.SEARCHING;
    private boolean homeCommandSent = false;
    private HologramTarget target = null;
    private long lootTickTime = 0L;
    private long lootFinishTime = 0L;
    private long homeDelayTime = 0L;
    private long approachStuckTime = 0L;
    private long cooldownStartTime = 0L;
    private long retreatStartTime = 0L;
    private int retreatSide = 1;
    private class_243 retreatPosition = null;
    private class_243 lastApproachPos = null;
    private double lastApproachDistance = Double.MAX_VALUE;
    private Random roamRandom = new Random();
    private SliderSettings lootAnka = new SliderSettings("\u0410\u043d\u043a\u0430 \u0434\u043b\u044f \u043b\u0443\u0442\u0430", "\u041d\u043e\u043c\u0435\u0440 \u0430\u043d\u043a\u0435\u0442\u044b \u043f\u0435\u0440\u0435\u0434 /home").setValue(101.0f).range(101, 605);
    private SliderSettings dropAnka = new SliderSettings("\u0410\u043d\u043a\u0430 \u0434\u043b\u044f \u0441\u0431\u0440\u043e\u0441\u0430", "\u041d\u043e\u043c\u0435\u0440 \u0430\u043d\u043a\u0435\u0442\u044b \u043f\u043e\u0441\u043b\u0435 \u043b\u0443\u0442\u0430").setValue(102.0f).range(101, 605);

    public AutoWarden() {
        super("AutoWarden", "Auto Warden Loot", ModuleCategory.MISC);
        this.setup(this.lootAnka, this.dropAnka);
    }

    @Override
    public void activate() {
        this.state = State.SEARCHING;
        this.homeCommandSent = false;
        this.target = null;
        this.lootTickTime = 0L;
        this.lootFinishTime = 0L;
        this.homeDelayTime = 0L;
        this.cooldownStartTime = 0L;
        this.retreatStartTime = 0L;
        this.retreatPosition = null;
        super.activate();
    }

    @Override
    public void deactivate() {
        this.resetTarget();
        this.stopMovement();
        super.deactivate();
    }

    @EventHandler
    public void onTick(TickEvent event) {
        if (AutoWarden.mc.field_1724 == null || AutoWarden.mc.field_1687 == null) {
            return;
        }
        if (!this.homeCommandSent) {
            this.sendHomeCommand();
            return;
        }
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.homeDelayTime < 10000L) {
            return;
        }
        switch (this.state.ordinal()) {
            case 0: {
                this.handleSearching();
                break;
            }
            case 1: {
                this.handleApproach();
                break;
            }
            case 2: {
                this.handleWaiting();
                break;
            }
            case 3: {
                this.handleLooting();
                break;
            }
            case 4: {
                this.handleRetreating(currentTime);
                break;
            }
            case 5: {
                this.handleWaitingCooldown(currentTime);
            }
        }
    }

    private void sendHomeCommand() {
        if (AutoWarden.mc.field_1724 != null && AutoWarden.mc.field_1724.field_3944 != null) {
            this.sendAnkaCommand(this.lootAnka);
            AutoWarden.mc.field_1724.field_3944.method_45729("/home");
            Notifications.getInstance().addList("AutoWarden - /home \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d", 1500L);
            this.homeCommandSent = true;
            this.homeDelayTime = System.currentTimeMillis();
        }
    }

    private void sendAnkaCommand(SliderSettings setting) {
        if (AutoWarden.mc.field_1724 == null || AutoWarden.mc.field_1724.field_3944 == null || setting == null) {
            return;
        }
        int number = class_3532.method_15340((int)((int)setting.getValue()), (int)101, (int)999);
        AutoWarden.mc.field_1724.field_3944.method_45729("/an" + number);
        Notifications.getInstance().addList("AutoWarden - /an" + number + " \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d", 1000L);
    }

    private void handleSearching() {
        Optional<HologramTarget> optional = this.findTarget();
        if (optional.isPresent()) {
            this.target = optional.get();
            this.state = State.APPROACHING;
            Notifications.getInstance().addList("AutoWarden - \u0446\u0435\u043b\u044c \u043f\u043e \u0442\u0430\u0439\u043c\u0435\u0440\u0443 " + AutoWarden.formatTimer(this.target.initialTimer), 2000L);
            this.resetApproachTracker();
            return;
        }
    }

    private void handleApproach() {
        if (!this.isTargetValid()) {
            this.resetTarget();
            return;
        }
        class_243 chestCenter = this.target.getChestCenter();
        double currentDistance = AutoWarden.mc.field_1724.method_19538().method_1022(chestCenter);
        if (currentDistance <= 1.5) {
            this.state = State.WAITING;
            return;
        }
        this.moveTowards(chestCenter);
    }

    private void handleWaiting() {
        if (!this.isTargetValid()) {
            this.resetTarget();
            return;
        }
        int currentTimer = this.parseTimer(this.target.hologram);
        if (currentTimer < 0 || currentTimer > 60) {
            this.resetTarget();
            return;
        }
        if (currentTimer <= 0) {
            this.openTargetChest();
        }
    }

    private void handleLooting() {
        if (AutoWarden.mc.field_1724.field_7512 == null) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - this.lootFinishTime > 1500L) {
                this.resetTarget();
            }
            return;
        }
        class_1703 class_17032 = AutoWarden.mc.field_1724.field_7512;
        if (!(class_17032 instanceof class_1707)) {
            return;
        }
        class_1707 handler = (class_1707)class_17032;
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lootTickTime < 120L) {
            return;
        }
        this.lootTickTime = currentTime;
        boolean moved = this.collectChestItems(handler);
        if (moved) {
            this.lootFinishTime = currentTime;
            return;
        }
        if (currentTime - this.lootFinishTime > 500L) {
            this.sendAnkaCommand(this.dropAnka);
            this.dropInventoryContents();
            this.closeScreen();
            this.startPostLootRetreat(currentTime);
        }
    }

    private boolean collectChestItems(class_1707 handler) {
        boolean moved = false;
        for (class_1735 slot : handler.field_7761) {
            if (slot.field_7871.equals((Object)AutoWarden.mc.field_1724.method_31548()) || !slot.method_7681()) continue;
            AutoWarden.mc.field_1761.method_2906(handler.field_7763, slot.field_7874, 0, class_1713.field_7794, (class_1657)AutoWarden.mc.field_1724);
            moved = true;
        }
        return moved;
    }

    private void dropInventoryContents() {
        if (AutoWarden.mc.field_1724 == null || AutoWarden.mc.field_1724.field_7512 == null) {
            return;
        }
        int syncId = AutoWarden.mc.field_1724.field_7512.field_7763;
        for (class_1735 slot : AutoWarden.mc.field_1724.field_7512.field_7761) {
            if (!slot.field_7871.equals((Object)AutoWarden.mc.field_1724.method_31548()) || !slot.method_7681() || slot.field_7874 < 0 || slot.field_7874 > 35) continue;
            AutoWarden.mc.field_1761.method_2906(syncId, slot.field_7874, 1, class_1713.field_7795, (class_1657)AutoWarden.mc.field_1724);
        }
    }

    private void openTargetChest() {
        if (this.target == null || AutoWarden.mc.field_1724 == null || AutoWarden.mc.field_1761 == null) {
            return;
        }
        class_3965 hit = new class_3965(this.target.getChestCenter(), class_2350.field_11036, this.target.chestPos, false);
        AutoWarden.mc.field_1761.method_2896(AutoWarden.mc.field_1724, class_1268.field_5808, hit);
        this.state = State.LOOTING;
        this.lootTickTime = System.currentTimeMillis();
        this.lootFinishTime = System.currentTimeMillis();
    }

    private void startPostLootRetreat(long currentTime) {
        this.retreatStartTime = currentTime;
        this.cooldownStartTime = 0L;
        this.retreatPosition = AutoWarden.mc.field_1724 != null ? AutoWarden.mc.field_1724.method_19538() : null;
        this.retreatSide = this.roamRandom.nextBoolean() ? 1 : -1;
        this.state = State.RETREATING;
        this.resetApproachTracker();
    }

    private void handleRetreating(long currentTime) {
        boolean timedOut;
        if (AutoWarden.mc.field_1724 == null) {
            this.resetTarget();
            return;
        }
        double movedDistance = this.retreatPosition == null ? 0.0 : AutoWarden.mc.field_1724.method_19538().method_1022(this.retreatPosition);
        boolean movedEnough = movedDistance >= 2.0;
        boolean bl = timedOut = currentTime - this.retreatStartTime >= 2500L;
        if (movedEnough || timedOut) {
            this.stopMovement();
            this.target = null;
            this.retreatPosition = null;
            this.cooldownStartTime = currentTime;
            this.state = State.WAITING_COOLDOWN;
            return;
        }
        AutoWarden.mc.field_1724.field_3913.field_3905 = 0.0f;
        AutoWarden.mc.field_1724.field_3913.field_3907 = this.retreatSide;
    }

    private void handleWaitingCooldown(long currentTime) {
        this.stopMovement();
        if (currentTime - this.cooldownStartTime >= 30000L) {
            this.resetTarget();
        }
    }

    private void stopMovement() {
        if (AutoWarden.mc.field_1724 == null) {
            return;
        }
        AutoWarden.mc.field_1724.field_3913.field_3905 = 0.0f;
        AutoWarden.mc.field_1724.field_3913.field_3907 = 0.0f;
    }

    private void moveTowards(class_243 targetPos) {
        if (AutoWarden.mc.field_1724 == null) {
            return;
        }
        class_243 playerPos = AutoWarden.mc.field_1724.method_19538();
        class_243 delta = targetPos.method_1020(playerPos);
        double distance = delta.method_1033();
        if (distance == 0.0) {
            AutoWarden.mc.field_1724.field_3913.field_3905 = 0.0f;
            AutoWarden.mc.field_1724.field_3913.field_3907 = 0.0f;
            return;
        }
        float targetYaw = (float)Math.toDegrees(Math.atan2(delta.field_1350, delta.field_1352)) - 90.0f;
        float deltaYaw = class_3532.method_15393((float)(targetYaw - AutoWarden.mc.field_1724.method_36454()));
        AutoWarden.mc.field_1724.field_3913.field_3905 = Math.abs(deltaYaw) > 45.0f ? 0.0f : 1.0f;
        AutoWarden.mc.field_1724.field_3913.field_3907 = 0.0f;
        if (targetPos.method_10214() > AutoWarden.mc.field_1724.method_23318() + 0.5 && AutoWarden.mc.field_1724.method_24828()) {
            AutoWarden.mc.field_1724.method_6043();
        }
    }

    private boolean isTargetValid() {
        if (this.target == null) {
            return false;
        }
        if (!this.target.hologram.method_5805()) {
            return false;
        }
        if (AutoWarden.mc.field_1687 == null) {
            return false;
        }
        return this.isChestPresent(this.target.chestPos);
    }

    private boolean isChestPresent(class_2338 pos) {
        if (AutoWarden.mc.field_1687 == null) {
            return false;
        }
        class_2586 entity = AutoWarden.mc.field_1687.method_8321(pos);
        return entity != null && LOOT_BLOCK_TYPES.contains(entity.method_11017());
    }

    private void resetTarget() {
        this.target = null;
        this.state = State.SEARCHING;
        this.resetApproachTracker();
    }

    private void resetApproachTracker() {
        this.lastApproachPos = null;
        this.lastApproachDistance = Double.MAX_VALUE;
        this.approachStuckTime = 0L;
    }

    private void closeScreen() {
        if (AutoWarden.mc.field_1724 != null) {
            AutoWarden.mc.field_1724.method_7346();
        }
    }

    private Optional<HologramTarget> findTarget() {
        if (AutoWarden.mc.field_1724 == null || AutoWarden.mc.field_1687 == null) {
            return Optional.empty();
        }
        class_243 playerPos = AutoWarden.mc.field_1724.method_19538();
        Optional<HologramTarget> result = Optional.empty();
        int bestTimer = Integer.MAX_VALUE;
        double bestDistance = Double.MAX_VALUE;
        for (class_1297 entity : AutoWarden.mc.field_1687.method_18112()) {
            class_2338 chest;
            int timer;
            if (!this.isHologramEntity(entity) || !entity.method_5807() || (timer = this.parseTimer(entity)) < 0 || timer > 60 || (chest = this.findChestNear(entity.method_24515())) == null) continue;
            HologramTarget target = new HologramTarget(entity, chest, timer);
            double distance = playerPos.method_1022(target.getChestCenter());
            if (timer >= bestTimer && (timer != bestTimer || !(distance < bestDistance))) continue;
            bestTimer = timer;
            bestDistance = distance;
            result = Optional.of(target);
        }
        return result;
    }

    private boolean isHologramEntity(class_1297 entity) {
        return entity instanceof class_1531;
    }

    private class_2338 findChestNear(class_2338 center) {
        if (AutoWarden.mc.field_1687 == null || center == null) {
            return null;
        }
        for (int x = -2; x <= 2; ++x) {
            for (int y = -2; y <= 1; ++y) {
                for (int z = -2; z <= 2; ++z) {
                    class_2338 pos = center.method_10069(x, y, z);
                    class_2586 entity = AutoWarden.mc.field_1687.method_8321(pos);
                    if (entity == null || !LOOT_BLOCK_TYPES.contains(entity.method_11017())) continue;
                    return pos;
                }
            }
        }
        return null;
    }

    private int parseTimer(class_1297 entity) {
        class_2561 customName = entity.method_5797();
        if (customName == null) {
            return -1;
        }
        String text = this.flattenText(customName);
        if (text.isEmpty()) {
            return -1;
        }
        return this.parseTimerFromText(text);
    }

    private String flattenText(class_2561 text) {
        if (text == null) {
            return "";
        }
        StringBuilder collector = new StringBuilder();
        this.collectText(text, collector);
        return collector.toString().trim();
    }

    private void collectText(class_2561 text, StringBuilder collector) {
        if (text == null) {
            return;
        }
        if (collector.length() > 0) {
            collector.append(' ');
        }
        collector.append(text.getString());
        for (class_2561 sibling : text.method_10855()) {
            this.collectText(sibling, collector);
        }
    }

    private int parseTimerFromText(String raw) {
        String sanitized = this.sanitizeTimerText(raw);
        if (sanitized.isEmpty()) {
            return -1;
        }
        Matcher matcher = TIMER_MMSS.matcher(sanitized);
        if (matcher.find()) {
            int minutes = this.clampInteger(matcher.group(1), 0, 99);
            int seconds = this.clampInteger(matcher.group(2), 0, 59);
            return minutes * 60 + seconds;
        }
        matcher = TIMER_MINUTE_SECOND.matcher(sanitized);
        if (matcher.find()) {
            int minutes = this.clampInteger(matcher.group(1), 0, 99);
            int seconds = this.clampInteger(matcher.group(2), 0, 59);
            return minutes * 60 + seconds;
        }
        matcher = TIMER_MINUTE_UNIT.matcher(sanitized);
        if (matcher.find()) {
            int minutes = this.clampInteger(matcher.group(1), 0, 99);
            return minutes * 60;
        }
        matcher = TIMER_SECOND_UNIT.matcher(sanitized);
        if (matcher.find()) {
            return this.clampInteger(matcher.group(1), 0, 599);
        }
        matcher = TIMER_NUMBER.matcher(sanitized);
        if (matcher.find()) {
            return this.clampInteger(matcher.group(1), 0, 999);
        }
        return -1;
    }

    private String sanitizeTimerText(String raw) {
        if (raw == null) {
            return "";
        }
        String cleaned = raw.replaceAll("\u00a7[0-9a-fk-or]", "");
        if (cleaned == null) {
            return "";
        }
        cleaned = cleaned.replace('\r', ' ').replace('\n', ' ');
        cleaned = cleaned.replaceAll("[^\\p{L}\\p{N}:\\.]+", " ").trim().toLowerCase(Locale.ROOT);
        return cleaned;
    }

    private int clampInteger(String raw, int min, int max) {
        try {
            return class_3532.method_15340((int)Integer.parseInt(raw), (int)min, (int)max);
        }
        catch (NumberFormatException ignored) {
            return min;
        }
    }

    private static String formatTimer(int seconds) {
        int minutes = seconds / 60;
        int secs = seconds % 60;
        return String.format("%02d:%02d", minutes, secs);
    }

    private static enum State {
        SEARCHING,
        APPROACHING,
        WAITING,
        LOOTING,
        RETREATING,
        WAITING_COOLDOWN;

    }

    private static class HologramTarget {
        final class_1297 hologram;
        final class_2338 chestPos;
        final int initialTimer;

        HologramTarget(class_1297 hologram, class_2338 chestPos, int initialTimer) {
            this.hologram = hologram;
            this.chestPos = chestPos;
            this.initialTimer = initialTimer;
        }

        class_243 getChestCenter() {
            return this.chestPos.method_46558();
        }
    }
}

