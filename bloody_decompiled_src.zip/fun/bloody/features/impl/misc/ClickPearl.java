/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1713
 *  net.minecraft.class_1802
 *  net.minecraft.class_2886
 *  net.minecraft.class_310
 *  net.minecraft.class_3675
 *  org.lwjgl.glfw.GLFW
 */
package fun.bloody.features.impl.misc;

import antidaunleak.api.annotation.Native;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.impl.movement.AutoSprint;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.utils.client.chat.ChatMessage;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.interactions.inv.InventoryResult;
import fun.bloody.utils.interactions.inv.InventoryToolkit;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ClickPearl
extends Module {
    private static final class_310 MC = class_310.method_1551();
    private final SelectSetting modeSetting = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "\u0421\u043f\u043e\u0441\u043e\u0431 \u0431\u0440\u043e\u0441\u043a\u0430").value("Default", "Legit").selected("Default");
    private final BindSetting keySetting = new BindSetting("\u041a\u043d\u043e\u043f\u043a\u0430", "\u041a\u043d\u043e\u043f\u043a\u0430 \u0434\u043b\u044f \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u044f");
    private boolean prevKeyPressed = false;
    private long lastThrowTime = 0L;
    private int packetSequence = 0;
    private int savedSlot = -1;
    private int pearlSlot = -1;
    private long actionStartTime = 0L;
    private boolean keysOverridden = false;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private boolean wasJumpPressed;
    private Phase phase = Phase.READY;

    public ClickPearl() {
        super("ClickPearl", "Click Pearl", ModuleCategory.MISC);
        this.setup(this.modeSetting, this.keySetting);
    }

    @EventHandler
    @Native(type=Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (ClickPearl.MC.field_1724 == null || ClickPearl.MC.field_1687 == null) {
            this.resetState();
            return;
        }
        boolean keyDown = this.isBindActive();
        if (!this.prevKeyPressed && keyDown && System.currentTimeMillis() - this.lastThrowTime > 100L && this.phase == Phase.READY) {
            this.lastThrowTime = System.currentTimeMillis();
            this.startPearlProcess();
        }
        this.prevKeyPressed = keyDown;
        if (this.phase != Phase.READY) {
            this.execute();
        }
    }

    private void startPearlProcess() {
        if (ClickPearl.MC.field_1755 != null) {
            return;
        }
        this.savedSlot = ClickPearl.MC.field_1724.method_31548().field_7545;
        InventoryResult hotbar = InventoryToolkit.findItemInHotBar(class_1802.field_8634);
        if (hotbar.found()) {
            this.pearlSlot = hotbar.slot();
            InventoryToolkit.switchTo(this.pearlSlot);
            this.phase = Phase.AWAIT_SWITCH;
            return;
        }
        InventoryResult inv = InventoryToolkit.findItemInInventory(class_1802.field_8634);
        if (inv.found()) {
            this.pearlSlot = inv.slot();
            if (this.modeSetting.getSelected().equals("Legit")) {
                this.wasForwardPressed = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1894.method_1429().method_1444());
                this.wasBackPressed = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1881.method_1429().method_1444());
                this.wasLeftPressed = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1913.method_1429().method_1444());
                this.wasRightPressed = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1849.method_1429().method_1444());
                this.wasJumpPressed = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1903.method_1429().method_1444());
                this.phase = Phase.SLOWING_DOWN;
                this.actionStartTime = System.currentTimeMillis();
            } else {
                this.phase = Phase.PREPARE;
            }
        } else {
            ChatMessage.brandmessage("\u041d\u0435\u0442\u0443 \u0436\u0435\u043c\u0447\u0443\u0433\u0430");
            this.resetState();
        }
    }

    private void execute() {
        if (ClickPearl.MC.field_1724 == null || ClickPearl.MC.field_1755 != null) {
            this.resetState();
            return;
        }
        long elapsed = System.currentTimeMillis() - this.actionStartTime;
        switch (this.phase.ordinal()) {
            case 1: {
                ClickPearl.MC.field_1724.field_3913.field_3905 = 0.0f;
                ClickPearl.MC.field_1724.field_3913.field_3907 = 0.0f;
                if (ClickPearl.MC.field_1724.method_5624()) {
                    ClickPearl.MC.field_1724.method_5728(false);
                    AutoSprint.tickStop = 1;
                }
                if (!this.keysOverridden) {
                    ClickPearl.MC.field_1690.field_1894.method_23481(false);
                    ClickPearl.MC.field_1690.field_1881.method_23481(false);
                    ClickPearl.MC.field_1690.field_1913.method_23481(false);
                    ClickPearl.MC.field_1690.field_1849.method_23481(false);
                    ClickPearl.MC.field_1690.field_1903.method_23481(false);
                    this.keysOverridden = true;
                }
                if (elapsed <= 1L) break;
                this.phase = Phase.PREPARE;
                break;
            }
            case 2: {
                int quickSwapSlot = ClickPearl.MC.field_1724.method_31548().field_7545;
                InventoryToolkit.clickSlot(this.pearlSlot, quickSwapSlot, class_1713.field_7791);
                InventoryToolkit.switchTo(quickSwapSlot);
                this.phase = Phase.AWAIT_SWITCH;
                break;
            }
            case 3: {
                if (ClickPearl.MC.field_1724.method_6047().method_7909() != class_1802.field_8634) break;
                this.phase = Phase.THROW;
                break;
            }
            case 4: {
                boolean fromInventory;
                InventoryToolkit.sendPacket(new class_2886(class_1268.field_5808, this.packetSequence++, ClickPearl.MC.field_1724.method_36454(), ClickPearl.MC.field_1724.method_36455()));
                ClickPearl.MC.field_1724.method_6104(class_1268.field_5808);
                boolean bl = fromInventory = this.pearlSlot >= 9 && this.pearlSlot <= 35;
                if (fromInventory) {
                    int quickSwapSlot = ClickPearl.MC.field_1724.method_31548().field_7545;
                    InventoryToolkit.clickSlot(this.pearlSlot, quickSwapSlot, class_1713.field_7791);
                }
                InventoryToolkit.switchTo(this.savedSlot);
                if (this.modeSetting.getSelected().equals("Legit") && fromInventory) {
                    this.restoreKeyStates();
                    this.actionStartTime = System.currentTimeMillis();
                    this.phase = Phase.SPEEDING_UP;
                    break;
                }
                this.phase = Phase.FINISH;
                break;
            }
            case 5: {
                long speedupElapsed = System.currentTimeMillis() - this.actionStartTime;
                float speedupProgress = Math.min(1.0f, (float)speedupElapsed / 20.0f);
                if (ClickPearl.MC.field_1724.field_3913 != null) {
                    boolean forward = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1894.method_1429().method_1444());
                    float targetForward = forward ? 1.0f : 0.0f;
                    ClickPearl.MC.field_1724.field_3913.field_3905 = this.lerp(ClickPearl.MC.field_1724.field_3913.field_3905, targetForward * speedupProgress, 0.4f);
                    if (speedupProgress > 0.4f && forward && !ClickPearl.MC.field_1724.method_5624()) {
                        ClickPearl.MC.field_1724.method_5728(true);
                    }
                }
                if (speedupElapsed <= 25L) break;
                this.phase = Phase.FINISH;
                break;
            }
            case 6: {
                this.resetState();
            }
        }
    }

    private float lerp(float start, float end, float delta) {
        return start + (end - start) * delta;
    }

    private void restoreKeyStates() {
        if (!this.keysOverridden) {
            return;
        }
        boolean currentForward = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1894.method_1429().method_1444());
        boolean currentBack = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1881.method_1429().method_1444());
        boolean currentLeft = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1913.method_1429().method_1444());
        boolean currentRight = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1849.method_1429().method_1444());
        boolean currentJump = class_3675.method_15987((long)MC.method_22683().method_4490(), (int)ClickPearl.MC.field_1690.field_1903.method_1429().method_1444());
        ClickPearl.MC.field_1690.field_1894.method_23481(this.wasForwardPressed && currentForward);
        ClickPearl.MC.field_1690.field_1881.method_23481(this.wasBackPressed && currentBack);
        ClickPearl.MC.field_1690.field_1913.method_23481(this.wasLeftPressed && currentLeft);
        ClickPearl.MC.field_1690.field_1849.method_23481(this.wasRightPressed && currentRight);
        ClickPearl.MC.field_1690.field_1903.method_23481(this.wasJumpPressed && currentJump);
        this.keysOverridden = false;
    }

    private void resetState() {
        if (this.keysOverridden) {
            this.restoreKeyStates();
        }
        this.pearlSlot = -1;
        this.savedSlot = -1;
        this.actionStartTime = 0L;
        this.phase = Phase.READY;
    }

    private boolean isBindActive() {
        long window = MC.method_22683().method_4490();
        int key = this.keySetting.getKey();
        if (key >= 0 && key <= 7) {
            return GLFW.glfwGetMouseButton((long)window, (int)key) == 1;
        }
        return class_3675.method_15987((long)window, (int)key);
    }

    private static enum Phase {
        READY,
        SLOWING_DOWN,
        PREPARE,
        AWAIT_SWITCH,
        THROW,
        SPEEDING_UP,
        FINISH;

    }
}

