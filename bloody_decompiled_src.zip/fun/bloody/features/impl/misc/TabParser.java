/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2561
 *  net.minecraft.class_2596
 *  net.minecraft.class_2797
 *  net.minecraft.class_640
 *  net.minecraft.class_7635$class_7636
 */
package fun.bloody.features.impl.misc;

import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.utils.client.chat.ChatMessage;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.math.time.TimerUtil;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2797;
import net.minecraft.class_640;
import net.minecraft.class_7635;

public class TabParser
extends Module {
    SelectSetting versionSelect = new SelectSetting("\u0412\u0435\u0440\u0441\u0438\u044f", "1.16.5").value("1.16.5", "1.21.4");
    MultiSelectSetting donateSelect = new MultiSelectSetting("\u0414\u043e\u043d\u0430\u0442 \u043f\u0440\u0435\u0444\u0438\u043a\u0441\u044b", "").value("\u0413\u0435\u0440\u0446\u043e\u0433", "\u041a\u043d\u044f\u0437\u044c", "\u041f\u0440\u0438\u043d\u0446", "\u0422\u0438\u0442\u0430\u043d", "\u042d\u043b\u0438\u0442\u0430", "\u0413\u043b\u0430\u0432\u0430");
    List<String> anarchyServers165 = new ArrayList<String>();
    List<String> anarchyServers214 = new ArrayList<String>();
    Map<String, Set<String>> parsedPlayers = new ConcurrentHashMap<String, Set<String>>();
    Map<String, Set<String>> initialPlayers = new ConcurrentHashMap<String, Set<String>>();
    TimerUtil switchTimer = TimerUtil.create();
    TimerUtil scanTimer = TimerUtil.create();
    int currentServerIndex = 0;
    boolean parsing = false;
    boolean waitingForServerLoad = false;
    static final Pattern NAME_PATTERN = Pattern.compile("^\\w{3,16}$");

    public TabParser() {
        super("Tab Parser", "Tab Parser", ModuleCategory.MISC);
        int i;
        this.setup(this.versionSelect, this.donateSelect);
        this.anarchyServers165.addAll(List.of("/an102", "/an103", "/an104", "/an105", "/an106", "/an107"));
        for (i = 203; i <= 221; ++i) {
            this.anarchyServers165.add("/an" + i);
        }
        for (i = 302; i <= 313; ++i) {
            this.anarchyServers165.add("/an" + i);
        }
        this.anarchyServers165.addAll(List.of("/an502", "/an503", "/an504", "/an505", "/an506", "/an507", "/an602"));
        this.anarchyServers214.addAll(List.of("/an11", "/an12", "/an21", "/an23", "/an31", "/an32", "/an51", "/an52"));
    }

    @Override
    public void activate() {
        super.activate();
        this.loadExistingData();
        this.saveInitialState();
        this.currentServerIndex = 0;
        this.parsing = true;
        this.waitingForServerLoad = false;
        this.switchTimer.resetCounter();
        this.scanTimer.resetCounter();
        for (String donate : this.donateSelect.getSelected()) {
            if (this.parsedPlayers.containsKey(donate)) continue;
            this.parsedPlayers.put(donate, ConcurrentHashMap.newKeySet());
        }
        this.switchToNextServer();
    }

    @Override
    public void deactivate() {
        super.deactivate();
        this.parsing = false;
        ChatMessage.brandmessage("\u041f\u0430\u0440\u0441\u0438\u043d\u0433 \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d.");
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (TabParser.mc.field_1724 == null || TabParser.mc.field_1687 == null || !this.parsing) {
            return;
        }
        if (this.waitingForServerLoad) {
            if (this.scanTimer.hasTimeElapsed(3000L)) {
                this.waitingForServerLoad = false;
                this.scanTimer.resetCounter();
            }
            return;
        }
        if (this.scanTimer.hasTimeElapsed(2000L)) {
            this.scanCurrentServer();
            this.scanTimer.resetCounter();
        }
        if (this.switchTimer.hasTimeElapsed(5000L)) {
            this.switchToNextServer();
            this.switchTimer.resetCounter();
        }
    }

    private void saveInitialState() {
        this.initialPlayers.clear();
        for (Map.Entry<String, Set<String>> entry : this.parsedPlayers.entrySet()) {
            this.initialPlayers.put(entry.getKey(), new HashSet(entry.getValue()));
        }
    }

    private int calculateNewPlayers() {
        int newCount = 0;
        for (Map.Entry<String, Set<String>> entry : this.parsedPlayers.entrySet()) {
            String donate = entry.getKey();
            Set<String> currentPlayers = entry.getValue();
            Set oldPlayers = this.initialPlayers.getOrDefault(donate, Collections.emptySet());
            for (String player : currentPlayers) {
                if (oldPlayers.contains(player)) continue;
                ++newCount;
            }
        }
        return newCount;
    }

    private void loadExistingData() {
        this.parsedPlayers.clear();
        for (String donate : this.donateSelect.getSelected()) {
            this.parsedPlayers.put(donate, ConcurrentHashMap.newKeySet());
        }
        File outputFile = TabParser.getOutputFile();
        if (!outputFile.exists()) {
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(outputFile));){
            String line;
            String currentDonate = null;
            int loadedCount = 0;
            while ((line = reader.readLine()) != null) {
                if ((line = line.trim()).startsWith("====") && line.contains("\u0434\u043e\u043d\u0430\u0442\u043e\u043c")) {
                    String[] parts = line.split("\u0434\u043e\u043d\u0430\u0442\u043e\u043c");
                    if (parts.length <= 1 || this.parsedPlayers.containsKey(currentDonate = parts[1].replace("====", "").trim())) continue;
                    this.parsedPlayers.put(currentDonate, ConcurrentHashMap.newKeySet());
                    continue;
                }
                if (line.isEmpty() || currentDonate == null || !NAME_PATTERN.matcher(line).matches()) continue;
                this.parsedPlayers.get(currentDonate).add(line);
                ++loadedCount;
            }
            ChatMessage.brandmessage("\u0417\u0430\u0433\u0440\u0443\u0436\u0435\u043d\u043e " + loadedCount + " \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044e\u0449\u0438\u0445 \u0437\u0430\u043f\u0438\u0441\u0435\u0439");
        }
        catch (IOException e) {
            ChatMessage.brandmessage("\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0440\u0438 \u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0435 \u0434\u0430\u043d\u043d\u044b\u0445: " + e.getMessage());
        }
    }

    private void scanCurrentServer() {
        if (mc.method_1562() == null || TabParser.mc.field_1687 == null) {
            return;
        }
        Collection playerList = mc.method_1562().method_2880();
        if (playerList == null || playerList.isEmpty()) {
            return;
        }
        block0: for (class_640 entry : playerList) {
            class_2561 displayName;
            String name = entry.method_2966().getName();
            if (!NAME_PATTERN.matcher(name).matches() || (displayName = entry.method_2971()) == null) continue;
            String displayText = displayName.getString().toLowerCase();
            for (String donate : this.donateSelect.getSelected()) {
                String donateLower = donate.toLowerCase();
                if (!displayText.contains(donateLower)) continue;
                Set<String> players = this.parsedPlayers.get(donate);
                if (players == null) continue block0;
                players.add(name);
                continue block0;
            }
        }
    }

    private void switchToNextServer() {
        List<String> servers;
        List<String> list = servers = this.versionSelect.isSelected("1.21.4") ? this.anarchyServers214 : this.anarchyServers165;
        if (this.currentServerIndex >= servers.size()) {
            this.parsing = false;
            int newPlayers = this.calculateNewPlayers();
            this.saveToFile();
            ChatMessage.brandmessage("\u0423\u0441\u043f\u0435\u0448\u043d\u043e \u0441\u043f\u0430\u0440\u0441\u0438\u043b \u0432\u0441\u0435 \u0430\u043d\u0430\u0440\u0445\u0438\u0438!");
            if (newPlayers > 0) {
                ChatMessage.brandmessage("\u0411\u044b\u043b\u043e \u0437\u0430\u043f\u0438\u0441\u0430\u043d\u043e " + newPlayers + " \u043d\u043e\u0432\u044b\u0445 \u043d\u0438\u043a\u043e\u0432");
            }
            ChatMessage.brandmessage("\u0427\u0442\u043e\u0431\u044b \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0444\u0430\u0439\u043b \u0441 \u043d\u0438\u043a\u043d\u0435\u0439\u043c\u0430\u043c\u0438 \u0432\u0432\u0435\u0434\u0438\u0442\u0435 .tabparser dir");
            this.setState(false);
            return;
        }
        String nextServer = servers.get(this.currentServerIndex);
        ++this.currentServerIndex;
        ChatMessage.brandmessage("\u041f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0430\u044e\u0441\u044c \u043d\u0430 \u0441\u0435\u0440\u0432\u0435\u0440: " + nextServer + " (" + this.currentServerIndex + "/" + servers.size() + ")");
        if (TabParser.mc.field_1724 != null && TabParser.mc.field_1724.field_3944 != null) {
            TabParser.mc.field_1724.field_3944.method_52787((class_2596)new class_2797(nextServer, Instant.now(), 0L, null, new class_7635.class_7636(0, new BitSet())));
            this.waitingForServerLoad = true;
            this.scanTimer.resetCounter();
        }
    }

    private void saveToFile() {
        File outputFile = TabParser.getOutputFile();
        try {
            outputFile.getParentFile().mkdirs();
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile, false));){
                List<String> orderedDonates = Arrays.asList("\u0413\u0435\u0440\u0446\u043e\u0433", "\u041a\u043d\u044f\u0437\u044c", "\u041f\u0440\u0438\u043d\u0446", "\u0422\u0438\u0442\u0430\u043d", "\u042d\u043b\u0438\u0442\u0430", "\u0413\u043b\u0430\u0432\u0430");
                int totalPlayers = 0;
                for (String donate : orderedDonates) {
                    Set<String> players;
                    if (!this.parsedPlayers.containsKey(donate) || (players = this.parsedPlayers.get(donate)) == null || players.isEmpty()) continue;
                    writer.write("==== \u0410\u043a\u043a\u0430\u0443\u043d\u0442\u044b \u0441 \u0434\u043e\u043d\u0430\u0442\u043e\u043c " + donate + " ====");
                    writer.newLine();
                    ArrayList<String> sortedPlayers = new ArrayList<String>(players);
                    Collections.sort(sortedPlayers);
                    for (String player : sortedPlayers) {
                        writer.write(player);
                        writer.newLine();
                    }
                    writer.newLine();
                    totalPlayers += players.size();
                }
                writer.flush();
                ChatMessage.brandmessage("\u0421\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e " + totalPlayers + " \u0438\u0433\u0440\u043e\u043a\u043e\u0432 \u0432 \u0444\u0430\u0439\u043b");
            }
        }
        catch (IOException e) {
            ChatMessage.brandmessage("\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0440\u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0438\u0438 \u0444\u0430\u0439\u043b\u0430: " + e.getMessage());
        }
    }

    public static File getOutputFile() {
        return new File(TabParser.mc.field_1697, "tabparser_results.txt");
    }
}

