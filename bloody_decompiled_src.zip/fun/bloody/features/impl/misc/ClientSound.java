/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3298
 */
package fun.bloody.features.impl.misc;

import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.Instance;
import java.io.BufferedInputStream;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;

public class ClientSound
extends Module {
    public static ClientSound getInstance() {
        return Instance.get(ClientSound.class);
    }

    public ClientSound() {
        super("ClientSound", "ClientSound", ModuleCategory.MISC);
    }

    public void playEnableSound() {
        if (!this.isState()) {
            return;
        }
        String fileName = "celestial_on.wav";
        this.playSound(fileName);
    }

    public void playDisableSound() {
        String fileName = "celestial_off.wav";
        this.playSound(fileName);
    }

    private void playSound(String fileName) {
        new Thread(() -> {
            try {
                class_310 mc = class_310.method_1551();
                if (mc == null || mc.method_1478() == null) {
                    return;
                }
                String resourcePath = "textures/sound/" + fileName;
                class_2960 resourceId = class_2960.method_60655((String)"minecraft", (String)resourcePath);
                InputStream is = ((class_3298)mc.method_1478().method_14486(resourceId).orElseThrow(() -> new RuntimeException("Sound not found: " + resourcePath))).method_14482();
                BufferedInputStream bis = new BufferedInputStream(is);
                AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(bis);
                if (audioInputStream == null) {
                    return;
                }
                Clip clip = AudioSystem.getClip();
                clip.open(audioInputStream);
                FloatControl gainControl = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
                float vol = 0.5f;
                float gain = (float)(Math.log(vol) / Math.log(10.0) * 20.0);
                gainControl.setValue(Math.max(gainControl.getMinimum(), Math.min(gainControl.getMaximum(), gain)));
                clip.addLineListener(event -> {
                    if (event.getType() == LineEvent.Type.STOP) {
                        try {
                            clip.close();
                            audioInputStream.close();
                            bis.close();
                            is.close();
                        }
                        catch (Exception exception) {
                            // empty catch block
                        }
                    }
                });
                clip.start();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }, "ClientSound-Player").start();
    }
}

