/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 *  net.minecraft.class_2720
 *  net.minecraft.class_2856
 *  net.minecraft.class_2856$class_2857
 */
package fun.bloody.features.impl.misc;

import fun.bloody.events.packet.PacketEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import java.util.UUID;
import net.minecraft.class_2596;
import net.minecraft.class_2720;
import net.minecraft.class_2856;

public class NoResourcePack
extends Module {
    public static NoResourcePack getInstance() {
        return Instance.get(NoResourcePack.class);
    }

    public NoResourcePack() {
        super("NoResourcePack", "No Resource Pack", ModuleCategory.MISC);
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        class_2596<?> class_25962 = e.getPacket();
        if (class_25962 instanceof class_2720) {
            class_2720 packet = (class_2720)class_25962;
            e.cancel();
            UUID packId = packet.comp_2158();
            mc.method_1562().method_52787((class_2596)new class_2856(packId, class_2856.class_2857.field_13016));
            mc.method_1562().method_52787((class_2596)new class_2856(packId, class_2856.class_2857.field_13017));
        }
    }
}

