/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.misc;

import antidaunleak.api.UserProfile;
import fun.bloody.Bloody;
import fun.bloody.commands.CommandDispatcher;
import fun.bloody.events.chat.ChatEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.utils.client.chat.ChatMessage;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.math.calc.Calculate;
import fun.bloody.utils.math.time.StopWatch;

public class SelfDestruct
extends Module {
    public static boolean unhooked;
    public static boolean hideInventoryButtons;
    StopWatch timer = new StopWatch();

    public SelfDestruct() {
        super("SelfDestruct", "Self Destruct", ModuleCategory.MISC);
    }

    @Override
    public void activate() {
        unhooked = true;
        Bloody.getInstance().getDiscordManager().stopRPC();
        for (Module module : Bloody.getInstance().getModuleProvider().getModules()) {
            if (module == this || !module.isState()) continue;
            module.setState(false);
        }
        ChatMessage.brandmessage("\u0414\u043b\u044f \u0432\u043e\u0437\u0432\u0440\u0430\u0449\u0435\u043d\u0438\u044f \u0447\u0438\u0442\u0430 \u0432\u043f\u0438\u0448\u0438\u0442\u0435 \u0432 \u0447\u0430\u0442 \u0432\u0430\u0448 username \u0432 \u0447\u0438\u0442\u0435");
        ChatMessage.brandmessage("\u0421\u043e\u043e\u0431\u0449\u0435\u043d\u0438\u0435 \u0443\u0434\u0430\u043b\u0438\u0442\u0441\u044f \u0447\u0435\u0440\u0435\u0437 \u043f\u043e\u043b \u0441\u0435\u043a\u0443\u043d\u0434\u044b");
        if (this.timer.every(500.0)) {
            SelfDestruct.mc.field_1705.method_1743().method_1808(true);
        }
        for (Module module : Bloody.getInstance().getModuleProvider().getModules()) {
            module.setKey(-1);
        }
        Bloody.getInstance().getCommandDispatcher();
        CommandDispatcher.prefix = "" + Calculate.getRandom(0, 9999999);
        super.activate();
    }

    @EventHandler
    public void onChat(ChatEvent event) {
        String msg = event.getMessage().trim();
        if (msg.equalsIgnoreCase(UserProfile.getInstance().profile("username"))) {
            unhooked = false;
            Bloody.getInstance().getDiscordManager().setRunning(true);
            this.state = false;
            Bloody.getInstance().getCommandDispatcher();
            CommandDispatcher.prefix = ".";
            ChatMessage.brandmessage("Unhook reset to FALSE");
            event.setCancelled(true);
        }
    }

    @Override
    public void deactivate() {
        unhooked = false;
        super.deactivate();
    }

    static {
        hideInventoryButtons = false;
    }
}

