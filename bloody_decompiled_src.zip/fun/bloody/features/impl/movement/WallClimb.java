/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1747
 *  net.minecraft.class_1799
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2382
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2680
 *  net.minecraft.class_2879
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 */
package fun.bloody.features.impl.movement;

import antidaunleak.api.annotation.Native;
import fun.bloody.events.player.RotationUpdateEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.Setting;
import fun.bloody.utils.client.chat.ChatMessage;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.features.aura.warp.Turns;
import fun.bloody.utils.features.aura.warp.TurnsConnection;
import fun.bloody.utils.math.time.StopWatch;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2879;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class WallClimb
extends Module {
    private final StopWatch placeTimer = new StopWatch();
    private int blockSlot = -1;
    private int previousSlot = -1;
    private boolean notifiedNoBlocks = false;
    private boolean needsRotation = false;
    private float targetYaw = 0.0f;

    public WallClimb() {
        super("WallClimb", "Wall Climb", ModuleCategory.MOVEMENT);
        this.setup(new Setting[0]);
    }

    @Override
    public void activate() {
        super.activate();
        this.notifiedNoBlocks = false;
        this.needsRotation = false;
        this.findBlockInInventory();
    }

    @Override
    public void deactivate() {
        super.deactivate();
        this.restoreSlot();
        this.blockSlot = -1;
        this.notifiedNoBlocks = false;
        this.needsRotation = false;
        TurnsConnection.INSTANCE.setRotation(null);
    }

    @EventHandler
    @Native(type=Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (WallClimb.mc.field_1724 == null || WallClimb.mc.field_1687 == null) {
            return;
        }
        if (this.blockSlot == -1) {
            this.findBlockInInventory();
            if (this.blockSlot == -1) {
                if (!this.notifiedNoBlocks) {
                    ChatMessage.brandmessage("\u0411\u043b\u043e\u043a\u0438 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u044b \u0432 \u0445\u043e\u0442\u0431\u0430\u0440\u0435!");
                    this.notifiedNoBlocks = true;
                }
                this.needsRotation = false;
                TurnsConnection.INSTANCE.setRotation(null);
                return;
            }
        }
        if (!this.isNearWall()) {
            this.restoreSlot();
            this.needsRotation = false;
            TurnsConnection.INSTANCE.setRotation(null);
            return;
        }
        if (this.previousSlot == -1) {
            this.previousSlot = WallClimb.mc.field_1724.method_31548().field_7545;
            WallClimb.mc.field_1724.method_31548().field_7545 = this.blockSlot;
        }
        this.targetYaw = this.findWallYaw();
        this.needsRotation = true;
        if (WallClimb.mc.field_1724.method_24828()) {
            WallClimb.mc.field_1690.field_1903.method_23481(true);
        } else {
            WallClimb.mc.field_1690.field_1903.method_23481(false);
        }
    }

    @EventHandler
    public void onRotationUpdate(RotationUpdateEvent e) {
        if (!this.isState() || !this.needsRotation) {
            return;
        }
        if (e.getType() == 0) {
            float targetPitch = 82.0f;
            Turns targetRotation = new Turns(this.targetYaw, targetPitch);
            TurnsConnection.INSTANCE.setRotation(targetRotation);
        } else if (e.getType() == 2 && this.placeTimer.finished(20.0)) {
            this.tryPlaceBlock();
            this.placeTimer.reset();
        }
    }

    private void findBlockInInventory() {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = WallClimb.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960() || !(stack.method_7909() instanceof class_1747)) continue;
            this.blockSlot = i;
            return;
        }
    }

    private void tryPlaceBlock() {
        class_2338 targetPos;
        class_2680 targetState;
        class_243 endPos;
        if (WallClimb.mc.field_1724 == null || WallClimb.mc.field_1761 == null || WallClimb.mc.field_1687 == null) {
            return;
        }
        Turns rotation = TurnsConnection.INSTANCE.getRotation();
        if (rotation == null) {
            rotation = new Turns(WallClimb.mc.field_1724.method_36454(), 82.0f);
        }
        float yaw = rotation.getYaw();
        float pitch = rotation.getPitch();
        float yawRad = yaw * ((float)Math.PI / 180);
        float pitchRad = pitch * ((float)Math.PI / 180);
        float cosYaw = (float)Math.cos((double)(-yawRad) - Math.PI);
        float sinYaw = (float)Math.sin((double)(-yawRad) - Math.PI);
        float cosPitch = (float)(-Math.cos(-pitchRad));
        float sinPitch = (float)Math.sin(-pitchRad);
        class_243 lookVec = new class_243((double)(sinYaw * cosPitch), (double)sinPitch, (double)(cosYaw * cosPitch));
        class_243 eyePos = WallClimb.mc.field_1724.method_33571();
        class_3959 raycastContext = new class_3959(eyePos, endPos = eyePos.method_1019(lookVec.method_1021(4.5)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)WallClimb.mc.field_1724);
        class_3965 hitResult = WallClimb.mc.field_1687.method_17742(raycastContext);
        if (hitResult != null && hitResult.method_17783() == class_239.class_240.field_1332 && !(targetState = WallClimb.mc.field_1687.method_8320(targetPos = hitResult.method_17777())).method_26215() && targetState.method_51367()) {
            class_2350 face = hitResult.method_17780();
            this.placeBlockAt(targetPos, face);
        }
    }

    private void placeBlockAt(class_2338 clickPos, class_2350 face) {
        if (WallClimb.mc.field_1724 == null || WallClimb.mc.field_1761 == null) {
            return;
        }
        try {
            class_243 hitVec = class_243.method_24953((class_2382)clickPos).method_1031((double)face.method_10148() * 0.5, (double)face.method_10164() * 0.5, (double)face.method_10165() * 0.5);
            class_3965 hitResult = new class_3965(hitVec, face, clickPos, false);
            WallClimb.mc.field_1761.method_2896(WallClimb.mc.field_1724, class_1268.field_5808, hitResult);
            WallClimb.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(class_1268.field_5808));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void restoreSlot() {
        if (this.previousSlot != -1 && WallClimb.mc.field_1724 != null) {
            WallClimb.mc.field_1724.method_31548().field_7545 = this.previousSlot;
            this.previousSlot = -1;
        }
    }

    private boolean isNearWall() {
        if (WallClimb.mc.field_1724 == null || WallClimb.mc.field_1687 == null) {
            return false;
        }
        class_2338 playerPos = WallClimb.mc.field_1724.method_24515();
        for (int y = 0; y <= 1; ++y) {
            class_2338 checkPos = playerPos.method_10086(y);
            if (WallClimb.mc.field_1687.method_8320(checkPos.method_10095()).method_26215() && WallClimb.mc.field_1687.method_8320(checkPos.method_10072()).method_26215() && WallClimb.mc.field_1687.method_8320(checkPos.method_10078()).method_26215() && WallClimb.mc.field_1687.method_8320(checkPos.method_10067()).method_26215()) continue;
            return true;
        }
        return false;
    }

    private float findWallYaw() {
        if (WallClimb.mc.field_1724 == null || WallClimb.mc.field_1687 == null) {
            return WallClimb.mc.field_1724.method_36454();
        }
        class_2338 playerPos = WallClimb.mc.field_1724.method_24515();
        for (int y = 0; y <= 1; ++y) {
            class_2338 checkPos = playerPos.method_10086(y);
            if (!WallClimb.mc.field_1687.method_8320(checkPos.method_10095()).method_26215()) {
                return 180.0f;
            }
            if (!WallClimb.mc.field_1687.method_8320(checkPos.method_10072()).method_26215()) {
                return 0.0f;
            }
            if (!WallClimb.mc.field_1687.method_8320(checkPos.method_10067()).method_26215()) {
                return 90.0f;
            }
            if (WallClimb.mc.field_1687.method_8320(checkPos.method_10078()).method_26215()) continue;
            return -90.0f;
        }
        return WallClimb.mc.field_1724.method_36454();
    }
}

