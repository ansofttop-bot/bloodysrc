/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 *  net.minecraft.class_2813
 *  net.minecraft.class_3675
 *  net.minecraft.class_408
 *  net.minecraft.class_490
 */
package fun.bloody.features.impl.movement;

import antidaunleak.api.annotation.Native;
import fun.bloody.Bloody;
import fun.bloody.events.container.CloseScreenEvent;
import fun.bloody.events.packet.PacketEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.display.interfaces.QuickImports;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_490;

public class InventoryMove
extends Module
implements QuickImports {
    private final List<class_2813> pendingPackets = new ArrayList<class_2813>();
    private final SelectSetting mode = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "\u0420\u0435\u0436\u0438\u043c \u043f\u0435\u0440\u0435\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u044f \u0432 \u0438\u043d\u0432\u0435\u043d\u0442\u0430\u0440\u0435").value("Legit").selected("Legit");
    private int tick = 0;

    public InventoryMove() {
        super("InventoryMove", "Inventory Move", ModuleCategory.MOVEMENT);
        this.setup(this.mode);
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        if (InventoryMove.mc.field_1724 == null) {
            return;
        }
        class_2596<?> p = e.getPacket();
        if (p instanceof class_2813) {
            class_2813 clickPacket = (class_2813)p;
            if (this.isMoving() && InventoryMove.mc.field_1755 instanceof class_490) {
                this.pendingPackets.add(clickPacket);
                e.cancel();
            }
        }
    }

    @EventHandler
    @Native(type=Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (InventoryMove.mc.field_1724 == null) {
            return;
        }
        if (this.tick != 0) {
            this.stopAllMovement();
            --this.tick;
            return;
        }
        if (InventoryMove.mc.field_1755 instanceof class_408) {
            return;
        }
        this.updateMovementKeys();
    }

    private void stopAllMovement() {
        InventoryMove.mc.field_1690.field_1894.method_23481(false);
        InventoryMove.mc.field_1690.field_1881.method_23481(false);
        InventoryMove.mc.field_1690.field_1913.method_23481(false);
        InventoryMove.mc.field_1690.field_1849.method_23481(false);
        InventoryMove.mc.field_1690.field_1903.method_23481(false);
        InventoryMove.mc.field_1690.field_1867.method_23481(false);
    }

    private void updateMovementKeys() {
        boolean[] keys2 = new boolean[]{class_3675.method_15987((long)mc.method_22683().method_4490(), (int)InventoryMove.mc.field_1690.field_1894.method_1429().method_1444()), class_3675.method_15987((long)mc.method_22683().method_4490(), (int)InventoryMove.mc.field_1690.field_1881.method_1429().method_1444()), class_3675.method_15987((long)mc.method_22683().method_4490(), (int)InventoryMove.mc.field_1690.field_1913.method_1429().method_1444()), class_3675.method_15987((long)mc.method_22683().method_4490(), (int)InventoryMove.mc.field_1690.field_1849.method_1429().method_1444()), class_3675.method_15987((long)mc.method_22683().method_4490(), (int)InventoryMove.mc.field_1690.field_1903.method_1429().method_1444()), class_3675.method_15987((long)mc.method_22683().method_4490(), (int)InventoryMove.mc.field_1690.field_1867.method_1429().method_1444())};
        InventoryMove.mc.field_1690.field_1894.method_23481(keys2[0]);
        InventoryMove.mc.field_1690.field_1881.method_23481(keys2[1]);
        InventoryMove.mc.field_1690.field_1913.method_23481(keys2[2]);
        InventoryMove.mc.field_1690.field_1849.method_23481(keys2[3]);
        InventoryMove.mc.field_1690.field_1903.method_23481(keys2[4]);
        InventoryMove.mc.field_1690.field_1867.method_23481(keys2[5]);
    }

    private boolean isMoving() {
        return InventoryMove.mc.field_1724 != null && (InventoryMove.mc.field_1724.field_3913.field_3905 != 0.0f || InventoryMove.mc.field_1724.field_3913.field_3907 != 0.0f || InventoryMove.mc.field_1690.field_1903.method_1434());
    }

    @EventHandler
    public void onCloseScreen(CloseScreenEvent e) {
        if (InventoryMove.mc.field_1755 instanceof class_490 && !this.pendingPackets.isEmpty() && this.isMoving()) {
            new Thread(() -> {
                this.tick = 5;
                try {
                    Thread.sleep(140L);
                }
                catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
                for (class_2813 pkt : this.pendingPackets) {
                    if (mc.method_1562() == null) continue;
                    mc.method_1562().method_52787((class_2596)pkt);
                }
                this.pendingPackets.clear();
            }).start();
            e.cancel();
        } else {
            this.pendingPackets.clear();
        }
    }

    public static void stopMovementTemporarily(int ticks) {
        for (Module module : Bloody.getInstance().getModuleRepository().modules()) {
            InventoryMove inventoryMove;
            if (!(module instanceof InventoryMove) || !(inventoryMove = (InventoryMove)module).isState()) continue;
            inventoryMove.tick = Math.max(inventoryMove.tick, ticks);
            break;
        }
    }

    @Override
    public void deactivate() {
        super.deactivate();
        this.pendingPackets.clear();
    }

    public List<class_2813> getPendingPackets() {
        return this.pendingPackets;
    }

    public SelectSetting getMode() {
        return this.mode;
    }

    public int getTick() {
        return this.tick;
    }
}

