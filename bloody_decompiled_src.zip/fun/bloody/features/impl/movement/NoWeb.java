/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 */
package fun.bloody.features.impl.movement;

import antidaunleak.api.annotation.Native;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.interactions.interact.PlayerInteractionHelper;
import fun.bloody.utils.interactions.simulate.Simulations;
import net.minecraft.class_2246;

public class NoWeb
extends Module {
    public final SelectSetting webMode = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0435\u0436\u0438\u043c \u043e\u0431\u0445\u043e\u0434\u0430").value("Grim");

    public static NoWeb getInstance() {
        return Instance.get(NoWeb.class);
    }

    public NoWeb() {
        super("NoWeb(ban)", "No Web(ban)", ModuleCategory.MOVEMENT);
        this.setup(this.webMode);
    }

    @EventHandler
    @Native(type=Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (PlayerInteractionHelper.isPlayerInBlock(class_2246.field_10343)) {
            double[] speed = Simulations.calculateDirection(0.65);
            NoWeb.mc.field_1724.method_5762(speed[0], 0.0, speed[1]);
            NoWeb.mc.field_1724.field_18276.field_1351 = NoWeb.mc.field_1690.field_1903.method_1434() ? 1.0 : (NoWeb.mc.field_1690.field_1832.method_1434() ? -1.0 : 0.0);
        }
    }
}

