/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1294
 */
package fun.bloody.features.impl.movement;

import antidaunleak.api.annotation.Native;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;
import net.minecraft.class_1294;

public class AutoSprint
extends Module {
    public static int tickStop;
    private MultiSelectSetting settings = new MultiSelectSetting("\u0418\u0433\u043d\u043e\u0440\u0438\u0440\u043e\u0432\u0430\u0442\u044c", "\u041d\u0435 \u0434\u0430\u0435\u0442 \u0441\u043f\u0440\u0438\u043d\u0442\u0438\u0442\u044c\u0441\u044f \u043f\u0440\u0438 \u044d\u0444\u0444\u0435\u043a\u0442\u0430\u0445").value("Slowness", "Blindness");

    public static AutoSprint getInstance() {
        return Instance.get(AutoSprint.class);
    }

    public AutoSprint() {
        super("AutoSprint", "Auto Sprint", ModuleCategory.MOVEMENT);
        this.setup(this.settings);
    }

    @EventHandler
    @Native(type=Native.Type.VMProtectBeginMutation)
    public void onTick(TickEvent e) {
        boolean sneaking;
        boolean hasSlowness = AutoSprint.mc.field_1724.method_6059(class_1294.field_5909);
        boolean hasBlindness = AutoSprint.mc.field_1724.method_6059(class_1294.field_5919);
        boolean shouldCancelSprintDueToSlowness = hasSlowness && !this.settings.isSelected("Slowness");
        boolean shouldCancelSprintDueToBlindness = hasBlindness && !this.settings.isSelected("Blindness");
        boolean horizontal = AutoSprint.mc.field_1724.field_5976 && !AutoSprint.mc.field_1724.field_34927;
        boolean bl = sneaking = AutoSprint.mc.field_1724.method_5715() && !AutoSprint.mc.field_1724.method_5681();
        if (tickStop > 0 || sneaking || shouldCancelSprintDueToSlowness || shouldCancelSprintDueToBlindness) {
            AutoSprint.mc.field_1724.method_5728(false);
        } else if (!horizontal && AutoSprint.mc.field_1724.field_6250 > 0.0f && !AutoSprint.mc.field_1690.field_1867.method_1434()) {
            AutoSprint.mc.field_1724.method_5728(true);
        }
        --tickStop;
    }
}

