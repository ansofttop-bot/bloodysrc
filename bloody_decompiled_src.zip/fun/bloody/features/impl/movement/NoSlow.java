/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.impl.movement;

import fun.bloody.events.item.UsingItemEvent;
import fun.bloody.events.player.TickEvent;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.setting.Setting;
import fun.bloody.utils.client.Instance;
import fun.bloody.utils.client.managers.event.EventHandler;

public class NoSlow
extends Module {
    public static int ticks = 0;

    public static NoSlow getInstance() {
        return Instance.get(NoSlow.class);
    }

    public NoSlow() {
        super("NoSlow (ban)", "No Slow (ban)", ModuleCategory.MOVEMENT);
        this.setup(new Setting[0]);
    }

    @EventHandler
    public void onTick(TickEvent event) {
        if (NoSlow.mc.field_1724 == null || NoSlow.mc.field_1724.method_6128()) {
            return;
        }
        ticks = NoSlow.mc.field_1724.method_6115() ? ++ticks : 0;
    }

    @EventHandler
    public void onUsingItem(UsingItemEvent e) {
        if (NoSlow.mc.field_1724 == null || NoSlow.mc.field_1724.method_6128()) {
            return;
        }
        if (e.getType() != 1) {
            return;
        }
        if (ticks >= 2) {
            e.cancel();
            ticks = 0;
        }
    }
}

