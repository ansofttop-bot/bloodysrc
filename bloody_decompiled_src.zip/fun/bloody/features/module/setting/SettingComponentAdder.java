/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.module.setting;

import fun.bloody.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.BindComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.CheckboxComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.ColorComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.GroupComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.SButtonComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.SliderComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.TextComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.multiselect.MultiSelectComponent;
import fun.bloody.display.screens.clickgui.components.implement.settings.select.SelectComponent;
import fun.bloody.features.module.setting.Setting;
import fun.bloody.features.module.setting.implement.BindSetting;
import fun.bloody.features.module.setting.implement.BooleanSetting;
import fun.bloody.features.module.setting.implement.ButtonSetting;
import fun.bloody.features.module.setting.implement.ColorSetting;
import fun.bloody.features.module.setting.implement.GroupSetting;
import fun.bloody.features.module.setting.implement.MultiSelectSetting;
import fun.bloody.features.module.setting.implement.SelectSetting;
import fun.bloody.features.module.setting.implement.SliderSettings;
import fun.bloody.features.module.setting.implement.TextSetting;
import java.util.List;

public class SettingComponentAdder {
    public void addSettingComponent(List<Setting> settings, List<AbstractSettingComponent> components) {
        settings.forEach(setting -> {
            if (setting instanceof BooleanSetting) {
                BooleanSetting booleanSetting = (BooleanSetting)setting;
                components.add(new CheckboxComponent(booleanSetting));
            }
            if (setting instanceof BindSetting) {
                BindSetting bindSetting = (BindSetting)setting;
                components.add(new BindComponent(bindSetting));
            }
            if (setting instanceof ColorSetting) {
                ColorSetting colorSetting = (ColorSetting)setting;
                components.add(new ColorComponent(colorSetting));
            }
            if (setting instanceof TextSetting) {
                TextSetting textSetting = (TextSetting)setting;
                components.add(new TextComponent(textSetting));
            }
            if (setting instanceof SliderSettings) {
                SliderSettings valueSetting = (SliderSettings)setting;
                components.add(new SliderComponent(valueSetting));
            }
            if (setting instanceof GroupSetting) {
                GroupSetting groupSetting = (GroupSetting)setting;
                components.add(new GroupComponent(groupSetting));
            }
            if (setting instanceof ButtonSetting) {
                ButtonSetting buttonSetting = (ButtonSetting)setting;
                components.add(new SButtonComponent(buttonSetting));
            }
            if (setting instanceof SelectSetting) {
                SelectSetting selectSetting = (SelectSetting)setting;
                components.add(new SelectComponent(selectSetting));
            }
            if (setting instanceof MultiSelectSetting) {
                MultiSelectSetting multiSelectSetting = (MultiSelectSetting)setting;
                components.add(new MultiSelectComponent(multiSelectSetting));
            }
        });
    }
}

