/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
package fun.bloody.features.module.setting;

import com.google.common.collect.Lists;
import fun.bloody.features.module.setting.Setting;
import fun.bloody.utils.client.interfaces.Setupable;
import java.util.Arrays;
import java.util.List;

public class SettingRepository
implements Setupable {
    private final List<Setting> settings = Lists.newArrayList();

    @Override
    public final void setup(Setting ... setting) {
        this.settings.addAll(Arrays.asList(setting));
    }

    public Setting get(String name) {
        return this.settings.stream().filter(setting -> setting.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public List<Setting> settings() {
        return this.settings;
    }
}

