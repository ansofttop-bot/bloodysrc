/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.module;

public enum ModuleCategory {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    RENDER("Render"),
    PLAYER("Player"),
    MISC("Misc"),
    CONFIGS("Configs"),
    AUTOBUY("AutoBuy");

    final String readableName;

    private ModuleCategory(String readableName) {
        this.readableName = readableName;
    }

    public String getReadableName() {
        return this.readableName;
    }
}

