/*
 * Decompiled with CFR 0.152.
 */
package fun.bloody.features.module;

import fun.bloody.features.impl.combat.AimAssist;
import fun.bloody.features.impl.combat.AntiBot;
import fun.bloody.features.impl.combat.Aura;
import fun.bloody.features.impl.combat.AutoArmor;
import fun.bloody.features.impl.combat.AutoSwap;
import fun.bloody.features.impl.combat.AutoTotem;
import fun.bloody.features.impl.combat.NoFriendDamage;
import fun.bloody.features.impl.combat.NoInteract;
import fun.bloody.features.impl.combat.ProjectileHelper;
import fun.bloody.features.impl.combat.ShiftTap;
import fun.bloody.features.impl.combat.TargetPearl;
import fun.bloody.features.impl.combat.TriggerBot;
import fun.bloody.features.impl.misc.AutoLeave;
import fun.bloody.features.impl.misc.AutoTpAccept;
import fun.bloody.features.impl.misc.AutoWarden;
import fun.bloody.features.impl.misc.ChestStealer;
import fun.bloody.features.impl.misc.ClickFriend;
import fun.bloody.features.impl.misc.ClickPearl;
import fun.bloody.features.impl.misc.ClientSound;
import fun.bloody.features.impl.misc.ElytraHelper;
import fun.bloody.features.impl.misc.FreeCam;
import fun.bloody.features.impl.misc.FuntimeAssist;
import fun.bloody.features.impl.misc.HollyworldAssist;
import fun.bloody.features.impl.misc.JoinerHelper;
import fun.bloody.features.impl.misc.ReallyworldAssist;
import fun.bloody.features.impl.misc.TabParser;
import fun.bloody.features.impl.misc.Unhook;
import fun.bloody.features.impl.misc.WardenHelper;
import fun.bloody.features.impl.movement.AutoSprint;
import fun.bloody.features.impl.movement.InventoryMove;
import fun.bloody.features.impl.movement.NoSlow;
import fun.bloody.features.impl.movement.NoWeb;
import fun.bloody.features.impl.player.AntiAFK;
import fun.bloody.features.impl.player.AutoPilot;
import fun.bloody.features.impl.player.FastBreak;
import fun.bloody.features.impl.player.FreeLook;
import fun.bloody.features.impl.player.ItemScroller;
import fun.bloody.features.impl.player.NameProtect;
import fun.bloody.features.impl.player.NoDelay;
import fun.bloody.features.impl.player.NoEntityTrace;
import fun.bloody.features.impl.player.NoPush;
import fun.bloody.features.impl.render.Ambience;
import fun.bloody.features.impl.render.Arrows;
import fun.bloody.features.impl.render.AspectRatio;
import fun.bloody.features.impl.render.AuctionHelper;
import fun.bloody.features.impl.render.BetterMinecraft;
import fun.bloody.features.impl.render.BlockESP;
import fun.bloody.features.impl.render.BlockOverlay;
import fun.bloody.features.impl.render.CameraSettings;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.impl.render.CrossHair;
import fun.bloody.features.impl.render.CustomHUD;
import fun.bloody.features.impl.render.Esp;
import fun.bloody.features.impl.render.FullBright;
import fun.bloody.features.impl.render.HitColor;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.features.impl.render.ItemPhysic;
import fun.bloody.features.impl.render.JumpCircle;
import fun.bloody.features.impl.render.KillEffect;
import fun.bloody.features.impl.render.NoRender;
import fun.bloody.features.impl.render.ProjectilePrediction;
import fun.bloody.features.impl.render.SeeInvisible;
import fun.bloody.features.impl.render.SwingAnimation;
import fun.bloody.features.impl.render.TargetESP;
import fun.bloody.features.impl.render.ViewModel;
import fun.bloody.features.impl.render.WavePlayer;
import fun.bloody.features.impl.render.WorldParticles;
import fun.bloody.features.impl.render.WorldTweaks;
import fun.bloody.features.module.Module;
import java.util.ArrayList;
import java.util.List;

public class ModuleRepository {
    private final List<Module> modules = new ArrayList<Module>();

    public void setup() {
        this.register(new ClickGui(), new CustomHUD(), new AntiAFK(), new JumpCircle(), new BetterMinecraft(), new ProjectileHelper(), new AutoPilot(), new NoEntityTrace(), new ShiftTap(), new AspectRatio(), new FreeLook(), new AutoWarden(), new WavePlayer(), new FullBright(), new WardenHelper(), new ItemPhysic(), new HitColor(), new FuntimeAssist(), new HollyworldAssist(), new ReallyworldAssist(), new ClickPearl(), new ClickFriend(), new TabParser(), new Ambience(), new TargetESP(), new NoWeb(), new ItemScroller(), new Hud(), new AuctionHelper(), new ProjectilePrediction(), new WorldParticles(), new TriggerBot(), new Aura(), new AutoSwap(), new NoFriendDamage(), new AntiBot(), new AutoSprint(), new NoPush(), new ElytraHelper(), new JoinerHelper(), new NoDelay(), new AimAssist(), new NoSlow(), new InventoryMove(), new FastBreak(), new CameraSettings(), new SwingAnimation(), new ViewModel(), new BlockOverlay(), new Esp(), new BlockESP(), new AutoTotem(), new FreeCam(), new ChestStealer(), new AutoTpAccept(), new Arrows(), new AutoLeave(), new WorldTweaks(), new NoRender(), new NameProtect(), new Unhook(), new ClientSound(), new SeeInvisible(), new TargetPearl(), new AutoArmor(), new NoInteract(), new CrossHair(), new KillEffect());
    }

    public void register(Module ... module) {
        this.modules.addAll(List.of(module));
    }

    public List<Module> modules() {
        return this.modules;
    }
}

