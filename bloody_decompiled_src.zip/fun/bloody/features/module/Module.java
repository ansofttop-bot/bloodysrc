/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_310
 */
package fun.bloody.features.module;

import fun.bloody.Bloody;
import fun.bloody.common.animation.Animation;
import fun.bloody.common.animation.Direction;
import fun.bloody.common.animation.implement.Decelerate;
import fun.bloody.display.hud.Notifications;
import fun.bloody.features.impl.misc.ClientSound;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.impl.render.Hud;
import fun.bloody.features.module.ModuleCategory;
import fun.bloody.features.module.ModuleRepository;
import fun.bloody.features.module.setting.SettingRepository;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.client.sound.SoundManager;
import fun.bloody.utils.display.interfaces.QuickImports;
import net.minecraft.class_124;
import net.minecraft.class_310;

public class Module
extends SettingRepository
implements QuickImports {
    private final String name;
    private final String visibleName;
    private final ModuleCategory category;
    private final Animation animation = new Decelerate().setMs(175).setValue(1.0);
    private int key = -1;
    private int type = 1;
    public boolean state;

    public Module(String name, ModuleCategory category) {
        this.name = name;
        this.category = category;
        this.visibleName = name;
    }

    public Module(String name, String visibleName, ModuleCategory category) {
        this.name = name;
        this.visibleName = visibleName;
        this.category = category;
    }

    public void switchState() {
        this.setState(!this.state);
    }

    public void setState(boolean state) {
        this.animation.setDirection(state ? Direction.FORWARDS : Direction.BACKWARDS);
        if (state != this.state) {
            this.state = state;
            this.handleStateChange();
        }
    }

    private void handleStateChange() {
        class_310 mc = class_310.method_1551();
        float volume = Hud.getInstance().getModuleVolume();
        if (mc.field_1724 != null && mc.field_1687 != null) {
            if (this.state) {
                if (Hud.getInstance().notificationSettings.isSelected("Module Switch")) {
                    Notifications.getInstance().addList("Feature " + String.valueOf(class_124.field_1080) + this.visibleName + String.valueOf(class_124.field_1070) + " - enabled!", 2000L, null);
                    if (!(this instanceof ClickGui) && this.shouldPlaySound()) {
                        SoundManager.playSound(SoundManager.ENABLE_MODULE, volume, 1.0f);
                    }
                }
                this.activate();
            } else {
                if (Hud.getInstance().notificationSettings.isSelected("Module Switch")) {
                    Notifications.getInstance().addList("Feature " + String.valueOf(class_124.field_1080) + this.visibleName + String.valueOf(class_124.field_1070) + " - disabled!", 2000L, null);
                    if (!(this instanceof ClickGui) && this.shouldPlaySound()) {
                        SoundManager.playSound(SoundManager.DISABLE_MODULE, volume, 1.0f);
                    }
                }
                this.deactivate();
            }
        }
        this.toggleSilent(this.state);
    }

    private boolean shouldPlaySound() {
        try {
            if (this instanceof ClientSound) {
                return true;
            }
            ModuleRepository repository = Bloody.getInstance().getModuleRepository();
            if (repository == null) {
                return true;
            }
            for (Module module : repository.modules()) {
                if (!(module instanceof ClientSound)) continue;
                return module.isState();
            }
            return true;
        }
        catch (Exception e) {
            return true;
        }
    }

    private void toggleSilent(boolean activate) {
        EventManager eventManager = Bloody.getInstance().getEventManager();
        if (activate) {
            eventManager.register(this);
        } else {
            eventManager.unregister(this);
        }
    }

    public void activate() {
    }

    public void deactivate() {
    }

    public String getName() {
        return this.name;
    }

    public String getVisibleName() {
        return this.visibleName;
    }

    public ModuleCategory getCategory() {
        return this.category;
    }

    public Animation getAnimation() {
        return this.animation;
    }

    public int getKey() {
        return this.key;
    }

    public int getType() {
        return this.type;
    }

    public boolean isState() {
        return this.state;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public void setType(int type) {
        this.type = type;
    }
}

