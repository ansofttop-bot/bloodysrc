/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 */
package fun.bloody.features.module;

import fun.bloody.common.logger.implement.ConsoleLogger;
import fun.bloody.events.keyboard.KeyEvent;
import fun.bloody.features.impl.misc.SelfDestruct;
import fun.bloody.features.impl.misc.Unhook;
import fun.bloody.features.impl.render.ClickGui;
import fun.bloody.features.module.Module;
import fun.bloody.features.module.exception.ModuleException;
import fun.bloody.utils.client.managers.event.EventHandler;
import fun.bloody.utils.client.managers.event.EventManager;
import fun.bloody.utils.display.interfaces.QuickImports;
import fun.bloody.utils.display.interfaces.QuickLogger;
import java.util.List;
import net.minecraft.class_124;

public class ModuleSwitcher
implements QuickLogger,
QuickImports {
    private final List<Module> modules;

    public ModuleSwitcher(List<Module> modules, EventManager eventManager) {
        this.modules = modules;
        eventManager.register(this);
    }

    @EventHandler
    public void onKey(KeyEvent event) {
        if (SelfDestruct.unhooked || Unhook.unhooked) {
            return;
        }
        for (Module module : this.modules) {
            if (module instanceof ClickGui || module.getKey() == -1 || event.key() != module.getKey() || ModuleSwitcher.mc.field_1755 != null) continue;
            try {
                this.handleModuleState(module, event.action());
            }
            catch (Exception e) {
                this.handleException(module.getName(), e);
            }
        }
    }

    private void handleModuleState(Module module, int action) {
        if (module.getType() == 1 && action == 1) {
            module.switchState();
        }
    }

    private void handleException(String moduleName, Exception e) {
        ConsoleLogger consoleLogger = new ConsoleLogger();
        if (e instanceof ModuleException) {
            this.logDirect("[" + moduleName + "] " + String.valueOf(class_124.field_1061) + e.getMessage());
        } else {
            consoleLogger.log("Error in module " + moduleName + ": " + e.getMessage());
        }
    }
}

